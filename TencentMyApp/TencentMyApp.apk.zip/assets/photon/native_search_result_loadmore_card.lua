local mPhotonView, mJavaBridge = ...

local mStatus = "LOAD"
local mListener

function onConnect()
    if(mStatus == "NO_NETWORK") then
        showLoadMoreTip()
    end
end

function init( ... )
    if(mJavaBridge:isNetworkActive() == false) then
        showNoNetworkTip()
    else
        showLoadMoreTip()
    end
end

function loadMore(  )
    if(mJavaBridge:isNetworkActive()) then
        local param = {}
        param["key"] = "LoadMore"
        Rapid:execAction("outeraction", param, param)
        showLoading()
    else
        showNoNetworkTip()
    end
end

function onLoadResult(  )
    local result = Rapid:getData("loadSuccess")
    if(result == false) then
        showFail()
    end
end

function showLoadMoreTip( ... )
    Rapid:getChild("loading"):getView():setVisibility(8)
    Rapid:getChild("tipBlue"):getView():setVisibility(0)
    Rapid:getChild("tipGray"):getView():setVisibility(8)
    Rapid:getChild("tipBlue"):setData("tipBlue", "点击显示更多")
    setStatus("LOAD")
end

function showLoading( ... )
    Rapid:getChild("loading"):getView():setVisibility(0)
    Rapid:getChild("tipBlue"):getView():setVisibility(8)
    Rapid:getChild("tipGray"):getView():setVisibility(8)
    setStatus("LOADING")
end

function showNoNetworkTip( ... )
    Rapid:getChild("loading"):getView():setVisibility(8)
    Rapid:getChild("tipBlue"):getView():setVisibility(0)
    Rapid:getChild("tipGray"):getView():setVisibility(0)
    Rapid:getChild("tipGray"):setData("tipGray", "你的手机暂无网络")
    Rapid:getChild("tipBlue"):setData("tipBlue", "去开启网络")
    setStatus("NO_NETWORK")
end

function showFail( ... )
    Rapid:getChild("loading"):getView():setVisibility(8)
    Rapid:getChild("tipBlue"):getView():setVisibility(0)
    Rapid:getChild("tipGray"):getView():setVisibility(0)
    Rapid:getChild("tipGray"):setData("tipGray", "网络出了点问题，请重新加载")
    Rapid:getChild("tipBlue"):setData("tipBlue", "重新加载")
    setStatus("LOAD_FAIL")
end

function clickTip( )
    if(mStatus == "NO_NETWORK") then
        mJavaBridge:goToNetworkSetting()
    elseif (mStatus == "LOAD" or mStatus == "LOAD_FAIL") then
        loadMore()
        report(211)
    end
end

function setStatus( status )
    mStatus = status
end

function report( action )
    local data = {}
    data["param"] = "scene:data@scene,sourcescene:data@sourceScene,modeltype:data@modelType,actionid:"..action..",slotid:data@slotId,extradata:data@queryWord,searchid:data@searchId"
    data["extendparam"] = "searchquery:data@queryWord,sourcequery:data@sourceQuery,tagname:data@tagName,search_session:data@searchsession"
    data["recommendid"] = "data@R1"
    data["reportelement"] = "card"
    Rapid:execAction("reportaction", data, data)
end