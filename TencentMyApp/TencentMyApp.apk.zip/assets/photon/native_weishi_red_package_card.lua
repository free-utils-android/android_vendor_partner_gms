local mPhotonView, mJavaBridge = ...

local WEI_SHI_PACKAGE_NAME = "com.tencent.weishi"
local FOUND_TAB_NETWORK_NAME = "found_tab_activity"

local packageChangeListener

-- 包安装/卸载监听接口
PackageChangeListener = {}
function PackageChangeListener.onPackageInstalled(packageName)
    if (packageName == WEI_SHI_PACKAGE_NAME) then
        mJavaBridge:refreshNetworkData(FOUND_TAB_NETWORK_NAME)
    end
end

function PackageChangeListener.onPackageUninstalled(packageName)
end

function init()
    mJavaBridge:Log("weishicard", "start add package listener")
    packageChangeListener = luajava.createProxy('com.tencent.assistant.event.PackageChangeListenerManager$PackageChangeListener', PackageChangeListener)
    mJavaBridge:addPackageChangeListener(packageChangeListener)
    mJavaBridge:Log("weishicard", "end add package listener")
end