local mPhotonView,mJavaBridge = ...


local _scene = nil
local _sourcescene = nil
local _modeltype = nil
local _sourceslotid = nil
local _slotid = nil


local mRecyclerView


function main()
    mRecyclerView = Rapid:getChild('rv_hot_word'):getView()
end

PhotonActionListener = {}
function PhotonActionListener.notify(key, value)
    if (key == "UpdateSourceQuery") then
        local params = {}
        params["key"] = "UpdateSourceQuery"
        Rapid:execAction("outeraction", params)
    end
end

function updateData()
    _scene = Rapid:getData("scene")
    _sourcescene = Rapid:getData("sourcescene")
    _modeltype = Rapid:getData("modeltype")
    _sourceslotid = Rapid:getData("sourcesceneslotid")
    local position = tonumber(Rapid:getData('position', '0')) + 1
    _slotid = '04_00' .. tostring(position)
    Rapid:setData('slotid', _slotid)
    Rapid:setData('slotId', _slotid)
    
    updateWordList()
end

-- 更新列表
function updateWordList()
    local dataList = {}
    local viewNameList = {}

    local itemCount = tonumber(Rapid:getData('tab_count','0'))

    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        fillData(itemData, i, itemCount)
        dataList[i] = itemData
        viewNameList[i] = 'popular_search_list_item_card.xml'
    end
    
    local recyclerActionListener =
        luajava.createProxy('com.tencent.rapidview.deobfuscated.IPhotonActionListener', PhotonActionListener)
    mRecyclerView:setActionListener(recyclerActionListener)
    mRecyclerView:updateData(viewNameList, dataList, true)
end

-- 填充数据
function fillData(itemData, index, itemCount)
    if itemData == nil then
        return
    end

    putBaseReportText(itemData)
    itemData:put("subPosition", mJavaBridge:create("Var", index))
    
    -- 卡片间距
    if index == 1 then
        itemData:put("marginLeft", mJavaBridge:create("Var", '16'))
    else
        itemData:put("marginLeft", mJavaBridge:create("Var", '0'))
    end

    if index == itemCount then
        itemData:put("marginRight", mJavaBridge:create("Var", '16'))
    else
        itemData:put("marginRight", mJavaBridge:create("Var", '12'))
    end

    -- 单条词卡和多条词卡
    if itemCount == 1 then
        -- 卡片宽度
        local cardRatio = (360 - 16 - 16) / 360 * 100
        itemData:put("item_width", mJavaBridge:create("Var", cardRatio .. '%x'))
        -- 最大文字宽度，最后减10是避免有的手机出现图片展示不全的情况
        local textRatio = (360 - 16 - 16 - 12 - 12 - 26 - 10) / 360 * 100
        itemData:put("textMaxWidth", mJavaBridge:create("Var", textRatio .. '%x'))
    else
        itemData:put("item_width", mJavaBridge:create("Var", '57.77%x'))
        itemData:put("textMaxWidth", mJavaBridge:create("Var", '41.11%x'))
    end

    local itemChildCount = itemData:get('item_count')
    if itemChildCount == nil or itemChildCount == '' then
        return
    end

    itemChildCount = itemData:get('item_count'):getString()
    for i = 1, tonumber(itemChildCount) do
        local itemChildData = itemData:get("item_data_"..i):getObject()
        local searchWord = itemChildData:get("search_word")        
        local tmast = itemChildData:get("tmast")
        local emojiUrl = itemChildData:get("emoji_url")
        local hotWordRecommendid = itemChildData:get("hot_word_recommendid")
        local hotWordReportContext = itemChildData:get("hot_word_report_context")

        itemData:put("search_word_" .. i, searchWord)
        itemData:put("tmast_" .. i, tmast)
        itemData:put("emoji_url_" .. i, emojiUrl)
        itemData:put("hot_word_recommendid_"..i , hotWordRecommendid)
        itemData:put("hot_word_report_context_"..i , hotWordReportContext)
    end
end

-- 存入基础上报字段
function putBaseReportText(itemData)
    if _scene ~= nil then
        local var_scene = mJavaBridge:create("Var", _scene)
        itemData:put("scene",var_scene)
    end
    
    if _sourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create("Var", _sourcescene)
        itemData:put("sourcescene",var_sourcescene)
        itemData:put("sourceScene",var_sourcescene)
    end
    
    if _modeltype ~= nil then
        local var_modeltype = mJavaBridge:create("Var", _modeltype)
        itemData:put("modeltype",var_modeltype)
        itemData:put("modelType",var_modeltype)
    end
    
    if _sourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create("Var", _sourceslotid)
        itemData:put("sourcesceneslotid",var_sourceslotid)
        itemData:put("sourceSceneSlotId",var_sourceslotid)
    end
    
    if _slotid ~= nil then
        local var_slotid = mJavaBridge:create("Var", _slotid)
        itemData:put("slotid",var_slotid)
        itemData:put("slotId",var_slotid)
    end
end