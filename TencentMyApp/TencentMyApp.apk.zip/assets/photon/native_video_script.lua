local mPhotonView,javaBridge = ...

function init()
	local sw = javaBridge:getScreenWidth()-javaBridge:dip2px(36)
	local w = sw/2
	local card0=mPhotonView:getParser():getChildView("card_0")
	if (card0 ~= nil and card0:getView() ~= nil)
	then
		local layoutPara = card0:getView():getLayoutParams()
		layoutPara.height=w/9*16
	end
	local card1=mPhotonView:getParser():getChildView("card_1")

	if (card1 ~= nil and card1:getView() ~= nil)
	then
		local layoutPara = card1:getView():getLayoutParams()
		layoutPara.height=w/9*16
	end
	local binder=mPhotonView:getParser():getBinder();
	local sourcescene = binder:get("sourcescene")
	local pos = binder:get("pos")
	local data ={}
	data["param"]="scene:20010104,actionid:100,slotid:20_"..tostring(pos*2-1)..",sourcescene:"..tostring(sourcescene)
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
	data["param"]="scene:20010104,actionid:100,slotid:20_"..tostring(pos*2)..",sourcescene:"..tostring(sourcescene)
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
	if (pos -1 ==0)
	then
		card0:getView():setPadding(0,javaBridge:dip2px(18),javaBridge:dip2px(6),0)
		card1:getView():setPadding(javaBridge:dip2px(6),javaBridge:dip2px(18),0,0)
		javaBridge:Log("lua_tim","test")
	end
end

function clickFirst()
	local binder=mPhotonView:getParser():getBinder();
	local sourcescene = binder:get("sourcescene")
	local pos = binder:get("pos")
	local data ={}
	data["param"]="scene:20010104,actionid:200,slotid:20_"..tostring(pos*2-1)..",sourcescene:"..tostring(sourcescene)
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
end

function clickSecond()
	local binder=mPhotonView:getParser():getBinder();
	local sourcescene = binder:get("sourcescene")
	local pos = binder:get("pos")
	local data ={}
	data["param"]="scene:20010104,actionid:200,slotid:20_"..tostring(pos*2)..",sourcescene:"..tostring(sourcescene)
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
end
