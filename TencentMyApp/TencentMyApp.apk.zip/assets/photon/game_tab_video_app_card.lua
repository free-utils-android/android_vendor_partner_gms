local mPhotonView,mJavaBridge = ...
-- view --
local mReleaseTimeView
local mStageLabelView
-- 常量 --
local TAG = "gametab_video_app_card_lua"
-- 全局变量 --
local mAppOnline
local mGameJumpUrl
local mShowLabelNewStyle = "0"
local IPlayerStateChangeListener = {}

function loadFinish()
    mReleaseTimeView = Rapid:getChild("app_first_release_time")
    mStageLabelView  = Rapid:getChild("app_stage_label")
end

function init()
    initMute()
end

function afterUpdateData()
    print("loadNewLabelCard!")
    beforeCardLoad()
    addVideoListener()
    initOperatingLabel()
    initGameDescribeLabel()
    initButton()
    dynamicLayout()
end

-- 初始化通用信息
function beforeCardLoad()
    mAppOnline = Rapid:getData("app_online")
    mGameJumpUrl = Rapid:getData("cloud_game_jump_url")

    -- 上线时间展示
    local appFirstReleaseTime = Rapid:getData("app_first_release_time")
    if appFirstReleaseTime == nil or appFirstReleaseTime == "" then
        mReleaseTimeView:setAttr("visibility", "gone")
    else
        mReleaseTimeView:setAttr("visibility", "visible")
    end

    -- 游戏状态展示
    local appStageLabel = Rapid:getData("app_stage_label")
    if appStageLabel == nil or appStageLabel == "" then
        mStageLabelView:setAttr("visibility", "gone")
    else
        mStageLabelView:setAttr("visibility", "visible")
    end

    -- 按钮不展示
    Rapid:getChild("layout_button"):setAttr("visibility", "gone")

    -- 云游戏展示初始化 云游未上线则云游条不显示
    local cloudGameLyout = Rapid:getChild("layout_cloud_game")
    if mGameJumpUrl == nil or mGameJumpUrl == "" then
        cloudGameLyout:setAttr("visibility", "gone")
    else
        cloudGameLyout:setAttr("visibility", "visible")
    end

    --运营标签新老样式开关
    mShowLabelNewStyle = tostring(Rapid:getData("show_label_new_style"))
    print("showLabelNewStyle="..mShowLabelNewStyle)

    --构建拼接了recommendid的详情页tmast跳转链接
    buildVideoJumpUrlWithRid()
end

function buildVideoJumpUrlWithRid()
    local recommendId = Rapid:getData("app_recommendid")
    local ridBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendId), "default")
    local videoJumpUrl = Rapid:getData("video_jump_url")
    local newVideoJumpUrl = videoJumpUrl.."&recommendid="..mJavaBridge:urlEncode(ridBase64)
    Rapid:setData("new_video_jump_url", newVideoJumpUrl);
end

local mStateChangeListener
function addVideoListener()
    videoView = mPhotonView:getParser():getChildView("video_view")

    if videoView == nil then
        return
    end

    if mStateChangeListener ~= nil then
        return
    end

    mStateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IPlayerStateChangeListener)
    videoView:getView():registerIPlayerStateChangeListener(mStateChangeListener)
end

-- 初始化运营标签
function initOperatingLabel()
    local operatingLabelsLayout = Rapid:getChild("operating_labels")
    local operatingLabelNum
    if mShowLabelNewStyle == "0" then
        operatingLabelNum = tonumber(Rapid:getData("operating_label_num"))
    else
        operatingLabelNum = tonumber(Rapid:getData("operating_label_num_new_style"))
    end

    print("initOperatingLabel label num="..tostring(operatingLabelNum))
    if operatingLabelNum <= 0 then
        operatingLabelsLayout:setAttr("visibility", "gone")
        return
    end

    operatingLabelsLayout:setAttr("visibility", "visible")

    for i = 1, 3 do
       if i <= operatingLabelNum then
           Rapid:getChild("operating_label_"..i):setAttr("visibility", "visible")
           showOperatingLabel(i)
       else
           Rapid:getChild("operating_label_"..i):setAttr("visibility", "gone")
       end
    end   
end

-- 初始化卡片状态
function showOperatingLabel(i)
    --图标
    local labelIcon
    if mShowLabelNewStyle == "0" then
         labelIcon = tostring(Rapid:getData("operating_label_data_"..i.."_icon"))
    else
         labelIcon = tostring(Rapid:getData("operating_label_data_"..i.."_icon_new_style"))
    end

    if labelIcon == nil or labelIcon == "" or labelIcon == "_default_value_" then
         Rapid:getChild("operating_label_icon_"..i):setAttr("visibility", "gone")
    else
         Rapid:getChild("operating_label_icon_"..i):setAttr("visibility", "visible")
         Rapid:getChild("operating_label_icon_"..i):setAttr("url", labelIcon)
         if i == 1 then
            Rapid:getChild("operating_labels"):getParser():update("marginleft", "14")
         end
    end

    --文本
    local labelTitle = ""
    local labelColor = ""
    if mShowLabelNewStyle == "0" then
        labelTitle = tostring(Rapid:getData("operating_label_data_"..i.."_title"))
        labelColor = tostring(Rapid:getData("operating_label_data_"..i.."_color"))
    else
        labelTitle = tostring(Rapid:getData("operating_label_data_"..i.."_title_new_style"))
        labelColor = tostring(Rapid:getData("operating_label_data_"..i.."_color_new_style"))
    end
    
    if labelTitle == nil or labelTitle == "" or labelTitle == "_default_value_" then
        Rapid:getChild("operating_label_title_"..i):setAttr("visibility", "gone")
    else
        Rapid:getChild("operating_label_title_"..i):setAttr("visibility", "visible")
        Rapid:getChild("operating_label_title_"..i):setAttr("text", labelTitle)
        Rapid:getChild("operating_label_title_"..i):setAttr("textcolor", labelColor)
    end
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    if(mute) then
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart(...)
    Rapid:getChild("mute_img"):setAttr("visibility","visible")
    initMute()
end

function IPlayerStateChangeListener.onPlayContinue(...)
    Rapid:getChild("mute_img"):setAttr("visibility","visible")
    initMute()
end

-- 视频播放进度回调
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    if (videoView == nil) then
        return
    end
    Rapid:setData("videoCurProgress", tostring(progress))
end

-- 视频暂停播放回调
function IPlayerStateChangeListener.onPlayPause(...)
    Rapid:getChild("mute_img"):setAttr("visibility","gone")
end

-- 视频停止播放回调
function IPlayerStateChangeListener.onPlayStop()
    Rapid:getChild("mute_img"):setAttr("visibility","gone")
end

-- 视频完成播放回调
function IPlayerStateChangeListener.onPlayComplete()
    Rapid:getChild("mute_img"):setAttr("visibility","gone")
    if videoView ~= nil then
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
end

-- 初始化类型标签
function initGameDescribeLabel()
    Rapid:getChild("app_label_txt"):setAttr("visibility", "gone")
    Rapid:getChild("app_label_1"):setAttr("visibility", "gone")
    Rapid:getChild("app_label_2"):setAttr("visibility", "gone")
    Rapid:getChild("app_label_3"):setAttr("visibility", "gone")

    local appEditorIntro = tostring(Rapid:getData("app_editor_intro"))
    if appEditorIntro ~= nil and appEditorIntro ~= "" and appEditorIntro ~= "_default_value_" then
        Rapid:getChild("app_label_txt"):setAttr("visibility", "visible")
        Rapid:getChild("app_label_txt"):setAttr("text", appEditorIntro)
        return
    end

    local appLabel = Rapid:getData("app_label")
    print("initTypeLabel applabel="..appLabel)
    if appLabel ~= nil and appLabel ~= "" then
        local splitStrTable = splitStr(appLabel)
        if splitStrTable ~= nil then
            for i, v in ipairs(splitStrTable) do
                -- 目前最多显示3个
                if i > 3 then
                    return
                end
                print("initTypeLabel text="..tostring(v))
                Rapid:getChild("app_label_"..i):setAttr("visibility", "visible")
                Rapid:getChild("app_label_"..i):setAttr("text", tostring(v))
            end
        end
    end
end

-- 分割字符串，“1|2|3|”
function splitStr(str)
    if (str == nil or str == "") then
        return {}
    end

    local lastStart = 1
    local singleStr = nil
    local index = 1
    local res = {}
    for k = 1, string.len(str) do
        if string.sub(str, k, k) == '|' then
            if (lastStart < k) then
                singleStr = string.sub(str, lastStart, k - 1)
                res[index] = singleStr
                index = index + 1
            end
            lastStart = k + 1
        end
    end
    -- 不以 | 结尾，需要把最后的 type 计算进来
    if (lastStart <= string.len(str)) then
        singleStr = string.sub(str, lastStart, string.len(str))
        res[index] = singleStr
        index = index + 1
    end
    return res
end

-- 初始化预约/下载按钮
function initButton()
    Rapid:getChild("layout_button"):setAttr("visibility", "visible")
    local downloadButton = Rapid:getChild("download_button")
    local bookingButton = Rapid:getChild("booking_button")

    if mAppOnline == nil or mAppOnline == "" then
        downloadButton:setAttr("visibility", "gone")
        bookingButton:setAttr("visibility", "gone")
        return
    end

    if mAppOnline == "true" then
        print("initButton show download")
        downloadButton:setAttr("visibility", "visible")
        bookingButton:setAttr("visibility", "gone")
        return
    end

    downloadButton:setAttr("visibility", "gone")
    bookingButton:setAttr("visibility", "visible")
end

--根据有无运营标签进行动态布局
function dynamicLayout()
    local operatingLabelNum
    if mShowLabelNewStyle == "0" then
        operatingLabelNum = tonumber(Rapid:getData("operating_label_num"))
    else
        operatingLabelNum = tonumber(Rapid:getData("operating_label_num_new_style"))
    end
    if operatingLabelNum == 0 then
        Rapid:getChild("app"):setAttr("padding", "0,10,0,15")
        Rapid:getChild("layout_button"):getParser():update("margintop", "10")
    else    
        Rapid:getChild("app"):setAttr("padding", "0,9,0,13")
        Rapid:getChild("layout_button"):getParser():update("margintop", "28")
    end
end

-- 设置静音
function setMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    if isMute then
        videoView:getView():setMuteToGlobal(false, true, true)
    else
        videoView:getView():setMuteToGlobal(true, true, true)
    end
    updateMuteImage(isMute)
end

-- 初始化静音按钮
function initMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    updateMuteImage(isMute)
end

-- 更新静音图标显示
function updateMuteImage(isMute)
    if isMute then
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end

-- 云游按钮曝光上报
function reportGameButtonExposure(highLight)
    -- action
    local cmd = 100
    local element = "button"
    local context = "data@card_report_context"
    local index = -1
    local extraStr = "uni_is_highlighted:" .. tostring(highLight)
    local actionStr = string.format("actionid:%s", cmd)
    local subPosStr = string.format("subposition:%s", index)
    local element = string.format("report_element:%s", element)
    local actionReportContext = "report_context:" .. context
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid," .. subPosStr .. "," .. actionStr ..
            ",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid"
    reportParams["recommendid"] = "data@card_recommendid"
    reportParams["extendparam"] = element .. ",sourcereportcontext:data@source_report_context," .. actionReportContext .. "," .. extraStr

    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function print(args)
    Rapid:Log(TAG, args)
end