local mPhotonView,javaBridge = ...

function init()
	javaBridge:Log("timluo_lua","test")
	local sw = javaBridge:getScreenWidth()-javaBridge:dip2px(36)
	local w = sw/2
	local iamge0=mPhotonView:getParser():getChildView("image_0")
	local h = w  
	-- w*3/4
	if (iamge0 ~= nil and iamge0:getView() ~= nil)
	then
		local layoutPara = iamge0:getView():getLayoutParams()
		layoutPara.height=h
	end
	local iamge1=mPhotonView:getParser():getChildView("image_1")
	if (iamge1 ~= nil and iamge1:getView() ~= nil)
	then
		local layoutPara = iamge1:getView():getLayoutParams()
		layoutPara.height=h
	end

	local binder=mPhotonView:getParser():getBinder();
	local sourcescene = binder:get("sourcescene")
	local pos = binder:get("pos")
	local data ={}
	data["param"]="scene:30219,actionid:100,slotid:03_"..tostring(pos*2-1)..",sourcescene:"..tostring(sourcescene)
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
	
	local card1=mPhotonView:getParser():getChildView("card_1")

	if (binder:get("image_1") ~=  nil and string.len(binder:get("image_1"))>0 and card1 ~= nil)
    then			
		card1:getParser():update("visibility", "visible")
		data["param"]="scene:30219,actionid:100,slotid:03_"..tostring(pos*2)..",sourcescene:"..tostring(sourcescene)
	    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
	else
		card1:getParser():update("visibility", "invisible")
		javaBridge:Log("lua_sara","hide video card")
	end

	local play0=mPhotonView:getParser():getChildView("play0")
	local play1=mPhotonView:getParser():getChildView("play1")

	local isInstall = javaBridge:isPkgInstalled("com.tencent.weishi")
	local lock0 = binder:get("lock_0")
	local appInstall = binder:get("app_install")
	if (appInstall ~= nil) then
		isInstall = appInstall
		javaBridge:Log("sara","appInstall "..appInstall)
	end
	if (lock0 == "1" and isInstall == 0) then
		iamge0:getView():setBlur(true)
		play0:getParser():update("visibility", "invisible")
		javaBridge:Log("sara","iamge0  setBlur  true")
	else
		iamge0:getView():setBlur(false)	
		play0:getParser():update("visibility", "visible")
		javaBridge:Log("sara","iamge0  setBlur  false")
	end
	iamge0:getParser():update("url","http://yyb.gtimg.com/img_disp/app_big_image/weishi_video_count.png")
	iamge0:getParser():update("url",binder:get("image_0"))

	local lock1 = binder:get("lock_1")
	if (lock1 == "1" and isInstall == 0) then
		iamge1:getView():setBlur(true)
		play1:getParser():update("visibility", "invisible")
		javaBridge:Log("sara","iamge1  setBlur  true")
	else
		iamge1:getView():setBlur(false)
		play1:getParser():update("visibility", "visible")
		javaBridge:Log("sara","iamge1  setBlur  false")
	end
	iamge1:getParser():update("url","http://yyb.gtimg.com/img_disp/app_big_image/weishi_video_count.png")
	iamge1:getParser():update("url",binder:get("image_1"))
end

function clickFirst()
	local binder=mPhotonView:getParser():getBinder();
	local sourcescene = binder:get("sourcescene")
	local pos = binder:get("pos")
	local data ={}
	data["param"]="scene:30219,actionid:200,slotid:03_"..tostring(pos*2-1)..",sourcescene:"..tostring(sourcescene)
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)

	local lock0 = binder:get("lock_0")
	local isInstall = javaBridge:isPkgInstalled("com.tencent.weishi")
	javaBridge:Log("sara","install  check  "..isInstall)
	-- if (lock0 == "1" and isInstall == 0 ) then
	-- 	local dialogData = {}
	-- 	dialogData["style"]="doublebutton"
	-- 	dialogData["title"]="提示"
	-- 	dialogData["content"]="若想观看该视频，请先下载微视"
	-- 	dialogData["leftbuttontext"]="取消"
	-- 	dialogData["rightbuttontext"]="确定"
	-- 	dialogData["leftbuttonclick"]=""
	-- 	dialogData["rightbuttonclick"]="dialog_aciton"
	-- 	mPhotonView:getParser():getTaskCenter():getActionRunner():run("dialogaction",dialogData,dialogData)

	-- 	data["param"]="scene:30219,actionid:100,slotid:04_001"..",sourcescene:"..tostring(sourcescene)
	--     mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
	-- else 
		local tmastData = {}
		tmastData["tmast"]=mPhotonView:getParser():getBinder():get("action_url_0")
		mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction",tmastData,tmastData)
	-- end
	
end

function clickSecond()
	local binder=mPhotonView:getParser():getBinder();
	local sourcescene = binder:get("sourcescene")
	local pos = binder:get("pos")
	local data ={}
	data["param"]="scene:30219,actionid:200,slotid:03_"..tostring(pos*2)..",sourcescene:"..tostring(sourcescene)
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)

	local lock1 = binder:get("lock_1")
	local isInstall = javaBridge:isPkgInstalled("com.tencent.weishi")
	-- if (lock1 == "1" and isInstall == 0) then
	-- 	local dialogData = {}
	-- 	dialogData["style"]="doublebutton"
	-- 	dialogData["title"]="提示"
	-- 	dialogData["content"]="若想观看该视频，请先下载微视"
	-- 	dialogData["leftbuttontext"]="取消"
	-- 	dialogData["rightbuttontext"]="确定"
	-- 	dialogData["leftbuttonclick"]=""
	-- 	dialogData["rightbuttonclick"]="dialog_aciton"
	-- 	mPhotonView:getParser():getTaskCenter():getActionRunner():run("dialogaction",dialogData,dialogData)

	-- 	data["param"]="scene:30219,actionid:100,slotid:04_001"..",sourcescene:"..tostring(sourcescene)
	--     mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
	-- else 
		local tmastData = {}
		tmastData["tmast"]=mPhotonView:getParser():getBinder():get("action_url_1")
		mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction",tmastData,tmastData)
	-- end
end
