local mPhotonView, mJavaBridge = ...

local TAG = "lua_game_tab_v2_lead_card"
local statusSelect

function viewShow()
    sendRequest()
end

function afterUpdateData()
    statusSelect = true
    updateSelect()
end

function updateSelect()
    if statusSelect then
        Rapid:getChild('select'):setAttr('url', 'https://cms.myapp.com/yyb/2022/04/08/1649407386693_c66217301b4625d8b71076c6cfa38ef9.png')
        Rapid:setData('uni_guidecard_check_status', '1')
    else
        Rapid:getChild('select'):setAttr('url', 'https://cms.myapp.com/yyb/2022/04/08/1649407386650_9c3e5ffc5b029e8b2ad10bbf021b3085.png')
        Rapid:setData('uni_guidecard_check_status', '2')
    end
end

function select()
    statusSelect = not statusSelect
    updateSelect()
end

function jump()
    mJavaBridge:setNormalSettingsData("home_game_tab_lead_card_switch", Rapid:getData('uni_guidecard_check_status', '1'))
    mJavaBridge:Log(TAG, string.format("home_game_tab_lead_card_switch: %s", tostring(mJavaBridge:getNormalSettingsData('home_game_tab_lead_card_switch', '0'))))
end

function sendRequest()
    mJavaBridge:request(3001, {}, onRequestListener)
end

function onRequestListener(succeed)
    mJavaBridge:Log(TAG, "onRequestListener"..string.format(" succeed: %s", tostring(succeed)))
end