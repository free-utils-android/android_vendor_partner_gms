local mPhotonView,mJavaBridge = ...

local container = nil
local alreadySplice = false
local pagCard = nil
local pagButton = nil
local videoView = nil
local gameWhiteCard = nil
local IPlayerStateChangeListener = {}
local stateChangeListener 
local needHideCardPag = false

local IRapidPagAnimationListener = {}
local pagAnimationListener
local alreadyReport = false

local OnClickDetectListener = {}
local onClickDetectListener

local UI_EVENT_VIEW_SCROLL_IDLE = 1317

local LOG_TAG = "HRM"

function main( ... )
    local container = Rapid:getChild("container"):getView()
    pagCard = Rapid:getChild("pag_card"):getView()
    pagButton = Rapid:getChild("pag_button"):getView()

    videoView = Rapid:getChild("video_view"):getView()
    videoView:hideReplayView()
    stateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IPlayerStateChangeListener)
    videoView:registerIPlayerStateChangeListener(stateChangeListener)

    -- 位置检测监听,用于滑动停止
    mJavaBridge:callModuleWithParams("Pag", "addViewOnScreenYCenterListener",{videoView, 240 , onScreenListener})

    pagAnimationListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.pag.IRapidPagAnimationListener", IRapidPagAnimationListener)
    pagCard:registerIRapidPagAnimationListener(pagAnimationListener)
    pagButton:registerIRapidPagAnimationListener(pagAnimationListener)

    gameWhiteCard = Rapid:getChild("game_white_card"):getView()
    local runnable = luajava.createProxy("java.lang.Runnable", Runnable)
    gameWhiteCard:post(runnable)

    local clickDetectView = Rapid:getChild("click_detect"):getView()
    onClickDetectListener = luajava.createProxy("com.tencent.assistant.component.deobfuscated.OnClickDetectListener", OnClickDetectListener)
    clickDetectView:setOnClickListener(onClickDetectListener)

    local uiListener = luajava.createProxy("com.tencent.assistant.event.listener.UIEventListener", UIEventListener)
    mJavaBridge:addUIEventListener(UI_EVENT_VIEW_SCROLL_IDLE, uiListener)
end

UIEventListener = {}
function UIEventListener.handleUIEvent(message)
    if message.what == UI_EVENT_VIEW_SCROLL_IDLE then
        checkVideoCanPlay()
    end
end

function updateData( ... )
    initButton()

    updateLabel()

    spliceCloudTmast()

    fillFullCreenCardData()

    updatePag(false)

    updateGame()

    Rapid:getChild("mute_img"):setAttr("visibility", "gone")

    onResume()
end

function exposeImageGroup()
    local index = Rapid:getData("index")
    local exposedKey = "exposed_image_"..index
    local exposed = RapidList:getItemData(index, exposedKey)
    if exposed ~= nil then
        return
    end
    RapidList:updateItemData(index, exposedKey, "exposed")

    exposeImage("pag_card", "卡片")
    exposeImage("pag_button", "按钮")
end

-- 特效曝光
function exposeImage(viewid, animeType)
    local reportParams = {}
    reportParams["viewid"] = viewid
    reportParams["dteventkey"] = "imp"
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:image,source_report_context:data@source_report_context,report_context:data@image_report_context,uni_effect_level:S,uni_only_cloudgame_check_status:data@is_only_show_free_play,uni_anime_type:"..animeType
    reportParams["recommendid"] = "data@app_recommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function updateGame()
    local gameScoreIsShow = Rapid:getData("game_score_is_show", "0")
    if tostring(gameScoreIsShow) == "1" then
        Rapid:setData("visible_game_score", "visible")
    else
        Rapid:setData("visible_game_score", "gone")
        Rapid:setData("game_types_margin_left", "16")
    end
end

-- 超出尺寸，隐藏卡片Pag
Runnable = {}
function Runnable.run(...)
    local maxWidth = mJavaBridge:dip2px(388)
    if ( gameWhiteCard:getWidth() > maxWidth ) then
        pagCard:setVisibility(8)
        needHideCardPag = true
    end
end

-- 如果当前时下载或者更新状态才显示 Pag
function needShowButtonPag( ... )
    local gameStatus = Rapid:getData("game_status")
    if gameStatus == "0" then
        return mJavaBridge:callModuleWithParams("Download", "isDownloadOrUpdate",{button})
    else
        return true
    end
end

function registerPagGroup( ... )
    mJavaBridge:callModuleWithParams("Pag", "registerPagComponent",{"game_tab_v2_feed_s_card", pagCard})
    mJavaBridge:callModuleWithParams("Pag", "registerPagComponent",{"game_tab_v2_feed_s_card", pagButton})
end

function spliceCloudTmast( ... )
    if alreadySplice then
        return
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", Rapid:getData("app_recommendid","")), "default")
    local jumpUrl = Rapid:getData("cloud_game_jump_url","")
    if rcdBase64 ~= nil and rcdBase64 ~= "" and jumpUrl ~= nil then
        alreadySplice = true
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
        Rapid:setData("cloud_game_jump_url", jumpUrl)
    end
end

function updateLabel( ... )
    if Rapid:getData("game_label") == nil or Rapid:getData("game_label") == "" then
        mJavaBridge:Log("updateLabel"," null ")
        setViewGone("game_label_icon")
        setViewGone("game_label")
        setViewVisible("game_rec")
    else
        mJavaBridge:Log("updateLabel"," not  null ")
        setViewVisible("game_label_icon")
        setViewVisible("game_label")
        setViewGone("game_rec")
    end
end

function setViewVisible( viewid )
    Rapid:getChild(viewid):setAttr("visibility","visible")
    Rapid:getChild(viewid):getView():setVisibility(0)
end

function setViewGone( viewid )
    Rapid:getChild(viewid):setAttr("visibility","gone")
    Rapid:getChild(viewid):getView():setVisibility(8)
end

function initButton( ... )
    local gameStatus = Rapid:getData("game_status")
    mJavaBridge:Log("game_tab_v2_feed_s_card","gameStatus "..gameStatus)
    setViewGone("download_button")
    setViewGone("booking_button")
    setViewGone("cloud_play_button")
    if gameStatus == "0" then
        mJavaBridge:Log("game_tab_v2_feed_s_card","下载按钮")
        button = Rapid:getChild("download_button"):getView()
        setViewVisible("download_button")
    elseif gameStatus == "1" then
        mJavaBridge:Log("game_tab_v2_feed_s_card","预约按钮")
        button = Rapid:getChild("booking_button"):getView()
        setViewVisible("booking_button")
    elseif gameStatus == "2" then
        mJavaBridge:Log("game_tab_v2_feed_s_card","云玩按钮")
        button = Rapid:getChild("cloud_play_button"):getView()
        setViewVisible("cloud_play_button")
    end

    updateButtonAttr()
end

function updateButtonAttr( ... )
    updateColor("background_color", "22222e")
    updateColor("text_color", "ffffff")
    updateColor("button_color", "40ffffff")
    updateColor("button_final", "3f3f54")
    Rapid:setData("score_text_color", "cc"..Rapid:getData("text_color"))
    Rapid:setData("after_btn_bg_color", Rapid:getData("button_final","3f3f54"))
    if Rapid:getData("shading_url","") ~= "" then
        Rapid:setData("after_btn_bg_color", "33ffffff")
    end
    local isLight = Rapid:getData("light_or_deep_color","1")
    if isLight == "1" then
        Rapid:setData("before_btn_text_color", "ffffff")
        Rapid:setData("before_btn_stroke_color", "40ffffff")
    elseif isLight == "0" then
        Rapid:setData("before_btn_text_color", Rapid:getData("text_color","ffffff"))
        Rapid:setData("before_btn_stroke_color", Rapid:getData("button_color","40ffffff"))
    end
end

function updateColor( params, defaultColor )
    if Rapid:getData(params,"") == "" then
        Rapid:setData(params, defaultColor)
    end
end

function onScreenListener( ... )
    if videoView:isPlaying() then
        return
    end
    mJavaBridge:delayRun(1500, delayPlayVideo)
    updatePag(true)
    mJavaBridge:Log(LOG_TAG,"is center")
    showFullScreenCard()
end

function delayPlayVideo( ... )
    if videoView:isPlaying() then
        return
    end
    if videoView:getCanNotSeeAreaRatio() > 0.1 then
        videoEnd()
        return
    end
    videoView:startPlay(false)
end

function fillFullCreenCardData( ... )
    local param = {}
    param["key"] = "fill_target_position_data"
    param["value"] = Rapid:getData("position")
    Rapid:execAction("outeraction", param, param)
end

function showFullScreenCard( ... )
    if not needShowButtonPag() then
        return
    end
    controlFullScreenCard("true")
end

function controlFullScreenCard( needVisible )
    local param = {}
    param["key"] = "full_screen_photon_view_visible"
    param["value"] = needVisible
    Rapid:execAction("outeraction", param, param)
end

-- 隐藏 Pag，包含此张卡上的「卡片」「按钮」两个Pag，以及 fullCard 上的 「全屏」Pag
function hidePag( ... )
    updatePag(false)
    controlFullScreenCard("false")
end

-- resume时主动判断是否居中
function onResume( ... )
    if videoView:isPlaying() then
        return
    end
    local isCenter = mJavaBridge:callModuleWithParams("Pag", "isViewAtScreenVerticalCenter",{mPhotonView:getView(), 240})
    if isCenter then
        mJavaBridge:delayRun(1500, delayPlayVideo)
        updatePag(true)
    end
end

function onPause()
    hidePag()
    videoView:stop(false)
end

function updatePag(isStart)
    if not needShowButtonPag() then
        isStart = false
    end
    if isStart then
        if not needHideCardPag then
            pagCard:setVisibility(0)
            pagCard:startPlay(true)
        end
        pagButton:setVisibility(0)
        pagButton:startPlay(true)
    else
        pagCard:setVisibility(8)
        pagButton:setVisibility(8)
        pagCard:stop()
        pagButton:stop()
    end
end

function initMute()
    if videoView == nil then
        return
    end

    setMuteImage(videoView:isMute())
end

function switchMute()
    mJavaBridge:Log(LOG_TAG, "click mute")
    if videoView == nil then
        return
    end
    local isMute = not videoView:isMute()

    videoView:setMuteToGlobal(isMute, true, true)
    setMuteImage(isMute)
end

function setMuteImage(isMute)
    if isMute then
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2022/04/29/1651225684664_9e768df2e274b4986d17999ea7294b0c.png")
    else
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2022/04/29/1651225688728_db4ec6100775c4b352a2f43bce59c11a.png")
    end
end

function videoEnd( ... )
    hidePag()
    if button ~= nil then
        button:applyLinearStyle()
    end
    Rapid:getChild("mute_img"):setAttr("visibility", "gone")
end

function checkVideoCanPlay( ... )
    if videoView == nil then
        return
    end
    if not videoView:isPlaying() then
        return
    end
    if videoView:getCanNotSeeAreaRatio() > 0.1 then
        videoView:stop(false)
        videoEnd()
    end
end

-- 点击拦截
function OnClickDetectListener.onClick()
    if videoView ~= nil then
        videoView:performClick()
    end
end

function IRapidPagAnimationListener.onAnimationStart( component )
    mJavaBridge:Log(LOG_TAG,"onAnimationStart")
    if button ~= nil then
        button:applyLinearStyle()
    end
    exposeImageGroup()
    if videoView:isPlaying() or videoView:getCanNotSeeAreaRatio() > 0.05 then
        return
    end
    videoView:seekTo(0)
    videoView:startPlay(true)
end

function IRapidPagAnimationListener.onAnimationEnd( component )
    mJavaBridge:Log(LOG_TAG,"onAnimationEnd")
    component:setVisibility(8)
    if button ~= nil then
        button:applyFacetStyle()
    end
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    setMuteImage(mute)
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart(videoView)
    mJavaBridge:Log(LOG_TAG,"onPlayStart")
    Rapid:getChild("mute_img"):setAttr("visibility", "visible")
    initMute()
    updatePag(true)
    showFullScreenCard()
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayContinue(videoView)
    mJavaBridge:Log(LOG_TAG,"onPlayContinue")
    Rapid:getChild("mute_img"):setAttr("visibility", "visible")
    initMute()
    updatePag(true)
    showFullScreenCard()
end

-- 视频播放进度回调
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    mJavaBridge:Log(LOG_TAG,"onProgressUpdate  "..progress)
    checkVideoCanPlay()
end

-- 视频暂停播放回调
function IPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    mJavaBridge:Log(LOG_TAG,"onPlayPause")
    videoEnd()
end

-- 视频停止播放回调
function IPlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    videoEnd()
end

-- 视频完成播放回调
function IPlayerStateChangeListener.onPlayComplete(videoView)
    mJavaBridge:Log(LOG_TAG,"onPlayComplete")

    videoEnd()
end

-- 播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    videoEnd()
end
