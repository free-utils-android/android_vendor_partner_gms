local mRapidView, mJavaBridge = ...

local TAG = "timeline_item"
local mCallbackObj
local mButtonClicked = false  -- 点击预约组件位置和item其它位置处理不一样，进行区分
local DEBUG = false

local TITLE_FONT_SIZE = 10
local MAX_TITLE_SIZE_WITH_ICON = 52
local MAX_TITLE_SIZE_NO_ICON = 64
local LAYOUT_WRAP_CONTENT = -2
local TITLE_HEIGHT = mJavaBridge:dip2px(15)
local SCALE_BIG = "scale_big"
local mCurIndex = 0

function main()
    logForDebug(TAG, "main enter")
end

function clickTag()
    local index = mRapidView:getParser():getBinder():get("index")
    mCurIndex = index

    mCallbackObj = Rapid:getData("callback")

    logForDebug(TAG, "click index==" .. tostring(index) .. " mButtonClicked:" .. tostring(mButtonClicked))
    mCallbackObj.onClickTag(index, mButtonClicked)
end

function onRefreshScale()
    local index = mRapidView:getParser():getBinder():get("index")
    mCallbackObj = Rapid:getData("callback")
    mCallbackObj.onRefresh(index)
end

function clickButton()
    local index = mRapidView:getParser():getBinder():get("index")
    logForDebug(TAG, "clickButton index==" .. tostring(index))
    mButtonClicked = true
    clickTag()
    mButtonClicked = false
end

-- 初始化预约/下载按钮，更多新游界面是没有显示
-- 注意：在滑动的时候也需要处理，不然会因为item复用导致显示成其他item的属性
function initButton()
    local appOnline = mRapidView:getParser():getBinder():get("booking")
    local index = mRapidView:getParser():getBinder():get("index")
    logForDebug(TAG, "initButton:" .. tostring(appOnline) .. " index==" .. tostring(index))

    local buttonContainer = Rapid:getChild("id_button")
    local viewDownloadButton = Rapid:getChild("download_button")
    local viewBookingButton = Rapid:getChild("booking_button")

    -- 更多新游
    if appOnline == nil or appOnline == "" then
        buttonContainer:setAttr("visibility", "gone")
        viewDownloadButton:setAttr("visibility", "gone")
        viewDownloadButton:setAttr("visibility", "gone")
        return
    end

    buttonContainer:setAttr("visibility", "visible")

    -- 显示预约
    if appOnline == "true" then
        viewDownloadButton:setAttr("visibility", "gone")
        viewBookingButton:setAttr("visibility", "visible")
        return
    end
    -- 显示下载
    viewDownloadButton:setAttr("visibility", "visible")
    viewBookingButton:setAttr("visibility", "gone")
end

-- 获取layout的宽度
-- 在有hot图片和没有的时候，显示的字数是不一样的，使用maxEms会是的显示的时候字体
-- 在部分机型的时候被切割，动态计算layout宽度，动态设置宽度能够解决这个问题
function getTextWidth(text, textsize)
    local mTextPaint = luajava.newInstance('android.text.TextPaint')
    Layout = luajava.bindClass('android.text.Layout')
    mTextPaint:setTextSize(textsize)
    local textWidth = Layout:getDesiredWidth(text, mTextPaint)
    logForDebug(TAG, "getTextWidth text:" .. text .. ",width:" .. textWidth)
    return textWidth
end

function initTitle()
    local index = mRapidView:getParser():getBinder():get("index")
    local appOnline = mRapidView:getParser():getBinder():get("booking")
    local titleContainer = Rapid:getChild("id_title_container")
    if appOnline == nil or appOnline == "" then
        titleContainer:setAttr("visibility", "gone")
        return
    end
    titleContainer:setAttr("visibility", "visible")

    local titleText = mRapidView:getParser():getBinder():get("title")
    local textWidth = getTextWidth(titleText, TITLE_FONT_SIZE)
    logForDebug(TAG, "item initTitle gone:" .. " index==" .. tostring(index) .. " textWidth:" .. tostring(textWidth))

    local title = Rapid:getChild("id_title")
    local hoturl = Rapid:getChild("icon_image")
    local showHotUrl = mRapidView:getParser():getBinder():get("hot_url")

    local params = title:getView():getLayoutParams()
    params.height = TITLE_HEIGHT

    if showHotUrl == nil or showHotUrl == "" then
        hoturl:setAttr("visibility", "gone")
        -- 使用最大宽度
        params.width = mJavaBridge:dip2px(MAX_TITLE_SIZE_NO_ICON)
    else
        hoturl:setAttr("visibility", "visible")

        if textWidth < MAX_TITLE_SIZE_WITH_ICON then
            params.width = LAYOUT_WRAP_CONTENT
        else
            -- 在有hot图片的时候最多显示52个dp
            params.width = mJavaBridge:dip2px(MAX_TITLE_SIZE_WITH_ICON)
        end
    end
    title:getView():setLayoutParams(params)
end

-- 初始化item相关，宽度和不是统一的，所以需要在load时候进行处理
function afterFillValue()
    local index = mRapidView:getParser():getBinder():get("index")
    local scale = mRapidView:getParser():getBinder():get("scale_big")
    local containerImageView = Rapid:getChild("adapter_container")
    local containerTimelineView = Rapid:getChild("id_timeline_desc")
    local containerTitleView = Rapid:getChild("id_title_container")
    local containerButtonView = Rapid:getChild("id_button")


    if containerImageView == nil or containerTimelineView == nil or containerTitleView == nil or
            containerButtonView == nil then
        logForDebug(TAG, "failed selectValue , index = " .. tostring(index) ..
            " scale:" .. tostring(scale))
        return
    end

    logForDebug(TAG, "afterFillValue , mCurIndex=" .. tostring(mCurIndex) ..
        " index = " .. tostring(index) .. " scale:" .. tostring(scale))
    
    containerImageView:getView():setScaleX(1.0)
    containerImageView:getView():setScaleY(1.0)
    containerTimelineView:getView():setScaleX(1.0)
    containerTimelineView:getView():setScaleY(1.0)
    containerTimelineView:getView():setAlpha(0.65)
    containerTitleView:getView():setAlpha(0.45)

    initTitle()
    initButton()

    onRefreshScale()
end

function hideUpdateAppIcon()
    logForDebug(TAG, "hideUpdateAppIcon " .. tostring(Rapid:getData("index")))
end

function logForDebug(logTag, logMsg)
    if not DEBUG then
        return
    end
    mJavaBridge:Log(TAG .. "::" .. logTag, logMsg)
end
