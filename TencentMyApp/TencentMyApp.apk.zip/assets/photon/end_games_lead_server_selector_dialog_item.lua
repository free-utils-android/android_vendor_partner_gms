local mRapidView,mJavaBridge = ...
local mUpdater

function main()
    mUpdater = mRapidView:getParser():getBinder():get("updater")
end

function click()
    local index = mRapidView:getParser():getBinder():get("index")
    local itemName = mRapidView:getParser():getBinder():get("item_name")
    mUpdater:selectItem(index,itemName)
    mRapidView:getParser():getBinder():update("is_selected","true")
    mRapidView:getParser():getBinder():update("textcolor","0080FF")
end