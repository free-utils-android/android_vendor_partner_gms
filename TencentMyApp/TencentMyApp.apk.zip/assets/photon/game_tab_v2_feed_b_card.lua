local mPhotonView, mJavaBridge = ...


local videoView
local button

local needSetBtnFacetStyle = true

local stateChangeListener
IPlayerStateChangeListener = {}
function IPlayerStateChangeListener.onMute(videoview, mute)
    updateMuteIcon(mute)
end

function updateMuteIcon(mute)
    if mute then
        Rapid:getChild('iv_mute'):setAttr("url", "https://cms.myapp.com/yyb/2022/04/29/1651225684664_9e768df2e274b4986d17999ea7294b0c.png")
    else
        Rapid:getChild('iv_mute'):setAttr("url", "https://cms.myapp.com/yyb/2022/04/29/1651225688728_db4ec6100775c4b352a2f43bce59c11a.png")
    end
end

-- 设置静音
function setMute()
    if isMute() then
        videoView:setMuteToGlobal(false, true, true)
    else
        videoView:setMuteToGlobal(true, true, true)
    end
    updateMuteIcon(isMute)
end

function isMute()
    return videoView:isMute()
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart(videoView)
    Rapid:getChild("rl_mute"):setAttr("visibility","visible")
    updateMuteIcon(isMute())
    needSetBtnFacetStyle = true
end

function IPlayerStateChangeListener.onPlayContinue(videoView, currentPosition)
    Rapid:getChild("rl_mute"):setAttr("visibility","visible")
    updateMuteIcon(isMute())
end

-- 视频播放进度回调
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    local secTime = tonumber(tostring(progress)) / 1000
    Rapid:setData("videoCurProgress", tostring(progress))
    if needSetBtnFacetStyle and secTime >= 10 then
        buttonApplyFacetStyle()
        needSetBtnFacetStyle = false
    end
end

-- 视频暂停播放回调
function IPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    videoEnd()
end

-- 视频停止播放回调
function IPlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    videoEnd()
end

-- 视频完成播放回调
function IPlayerStateChangeListener.onPlayComplete(videoView)
    videoEnd()
    if videoView ~= nil then
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
end

-- 视频播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    videoEnd()
end

function main()
    videoView = Rapid:getChild("video_view"):getView()
    stateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IPlayerStateChangeListener)
    videoView:registerIPlayerStateChangeListener(stateChangeListener)
end

function videoEnd()
    Rapid:getChild("rl_mute"):setAttr("visibility","gone")
    buttonApplyLinearStyle()
end

function buttonApplyFacetStyle()
    if button ~= nil then
        button:applyFacetStyle()
    end
end

function buttonApplyLinearStyle()
    if button ~= nil then
        button:applyLinearStyle()
    end
end

function afterUpdateData()
    updateCloudPlayUrl()
    initButton()
    showVideoOrImg()
    updateWhiteBar()
end

function updateWhiteBar()
    local screenWidth = mJavaBridge:px2dip(mPhotonView:getParser():getScreenWidth())
    local screenHeight = mJavaBridge:px2dip(mPhotonView:getParser():getScreenHeight())
    if screenWidth > screenHeight then
        -- 全屏后getScreenWidth接口可能会取反为屏幕高，所以对换一下
        screenWidth = screenHeight
    end
    local marginTop = 210 / 360 * screenWidth
    Rapid:setData('whiteBarMarginTop', tostring(marginTop))
end

function updateCloudPlayUrl()
    local recommendid = Rapid:getData('app_recommendid')
    local jumpUrl = Rapid:getData('cloud_game_jump_url', '')
    if jumpUrl == '' then
        return
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendid), "default")
    if rcdBase64 ~= nil and rcdBase64 ~= "" then
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
    end
    Rapid:setData('cloud_game_jump_url', jumpUrl)
end

function showVideoOrImg()
    local vid = Rapid:getData('vid', '')
    if vid == '' then
        Rapid:getChild('video_view'):setAttr('visibility', 'gone')
        Rapid:getChild('rl_mute'):setAttr('visibility', 'gone')
        Rapid:getChild('iv_cover'):setAttr('visibility', 'visible')
    else
        Rapid:getChild('video_view'):setAttr('visibility', 'visible')
        Rapid:getChild('rl_mute'):setAttr('visibility', 'visible')
        Rapid:getChild('iv_cover'):setAttr('visibility', 'gone')
    end
end

function initButton()
    Rapid:getChild('download_button'):setAttr('visibility', 'gone')
    Rapid:getChild('booking_button'):setAttr('visibility', 'gone')
    Rapid:getChild('cloud_play_button'):setAttr('visibility', 'gone')
    local gameStatus = Rapid:getData("game_status")
    if gameStatus == "0" then
        button = Rapid:getChild("download_button"):getView()
    elseif gameStatus == "1" then
        button = Rapid:getChild("booking_button"):getView()
    elseif gameStatus == "2" then
        button = Rapid:getChild("cloud_play_button"):getView()
    else
        return
    end
    updateButtonAttr()
    button:setVisibility(0)
    buttonApplyLinearStyle()
end

function updateButtonAttr()
    updateColor("background_color", "22222e")
    updateColor("text_color", "ffffff")
    updateColor("button_color", "40ffffff")
    updateColor("button_final", "3f3f54")
    Rapid:setData("score_text_color", "cc"..Rapid:getData("text_color"))
    Rapid:setData("desc_text_color", "cc"..Rapid:getData("text_color"))
    Rapid:setData("after_btn_bg_color", Rapid:getData("button_final","3f3f54"))

    local isLight = Rapid:getData("light_or_deep_color","1")
    if isLight == "1" then
        Rapid:setData("before_btn_text_color", "ffffff")
        Rapid:setData("before_btn_stroke_color", "40ffffff")
    elseif isLight == "0" then
        Rapid:setData("before_btn_text_color", Rapid:getData("text_color","ffffff"))
        Rapid:setData("before_btn_stroke_color", Rapid:getData("button_color","40ffffff"))
    end
end

function updateColor(params, defaultColor)
    if Rapid:getData(params,"") == "" then
        Rapid:setData(params, defaultColor)
    end
end