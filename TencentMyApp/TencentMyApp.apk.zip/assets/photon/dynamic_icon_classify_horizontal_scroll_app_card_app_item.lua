local mPhotonView, mJavaBridge = ...


local mRunnable

local mDownloadAnimSet
local mIconAnimSet = nil

-- icon缩放动画全周期内只需要播放一次，标记用于记录（按钮抖动无此限制
local mHasRunIconScaleAnim = false

function main()
    mRunnable = luajava.createProxy('java.lang.Runnable', Runnable)
    mHasRunIconScaleAnim = false

    local itemRl = Rapid:getChild('rl_item'):getView()
    itemRl:setClipChildren(false)
    itemRl:setClipToPadding(false)

    mIconAnimSet = luajava.newInstance('android.animation.AnimatorSet')
    mBounceInterpolator = luajava.newInstance('android.view.animation.BounceInterpolator')
end

-- 首位icon所属的layout放大
function runLayoutScaleExpandAnim()
    local view = Rapid:getChild('rl_anim'):getView()
    pcall(removeCallbacks,view)

    if mHasRunIconScaleAnim then
        runShakeAnim()
        return
    end
    startIconAnimation()
    mHasRunIconScaleAnim = true
end

function startIconAnimation()
    local destAnimLayout = Rapid:getChild('rl_app_icon'):getView()
    destAnimLayout:clearAnimation()

    -- 这里不能敷用，否则会导致icon动画无法播放
    mIconAnimSet = luajava.newInstance('android.animation.AnimatorSet')
    local bounceInterpolator = luajava.newInstance('android.view.animation.BounceInterpolator')

    local listener = luajava.createProxy('android.animation.Animator$AnimatorListener', LayoutScaleAnimationListener)

   
    local ObjectAnimator = luajava.bindClass("android.animation.ObjectAnimator")

    local layoutScaleXAnim = ObjectAnimator:ofFloat(destAnimLayout, 'scaleX', createScaleAnimParam())
    local layoutScaleYAnim = ObjectAnimator:ofFloat(destAnimLayout, 'scaleY', createScaleAnimParam())

    local objParams = {}
    objParams[1] = layoutScaleXAnim
    objParams[2] = layoutScaleYAnim

    mIconAnimSet:setInterpolator(bounceInterpolator)
    mIconAnimSet:playTogether(objParams)
    mIconAnimSet:setDuration(500)
    mIconAnimSet:addListener(listener)
    mIconAnimSet:start()
end

-- 首位icon所属的layout放大监听
LayoutScaleAnimationListener = {}
function LayoutScaleAnimationListener.onAnimationStart(animator)

end

function LayoutScaleAnimationListener.onAnimationEnd(animator)
    Rapid:Log("realhe","onAnimationEnd onAnimationEnd")
    runShakeAnim()

end

function LayoutScaleAnimationListener.onAnimationCancel(animator)
    
end

function LayoutScaleAnimationListener.onAnimationRepeat(animator)
    
end

-- 下载预约按钮抖动
function runShakeAnim()

    local downloadbutton = Rapid:getChild('rl_anim'):getView()
    downloadbutton:clearAnimation()

    if  mDownloadAnimSet == nil then
        mDownloadAnimSet = createButtonAnimation(downloadbutton)
    end
    Rapid:Log("realhe","runShakeAnim")

    mDownloadAnimSet:start()
end

function createButtonAnimation( downloadbutton)
    Rapid:Log("realhe","createButtonAnimation")
    local downloadAnimSet = luajava.newInstance('android.animation.AnimatorSet')
    local ObjectAnimator = luajava.bindClass("android.animation.ObjectAnimator")
    local listener = luajava.createProxy('android.animation.Animator$AnimatorListener', DownloadAnimationListener)

    

    local objScaleXAnim = ObjectAnimator:ofFloat(downloadbutton, 'scaleX', createScaleAnimParam())
    objScaleXAnim:setDuration(200)
    local objScaleYAnim = ObjectAnimator:ofFloat(downloadbutton, 'scaleY', createScaleAnimParam())
    objScaleYAnim:setDuration(200)
    local objDouAnim = ObjectAnimator:ofFloat(downloadbutton, 'rotation', createShakeAnimParam())
    objDouAnim:setDuration(600)

    local objParams = {}
    objParams[1] = objScaleXAnim
    objParams[2] = objDouAnim
    objParams[3] = objScaleYAnim

    downloadAnimSet:playTogether(objParams)
    downloadAnimSet:addListener(listener)
    return downloadAnimSet
end

-- 下载按钮抖动监听
DownloadAnimationListener = {}
function DownloadAnimationListener.onAnimationStart(animator)

end

function DownloadAnimationListener.onAnimationEnd(animator)
    startDownloadButtonAnimation()
end

function DownloadAnimationListener.onAnimationCancel(animator)
    
end

function DownloadAnimationListener.onAnimationRepeat(animator)
    
end

function startDownloadButtonAnimation()
    local view = Rapid:getChild('rl_anim'):getView()
    pcall(removeCallbacks,view) -- 移除Callback，避免crash
    view:postDelayed(mRunnable, 3000)
end

function removeCallbacks(view)
    view:removeCallbacks(mRunnable)
end

-- 下载预约按钮循环抖动
Runnable = {}
function Runnable.run()
    runShakeAnim()
end

-- 创建缩放动画的参数
function createScaleAnimParam()
    local params = {}
    params[1] = 1.25
    params[2] = 1.0
    return params
end

-- 创建抖动动画的参数
function createShakeAnimParam()
    local params = {}
    params[1] = 0.0
    params[2] = 5.0
    params[3] = -5.0
    params[4] = 5.0
    params[5] = -5.0
    params[6] = 5.0
    params[7] = -5.0
    params[8] = 5.0
    params[9] = -5.0
    params[10] = 5.0
    params[11] = -5.0
    params[12] = 5.0
    params[13] = -5.0
    params[14] = 0.0
    return params
end

