local mPhotonView,mJavaBridge = ...
local stepNum = 10000
RubbishScanCallBack = {}
function RubbishScanCallBack.updateScanData(selectedSize,selectedSizeFormat,selectedSizeUnit,totalSize,progress,selectedColor,unSelectedColor)

    --mPhotonView:getParser():getChildView("stopButton"):getView():setText("停止扫描")
    --扫描中文案
    local button_scanning_text = mPhotonView:getParser():getBinder():get("button_scanning_text")
    if button_scanning_text~=nil then
        mPhotonView:getParser():getChildView("detailbutton"):getView():setText(tostring(button_scanning_text).."..("..tostring(progress).."%)")
    else
        mPhotonView:getParser():getChildView("detailbutton"):getView():setText("正在扫描..("..tostring(progress).."%)")
    end
    --扫描中文案

    --全屏背景色
    local Color = luajava.bindClass('android.graphics.Color')
    mPhotonView:getParser():getChildView("rootView"):getView():setBackgroundColor(Color:parseColor(selectedColor))
    mPhotonView:getParser():getChildView("rubbishsize"):getView():setText(selectedSize)
    mPhotonView:getParser():getChildView("rubbishsize_unit"):getView():setText(selectedSizeUnit)
    mPhotonView:getParser():getChildView("rubbishsize_unit_half"):getView():setText(selectedSizeUnit)

    --mPhotonView:getParser():getChildView("rubbishsize"):getView():invalidate()

end

function RubbishScanCallBack.doScanFinish(selectedSize,selectedSizeFormat,selectedSizeUnit,totalSize,selectedColor,unSelectedColor)

    mJavaBridge:Log("onPartionResult","doScanFinish selectedSize wqeqweqe="..tostring(selectedSize))
    mJavaBridge:Log("onPartionResult","doScanFinish totalSize wqeqeqe="..tostring(totalSize))
    mPhotonView:getParser():getChildView("detailbutton"):getView():setText("查看垃圾详情 >")
    mPhotonView:getParser():getChildView("rubbishsize"):getView():setText(selectedSize)
    local Color = luajava.bindClass('android.graphics.Color')
    mPhotonView:getParser():getChildView("rootView"):getView():setBackgroundColor(Color:parseColor(selectedColor))
    --清理钮背景色
    local button_clean_bg_color = mPhotonView:getParser():getBinder():get("button_clean_bg_color")
    local button_clean_edge_color = mPhotonView:getParser():getBinder():get("button_clean_edge_color")

    local button_clean_bg_color_format = "color:ffffff"
    if button_clean_bg_color ~=nil and button_clean_bg_color~= "" then
        button_clean_bg_color_format = "color:"..tostring(button_clean_bg_color)
    end

    local button_clean_edge_color_format = ",strokecolor:ffffff"
    if button_clean_edge_color ~=nil and  button_clean_edge_color ~="" then
        button_clean_edge_color_format = ",strokecolor:"..tostring(button_clean_edge_color)
    end
    local fullStopButtonBg ='strokewidth:4,'..tostring(button_clean_bg_color_format)..tostring(button_clean_edge_color_format)..",cornerradius:45,shape:0"
    Rapid:getChild("clearButton"):setAttr("backgroundgradientdrawable",fullStopButtonBg)

    --清理文案色值 根据北京颜色值来展示
    local button_clean_text_color = mPhotonView:getParser():getBinder():get("button_clean_text_color")
    if button_clean_text_color ~=nil and button_clean_text_color ~= "" then
        mPhotonView:getParser():getChildView("clearButton"):getView():setTextColor(Color:parseColor("#"..tostring(button_clean_text_color)))
    end

   --mPhotonView:getParser():getChildView("clearButton"):getView():setTextColor(Color:parseColor(selectedColor))

    --清理按钮文安
    local button_clean_text = mPhotonView:getParser():getBinder():get("button_clean_text")
    if button_clean_text ~= nil and button_clean_text ~= "" then
        mPhotonView:getParser():getChildView("clearButton"):getView():setText(tostring(button_clean_text))
    else
        mPhotonView:getParser():getChildView("clearButton"):getView():setText("放心清理")
    end
    mPhotonView:getParser():getChildView("clearButton"):getView():setVisibility(0)
    mPhotonView:getParser():getChildView("stopButton"):getView():setVisibility(8)

    mPhotonView:getParser():getChildView("rubbishsize_unit"):getView():setText(selectedSizeUnit)
    mPhotonView:getParser():getChildView("rubbishsize_unit_half"):getView():setText(selectedSizeUnit)

    mPhotonView:getParser():getBinder():update("selectedSizeStr",selectedSizeFormat..selectedSizeUnit)
    mPhotonView:getParser():getBinder():update("totalSize",totalSize)
    --local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    --local params1 = {}
    --params1["param"] = "scene:data@scene,sourcescene:data@source_scene,slotid:99_09,actionid:91,subposition:001,modeltype:data@modeltype"
    --params1["extendparam"] = "report_element:trashclean,uni_freeclean_trash_size:data@selectedSizeStr,uni_scan_type:1,uni_finished_method:1,uni_trash_size:data@totalSize"
    --params1["recommendid"] = "data@recommendid_card"
    --actionRunner:run("reportaction", params1, nil)


end

function updateValue()
    mJavaBridge:Log("onPartionResult","updateValue ")
    local rubbishCleanManager = luajava.bindClass("com.tencent.nucleus.manager.spacecleannew.RubbishCleanManager")
    rubbishScanCallBack = luajava.createProxy('com.tencent.nucleus.manager.spacecleannew.RubbishScanCallBack', RubbishScanCallBack)
    rubbishCleanManager:getInstance():registerScanListener(rubbishScanCallBack)
    local isFullScreen = mPhotonView:getParser():getBinder():get("is_full_screem")
    if (isFullScreen == "1") then
        Rapid:getChild("rootView"):setAttr("height","104%y")
        mPhotonView:getParser():getChildView("rubbishsize"):getView():setTextSize(1,56)
        mPhotonView:getParser():getChildView("rubbishsize_unit"):getView():setVisibility(0)
    else
        Rapid:getChild("rootView"):setAttr("height","50%y")
        mPhotonView:getParser():getChildView("rubbishsize"):getView():setTextSize(1,86)
        mPhotonView:getParser():getChildView("rubbishsize_unit_half"):getView():setVisibility(0)
    end



    --扫描按钮背景色
    local button_scanning_edge_color = mPhotonView:getParser():getBinder():get("button_scanning_edge_color")
    local button_scanning_bg_color = mPhotonView:getParser():getBinder():get("button_scanning_bg_color")


    local button_scanning_bg_color_format = "color:ffffff"
    if button_scanning_bg_color ~=nil then
        button_scanning_bg_color_format = "color:"..tostring(button_scanning_bg_color)
    end

    local button_scanning_edge_color_format = ",strokecolor:00ffffff"
    if button_scanning_edge_color ~=nil and button_scanning_edge_color ~= ''  then
        button_scanning_edge_color_format = ",strokecolor:"..tostring(button_scanning_edge_color)
    end

    local fullStopButtonBg ='strokewidth:4,'..tostring(button_scanning_bg_color_format)..tostring(button_scanning_edge_color_format)..",cornerradius:45,shape:0"
    Rapid:getChild("stopButton"):setAttr("backgroundgradientdrawable",fullStopButtonBg)
    mJavaBridge:Log("fullStopButtonBg","fullStopButtonBg="..tostring(fullStopButtonBg))
    --扫描按钮文案色值
    local Color = luajava.bindClass('android.graphics.Color')
    local button_scanning_text_color = mPhotonView:getParser():getBinder():get("button_scanning_text_color")
    if button_scanning_text_color ~=nil then
        mPhotonView:getParser():getChildView("stopButton"):getView():setTextColor(Color:parseColor("#"..tostring(button_scanning_text_color)))
    end


    mPhotonView:getParser():getChildView("stopButton"):getView():setText("停止扫描")

    --扫描按钮文案
    local button_scanning_text = mPhotonView:getParser():getBinder():get("button_scanning_text")
    if button_scanning_text ~= nil and  button_scanning_text ~= '' then
        mPhotonView:getParser():getChildView("detailbutton"):getView():setText(tostring(button_scanning_text))
    end

    local scanning_notice_color = mPhotonView:getParser():getBinder():get("scanning_notice_color")
    if scanning_notice_color ~=nil then
        mPhotonView:getParser():getChildView("detailbutton"):getView():setTextColor(Color:parseColor("#"..tostring(scanning_notice_color)))
    end

end


function finish()
    mJavaBridge:finish()
end

function stopScan()
    mJavaBridge:switchRubbishCleanModel(0X06)
end

function clearRubbish()
    mJavaBridge:switchRubbishCleanModel(0x14)
end

function switchRubbish()
    mJavaBridge:switchRubbishCleanModel(0X06)
end