local mPhotonView, mJavaBridge = ...
local Rapid

local TAG = "endgames_lua_welfare"
local AUTHORIZE_CMD = 306
local APP_TAG= "?appIds=%s"

local endgamesFullHeroWelfare = {}
local mAuthString = ""
local mAuthorize = false
local mAuthUrl = nil
local mAppIdStrings = ""
local mAuthContent = ""
local mUnAuthorizeNum = 0
local mAuthTable = {}
local mAppId = 0
local mNeedServer = true

local needContinue = false

function endgamesFullHeroWelfare.init(photonView, javaBridge, rapid)
    mPhotonView = photonView
    mJavaBridge = javaBridge
    Rapid = rapid
    mJavaBridge:Log(TAG, "welfare.init")
end

function endgamesFullHeroWelfare.afterUpdateData()
    mJavaBridge:Log(TAG, "welfare.afterUpdateData")
    getAuthString()
    initAuthorizeParam()
    parserAuthorize(mAuthString)
end

function endgamesFullHeroWelfare.onResume()
    mJavaBridge:Log(TAG, "welfare.onResume")
    requestQueryIfNeeded()
end

function endgamesFullHeroWelfare.onLoginStatusChanged()
    if not needContinue then
        return
    end
    mJavaBridge:Log(TAG, "welfare.onLoginStatusChanged")
    if mJavaBridge:getLoginType() == "NONE" then
        return
    end
    -- TODO 待验证
    sendPermissionQueryRequest()
end

function endgamesFullHeroWelfare.receive()
    mAuthorize = false
    mJavaBridge:Log(TAG, "welfare.receive")
    -- 判断是否登录
    if mJavaBridge:getLoginType() == "NONE" then
        openLoginActivity()
        return
    end

    needContinue = true
    sendPermissionQueryRequest()
end

function xLog(fun, note, data)
    mJavaBridge:Log(TAG, tostring(fun).." "..tostring(note)..": "..tableToString(data))
end

function tableToString(data)
    if type(data) == 'table' then
        local text = ''
        for k, v in pairs(data) do
            mJavaBridge:Log(TAG, "tableToString k: "..tostring(k)..", v: "..tostring(v))
            if text == '' then
                text = '{\"'..tostring(k)..'\":\"'..tostring(v)..'\"'
            else
                text = text..',\"'..tostring(k)..'\":\"'..tostring(v)..'\"'
            end
        end
        if text ~= '' then
            text = text..'}'
        end
        return text
    else
        return tostring(data)
    end
end

function getAuthString()
    mAuthString = Rapid:getData("personal_security_json", "")
    mAppId = tonumber(Rapid:getData("app_id", ""))
end

function initAuthorizeParam()
    mAuthUrl = Rapid:getData("auth_detail_jump_url")
    mAuthorize = tostring(Rapid:getData('is_authorized')) == '1'
    mAppIdStrings = ""
end

function openLoginActivity()
    needContinue = true
    local jsParams = {}
    jsParams["logintype"] = "DEFAULT"
    mJavaBridge:runJsBridge("openLoginActivity", jsParams, nil)
end

function showServers()
    local params = {}
    params["pkgName"] = Rapid:getData("pkg_name", "com.tencent.tmgp.sgame")
    params["appid"] = Rapid:getData("app_id", "12127266")
    xLog("showServers", "params", params)
    mJavaBridge:request(2198, params, onServerRequestListener)
end

function onServerRequestListener(succeed, viewNameList, dataList)
    if (succeed) then
        showServerRoleSelectorDialog(dataList)
    else
        mJavaBridge:showToast("获取区服失败", 1000)
    end
end

function showServerRoleSelectorDialog(dataList)
    local defaultServer = ""
    local serversList = ""

    if dataList == nil or dataList:size() < 1 then
        mJavaBridge:showToast("获取区服信息失败", 1000)
        return
    end

    local dataMap = dataList:get(0)
    local retCode = tonumber(tostring(dataMap:get("ret")))
    local errorMsg = dataMap:get("msg")
    if retCode ~= 0 then
        if errorMsg == nil then
            errorMsg = "获取区服信息失败,错误码："..tostring(retCode)
        end
        mJavaBridge:showToast(tostring(errorMsg), 1000)
        return
    end

    local serverList = dataMap:get("partitionList")
    local defaultServer = dataMap:get("defaultServer")
    local defaultRole = dataMap:get("defaultRole")

    local dialogParams = {}
    dialogParams["default_server"] = tostring(defaultServer)
    dialogParams["default_role"] = tostring(defaultRole)
    dialogParams["servers"] = tostring(serverList)
    dialogParams["need_role"] = Rapid:getData("need_role",false)
    dialogParams["need_server"] = mNeedServer
    dialogParams["pkg_name"] = Rapid:getData("pkg_name", "com.tencent.tmgp.sgame")

    xLog("showServerRoleSelectorDialog", "dialogParams", dialogParams)

    if mServerDialogShowing then
        return
    end
    mServerDialogShowing = true

    local selectDialog = mJavaBridge:showCustomDialogAsync("common_server_selector_dialog_v3.xml", 
        dialogParams, nil, "资源拉取失败，请稍后重试")
    local dialogListner = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",
        ServerRoleDialogEventListener)
    selectDialog:setPhotonDialogEventListener(dialogListner)
end

ServerRoleDialogEventListener = {}
function ServerRoleDialogEventListener.onDialogEvent(eventType, dialogData)
    if eventType == "ON_SERVER_ROLE_SELECTED" and dialogData ~= nil then
        mServerName = tostring(dialogData:get("selecetd_server_name"))
        mServerID = tostring(dialogData:get("selecetd_server_id"))
        mRoleName = tostring(dialogData:get("selecetd_role_name"))
        mRoleID = tostring(dialogData:get("selecetd_role_id"))
        reportPermissionSucceed()
        local value = mServerID
        if mRoleName == "nil" then
            value = value..","
        else 
            value = value..","..mRoleName
        end
        local param = {}
        param["key"] = "authorized"
        param["value"] = value
        Rapid:execAction("outeraction", param, param)
    elseif eventType == "DISMISS" then
        mServerDialogShowing = false
    end
end

function showAuthorizeDialog()
    mJavaBridge:Log(TAG, "showAuthorizeDialog")
    local itemData = {}
    itemData["title"] = "王者荣耀信息授权申请"
    itemData["content"] = "应用宝申请使用您的王者荣耀游戏信息，用于#1）游戏福利发放；#2）常玩英雄内容推荐；#可在“管理>右上角设置>游戏信息授权管理”查看和修改授权信息，也可点击下方蓝字修改："
    itemData["prompt"] = "游戏信息授权管理"
    local selectDialog = mJavaBridge:showCustomDialogAsync("endgames_full_hero_authorize_dialog.xml", itemData, nil, "授权弹窗")
    local dialogListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",     
        AuthorizeDialogEventListener)
    selectDialog:setPhotonDialogEventListener(dialogListener)
end

AuthorizeDialogEventListener = {}
function AuthorizeDialogEventListener.onDialogEvent(eventType, dialogData)
    mJavaBridge:Log(TAG, "AuthorizeDialogEventListener: eventType: "..tostring(eventType)
        ..", dialogData: "..tostring(dialogData))
    
    if eventType == "ON_ONE_KEY_SELECTED" then
        sendPermissionAuthorizeRequest()
    elseif eventType == "ON_DETAIL_SELECTED" then
        jumpPage()
    elseif eventType == "ON_CLEAR_AUTHORIZE" then
        sendPermissionClearRequest()
    end
end

function jumpPage()
    local jumpUrl = Rapid:getData('auth_detail_jump_url')
    if jumpUrl == nil then
        mJavaBridge:Log(TAG, "Error: jumpPage() jumpUrl is nil")
        return
    end
    local params = {}
    params["tmast"] = jumpUrl
    Rapid:execAction("tmastaction", params, nil)
end

function requestQueryIfNeeded() 
    mAuthorize = false
    sendPermissionQueryRequest()
end

function sendPermissionQueryRequest() 
    mJavaBridge:Log(TAG, "sendPermissionQueryRequest")
    local params = {}
    params["action"] = "0" -- action == 0 查询授权
    params["data"] = Rapid:getData("personal_security_json", "")
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function sendPermissionAuthorizeRequest()
    mJavaBridge:Log(TAG, "sendPermissionAuthorizeRequest")
    local params = {}
    params["action"] = "1" -- action == 1 写授权
    params["data"] = Rapid:getData("personal_security_json", "")
    mJavaBridge:Log(TAG, "sendPermissionAuthorizeRequest mAuthString: "..tostring(mAuthString))
    mJavaBridge:Log(TAG, "sendPermissionAuthorizeRequest AUTHORIZE_CMD: "..tostring(AUTHORIZE_CMD))
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function sendPermissionClearRequest()
    mJavaBridge:Log(TAG, "sendPermissionClearRequest")
    local params = {}
    params["action"] = "2"  -- action == 2 清除授权
    params["data"] = Rapid:getData("personal_security_json", "")
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function onPermissionRequestListener(succeed, viewNameList, dataList)
    mJavaBridge:Log(TAG, "onPermissionRequestListener")
    if dataList == nil or dataList:size() == 0 then
         mJavaBridge:Log(TAG, "onPermissionRequestListener dataList error!")   -- 写这里返回了
         return
    end
    if (succeed) then
        mJavaBridge:Log(TAG, " onPermissionRequestListener success!")
        onPermissionSucceed(viewNameList, dataList)
    else
        mJavaBridge:Log(TAG, " onPermissionRequestListener failure!")
    end
end

function onPermissionSucceed(viewNameList, dataList)
    if dataList == nil or dataList:size() < 1 then
        return
    end

    local dataMap = dataList:get(0)
    if dataMap == nil then
        mJavaBridge:Log(TAG, "is_authorize get Error!")
        return
    end

    local action = tostring(dataMap:get("action"))
    mJavaBridge:Log(TAG, "action :"..tostring(action)) 
    if action == "0" then -- action == 0 查询授权
        local result = tostring(dataMap:get("result"))
        mJavaBridge:Log(TAG, "action query result :"..result)
        if result == nil then
            return
        end
        mAuthString = result
        parserAuthorize(mAuthString)
        if mJavaBridge:getLoginType() == "NONE" or not needContinue then
            return
        end
        if mAuthorize then
            showServers()
        else
            showAuthorizeDialog()
        end
        needContinue = false
    elseif action == "1" then -- action == 1 写授权
        mJavaBridge:Log(TAG, "action write")
        mAuthorize = true
        showServers()
    else    -- action == 2 清除授权
        mJavaBridge:Log(TAG, "action clear:"..tostring(action)) 
    end
end

function parserAuthorize(authInfo)
    mJavaBridge:Log(TAG, "playing_game_name_id authInfo: "..tostring(authInfo))
    if authInfo == nil then
        return
    end

    local jsonAuthInfo = mJavaBridge:create('JSONObject', authInfo)
    if jsonAuthInfo == nil then
        return
    end

    local giftNum = tonumber(jsonAuthInfo:optString("total_num", ""))
    mJavaBridge:Log(TAG, "playing_game_name_id total_num: "..tostring(giftNum))
    local playingGames = jsonAuthInfo:optJSONArray("playing_games")
    if playingGames == nil then
        mJavaBridge:Log(TAG, "playingGames nil")
        return
    end

    mAppIdStrings = ""
    mAuthContent = ""
    mUnAuthorizeNum = 0

    for i = 0, giftNum - 1 do
        mJavaBridge:Log(TAG, "enter for")
        local playingItem = playingGames:optJSONObject(i)
        if playingItem == nil then
            mJavaBridge:Log(TAG, " playingItem nil")
            break
        end

        mJavaBridge:Log(TAG, "playing_game_name_id playingItem: "..tostring(playingItem))
        local appId = tonumber(playingItem:optString("game_id", ""))
        local appName = tostring(playingItem:optString("name", ""))

        mJavaBridge:Log(TAG, "playing_game_name_id playingItem id: "..tostring(appId).." name: "..tostring(appName))

        local playingSences = playingItem:optJSONArray("scenes")
        parserScence(playingSences, appId, appName)
    end
end

function parserScence(scene, appId, appName)
    if scene == nil then
        mJavaBridge:Log(TAG, "playing_game_name_id sence null appid: "..tostring(mAppId))
        return
    end

    mAuthTable = {}
    for i = 0, 2 do
        local playingSenceItem = scene:optJSONObject(i)
        if playingSenceItem == nil then
            return
        end

        local content = playingSenceItem:optString("content")
        local visual = playingSenceItem:optString("visual")
        mAuthTable[i + 1] = tonumber(visual)
    
        mJavaBridge:Log(TAG, "playing_game_name_id content: "..tostring(content)..", visual: "..tostring(visual))
    end

    local isAuthorize = isCurrentAppAuthorized()
    
    if appId == mAppId then
        mAuthorize = isAuthorize
        mJavaBridge:Log(TAG, "mAuthorize: "..tostring(mAuthorize))
    end

    if not isAuthorize then
        mUnAuthorizeNum = mUnAuthorizeNum + 1
        if mUnAuthorizeNum == 1 then
            mAuthContent = appName
            mAppIdStrings = tostring(appId)
            return
        end
        if mUnAuthorizeNum <= 3 then
            mAuthContent = tostring(mAuthContent)..tostring("、")..appName
        end
        if mUnAuthorizeNum == 4 then --大于4个只需要加一个等，后续不需要处理了
            mAuthContent = mAuthContent..tostring("...等")
        end
        mAppIdStrings = mAppIdStrings.."_"..tostring(appId)
    end

    mJavaBridge:Log(TAG, "mUnAuthorizeNum:"..tostring(mUnAuthorizeNum)..", mAuthContent:"..tostring(mAuthContent)
       ..", mAppIdStrings:"..tostring(mAppIdStrings))
end

function isCurrentAppAuthorized()
    mJavaBridge:Log(TAG, "isCurrentAppAuthorized")
    local length = #mAuthTable
    mJavaBridge:Log(TAG, "current appid: "..tostring(mAppId).." len: "..tostring(length))
    for i = 1, 3 do  
        if mAuthTable[i] == 2 then   -- 0 全部  1 自己 2 取消
            mJavaBridge:Log(TAG, "isCurrentAppAuthorized false") 
            return false
        end
    end
    mJavaBridge:Log(TAG, "isCurrentAppAuthorized true") 
    return true
end

function reportPermissionSucceed()
    local reportParams = {}
    reportParams["viewid"] = "already_challenge_container"
    reportParams["dteventkey"] = "clck"
    reportParams["param"] = "slotid:99_-1,status:-1,actionid:510,scene:10388,sourceScene:data@sourcescene,modeltype:-1,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:0,searchid:0"
    reportParams["extendparam"] = "report_element:permission,source_report_context:data@source_report_context,perm_source:hero_selection"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

-- 最终返回
return endgamesFullHeroWelfare