local mPhotonView, mJavaBridge = ...

local TAG = "search_single_app_card"

local mCloudPlayContainer
local mBottomMargin
local mCloudPlayName

local function showCloudPlay()
    mCloudPlayContainer:setAttr("visibility", "visible")
    mCloudPlayContainer:getView():invalidate()
    mBottomMargin:setAttr("visibility", "gone")
end

local function hideCloudPlay()
    mCloudPlayContainer:setAttr("visibility", "gone")
    mBottomMargin:setAttr("visibility", "visible")
end

local function updateTextViewWidth()
    local cloudPlayName = Rapid:getData('cloud_play_name', '')
    local cloudPlayNameTextWidth = mJavaBridge:px2dip(mCloudPlayName:getView():getPaint():measureText(cloudPlayName))
    Rapid:setData('cloud_play_button_width', cloudPlayNameTextWidth + 48)
end

local function updateAppState() 
    local appModel = Rapid:getData("app_model")
    if appModel == nil then
        return nil
    end
    local appState = mJavaBridge:getAppState(appModel)
    Rapid:setData('buttonstatus', appState)
    return appState
end

local function isAppStateCLoudPlay()
    local appState = updateAppState()
    if appState == nil or appState == "DOWNLOADED" or appState == "INSTALLED" then
        return false
    end
    return true
end

local function checkCloudPlay()
    -- 云玩功能是否可用
    local cloudPlayEnable = Rapid:getData('cloud_play_enable', '0')
    if tostring(cloudPlayEnable) ~= '1' then
        return false
    end

    -- 下载按钮状态是否符合云玩外显条件
    if not isAppStateCLoudPlay() then
        return false
    end

    return true
end

local function downloadPlugin()
    mJavaBridge:Log(TAG, "downloadPlugin")
    local params = {}
    params["packagename"] = "com.tencent.assistant.plugin.cloudgame"
    mJavaBridge:runJsBridge("downloadPlugin", params, nil)
end

local function jumpAction(tmast)
    mJavaBridge:Log(TAG, "downloadPlugin tmast: "..tostring(tmast))
    local params = {}
    params["tmast"] = tmast
    Rapid:execAction("tmastaction", params, nil)
end

local function getPositionString(position)
    return string.format("%03d", position)
end

local function updateReportData()
    local position = Rapid:getData('position')
    local subPosition = getPositionString(position + 1)
    Rapid:setData('button_slotId', '99_'..subPosition)
end

local function updateDataCloudPlay()
    if not checkCloudPlay() then
        hideCloudPlay()
        return
    end
    showCloudPlay()
    updateTextViewWidth()
    updateReportData()
end

local function initAdvertisingStyleData()
    local advertisingStyle = tonumber(Rapid:getData('advertising_style'))
    if advertisingStyle == nil or advertisingStyle < 0 then
        Rapid:setData('advertising_style', '0')
    end
    local radiu = mJavaBridge:dip2px(8)
    local cornerradiusarray = '0_'..radiu..'_0_'..radiu
    Rapid:setData('advertising_style_2_gradientdrawable', 'cornerradiusarray:'..cornerradiusarray..',color:33ff8600')
end

local function initInternalContainer(enable)
    if enable then
        Rapid:getChild('internal_container'):setAttr('gradientdrawable', 'cornerradius:8,color:14ff8600')
        Rapid:getChild('internal_container'):setAttr('margin', '12,8.6,12,8')
    else
        Rapid:getChild('internal_container'):setAttr('gradientdrawable', 'cornerradius:0,color:00ff8600')
        Rapid:getChild('internal_container'):setAttr('margin', '0,0,0,0')
    end
end

local function initAdvertisingStyle1(enable)
    if enable then
        Rapid:getChild('advertising_style_1'):setAttr('visibility', 'visible')
    else
        Rapid:getChild('advertising_style_1'):setAttr('visibility', 'gone')
    end
end

local function initAdvertisingStyle2(enable)
    if enable then
        Rapid:getChild('advertising_style_2'):setAttr('visibility', 'visible')
    else
        Rapid:getChild('advertising_style_2'):setAttr('visibility', 'gone')
    end
end

local function initAdvertisingStyle3(enable)
    if enable then
        Rapid:getChild('advertising_style_3'):setAttr('visibility', 'visible')
        Rapid:getChild('downloadTimes'):setAttr('marginleft', '8')
    else
        Rapid:getChild('advertising_style_3'):setAttr('visibility', 'gone')
        Rapid:getChild('downloadTimes'):setAttr('marginleft', '12')
    end
end

local function initAdvertisingStyles(internalContainerEnable, advertisingStyle1Enable, advertisingStyle2Enable, advertisingStyle3Enable)
    initInternalContainer(internalContainerEnable)
    initAdvertisingStyle1(advertisingStyle1Enable)
    initAdvertisingStyle2(advertisingStyle2Enable)
    initAdvertisingStyle3(advertisingStyle3Enable)
end

local function initAdvertisingStyleUI()
    local advertisingStyle = tonumber(Rapid:getData('advertising_style'))
    if advertisingStyle <= 0 then
        initAdvertisingStyles(false, false, false, false)
        return
    end
    if advertisingStyle == 1 then
        initAdvertisingStyles(true, true, false, false)
        return
    end
    if advertisingStyle == 2 then
        initAdvertisingStyles(true, false, true, false)
        return
    end
    if advertisingStyle == 3 then
        initAdvertisingStyles(true, false, false, true)
    end
end

local function updateDataAdvertisingStyle()
    initAdvertisingStyleData()
    initAdvertisingStyleUI()
end

local function checkOmtEnable()
    -- 当显示广告样式时，则不展示oma
    local advertisingStyle = tonumber(Rapid:getData('advertising_style'))
    if advertisingStyle > 0 then
        return false
    end
    -- 当列表存在相关卡片时，则不展示oma
    if tostring(Rapid:getData('relevant_card_enable', '0')) == "1" then
        return false
    end
    return true
end

function loadFinish()
    mCloudPlayContainer = Rapid:getChild('cloud_play_container')
    mBottomMargin = Rapid:getChild('bottomMargin')
    mCloudPlayName = Rapid:getChild('cloud_play_name')
end

function viewShow()
    if checkCloudPlay() then
        downloadPlugin()
    end
end

function afterUpdateData()
    updateDataCloudPlay()
    updateDataAdvertisingStyle()
    handleLine()
end

function handleLine()
    local isReleShow,canNotify = canNotifyRelevantCardShow()
    Rapid:setData('canNotifyRelevantCardShow', canNotify)
    if isReleShow == "true" then
        -- 相关卡片已展示，则隐藏分隔线
        Rapid:getChild('bottomDivider'):setAttr("visibility", "gone")
    else
        -- 否则隐藏分隔线
        Rapid:getChild('bottomDivider'):setAttr("visibility", "visible")
    end
end

function onResume()
    local relevantCardEnable = Rapid:getData('relevant_card_enable', '0')
    if tostring(relevantCardEnable ) == '1' then
        handleLine()
    end 
end

function trialJump()
    updateAppState()
    jumpAction(Rapid:getData('cloud_play_jump'))
end

-- 检查是否可以显示相关卡片
function isRelevantCardShow()
    local appModel = Rapid:getData("app_model")
    if appModel == nil then
        return false
    end

    local appState = mJavaBridge:getAppState(appModel)
    if appState == nil or appState == '' then
        return false
    end

    if appState == 'DOWNLOADING' or appState == 'PAUSED' 
    or appState == 'UPDATE' or appState == 'DOWNLOADED' 
    or appState == 'INSTALLED' then
        return true
    end
    return false
end

-- 出oma时，是否可以通知相关卡片展示
function canNotifyRelevantCardShow()
    local relevantCardEnable = Rapid:getData('relevant_card_enable', '0')
    if tostring(relevantCardEnable ) == '1' then
        if isRelevantCardShow() then
            return "true","false"
        else
            return "false","true"
        end
    end
    return "false","false"
end

function showOmt()
    if checkOmtEnable() then
        local params = {}
        params['key'] = 'showPhotonOMT'
        params['value'] = 'id:omtContainer,appModelKey:app_model'
        mPhotonView:getParser():getTaskCenter():getActionRunner():run('outeraction', params, nil)
        return
    end
    if tostring(Rapid:getData('canNotifyRelevantCardShow', 'false')) == "true" then
        mJavaBridge:delayRun(200, showRelativeCard)
    end
end

-- 通知展示相关卡片
function showRelativeCard()
    local recyclerView = getOuterRecyclerView()
    if recyclerView ~= nil then
        local adapter = recyclerView:getAdapter()
        if adapter ~= nil then
            -- 修改标记位
            Rapid:setData('canNotifyRelevantCardShow', "false")
            local position = Rapid:getData('position', '-1')
            local posInt = tonumber(position) + 1
            adapter:notifyItemChanged(posInt)
            -- 隐藏分隔线
            Rapid:getChild('bottomDivider'):setAttr("visibility", "gone")
        end
    end
end

-- 获取卡片依附的recyclerview对象
function getOuterRecyclerView()
    local childView = Rapid:getChild('rootView'):getView()
    -- 获取placeholder对象
    local parentView = childView:getParent()
    if parentView ~= nil then
        return parentView:getParent()
    end
    return nil
end