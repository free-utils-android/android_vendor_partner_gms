local mPhotonView, mJavaBridge = ...

local TAG = "common_used_gird_card"

local mRecyclerView
local rootView
local needReport = true

local RUBBISH_CLEAN_DEFAULT_TXT = '一键手机瘦身'
local WX_CLEAN_DEFAULT_TXT = '一键放心清理'
local QQ_CLEAN_DEFAULT_TXT = '一键放心清理'
local BIG_FILE_CLEAN_DEFAULT_TXT = '定期清理文件'
local SECURITY_SCANED_DEFAULT_TXT = '暂无安全隐患'
local SECURITY_NEED_SCAN_DEFAULT_TXT = '天未扫描'
local SECURITY_NEVER_SCAN_DEFAULT_TXT = '立即安全扫描'
local SECURITY_RISK_DEFAULT_TXT = '存在安全隐患'

local mSystem
function init()
    mRecyclerView = Rapid:getChild("recyclerView")
    rootView = Rapid:getChild("grid_view_root")
    
    mSystem = luajava.bindClass("java.lang.System")
    mJavaBridge:setSettingsDataAsync("ass_account_click_state", 0)
end


function onResume()
    refreshData()
end



function refreshData()

    local realDataList = {}
    local realViewList = {}


    local item_num = tonumber(Rapid:getData("item_num"));

    if (item_num == nil or item_num == 0) then
        rootView:getView():setVisibility(8)
        return
    end

    for i = 0, item_num - 1 do
    repeat
        local subTitleDefault = ""
        local subTitleDefault2 = ""
        local subTitleNum = ""
        local subTitleNumColor = ""
        local subTitle = ""
        local index = i + 1
        local item_data = {}
        local item = Rapid:getData("item_data_" .. index)
        item_data["function_id"] = Rapid:getData("item_data_" .. index .. "_function_id")
        subTitleDefault = Rapid:getData("item_data_" .. index .. "_item_sub_title", "")
        subTitleDefault2 = Rapid:getData("item_data_" .. index .. "_item_sub_title_2", "")
        item_data["item_title"] = Rapid:getData("item_data_" .. index .. "_item_title")
        item_data["item_icon"] = Rapid:getData("item_data_" .. index .. "_item_icon")
        item_data["jump_url"] = Rapid:getData("item_data_" .. index .. "_jump_url")

        item_data["recommendid"] = Rapid:getData("card_recommendid")
        item_data["modeltype"] = Rapid:getData("modeltype")
        item_data["slotid"] = Rapid:getData("slotid")
        item_data["subposition"] = index
        item_data["scene"] = Rapid:getData("scene")
        item_data["sourcescene"] = Rapid:getData("sourcescene")
        item_data["sourcesceneslotid"] = Rapid:getData("sourcesceneslotid")
        item_data["manager_score"] = mJavaBridge:getNormalSettingsData("key_cal_final_score", "-1")

        local score = item_data["manager_score"]
        local function_id = tonumber(Rapid:getData("item_data_" .. index .. "_function_id"))
        mJavaBridge:Log("AccountSecurityManager", "--lua--get score:function_id:----" .. function_id)
        --垃圾清理1、QQ清理4、微信清理2
        if (function_id == 1 or function_id == 4 or function_id == 2) then
            subTitleNum = getCleanData(function_id)

            item_data["subtitlenumcolor"] = needColor(subTitleNum)

            if subTitleNum == "" then
                subTitle = getDefaultSubTitle(function_id, subTitleDefault)
            else
                subTitle = "垃圾"
            end
        end

        --安全扫描6
        if (function_id == 6) then
            -- 安全扫描的上次扫描时间
            local lastScanTime = getSecurityScanTime()

            -- 距离上次扫描间隔多少时间（天）
            local calcTimeForDay = toInteger((mSystem:currentTimeMillis() - tonumber(lastScanTime)) / 86400000)
            
            local riskPkgs = getSecurityScanRiskPkgs()

            mJavaBridge:Log(TAG, "riskPkgs:" .. riskPkgs)

            if riskPkgs ~= "" and riskPkgs ~= "|" then
                -- 有风险app时，不用判断天数
            else
                if (tonumber(lastScanTime) > 0 and calcTimeForDay > 1) then
                    subTitleNum = calcTimeForDay

                    item_data["subtitlenumcolor"] = "f86273"
                end
            end

            subTitle = getDefaultSecuritySubTitle(lastScanTime, calcTimeForDay, subTitleDefault, subTitleDefault2)
        end

        --账号检测8
        if (function_id == 8) then
            item_data["item_sub_title"] = Rapid:getData("item_data_" .. index .. "_item_sub_title")
            item_data["item_sub_title_2"] = Rapid:getData("item_data_" .. index .. "_item_sub_title_2")
            item_data["item_sub_title_3"] = Rapid:getData("item_data_" .. index .. "_item_sub_title_3")
            item_data["item_sub_title_4"] = Rapid:getData("item_data_" .. index .. "_item_sub_title_4")
            item_data["item_sub_title_5"] = Rapid:getData("item_data_" .. index .. "_item_sub_title_5")

            mJavaBridge:Log("AccountSecurityManager", "--lua--get score:item_sub_title:----" .. item_data["item_sub_title"])
            if getAccountSecurityState() == 6 or getAccountSecurityState() == 7 then
                break;
            end
        end


        if subTitle == "" then
            subTitle = getDefaultSubTitle(function_id, subTitleDefault)
        end

        item_data["subtitle"] = subTitle
        item_data["subtitlenum"] = subTitleNum

        if subTitleNum == "" then
            item_data["subtitlenumcolor"] = "777777"
        end

        realDataList[index] = item_data
        realViewList[index] = "common_used_card_item.xml"


        if needReport then
            local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
            local params1 = {}
            params1["param"] ="scene:data@scene,actionid:100,slotid:data@slotid,subposition:" .. index .. ",modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,status:-1"
            params1["extendparam"] = "report_element:entrance,uni_card_title:".. item_data["item_title"] .. ",uni_manage_score:" .. score ..  ",uni_entrance_id:" .. function_id
            params1["recommendid"] = "data@card_recommendid"
            actionRunner:run("reportaction", params1, nil)


            local params2 = {}
            params2["param"] ="scene:data@scene,actionid:-100,slotid:data@slotid,subposition:" .. index .. ",modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,status:-1"
            params2["extendparam"] = "report_element:entrance,uni_card_title:".. item_data["item_title"] .. ",uni_manage_score:" .. score ..  ",uni_entrance_id:" .. function_id
            params2["recommendid"] = "data@card_recommendid"
            actionRunner:run("reportaction", params2, nil)

        end

    until true
    end
    needReport = false
    mRecyclerView:getView():clear()

    mRecyclerView:getView():updateData(realViewList, realDataList)
end

function getDefaultSubTitle(function_id, subTitle)
    if subTitle ~= "" then
        return subTitle
    end

    --垃圾清理
    if (function_id == 1) then
        return RUBBISH_CLEAN_DEFAULT_TXT
    end
    --QQ清理
    if (function_id == 4) then
        return QQ_CLEAN_DEFAULT_TXT
    end
    --微信清理
    if (function_id == 2) then
        return WX_CLEAN_DEFAULT_TXT
    end
    --大文件清理
    if (function_id == 3) then
        return BIG_FILE_CLEAN_DEFAULT_TXT
    end
end

function getCleanData(function_id)
    local num = 0
    --垃圾清理
    if (function_id == 1) then
        num = mJavaBridge:getRubbishData()
    end
    --QQ清理
    if (function_id == 4) then
        num = mJavaBridge:getQQCleanData()
    end
    --微信清理
    if (function_id == 2) then
        num = mJavaBridge:getWxCleanData()
    end

    return num
end

function getDefaultSecuritySubTitle(lastScanTime, calcTimeForDay, subTitle, subTitle2)
    -- 从未进行过安全扫描
    if tonumber(lastScanTime) == 0 then
        return SECURITY_NEVER_SCAN_DEFAULT_TXT
    end

    local riskPkgs = getSecurityScanRiskPkgs()

    -- 有风险app
    if riskPkgs ~= "" and riskPkgs ~= "|" then
        return SECURITY_RISK_DEFAULT_TXT
    end

    if (calcTimeForDay <= 1) then
        -- 扫描天数小于一天，展示无安全隐患
        if subTitle ~= "" then
            return subTitle
        end

        return SECURITY_SCANED_DEFAULT_TXT
    else
        -- 扫描天数大于一天，建议去扫描
        if subTitle2 ~= "" then
            return subTitle2
        end

        return SECURITY_NEED_SCAN_DEFAULT_TXT
    end
end

function needColor(subTitleNum)

    if string.sub(subTitleNum,-2)=="GB" then
        return "f86273"
    end
    if string.sub(subTitleNum,-2)=="MB" then
        local len = string.len( subTitleNum )
        local str = string.sub( subTitleNum, 1,  len - 2 )
        local count = tonumber(str)
        if(count > 500) then
            return "f86273";
        end
    end
    return "777777"
end

function getSecurityScanTime()
    return mJavaBridge:getNormalSettingsData("k_l_v_t", 0)
end

function getSecurityScanRiskPkgs()
    return mJavaBridge:getNormalSettingsData("k_l_v_l", "")
end

function toInteger( x )
    num = tonumber( x )
    return num < 0 and math.ceil( num ) or math.floor( num )
end

--获取账号安全信息状态
--0:30天内检测过，并无风险--不扣分
--1:30天内检测过，有风险未排除--扣分
--2:表示30天内并未检测过--扣分
--3:未登录---扣分
--4:从未检测过---扣分
--5:数据还未准备好
--6:QQ登录
--其中 30天为默认值，可以后台下发
function getAccountSecurityState()
    return mJavaBridge:getAccountSecurityState()
end