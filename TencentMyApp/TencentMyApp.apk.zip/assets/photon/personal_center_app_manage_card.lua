local mPhotonView, mJavaBridge = ...


local KEY_TOBE_INSTALL_APP_IDS = 'key_tobe_install_app_ids'
local KEY_UPDATE_APP_IDS = 'key_update_app_ids'

-- 入口类型
local TYPE_TOBE_INSTALL = '1' --安装
local TYPE_TOBE_UPDATE = '2' --更新
local TYPE_NONE = '0'


-- 气泡类型
local BUBBLE_DLOAD = 'dload_num'
local BUBBLE_UPDATE = 'update_num'

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil
local mRid = nil

local mRecyclerView = nil
local mDataList = nil

local TYPE_DOWNLOAD = "1"
local TYPE_UPDATE = "2"
local TYPE_UNINSTALL = "3"
local typeMap = luajava.newInstance("java.util.HashMap")

-- 是否可以获取待更新数据
local mHasGetUpdateData = false
-- 是否展示待安装气泡
local mShowInstallBubble = false

function eventUpdateCallback(result_code, method, data)
    if method == "updateAppArea" and mHasGetUpdateData == false then
        mHasGetUpdateData = true
        reflushTobeUpdateData()
    end
end


function main()
    mHasGetUpdateData = false
    mShowInstallBubble = false
    mRecyclerView = mPhotonView:getParser():getChildView('recyclerview')

    -- 注册应用更新数据监听
    mJavaBridge:registeAppUpdate(eventUpdateCallback)
end

function onDestory()
    -- 反注册应用更新数据监听
    mJavaBridge:unRegisteAppUpdate()
end

function onResume()
    mJavaBridge:Log("qiwei","onResume()")
    initRedDotData()
end

function initRedDotData()
    Rapid:getChild('rl_bubble'):setAttr('visibility','gone')
    showTriangle(TYPE_NONE)
    
    reflushTobeInstallData()
    reflushTobeUpdateData()
end

-- 更新待安装应用的数据
function reflushTobeInstallData()
    mShowInstallBubble = false
    reflushData(TYPE_TOBE_INSTALL, 'item_data_red_num', '0')

    local apps = mJavaBridge:callModule('AppManager', 'getDownloadedApkList')
    if apps == nil then
        return
    end
    local redDotNum = tonumber(apps['item_count'])
    local redDotNumReal = redDotNum
    if redDotNum <= 0 then
        return
    end
    -- 有待安装的数据
    -- 过滤已曝光的应用，剩下的表示新增的安装应用，展示红点，否则展示气泡
    -- 如果未过滤则表示需要显示全部的数据
    redDotNum = filterAppData(KEY_TOBE_INSTALL_APP_IDS, apps)

    --没有配置下载按钮默认不展示气泡
    if not hasTypeMode(TYPE_DOWNLOAD) then
        return
    end

    if redDotNum > 0 then
        -- 展示红点
        reflushData(TYPE_TOBE_INSTALL, 'item_data_red_num', redDotNumReal)
        -- 展示气泡
        mShowInstallBubble = true
        showBubble(TYPE_TOBE_INSTALL, apps)
    end
end

-- 更新待更新应用的数据
function reflushTobeUpdateData()
    reflushData(TYPE_TOBE_UPDATE, 'item_data_red_num', '0')

    local apps = mJavaBridge:callModule('AppManager', 'getUpdateApkList')
    if apps == nil then
        return
    end
    local redDotNum = tonumber(apps['item_count'])
    local redDotNumReal = redDotNum
    if redDotNum <= 0 and mHasGetUpdateData == false and mJavaBridge:isAppUpdateRequesting() then
        -- 还没拿到更新数据
        return
    end

    -- 有更新数据
    -- 过滤已曝光的应用，剩下的表示新增的更新应用，展示红点，否则展示气泡
    redDotNum = filterAppData(KEY_UPDATE_APP_IDS, apps)
    --没有配置更新按钮默认不展示
    if not hasTypeMode(TYPE_TOBE_UPDATE) then
        return
    end

    if redDotNum > 0 then
        -- 更新红点
        reflushData(TYPE_TOBE_UPDATE, 'item_data_red_num', redDotNumReal)

        -- 判定是否展示了安装气泡
        if not mShowInstallBubble then
            -- 展示气泡
            showBubble(TYPE_TOBE_UPDATE, apps)
        end
    end
end

-- 展示气泡
function showBubble(type, apps)
    -- 设置默认值
    Rapid:getChild('rl_bubble'):setAttr('visibility', 'visible')
    Rapid:getChild('cv_image_1'):setAttr('visibility', 'gone')
    Rapid:getChild('cv_image_2'):setAttr('visibility', 'gone')
    Rapid:getChild('cv_image_3'):setAttr('visibility', 'gone')

    local itemCount = tonumber(apps['item_count'])
    local itemCountFormat = itemCount
    if itemCount > 99 then
        itemCountFormat = "99+"
    end
    if type == TYPE_TOBE_INSTALL then
        Rapid:setData('uni_bubble_type', BUBBLE_DLOAD)
        Rapid:setData('content', itemCountFormat .. '款应用待安装')
    elseif type == TYPE_TOBE_UPDATE then
        Rapid:setData('uni_bubble_type', BUBBLE_UPDATE)
        Rapid:setData('content', itemCountFormat .. '款应用可更新')
    end

    for i = 1, itemCount do
        if i > 3 then
            -- 最多展示3个
            break
        end
        local iconUrl = apps['app_icon_url_'..i]
        if iconUrl ~= nil and tostring(iconUrl) ~= '' then
            Rapid:setData('icon_url_'..i, tostring(iconUrl))
            Rapid:getChild('cv_image_'..i):setAttr('visibility','visible')
        end
    end

    showTriangle(type)
    bubbleExposure()
end

-- 显示三角形
function showTriangle(type)
    local itemCount = mDataList:size()
    for i = 0, (itemCount-1) do
        local itemData = mDataList:get(i)
        if type == tostring(itemData:get('item_type')) then
            updateItemData(i, 'show_triangle', true)
        else
            updateItemData(i, 'show_triangle', false)
        end
    end
end

-- 更新数据
function reflushData(type, key, value)
    -- 根据type找到对应的item的下标
    local itemCount = mDataList:size()
    for i = 0, (itemCount-1) do
        local itemData = mDataList:get(i)
        if type == tostring(itemData:get('item_type')) then
            updateItemData(i, key, value)
            break
        end
    end
end

-- 刷新单个item的数据
function updateItemData(index, key, value)
	mRecyclerView:getView():updateItemData(index, key, value)
	mRecyclerView:getView():getAdapter():notifyItemChanged(index)
end

-- 过滤已曝光应用数据
-- return 需要显示的应用个数
function filterAppData(filterKey, apps)
    local showIncrementRedDot = tostring(apps['exposed_dismiss'])
    local appCount = tonumber(apps['item_count'])
    if showIncrementRedDot ~= 'true' then
        -- 不做过滤数据
        return appCount
    end
    -- 已曝光的appId
    local appIds = mJavaBridge:getNormalSettingsData(filterKey, '')
    if appIds == '' then
        return appCount
    end

    local filterCount = 0
    for i = 1, appCount do
        local index = string.find(appIds, tostring(apps['app_id_'..i]))
        if index ~= nil and index > 0 then
            -- 找到了被过滤的app
            filterCount = filterCount + 1
        end
    end
    return appCount - filterCount
end

-- 点击了气泡
function clickBubble()
    local curBubbleType = tostring(Rapid:getData('uni_bubble_type', ''))
    if curBubbleType == BUBBLE_DLOAD then
        -- 跳转下载管理页
        tmastJump('tmast://download?')
    elseif curBubbleType == BUBBLE_UPDATE then
        -- 跳转更新列表页
        tmastJump('tmast://update?')
    end
end

-- 气泡曝光
function bubbleExposure()
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params = {}
    params["viewid"] = "rl_bubble"
    params["dteventkey"] = "imp"
    params["param"] ="scene:data@scene,actionid:100,slotid:data@slotid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params["extendparam"] = "report_element:bubble,report_context:data@report_context,uni_bubble_type:data@uni_bubble_type"
    params["recommendid"] = "data@recomendid_card"
    actionRunner:run("reportaction", params, nil)
end

function tmastJump(tmastUrl)
    local params = {}
    params['tmast'] = tmastUrl
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end

function loadData()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    mRid = Rapid:getData("recomendid_card")
    
    mDataList = luajava.newInstance("java.util.ArrayList")
    local viewNameList = luajava.newInstance("java.util.ArrayList")
    local itemCount = tonumber(Rapid:getData('item_count','0'))
    local hasFourApp = tostring(Rapid:getData('hasFourApp', ''))
    if hasFourApp == 'true' then
        -- 设置一行按4个排版
        Rapid:getChild('recyclerview'):setAttr('layoutmanager','girdlayoutmanager,4')
        -- 最多只允许展示4个入口
        if itemCount > 4 then
            itemCount = 4
        end
    else
        -- 设置一行按3个排版
        Rapid:getChild('recyclerview'):setAttr('layoutmanager','girdlayoutmanager,3')
        -- 最多只允许展示3个入口
        if itemCount > 3 then
            itemCount = 3
        end
    end

    for i = 1, itemCount do
        local mapData = luajava.newInstance("java.util.HashMap")
        putMapData(mapData, "item_title", Rapid:getData("item_data_" .. tostring(i).."_item_title"))
        putMapData(mapData, "item_icon_url", Rapid:getData("item_data_" .. tostring(i).."_item_icon_url"))
        putMapData(mapData, "item_jump_url", Rapid:getData("item_data_" .. tostring(i).."_item_jump_url"))
        putMapData(mapData, "item_type", Rapid:getData("item_data_" .. tostring(i).."_item_type", ''))
        putMapData(mapData, "report_context_app", Rapid:getData("item_data_" .. tostring(i).."_report_context_app"))

        putMapData(mapData, "subPosition", i)
        if mapData:get('item_data_red_num') == nil then
            -- 防止item复用导致的数据错乱，判定为空才赋值是防止在滑出页面
            -- 再滑回来时导致已设置的数据更新错误
            putMapData(mapData, "item_data_red_num", '0')
        end

        putBaseReportText(mapData)

        mDataList:add(mapData)
        viewNameList:add('personal_center_app_manage_card_item.xml')
        putMapData(typeMap, Rapid:getData("item_data_" .. tostring(i).."_item_type", ''), Rapid:getData("item_data_" .. tostring(i).."_item_type", ''))
    end
    mRecyclerView:getView():updateData(mDataList, viewNameList, true)

    initRedDotData()
end

function putBaseReportText(mapData)
    putMapData(mapData, "scene", mScene)
    
    putMapData(mapData, "sourcescene", mSourcescene)
    putMapData(mapData, "sourceScene", mSourcescene)
    
    putMapData(mapData, "modeltype", mModeltype)
    putMapData(mapData, "modelType", mModeltype)
    
    putMapData(mapData, "sourcesceneslotid", mSourceslotid)
    putMapData(mapData, "sourceSceneSlotId", mSourceslotid)
    
    putMapData(mapData, "slotid", mSlotid)
    putMapData(mapData, "slotId", mSlotid)
    
    putMapData(mapData, "card_recommendid", mRid)
end

function putMapData(map, key, value)
    if ((key ~= nil) and (value ~= nil)) then
        local var = mJavaBridge:create("var", value)
        map:put(key, var)
    end
end

function hasTypeMode(type)
    return typeMap:containsKey(type)
end
