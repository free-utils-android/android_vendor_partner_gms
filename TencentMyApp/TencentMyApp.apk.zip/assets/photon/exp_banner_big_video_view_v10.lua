local mPhotonView, mJavaBridge = ...

local bigVideo
local materialType

local BANNER_TEMP_INDEX_KEY = "banner_temp_index_key"
local BANNER_TEMP_BANNER_ID_KEY = "banner_temp_banner_id_key"
local MATERIAL_TYPE_VIDEO = 1
local MATERIAL_TYPE_IMAGE = 2
local currentVid = ""
local currentMaterialId

local cardIndex
function init()
    mJavaBridge:Log("banner_video", "--init-Vvvvvvv10-")
    bigVideo = Rapid:getChild("video_view")
    mJavaBridge:Log("banner_video", "--init end--")
    cardIndex = Rapid:getData("index")
end


------------------播放状态监听begin------------------
IPlayerViewStateChangeListener = {}
function IPlayerViewStateChangeListener.onResume( ... )
    mJavaBridge:Log("banner_video", "--onResume--truef0934k0ibkj")
    return false
end

function IPlayerViewStateChangeListener.onUpdateFinished( ... )
    mJavaBridge:Log("banner_video", "--onUpdateFinished--truef0934k0ibkj")
    return false
end

function IPlayerViewStateChangeListener.onAttachToWindow( ... )
    mJavaBridge:Log("banner_video", "--onAttachToWindow--truef0934k0ibkj")

    bigVideo:getView():setNeedLoopPlay(true)
    if bigVideo:getView():canPlayCurrentNetworkEnvironment() then 
        mJavaBridge:postRun(tryContinueOrRestartPlay)
        bigVideo:getView():setAutoPlay(true)
    else
        bigVideo:getView():stop()
        bigVideo:getView():setAutoPlay(false)
    end

    return false
end

function IPlayerViewStateChangeListener.onPause( ... )
    mJavaBridge:Log("banner_video", "--onPause--truef0934k0ibkj")
    return false
end

function IPlayerViewStateChangeListener.onStop( ... )
    mJavaBridge:Log("banner_video", "--onStop--truef0934k0ibkj")
    bigVideo:getView():pause(true,2)
    return true
end

function IPlayerViewStateChangeListener.onDetachedFromWindow( ... )
    mJavaBridge:Log("banner_video", "--onDetachedFromWindow--true f0934k0ibkj")
    --bigVideo:getView():pause(true,3)
    return true
end

function IPlayerViewStateChangeListener.onBackHome(videoView)
    mJavaBridge:Log("banner_video", "--onBackHome--truef0934k0ibkj")
    return false
end


function IPlayerViewStateChangeListener.onDestroy(...)
    mJavaBridge:Log("banner_video", "--onDestroy--truef0934k0ibkj")
    return false
end
------------------播放状态监听end--------------------

------------------滑动事件监听begin------------------
IPlayerVisibleAreaRatioChangeListener = {}
function IPlayerVisibleAreaRatioChangeListener.onVisibleAreaRatioChange( inside_ratio )
    mJavaBridge:Log("banner_video", "--onVisibleAreaRatioChange--truef0934k0ibkj:" .. tostring(inside_ratio))
    if(inside_ratio <= 0.3) then
        bigVideo:getView():pause(true,2)
    else
        bigVideo:getView():tryContinueOrRestartPlay(true);
    end

    return true
end
------------------滑动事件监听end--------------------

function tryContinueOrRestartPlay()
    if materialType == MATERIAL_TYPE_VIDEO then
        bigVideo:getView():tryContinueOrRestartPlay(true);
    end
end

------------------after_update_data--填充数据----------------------
function initData()

    local bannerIndex = tonumber(Rapid:getData(BANNER_TEMP_INDEX_KEY, 1))
    mJavaBridge:Log("banner_video", "----initData--index--" .. bannerIndex)
    local preBannerId = tostring(Rapid:getData(BANNER_TEMP_BANNER_ID_KEY, ""))

    if bigVideo ~= nil then
        bigVideo:getView():setNeedLoopPlay(true)
    end

    local banner_num = tonumber(Rapid:getData('banners_num'))

    mJavaBridge:Log("banner_video", "--init--" .. bannerIndex .. ", " .. preBannerId .. "," .. banner_num)

    if banner_num == 0 then
        changeViewVisibility("container", "gone")
        return
    end
    changeViewVisibility("container", "visible")

    if banner_num == 1 then
        bannerIndex = 1
    end

    if bannerIndex > banner_num then
        bannerIndex = 1
    end


    mJavaBridge:Log("banner_video", "--initData--bannerIndex:" .. bannerIndex)

    --素材类型，1为视频，2为图文
    local video_id = Rapid:getData("video_id_" .. bannerIndex)
    if video_id ~= nil and  video_id ~= "" then
        materialType = MATERIAL_TYPE_VIDEO
    else
        materialType = MATERIAL_TYPE_IMAGE
    end


    if currentMaterialId == preBannerId then
        mJavaBridge:Log("banner_video", "---same---return----currentVid:" .. currentVid)
        if materialType == MATERIAL_TYPE_VIDEO and bigVideo ~= nil and currentVid ~= bigVideo:getView():getVideoUri() then
            mJavaBridge:Log("banner_video", "---need---reset---getVideoUri:" .. bigVideo:getView():getVideoUri())
            bigVideo:getView():setVid(currentVid)
        end
        return
    end

    mJavaBridge:Log("banner_video", "--material_type--:" .. materialType)

    if materialType == MATERIAL_TYPE_VIDEO then
        --视频
        mJavaBridge:Log("banner_video", "--material_type--:is video")
        changeViewVisibility("image_view", "gone")
        changeViewVisibility("video_view", "visible")
        changeViewVisibility("video_mask_all_area", "visible")
        Rapid:setData("vid", Rapid:getData("video_id_" .. bannerIndex))
        Rapid:setData("cover_image_url", Rapid:getData("img_url_" .. bannerIndex))
        Rapid:setData("report_id", "vedio")
        mJavaBridge:Log("banner_video", "--material_type--:333")
        currentVid = Rapid:getData("video_id_" .. bannerIndex)
        initVideoView()
    else
        --图文
        mJavaBridge:Log("banner_video", "--material_type--:is image")
        changeViewVisibility("image_view", "visible")
        changeViewVisibility("video_view", "gone")
        changeViewVisibility("video_mask_all_area", "gone")
        Rapid:setData("img_url", Rapid:getData("img_url_" .. bannerIndex))
        Rapid:setData("report_id", "image")
        currentVid = ""
        unRegisteVideoView()
    end
    
    Rapid:setData("main_title", Rapid:getData("app_title_" .. bannerIndex))
    Rapid:setData("sub_title", Rapid:getData("app_recmd_" .. bannerIndex))
    mJavaBridge:Log("banner_video", "--main_title--" .. tostring(Rapid:getData("app_title_" .. bannerIndex)))
    initButton(bannerIndex)

    local score = tostring(Rapid:getData("average_rating_" .. bannerIndex, 0))
    local len = string.len( score )
    if string.sub(score,-3)== "分" then
        score = string.sub(score, 1, len - 3)
    end
    Rapid:setData("average_rating", score)
    Rapid:setData("app_recommendid", Rapid:getData("app_recommendid_" .. bannerIndex))
    Rapid:setData("app_model", Rapid:getData("app_model_" .. bannerIndex))
    Rapid:setData("appid", Rapid:getData("app_id_" .. bannerIndex, ""))
    Rapid:setData("jump_url", Rapid:getData("jump_url_" .. bannerIndex))
    Rapid:setData("material_id", Rapid:getData("material_id_" .. bannerIndex))
    Rapid:setData("report_context_sub_item", Rapid:getData("report_context_" .. bannerIndex))
    Rapid:setData("card_slotid", tostring(Rapid:getData("slotid")) .. "_-1_-1")
    mJavaBridge:Log("banner_video", "--end --" .. tostring(Rapid:getData(BANNER_TEMP_BANNER_ID_KEY)))
    --无app信息时，需要隐藏download_button和评分信息
    --评分过低3.6时，需要隐藏评分信息
    decideIfHideAppArea(bannerIndex)
    decideIfHideScore()
end




------------------view_show时调用--初次index不加1，后续index+1----确定index后，更新展示+上报-------------------
function stepToNextData()
    mJavaBridge:Log("banner_video", "----stepToNextData----")
    local bannerIndex = tonumber(Rapid:getData(BANNER_TEMP_INDEX_KEY, 1))
    local preBannerId = tostring(Rapid:getData(BANNER_TEMP_BANNER_ID_KEY, ""))

    local banner_num = tonumber(Rapid:getData('banners_num'))

    mJavaBridge:Log("banner_video", "--init--" .. bannerIndex .. ", " .. preBannerId .. "," .. banner_num)

    if banner_num == 0 then
        changeViewVisibility("container", "gone")
        return
    end
    changeViewVisibility("container", "visible")

    ----第一次展示，不修改布局，也不增加index，只做清理和曝光
    if preBannerId == "" and bannerIndex == 1 then
        currentMaterialId = Rapid:getData("material_id_" .. bannerIndex)
        --Rapid:setData(BANNER_TEMP_BANNER_ID_KEY, currentMaterialId)
        RapidList:updateItemData(cardIndex,BANNER_TEMP_BANNER_ID_KEY,currentMaterialId)
        mJavaBridge:Log("banner_video", "----stepToNextData---first-----return-----")
        mJavaBridge:delayRun(1000, reportCardExposure)
        --使用完毕后清空内容，防止蹿位
        for i = 1, banner_num do
            Rapid:setData("video_id_" .. i, "")
            Rapid:setData("app_id_" .. i, "")
            Rapid:setData("app_recommendid_" .. i, "")
            Rapid:setData("app_model_" .. i, "")
            Rapid:setData("average_rating_" .. i, "0")
            Rapid:setData("app_title_" .. i, "")
            Rapid:setData("app_recmd_" .. i, "")
            Rapid:setData("report_context_" .. i, "")
            Rapid:setData("show_booking_button_" .. i, "")
            Rapid:setData("ordered_" .. i, "")
        end
        return
    end

    if banner_num == 1 then
        bannerIndex = 1
    end

    
    --再次展示下一个,循环展示

    if banner_num > 1 
    and preBannerId ~= nil 
    and preBannerId ~= "" then 
        bannerIndex = bannerIndex + 1
        mJavaBridge:Log("banner_video", "--next-1-" .. bannerIndex)
    end
    if bannerIndex > banner_num then
        bannerIndex = 1
    end

    --如果bannerid和原来一样，则再次展示下一个，循环展示
    local nowBannerId = Rapid:getData("material_id_" .. bannerIndex)    
    if nowBannerId == preBannerId and banner_num > 1 then 
        bannerIndex = bannerIndex + 1
        mJavaBridge:Log("banner_video", "--next-2-" .. bannerIndex)
    end
    if bannerIndex > banner_num then
        bannerIndex = 1
    end
    
    mJavaBridge:Log("banner_video", "--final--bannerIndex:" .. bannerIndex)

    --素材类型，1为视频，2为图文
    local video_id = Rapid:getData("video_id_" .. bannerIndex)
    if video_id ~= nil and  video_id ~= "" then
        materialType = MATERIAL_TYPE_VIDEO
    else
        materialType = MATERIAL_TYPE_IMAGE
    end
    mJavaBridge:Log("banner_video", "--material_type--:" .. materialType)

    if materialType == MATERIAL_TYPE_VIDEO then
        --视频
        mJavaBridge:Log("banner_video", "--material_type--:is video")
        changeViewVisibility("image_view", "gone")
        changeViewVisibility("video_view", "visible")
        changeViewVisibility("video_mask_all_area", "visible")
        Rapid:setData("vid", Rapid:getData("video_id_" .. bannerIndex))
        Rapid:setData("cover_image_url", Rapid:getData("img_url_" .. bannerIndex))
        Rapid:setData("report_id", "vedio")
        mJavaBridge:Log("banner_video", "--material_type--:333")
        initVideoView()
    else
        --图文
        mJavaBridge:Log("banner_video", "--material_type--:is image")
        changeViewVisibility("image_view", "visible")
        changeViewVisibility("video_view", "gone")
        changeViewVisibility("video_mask_all_area", "gone")
        Rapid:setData("img_url", Rapid:getData("img_url_" .. bannerIndex))
        Rapid:setData("report_id", "image")
        unRegisteVideoView()

    end
    
    
    Rapid:setData("main_title", Rapid:getData("app_title_" .. bannerIndex))
    Rapid:setData("sub_title", Rapid:getData("app_recmd_" .. bannerIndex))
    mJavaBridge:Log("banner_video", "--main_title--" .. tostring(Rapid:getData("app_title_" .. bannerIndex)))
    initButton(bannerIndex)

    local score = tostring(Rapid:getData("average_rating_" .. bannerIndex, 0))
    local len = string.len( score )
    if string.sub(score,-3)== "分" then
        score = string.sub(score, 1, len - 3)
    end
    Rapid:setData("average_rating", score)
    Rapid:setData("app_recommendid", Rapid:getData("app_recommendid_" .. bannerIndex))
    Rapid:setData("app_model", Rapid:getData("app_model_" .. bannerIndex))
    Rapid:setData("appid", Rapid:getData("app_id_" .. bannerIndex, ""))
    Rapid:setData("jump_url", Rapid:getData("jump_url_" .. bannerIndex))
    Rapid:setData("material_id", Rapid:getData("material_id_" .. bannerIndex))
    Rapid:setData("report_context_sub_item", Rapid:getData("report_context_" .. bannerIndex))
    Rapid:setData("card_slotid", tostring(Rapid:getData("slotid")) .. "_-1_-1")
    --记录最终的当前banner信息
    --Rapid:setData(BANNER_TEMP_INDEX_KEY, bannerIndex)
    RapidList:updateItemData(cardIndex,BANNER_TEMP_INDEX_KEY,bannerIndex)
    currentMaterialId = Rapid:getData("material_id_" .. bannerIndex)
    --Rapid:setData(BANNER_TEMP_BANNER_ID_KEY, currentMaterialId)
    RapidList:updateItemData(cardIndex,BANNER_TEMP_BANNER_ID_KEY,currentMaterialId)
    mJavaBridge:Log("banner_video", "--end --" .. tostring(Rapid:getData(BANNER_TEMP_BANNER_ID_KEY)))
    --无app信息时，需要隐藏download_button和评分信息
    --评分过低3.6时，需要隐藏评分信息
    decideIfHideAppArea(bannerIndex)
    decideIfHideScore()
    mJavaBridge:delayRun(1000, reportCardExposure)
    --使用完毕后清空内容，防止蹿位
    for i = 1, banner_num do
        Rapid:setData("video_id_" .. i, "")
        Rapid:setData("app_id_" .. i, "")
        Rapid:setData("app_recommendid_" .. i, "")
        Rapid:setData("app_model_" .. i, "")
        Rapid:setData("average_rating_" .. i, "0")
        Rapid:setData("app_title_" .. i, "")
        Rapid:setData("app_recmd_" .. i, "")
        Rapid:setData("report_context_" .. i, "")
        Rapid:setData("show_booking_button_" .. i, "")
        Rapid:setData("ordered_" .. i, "")
    end
end

function reportCardExposure()

    --Card卡片的整体上报
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params = {}
    params["viewid"] = "container"
    params["dteventkey"] = "imp"
    params["param"] ="scene:data@scene,slotid:data@slotid,actionid:100,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,report_context:data@report_context"
    params["extendparam"] = "report_element:card,report_context:data@report_context"
    params["recommendid"] = "data@card_recommendid"
    actionRunner:run("reportaction", params, nil)

    --Card卡片的整体上报
    local actionRunner2 = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params2 = {}
    params2["param"] ="scene:data@scene,slotid:data@slotid,actionid:-100,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,report_context:data@report_context"
    params2["extendparam"] = "report_element:card,report_context:data@report_context"
    params2["recommendid"] = "data@card_recommendid"
    actionRunner2:run("reportaction", params2, nil)

    --App的整体上报
    local actionAppRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local paramsApp = {}
    paramsApp["viewid"] = "title_view"
    paramsApp["dteventkey"] = "imp"
    paramsApp["param"] ="scene:data@scene,slotid:data@slotid,actionid:100,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    paramsApp["extendparam"] = "report_element:app,report_context:data@report_context_sub_item"
    paramsApp["recommendid"] = "data@app_recommendid"
    actionAppRunner:run("reportaction", paramsApp, nil)
    

    
     --App的整体上报
     local actionAppRunner2 = mPhotonView:getParser():getTaskCenter():getActionRunner()
     local paramsApp2 = {}
     paramsApp2["param"] ="scene:data@scene,slotid:data@slotid,actionid:-100,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
     paramsApp2["extendparam"] = "report_element:app,report_context:data@report_context_sub_item"
     paramsApp2["recommendid"] = "data@app_recommendid"
     actionAppRunner2:run("reportaction", paramsApp2, nil)

     if materialType == MATERIAL_TYPE_VIDEO then
        reportVideoExposure()
     else
        reportImageExposure()
     end
end

function reportVideoExposure()
    --Video的整体上报
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params = {}
    params["viewid"] = "video_view"
    params["dteventkey"] = "imp"
    params["param"] ="scene:data@scene,actionid:100,slotid:data@slotid,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params["extendparam"] = "report_element:video,report_context:data@report_context_sub_item,videoid:data@vid,uni_related_appid:data@appid,rsc_flag:1"
    params["recommendid"] = "data@card_recommendid"
    actionRunner:run("reportaction", params, nil)

    local actionRunner2 = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params2 = {}
    params2["param"] ="scene:data@scene,actionid:-100,slotid:data@slotid,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params2["extendparam"] = "report_element:video,report_context:data@report_context_sub_item,videoid:data@vid,uni_related_appid:data@appid,rsc_flag:1"
    params2["recommendid"] = "data@card_recommendid"
    actionRunner2:run("reportaction", params2, nil)
end

function reportVideoClick()

    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params = {}
    params["viewid"] = "video_view"
    params["dteventkey"] = "clck"
    params["param"] ="scene:data@scene,actionid:200,slotid:data@slotid,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params["extendparam"] = "report_element:video,report_context:data@report_context_sub_item,videoid:data@vid,uni_related_appid:data@appid,rsc_flag:1"
    params["recommendid"] = "data@card_recommendid"
    actionRunner:run("reportaction", params, nil)
end

function reportImageExposure()
    --Image的整体上报
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params = {}
    params["viewid"] = "image_view"
    params["dteventkey"] = "imp"
    params["param"] ="scene:data@scene,actionid:100,slotid:data@slotid,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params["extendparam"] = "report_element:image,report_context:data@report_context_sub_item,videoid:data@vid,uni_related_appid:data@appid,rsc_flag:1"
    params["recommendid"] = "data@card_recommendid"
    actionRunner:run("reportaction", params, nil)


    local actionRunner2 = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params2 = {}
    params2["param"] ="scene:data@scene,actionid:-100,slotid:data@slotid,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params2["extendparam"] = "report_element:image,report_context:data@report_context_sub_item,videoid:data@vid,uni_related_appid:data@appid,rsc_flag:1"
    params2["recommendid"] = "data@card_recommendid"
    actionRunner2:run("reportaction", params2, nil)

end

function reportImageClick()
    --Image的整体上报
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params = {}
    params["viewid"] = "image_view"
    params["dteventkey"] = "clck"
    params["param"] ="scene:data@scene,actionid:200,slotid:data@slotid,appid:data@appid,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params["extendparam"] = "report_element:image,report_context:data@report_context_sub_item,videoid:data@vid,uni_related_appid:data@appid,rsc_flag:1"
    params["recommendid"] = "data@card_recommendid"
    actionRunner:run("reportaction", params, nil)
end

function initButton(index)
    Rapid:setData("ordered", Rapid:getData("ordered_" .. index))

    local showBookingButton = Rapid:getData("show_booking_button_"..index, '0')
    if showBookingButton == "1" then 
        Rapid:getChild("download_button"):setAttr("visibility", "gone")
        pcall(setViewVisible,"booking_button","visible")
    else
        Rapid:getChild("download_button"):setAttr("visibility", "visible")
        pcall(setViewVisible,"booking_button","gone")
    end
end

function setViewVisible(id,visibility)
    if Rapid:getChild(id) == nil then
        return false
    end
    Rapid:getChild(id):setAttr("visibility", visibility)
end


function initVideoView()
        --非wifi下不自动播放
    if bigVideo:getView():canPlayCurrentNetworkEnvironment() then 
        bigVideo:getView():setAutoPlay(true)
    else
        bigVideo:getView():setAutoPlay(false)
    end
    local state_change_listener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerViewStateChangeListener", IPlayerViewStateChangeListener)

    local area_ratio_change_listener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerVisibleAreaRatioChangeListener", IPlayerVisibleAreaRatioChangeListener)
    if (bigVideo ~= nil and state_change_listener ~= nil and area_ratio_change_listener ~= nil) then
        bigVideo:getView():setPlayerViewStateChangeListener(state_change_listener)
        bigVideo:getView():setPlayerVisibleAreaChangeListener(area_ratio_change_listener)
    end
end


function unRegisteVideoView()
    --图文模式下不自动播放
    if (bigVideo ~= nil) then
        bigVideo:getView():setPlayerViewStateChangeListener(nil)
        bigVideo:getView():setPlayerVisibleAreaChangeListener(nil)
        bigVideo:getView():stop()
        bigVideo:getView():setAutoPlay(false)
    end
end

function decideIfHideAppArea(index)
    --如果没有app信息，则隐藏app视图
    local appid = tostring((Rapid:getData("appid")))
    if appid == "" then
        changeViewVisibility("score_text", "gone")
        changeViewVisibility("score_left_img", "gone")
        changeViewVisibility("download_button", "gone")
    else
        changeViewVisibility("score_text", "visible")
        changeViewVisibility("score_left_img", "visible")

        local showBookingButton = Rapid:getData("show_booking_button_"..index, '0')
        if showBookingButton ~= "1" then
            changeViewVisibility("download_button", "visible")
        end
    end
end


function decideIfHideScore()
    --如果评分信息小于3.6，则不展示评分信息

    mJavaBridge:Log("banner_video", "--tonumber--:")
    local score = tonumber(Rapid:getData("average_rating"))
    mJavaBridge:Log("banner_video", "--decideIfHideScore--:" .. score)
    if(score < 3.6) then
        changeViewVisibility("score_text", "gone")
        changeViewVisibility("score_left_img", "gone")
    else
        changeViewVisibility("score_text", "visible")
        changeViewVisibility("score_left_img", "visible")
    end
end

function changeViewVisibility(childViewId, state)
    Rapid:getChild(tostring(childViewId)):setAttr("visibility", tostring(state))
end