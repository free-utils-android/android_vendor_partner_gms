local mPhotonView, mJavaBridge = ...

local TAG = "lua_game_center_feeds_whitebar_card"

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")
    updateButton()
    updateLabel()
    updatePlayJumpUrl()
    updateGame()
end

function updateGame()
    local gameScoreIsShow = Rapid:getData('game_score_is_show', '0')
    if tostring(gameScoreIsShow) == '1' then
        Rapid:setData('visible_game_score', 'visible')
    else
        Rapid:setData('visible_game_score', 'gone')
    end
end

function getButton()
    local gameStatus = Rapid:getData("game_status")
    mJavaBridge:Log(TAG, "gameStatus: "..tostring(gameStatus))
    if gameStatus == "0" then
        mJavaBridge:Log(TAG, "下载按钮")
        return Rapid:getChild("download_button"):getView()
    elseif gameStatus == "1" then
        mJavaBridge:Log(TAG, "预约按钮")
        return Rapid:getChild("booking_button"):getView()
    elseif gameStatus == "2" then
        mJavaBridge:Log(TAG, "云玩按钮")
        return Rapid:getChild("cloud_play_button"):getView()
    end
    return nil
end

function updateButton()
    Rapid:getChild("download_button"):getView():setVisibility(8)
    Rapid:getChild("booking_button"):getView():setVisibility(8)
    Rapid:getChild("cloud_play_button"):getView():setVisibility(8)
    local button = getButton()
    if button ~= nil then
        button:setVisibility(0)
    end
end

function updateLabel()
    if Rapid:getData("game_label", "") == "" then
        Rapid:getChild("game_label_icon"):getView():setVisibility(8)
        Rapid:getChild("game_label"):getView():setVisibility(8)
        Rapid:getChild("rec_reason"):getView():setVisibility(0)
    else
        Rapid:getChild("game_label_icon"):getView():setVisibility(0)
        Rapid:getChild("game_label"):getView():setVisibility(0)
        Rapid:getChild("rec_reason"):getView():setVisibility(8)
    end
end

function updatePlayJumpUrl()
    Rapid:setData('cloud_game_jump_url', jumpUrlJoinRid(Rapid:getData('cloud_game_jump_url'), 
        Rapid:getData('app_recommendid')))
end

function jumpUrlJoinRid(jumpUrl, recommendid)
    if jumpUrl == nil or jumpUrl == "" then
        return jumpUrl
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendid), "default")
    if rcdBase64 ~= nil and rcdBase64 ~= "" then
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
        mJavaBridge:Log("jumpUrlJoinRid", 'jumpUrl: '..tostring(jumpUrl))
    end
    return jumpUrl
end