local mPhotonView, mJavaBridge = ...
local mGiftRecyclerView = nil
local mTomorrowecyclerView = nil
local mTomorrowContainner = nil
local CARD_WELFARE_TAG = "welfare_dialog"

local TYPE_BAOQUAN = "3"
local DEBUG = true

function close_dialog()
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:dismiss()
    end
end

function main()
    mGiftRecyclerView = Rapid:getChild("dialog_gift_rv")
    mTomorrowecyclerView = Rapid:getChild("tomorrow_gift_rv")
    mTomorrowContainner = mPhotonView:getParser():getChildView("tomorrow_container")
end

function updateData()
    refreshRecycleView()
    refreshTomorrowRecycleView()
end

function refreshRecycleView()
    local count = tonumber(Rapid:getData("item_count", "0"))

    mJavaBridge:Log("popWin", "count：" .. count)

    local viewNameList = {}
    local viewDataList = {}
    local index = count
    for i = 1, count do
        local itemData = Rapid:getData("item_data_" .. i)
        if itemData ~= nil then
            local strType = tostring(itemData["type"])
            local giftItemData = {}
            giftItemData["report_context"] = itemData["report_context"]
            giftItemData["platform_gift_id"] = itemData["platform_gift_id"]
            giftItemData["type"] = itemData["type"]
            giftItemData["name"] = itemData["name"]
            giftItemData["worth"] = tostring(itemData["worth"])
            giftItemData["desc"] = itemData["desc"]
            giftItemData["tag"] = itemData["tag"]
            giftItemData["icon_url"] = itemData["icon_url"]
            giftItemData["icon_color"] = itemData["icon_color"]
            giftItemData["title"] = itemData["title"]
            giftItemData["catogory"] = itemData["catogory"]
            giftItemData["return_url"] = itemData["return_url"]
            giftItemData["return_text"] = itemData["return_text"]
            giftItemData["gift_desc"] = itemData["gift_desc"]

            -- giftItemData["status"]  = itemData['status'])
            if strType == TYPE_BAOQUAN then
                giftItemData["gift_desc"]  = tostring(itemData['worth']) .. "元宝券"
                viewNameList[i] = "playing_mixed_app_detail_welfare_gift_detail_dialog_campaign_item_v2.xml"
                viewDataList[i] = giftItemData
            else
                viewNameList[i] = "playing_mixed_app_detail_welfare_gift_detail_dialog_normal_item_v2.xml"
                viewDataList[i] = giftItemData
            end 
        end
    end

    local signJson = Rapid:getData("sign_data")
    -- 签到的数据
    if signJson ~= nil then
        local signObj = mJavaBridge:create("jsonobject", signJson)
        if signObj ~= nil then
            local iconJson = mJavaBridge:create("jsonarray", signObj:optString("icon_url"))
            if iconJson ~= nil then
                count = count + iconJson:length()
                for i = 0, iconJson:length() - 1 do
                    local giftItemData = {}
                    giftItemData["report_context"] = signObj:optString("report_context")
                    giftItemData["platform_gift_id"] = signObj:optString("platform_gift_id")
                    giftItemData["type"] = signObj:optString("type")
                    giftItemData["name"] = iconJson:optJSONObject(i):optString("name")
                    giftItemData["worth"] = signObj:optString("worth")
                    giftItemData["desc"] = giftItemData["name"]
                    giftItemData["tag"] = signObj:optString("tag")
                    giftItemData["icon_url"] = iconJson:optJSONObject(i):optString("url")

                    giftItemData["title"] = signObj:optString("title")
                    giftItemData["catogory"] = signObj:optString("catogory")
                    viewNameList[i + index + 1] = "playing_mixed_app_detail_welfare_gift_detail_dialog_normal_item_v2.xml"
                    viewDataList[i + index + 1] = giftItemData
                    index = index + 1
                end
            end
        end
    end

    local future_count = tonumber(Rapid:getData("future_item_count", "0"))

    Rapid:setData("dialog_title", "恭喜获得" .. count .. "个礼包")
    if future_count == 0 then
        Rapid:setData("dialog_context", "记得在有效期内使用，明天再来看看其他福利吧！")
    else
        Rapid:setData("dialog_context", "福利记得在有效期内使用，还有" .. future_count .. "个福利待领取哦！")
    end

    Rapid:setData("dialog_cancel", "完成")
    mGiftRecyclerView:getView():clear()
    mGiftRecyclerView:getView():updateData(viewNameList, viewDataList)
end

function refreshTomorrowRecycleView()
    local tomorrow_count = tonumber(Rapid:getData("tomorrow_item_count", "0"))
    if tomorrow_count == 0 then
        mJavaBridge:Log("popWin", "mTomorrowContainner  gone")
        mTomorrowContainner:getView():setVisibility(8)
    else
        mTomorrowContainner:getView():setVisibility(0)
        mJavaBridge:Log("popWin", "mTomorrowContainner visible ")
    end

    local viewNameList = {}
    local viewDataList = {}

    mJavaBridge:Log("popWin", "tomorrow_count:" .. tomorrow_count)

    for i = 1, tomorrow_count do
        local itemData = Rapid:getData("tomorrow_item_data_" .. i)
        if itemData ~= nil then
            local tomorrowItem = {}
            tomorrowItem["icon_url"] = itemData["icon_url"]
            tomorrowItem["icon_name"] = itemData["icon_name"]
            viewNameList[i] = "playing_mixed_app_detail_welfare_gift_detail_dialog_toworrow_item_v2.xml"
            viewDataList[i] = tomorrowItem
        end
    end

    mTomorrowecyclerView:getView():clear()
    mTomorrowecyclerView:getView():updateData(viewNameList, viewDataList)
end
