local mPhotonView, mJavaBridge = ...



function fillValue()
 
    local outerIndex = tonumber(mPhotonView:getParser():getBinder():get('position'))
    if outerIndex == nil then
        outerIndex = tonumber(mPhotonView:getParser():getBinder():get('index'))
    end

    mRecyclerView = mPhotonView:getParser():getChildView('recycler_view')
 

    updateValue()
end

function updateValue()
    local subViewName = 'native_search_horizontal_rank_list_card_list_item.xml'
    local viewNameList = {}
    local dataList = {}
    local num = tonumber(mPhotonView:getParser():getBinder():get('item_count'))

    local scene = mPhotonView:getParser():getBinder():get('scene')
    local sourcescene = mPhotonView:getParser():getBinder():get('sourceScene')
    local modeltype = mPhotonView:getParser():getBinder():get('modelType')
    local slotId = mPhotonView:getParser():getBinder():get('slotId')
    local contentId = mPhotonView:getParser():getBinder():get('contentId')
    local queryWord = mPhotonView:getParser():getBinder():get('queryWord')
    local sourceQuery = mPhotonView:getParser():getBinder():get('sourceQuery')
    local tagName = mPhotonView:getParser():getBinder():get('tagName')
    local searchId = mPhotonView:getParser():getBinder():get('searchId')
    local sourceSceneSlotId = mPhotonView:getParser():getBinder():get('sourceSceneSlotId')
    local searchScene = mPhotonView:getParser():getBinder():get('searchScene')
    local topUrl = mPhotonView:getParser():getBinder():get('top_url')
    local topUrlArray = {};

    local searchSession = mPhotonView:getParser():getBinder():get('searchsession')

    if topUrl ~= nil then
        topUrlArray = splitString(topUrl)
    end


    for i = 0, num - 1 do
        local index = i + 1
        local itemData = mPhotonView:getParser():getBinder():get('item_data_' .. index)

        itemData:put('scene', mJavaBridge:create('var', scene))
        itemData:put('sourceScene', mJavaBridge:create('var', sourcescene))
        itemData:put('modelType', mJavaBridge:create('var', modeltype))
        itemData:put('slotId', mJavaBridge:create('var', slotId))
        itemData:put('searchScene', mJavaBridge:create('var', searchScene))
        
        itemData:put('topTagUrl', mJavaBridge:create('var', topUrlArray[index]))
        
        
        local operation_text = itemData:get('operation_text');
        itemData:put('operation_text',mJavaBridge:create('var', tableToString(splitString(operation_text:getString()))))
       

        itemData:put('queryWord', mJavaBridge:create('var', queryWord))
        itemData:put('searchId', mJavaBridge:create('var', tostring(searchId)))
        if sourceQuery ~= nil then
            itemData:put('sourceQuery', mJavaBridge:create('var', sourceQuery))
        end
      
        itemData:put('sourceSceneSlotId', mJavaBridge:create('var', sourceSceneSlotId))
      
        itemData:put('searchsession', mJavaBridge:create('var', tostring(searchSession)))

        itemData:put('subPosition', mJavaBridge:create('var', tostring(index)))
        -- 设置曝光flag
        mRecyclerView:getView():setViewShowFlag(i, 'view_show_flag' .. i)
        dataList[index] = itemData
        viewNameList[index] = subViewName
    end
    mRecyclerView:getView():clear()
    mRecyclerView:getView():updateData(viewNameList, dataList)
end

-- 分割字符串，“1|2|3|4”
function splitString(str)
    if (str == nil or str == "") then
        return {}
    end
    local last_start = 1
    local single_str = nil
    local index = 1
    local res = {}
    for k = 1, string.len(str) do
        if string.sub(str, k, k) == '|' then
            if (last_start < k) then
                single_str = string.sub(str, last_start, k - 1)
                res[index] = single_str
                index = index + 1
            end
            last_start = k + 1
        end
    end
    -- 不以 | 结尾，需要把最后的 type 计算进来
    if (last_start <= string.len(str)) then
        single_str = string.sub(str, last_start, string.len(str))
        res[index] = single_str
        index = index + 1
    end
    return res
end
-- tabel转成字符串，value之间空格拼接
function tableToString( str )
    local result = ""
    if (str == nil or str == "") then
        return result
    end
    for key, value in ipairs(str) do
        result = result..value.." "
    end
    -- 去除头尾空格
    return result:match("^[%s]*(.-)[%s]*$")
end

