local mPhotonView, mJavaBridge = ...

local mRv = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil
local mRid = nil

function main()
    mRv = mPhotonView:getParser():getChildView('rv')
end

function updateData()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    mRid = Rapid:getData("recommend_card")

    local dataList = {}
    local viewList = {}
    local itemCount = tonumber(Rapid:getData('item_num', '0'))
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        fillItemData(itemData, i)
        
        dataList[i] = itemData
        viewList[i] = 'novel_tab_categary_card_item.xml'
    end
    mRv:getView():updateData(viewList, dataList, true)
end

function fillItemData(itemData, index)
    if itemData == nil then
        return
    end

    putBaseReportText(itemData)
    putMapData(itemData, 'subPosition', index)
    if index <= 3 then
        putMapData(itemData, 'marginTop', 0)
    else
        putMapData(itemData, 'marginTop', 10)
    end
end

function putBaseReportText(mapData)
    putMapData(mapData, "scene", mScene)
    
    putMapData(mapData, "sourcescene", mSourcescene)
    putMapData(mapData, "sourceScene", mSourcescene)
    
    putMapData(mapData, "modeltype", mModeltype)
    putMapData(mapData, "modelType", mModeltype)
    
    putMapData(mapData, "sourcesceneslotid", mSourceslotid)
    putMapData(mapData, "sourceSceneSlotId", mSourceslotid)
    
    putMapData(mapData, "slotid", mSlotid)
    putMapData(mapData, "slotId", mSlotid)
    
    putMapData(mapData, "recommend_card", mRid)
end

function putMapData(map, key, value)
    if ((map ~= nil) and (key ~= nil) and (value ~= nil)) then
        local var = mJavaBridge:create("var", value)
        map:put(key, var)
    end
end