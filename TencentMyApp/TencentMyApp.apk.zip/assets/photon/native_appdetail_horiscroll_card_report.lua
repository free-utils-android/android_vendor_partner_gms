local mPhotonView, mJavaBridge = ...

function reportPosition(position)
    local slotId = mPhotonView:getParser():getBinder():get('newSlotId')
    --从第五个app以后开始上报，前五个当卡片滚动显示出来时一起曝光
    if (position ~= nil and tonumber(position) > 5) then
        local slotNewId = slotId .. '_-1'
        local data = {}
        data['param'] =
            'slotid:' ..
            slotNewId ..
                ',actionid:100,subposition:' ..
                    position ..
                        ',scene:data@scene,sourcescene:data@sourceScene,sourcesceneslotid:data@sourceSceneSlotId,appid:data@item_appId,searchid:0,packagename:data@packagename'
        data['recommendid'] = 'data@recommendid'
        mPhotonView:getParser():getTaskCenter():getActionRunner():run('reportaction', data, data)
    end
end
