local mPhotonView,mJavaBridge = ...


function main()
    local recyclerView = mPhotonView:getParser():getChildView('recyclerview') 
    recyclerView:getView():getLayoutManager():setOrientation(0)
end