local mPhotonView,mJavaBridge = ...

function updateValue()
    local downloadBtnStr = mPhotonView:getParser():getBinder():get("update_button_text")
    local downloadingBtnStr= mPhotonView:getParser():getBinder():get("updating_buttontext")
    local downloadedBtnStr = mPhotonView:getParser():getBinder():get("install_buttontext")
    local buttonStr = 'update:'..tostring(downloadBtnStr)..',downloading:'..tostring(downloadingBtnStr)..',downloaded:'..tostring(downloadedBtnStr)
    Rapid:getChild("down_load_btn"):setAttr("textmap", tostring(buttonStr))

    local  version_name = mPhotonView:getParser():getBinder():get("version_name")
    local  buildno = mPhotonView:getParser():getBinder():get("build_no")
    Rapid:getChild("down_load_btn"):setAttr("extendparam", 'uni_target_app_version:'..tostring(version_name)..'_'..tostring(buildno))

    local  cancleButtonStyle = mPhotonView:getParser():getBinder():get("cancel_button_position")
    local  force = mPhotonView:getParser():getBinder():get("force")
    if force ~= '1' then
        if cancleButtonStyle == '1' then
            mPhotonView:getParser():getChildView("close_right"):getView():setVisibility(0)
        else
            mPhotonView:getParser():getChildView("close_buttom"):getView():setVisibility(0)
        end
    else
        mPhotonView:getParser():getChildView("exitButton"):getView():setVisibility(0)
    end


    local  banndericon = mPhotonView:getParser():getBinder():get("pic_url")
    if (banndericon == nil or banndericon == '' or #banndericon < 20 ) then
        mPhotonView:getParser():getChildView("banndericon"):getView():setVisibility(8)
    end

end

function closepage( ... )
    mJavaBridge:finish()
    mJavaBridge:updatePopTimeInfo();
    local  from_exit_dialog = mPhotonView:getParser():getBinder():get("from_exit_dialog")
    if from_exit_dialog == '1' then
        mJavaBridge:appExit()
    end
end

function exitapp( ... )
    mJavaBridge:appExit()
end

function writeClipboard()
    local  need_clipboard = mPhotonView:getParser():getBinder():get("need_clipboard")
    local  clipboard_content = mPhotonView:getParser():getBinder():get("clipboard_content")
    if need_clipboard == '1' then
        local Context = luajava.bindClass('android.content.Context')
        local ClipData = luajava.bindClass('android.content.ClipData')
        local mClipboardManager = mPhotonView:getParser():getContext():getSystemService(Context.CLIPBOARD_SERVICE)
        mClipboardManager:setPrimaryClip(ClipData:newPlainText('Label', clipboard_content))
    end
end
