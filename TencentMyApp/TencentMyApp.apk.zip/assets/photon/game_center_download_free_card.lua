local mPhotonView, mJavaBridge = ...

local TAG = "lua_game_center_download_free_card"

local mRecyclerView

-- 检查是否有nil
function checkNil(...)
    local args = {...}
    for i = 1, select("#", ...) do
        if args[i] == nil then
            return true
        end
    end
    return false
end

function getPositionString(position)
    return string.format("%03d", position)
end

function queryData(start, params, fine)
    local data = {}
    if type(params) ~= 'table' then
        return data
    end
    if start == nil then
        start = ''
    end
    if fine == nil then
        fine = ''
    end
    for k, v in pairs(params) do
        data[k] = Rapid:getData(start..k..fine, v)
    end
    return data
end

function queryItemData(start, params)
    local data = {}
    if type(params) ~= 'table' then
        return data
    end
    if start == nil then
        start = ''
    end
    local itemData = Rapid:getData(start)
    if type(itemData) ~= 'userdata' then
        return data
    end
    for k, v in pairs(params) do
        data[k] = itemData:get(k):getLuaValue()
        if data[k] == nil then
            data[k] = v
        end
    end
    return data
end

-- 填充数据
function fillData(data, params, keys)
    if type(data) ~= 'table' or type(params) ~= 'table' then
        return
    end
    if keys == nil then
        for k, v in pairs(params) do
            data[k] = v
        end
    elseif type(keys) == 'table' then
        for i, key in pairs(keys) do
            if type(key) == 'string' then
                data[key] = params[key]
            end
        end
    end
end

function jumpUrlJoinRid(jumpUrl, recommendid)
    if jumpUrl == nil or jumpUrl == "" then
        return jumpUrl
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendid), "default")
    if rcdBase64 ~= nil and rcdBase64 ~= "" then
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
        mJavaBridge:Log(TAG, 'jumpUrl: '..tostring(jumpUrl))
    end
    return jumpUrl
end

function onItemData(data, itemCount, index, itemData)
    itemData['subposition'] = getPositionString(index)
    if index == 1 then
        itemData['marginleft'] = 16
    else
        itemData['marginleft'] = 10
    end
    if index == itemCount then
        itemData['marginright'] = 16
    else
        itemData['marginright'] = 10
    end
    fillData(itemData, data, {
        'modeltype',
        'scene',
        'slotid',
        'sourcescene',
        'sourcesceneslotid',
        'sourcemodeltype',
    })
    itemData['jump_url'] = jumpUrlJoinRid(itemData['jump_url'], itemData['recommendid'])
end

-- 填充视图和数据
function fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    if checkNil(viewNameList, dataList, params, queries, itemQueries) then
        return
    end
    if checkNil(params['view_name'], params['item_count_name']) then
        return
    end

    fillData(queries, {
        ['modeltype'] = '',
        ['scene'] = '',
        ['slotid'] = '',
        ['sourcescene'] = '',
        ['sourcesceneslotid'] = '',
        ['sourcemodeltype'] = '',
        [params['item_count_name']] = 0,
    })

    local data = queryData('', queries, '')
    local itemCount = tonumber(data[params['item_count_name']])
    if itemCount == nil or itemCount <= 0 then
        return
    end

    for i = 1, itemCount do
        table.insert(viewNameList, params['view_name'])
        local itemData = queryItemData('item_data_'..i, itemQueries)
        onItemData(data, itemCount, i, itemData)
        table.insert(dataList, itemData)
    end
end

function insuranceData(key)
    if Rapid:getData(key) == nil then
        Rapid:setData(key, -1)
    end
end

-- 防止source相关的上报字段为空时,大同上报在oma下的问题
function insuranceOmaSource()
    insuranceData('sourcemodeltype')
    insuranceData('sourcesceneslotid')
end

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")
    mRecyclerView = Rapid:getChild('recycler_view')
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")
    insuranceOmaSource()
    
    local viewNameList = {}
    local dataList = {}
    local params = {
        ['view_name'] = 'game_center_download_free_card_item.xml',
        ['item_count_name'] = 'item_num',
    }
    local queries = {
        [params['item_count_name']] = 0,
    }
    local itemQueries = {
        ['app_icon_url'] = '',
        ['jump_url'] = '',
        ['game_detail_jump_url'] = '',
        ['app_name'] = '',
        ['appid'] = '',
        ['app_model'] = '',
        ['report_context'] = '',
        ['recommendid'] = '',
    }
    fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    mRecyclerView:getView():updateData(viewNameList, dataList, true)
end