local mPhotonView, mJavaBridge = ...

local name = nil
local selectView = nil
local unSelectView = nil

local unSelectHotView = nil
local selectHotView = nil

function init( ... )
    name = Rapid:getChild("name")

    selectView = Rapid:getChild("select")
    unSelectView = Rapid:getChild("unselect")

    unSelectHotView = Rapid:getChild("unselect_hot")
    selectHotView = Rapid:getChild("select_hot")
end

function afterUpdateData( ... )
    if Rapid:getData("is_select","0") == "1" then
        select()
    else
        unselect()
    end
end

function select( ... )
    local heroId = Rapid:getData("hero_id","0")
    if heroId == "-1" then
        unSelectHotView:setAttr("visibility","invisible")
        selectView:setAttr("visibility","invisible")
        unSelectView:setAttr("visibility","invisible")
        selectHotView:setAttr("visibility","visible")
    else
        unSelectHotView:setAttr("visibility","invisible")
        selectView:setAttr("visibility","visible")
        unSelectView:setAttr("visibility","invisible")
    end
    name:setAttr("textstyle","bold")
    if Rapid:getData("is_select","0") == "1" then
        return
    end
    Rapid:setData("is_select","1")
    notifyClickHero()
end

function notifyClickHero( ... )
    local param = {}
    param["key"] = "click_hero"
    param["value"] = tostring(Rapid:getData("hero_group"))..","..tostring(Rapid:getData("hero_id","-1"))..","..tostring(Rapid:getData("index"))
    Rapid:execAction("outeraction", param, param)
end

function unselect( ... )
    Rapid:setData("is_select","0")
    local heroId = Rapid:getData("hero_id","0")
    if heroId == "-1" then
        selectHotView:setAttr("visibility","invisible")
        unSelectHotView:setAttr("visibility","visible")
        selectView:setAttr("visibility","invisible")
        unSelectView:setAttr("visibility","invisible")
    else
        unSelectHotView:setAttr("visibility","invisible")
        selectView:setAttr("visibility","invisible")
        unSelectView:setAttr("visibility","visible")
    end
    name:setAttr("textstyle","normal")
end