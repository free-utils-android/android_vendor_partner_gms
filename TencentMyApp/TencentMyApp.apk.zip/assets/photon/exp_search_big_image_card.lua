local mPhotonView, mJavaBridge = ...

local TAG = "lua_exp_search_big_image_card"

local function jumpAppDetailByUrl(jumpUrl)
    local param = {
        ["tmast"] = jumpUrl,
        ["extra"] = "sourcemodeltype:data@modeltype,searchsession:data@searchsession"
    }
    Rapid:execAction("tmastaction", param, param)
end

local function jumpAppDetailByAppModel()
    local param = {
        ["appsimpledetail"] = "data@app_model",
        ["pageid"] = "data@scene",
        ["sourceslot"] = "data@slotid",
        ["sourceslotsubposition"] = "001",
        ["searchid"] = "data@searchId",
        ["orderurl"] = "data@order_jump_url",
        ["extradata"] = "data@queryWord",
        ["modeltype"] = "data@modeltype",
        ["extra"] = "searchsession:data@searchsession",
        ["extendparam"] = "report_context:data@app_report_context,searchquery:data@queryWord,sourcequery:data@sourceQuery,search_scene:data@searchScene"
    }
    Rapid:execAction("jumpappdetailaction", param, param)
end

function jumpAppDetail()
    local appJumpUrl = Rapid:getData("app_jump_url")
    if appJumpUrl ~= nil and appJumpUrl ~= "" then
        jumpAppDetailByUrl(appJumpUrl)
    else
        jumpAppDetailByAppModel()
    end
end

function updateAppState() 
    local appModel = Rapid:getData("app_model")
    if appModel == nil then
        return nil
    end
    local appState = mJavaBridge:getAppState(appModel)
    Rapid:setData('buttonstatus', appState)
end

function jumpAction(tmast)
    local params = {}
    params["tmast"] = tmast
    Rapid:execAction("tmastaction", params, nil)
end

function trialJump()
    updateAppState()
    jumpAction(Rapid:getData('cloud_play_jump'))
end

function afterUpdateData()
    updateAppState()
    updateCloudBar()
end

function updateCloudBar()
    Rapid:getChild('cloud_play_container'):setAttr('visibility', 'gone')
    local showCloudBar = Rapid:getData('show_cloud_bar', '')
    if showCloudBar ~= '1' then
        return
    end
    local showCloudBar = Rapid:getData('cloud_play_enable', '')
    if showCloudBar ~= '1' then
        return
    end
    Rapid:getChild('cloud_play_container'):setAttr('visibility', 'visible')
end