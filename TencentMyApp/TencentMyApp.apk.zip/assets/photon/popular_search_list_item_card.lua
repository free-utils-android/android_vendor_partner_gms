local mPhotonView,mJavaBridge = ...


-- 热词点击跳转
function hotWordClick(i)
    local subposition = Rapid:getData("subPosition")
    local slotId = Rapid:getData("slotid")
    local actionUrl = Rapid:getData("tmast_" .. i, "")

    if (actionUrl == "") then
        local recommendId = Rapid:getData("hot_word_recommendid_" .. i)
        local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendId), "default")
        local hotWord = Rapid:getData("search_word_" .. i)

        local tmast = "tmast://search?key=" .. tostring(hotWord) .. "&sourceScene=2007&searchScene=200702&sourceSlotId=" .. tostring(slotId) .. "&subPosition=" .. subposition
        if(rcdBase64 ~= nil) then
            tmast = tmast.."&recommendId="..mJavaBridge:urlEncode(rcdBase64)
        end
        local params = {}
        params["tmast"] = tmast
        Rapid:execAction("tmastaction", params, nil)
    else
        local uri = luajava.bindClass('android.net.Uri')
        uri = uri:parse(actionUrl)
        if (uri:getScheme() == "tmast" or uri:getScheme() == "http" or uri:getScheme() == "https") then
            local data = {}
            data["tmast"] = uri:toString()
            mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", data, data)
        end
    end
end