local mPhotonView, mJavaBridge = ...


function updateData()
    local selected = tostring(Rapid:getData('is_selected', 'false'))
    if selected == 'true' then
        Rapid:getChild('tv_rank'):setAttr('textcolor', 'd9000000')
        Rapid:getChild('tv_rank'):setAttr('textsize', '18')
        Rapid:getChild('tv_rank'):setAttr('textstyle', 'bold')
    else
        Rapid:getChild('tv_rank'):setAttr('textcolor', '73000000')
        Rapid:getChild('tv_rank'):setAttr('textsize', '14')
        Rapid:getChild('tv_rank'):setAttr('textstyle', 'normal')
    end
end

-- 点击了榜单
function clickRank()
    local callbackObj = Rapid:getData('callback')
    if callbackObj == nil then
        return
    end
    local index = Rapid:getData('rank_index')
    callbackObj.onClickRank(index)
end