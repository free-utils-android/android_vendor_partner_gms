local mPhotonView, mJavaBridge = ...

local isSelected = false
local selectView = nil
local unSelectView = nil
local unSelectHot = nil
local TAG = "HRMMMMM"

local UNSELECT_HOT_URL = "https://cms.myapp.com/yyb/2022/06/10/1654853608560_d0625c539274247b682cfc4d27635ecd.png"
local SELECT_HOT_URL = "https://cms.myapp.com/yyb/2022/06/10/1654853636360_23193351ab192a7a5ce050c811aa9595.png"

function init( ... )
    selectView = Rapid:getChild("select")
    unSelectView = Rapid:getChild("unselect")
    unSelectHot = Rapid:getChild("unselect_hot")
end

function afterUpdateData( ... )
    local heroId = Rapid:getData("hero_id","0")
    if heroId ~= "-1" then
        return
    end
    if isSelected then
        Rapid:setData("hero_avator", SELECT_HOT_URL)
    else
        Rapid:setData("hero_avator", UNSELECT_HOT_URL)
        unSelectView:setAttr("visibility","gone")
        unSelectHot:setAttr("visibility","visible")
    end
end

function select( ... )
    if isSelected then
        return
    end
    isSelected = true
    local heroId = Rapid:getData("hero_id","0")
    if heroId == "-1" then
        Rapid:setData("hero_avator", SELECT_HOT_URL)
    end
    selectView:setAttr("visibility","visible")
    unSelectView:setAttr("visibility","gone")
    unSelectHot:setAttr("visibility","gone")
    saveSelectHeroInfo()
    -- 首次选中不需要提醒,否则会导致页面刷新,陷入循环
    if not Rapid:getData("isFromBindViewHolder", false) then
        notifyClickHero()
        -- 上报点击
        reportClick()
    end
end

function notifyClickHero( ... )
    local param = {}
    param["key"] = "click_hero"
    param["value"] = Rapid:getData("hero_id","-1")
    Rapid:execAction("outeraction", param, param)
end

function unselect( ... )
    if not isSelected then
        return
    end
    isSelected = false
    selectView:setAttr("visibility","gone")
    unSelectView:setAttr("visibility","visible")
    local heroId = Rapid:getData("hero_id","0")
    if heroId == "-1" then
        Rapid:setData("hero_avator", UNSELECT_HOT_URL)
        unSelectView:setAttr("visibility","gone")
        unSelectHot:setAttr("visibility","visible")
    end
end

function saveSelectHeroInfo( ... )
    if Rapid:getData("hero_group") == nil then
        return
    end
    -- 如果是点击热门标签清空缓存数据
    if Rapid:getData("hero_id","") == "-1" then
        mJavaBridge:removeMemoryCache("endgames_hero_group")
        mJavaBridge:removeMemoryCache("endgames_hero_id")
    else
        mJavaBridge:putToMemoryCache("endgames_hero_group", Rapid:getData("hero_group"))
        mJavaBridge:putToMemoryCache("endgames_hero_id", Rapid:getData("hero_id"))
    end
end

function reportClick( ... )
    local data = {}
    data["param"] = "slotid:data@slotid,subposition:data@subposition,scene:data@scene,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,sourcemodeltype:data@sourcemodeltype"
        ..",modeltype:data@modeltype,appid:0,actionid:250"
    data["extendparam"] ="is_register:data@is_register,is_authorized:data@is_authorized,report_context:data@report_context,elementid:avatar"
    data["reportelement"] = "avatar"
    data["recommendid"] = "data@recommendid"
    data["dteventkey"] = "clck"
    data["viewid"] = "hero"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, nil)
end