local mPhotonView, mJavaBridge = ...

function contentClick()
    local install = mPhotonView:getParser():getBinder():get('xp_exit_remind_install_first')
    if (install ~= nil and install == true) then
        local params = {}
        params['key'] = 'install_app'
        params['value'] = ''
        mPhotonView:getParser():getTaskCenter():getActionRunner():run('outeraction', params, nil)
        -- 将deepLink写到剪切板
        local deepLink = mPhotonView:getParser():getBinder():get('deep_link')
        if (deepLink ~= nil and deepLink ~= '') then
            writeClipboard(deepLink)
        end
    else
        mPhotonView:getParser():getTaskCenter():run('jump_tmast')
    end
end

-- 通用能力：写剪切板，方便微视启动时跳转指定界面
function writeClipboard(deepLink)
    local Context = luajava.bindClass('android.content.Context')
    local ClipData = luajava.bindClass('android.content.ClipData')
    local mClipboardManager = mPhotonView:getParser():getContext():getSystemService(Context.CLIPBOARD_SERVICE)
    -- 为什么要加个后缀?因为不加后缀微视不解析，理论上应该设计的足够通用，以后别人接就方便些，不知道他们怎么想的......
    mClipboardManager:setPrimaryClip(ClipData:newPlainText('Label', deepLink .. '&from=yyb-converge-traffic'))
end
