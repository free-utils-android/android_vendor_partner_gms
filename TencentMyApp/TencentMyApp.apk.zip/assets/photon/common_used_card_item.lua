local mPhotonView, mJavaBridge = ...

local UI_EVENT_ONESHOT_CLEAN_CAL_SCORE_END = 1363
--这里改成获取userinfo的时机，而不是微信登录的时机
local UI_EVENT_GET_WXLOGIN_SUCCESS = 1084
local UI_EVENT_GET_WXLOGIN_FAIL = 1089
local FOCUS_ITEM_TYPE = "8"
local TAG = "common_used_gird_card_item"
local uiListener
local jumpUrlReplace = "https://www.qq.com"
local jumpUrlOri = ""
local LOGIN_STATE_CLICKED = 1
local LOGIN_STATE_WX_LOGIN = 2
local LOGIN_STATE_GET_WX_ACCOUNT = 3

function initItem()

    local function_id = Rapid:getData("function_id")
    if (function_id  ~= FOCUS_ITEM_TYPE) then
        return
    end
    uiListener = luajava.createProxy("com.tencent.assistant.event.listener.UIEventListener", UIEventListener)
    mJavaBridge:addUIEventListener(UI_EVENT_ONESHOT_CLEAN_CAL_SCORE_END, uiListener)
    mJavaBridge:addUIEventListener(UI_EVENT_GET_WXLOGIN_SUCCESS, uiListener)
    mJavaBridge:addUIEventListener(UI_EVENT_GET_WXLOGIN_FAIL, uiListener)
    if getClickLoginState() == LOGIN_STATE_WX_LOGIN then
        setClickLoginState(0)
    end
    mJavaBridge:calcFinalScoreAsync(nil)
    if getClickLoginState() ~= 1 then
        mPhotonView:getParser():getBinder():update("subtitle", "")
    end
    jumpUrlOri = Rapid:getData("jump_url")
end

function refreshData()
    mJavaBridge:Log("AccountSecurityManager", "--lua--get score:refreshData:" )
    local function_id = Rapid:getData("function_id")
    if (function_id ~= FOCUS_ITEM_TYPE) then
        return
    end
    local subTitle = ""
    --账号检测8
    -- 安全扫描的上次扫描时间
    local securityState = getAccountSecurityState()
    mJavaBridge:Log("AccountSecurityManager", "--lua--get score:refreshData---1---0--:" .. securityState )
    subTitle = getSubTitle(securityState)
    --mJavaBridge:Log("AccountSecurityManager", "--lua--get score:refreshData---1:" .. subTitle )
    mPhotonView:getParser():getBinder():update("subtitlenum", "")

    local day = mJavaBridge:getNormalSettingsData("account_detect_days", "30")
    subTitle = string.gsub(subTitle, "${size}", day)
    mJavaBridge:Log("AccountSecurityManager", "--lua--get score:refreshData---2:" .. getClickLoginState() )
    if getClickLoginState() ~= 2 then
        mPhotonView:getParser():getBinder():update("subtitle", subTitle)
        mJavaBridge:Log("AccountSecurityManager", "--lua--get score:refreshData---3:" .. getClickLoginState() )
    end


    if (securityState == 3) then
        mPhotonView:getParser():getBinder():update("jump_url", "tmast://login?logintype=0")
        return
    end
    mPhotonView:getParser():getBinder():update("jump_url", getJumpUrl(jumpUrlOri))
end

function onResume()
    mJavaBridge:Log("AccountSecurityManager", "--lua--get score:onResume:" ..  getClickLoginState())
end

function getSubTitle(securityState)
    if (securityState == 0) then
        return Rapid:getData("item_sub_title_3")
    elseif (securityState == 1) then
        return Rapid:getData("item_sub_title_4")
    elseif (securityState == 2) then
        return Rapid:getData("item_sub_title_5")
    elseif (securityState == 3) then
        return Rapid:getData("item_sub_title")
    elseif (securityState == 4) then
        return Rapid:getData("item_sub_title_2")
    end
    return ""
end

--获取账号安全信息状态
--0:30天内检测过，并无风险--不扣分
--1:30天内检测过，有风险未排除--扣分
--2:表示30天内并未检测过--扣分
--3:未登录---扣分
--4:从未检测过---扣分
--5:数据还未准备好
--6:QQ登录
--其中 30天为默认值，可以后台下发
function getAccountSecurityState()
    return mJavaBridge:getAccountSecurityState()
end

UIEventListener = {}
function UIEventListener.handleUIEvent(message)
    if message.what == UI_EVENT_ONESHOT_CLEAN_CAL_SCORE_END then
        local scoreMessage = message.arg1
        refreshData()
        mJavaBridge:Log("AccountSecurityManager", "--lua--get score:CAL_SCORE:1----")
        if getClickLoginState() == LOGIN_STATE_WX_LOGIN then
            setClickLoginState(LOGIN_STATE_GET_WX_ACCOUNT)
            mJavaBridge:Log("AccountSecurityManager", "--lua--get score:CAL_SCORE:2----")
            goAccountRiskH5(jumpUrlOri)
        end

    end
    if message.what == UI_EVENT_GET_WXLOGIN_SUCCESS then
        mJavaBridge:Log("AccountSecurityManager", "--lua--get score:WXLOGIN:1----" .. getClickLoginState())
        if getClickLoginState() == LOGIN_STATE_CLICKED then
            setClickLoginState(LOGIN_STATE_WX_LOGIN)
            mJavaBridge:calcFinalScoreAsync(nil)
        end
    end
    if message.what == UI_EVENT_GET_WXLOGIN_FAIL then
        if getClickLoginState() == LOGIN_STATE_CLICKED then
            setClickLoginState(0)
        end
    end
end

function goAccountRiskH5(jumpUrlOrigin)
    local params = {}
    local lastJump = getJumpUrl(jumpUrlOrigin)
    if lastJump == "" then 
        --send_toast("微信登录态失效，请重新登录后再试")
        setClickLoginState(LOGIN_STATE_WX_LOGIN)
        mJavaBridge:Log("AccountSecurityManager", "--lua--get score:goAccountRiskH5:null----")
        return
    end
    local URLEncoder = luajava.bindClass('java.net.URLEncoder')
    lastJump = URLEncoder:encode(lastJump)
    lastJump = "tmast://webview?url=" .. lastJump .. "&navStyle=1&navStyleMaskStyle=1&showTitleWhenTrans=1"
    params['tmast'] = lastJump
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil) 
    mJavaBridge:setAccountSecurityCheckTime()
end

function getJumpUrl(jumpUrlOrigin)
    local res = mJavaBridge:getAccountSecurityRes()
    if res == nil or res.jumpUrl == nil then
        if getClickLoginState() == LOGIN_STATE_GET_WX_ACCOUNT then
            setClickLoginState(LOGIN_STATE_WX_LOGIN)
        end
        mJavaBridge:Log("AccountSecurityManager", "--lua--get score:getJumpUrl:null")
    else 
        local jumpUrlRight = string.gsub(res.jumpUrl, jumpUrlReplace, "")
        local jumpUrl = jumpUrlOrigin .. jumpUrlRight .. mJavaBridge:getAccountExInfo()
        mJavaBridge:Log("AccountSecurityManager", "--lua--get score:getJumpUrl:ok:" .. jumpUrl)
        return jumpUrl
    end
    mJavaBridge:Log("AccountSecurityManager", "--lua--get score:getJumpUrl:null--2--")
    return ""
end

function onDestory()
    if (uiListener  ~= nil) then
        mJavaBridge:removeUIEventListener(UI_EVENT_ONESHOT_CLEAN_CAL_SCORE_END, uiListener)
        mJavaBridge:removeUIEventListener(UI_EVENT_GET_WXLOGIN_SUCCESS, uiListener)
        mJavaBridge:removeUIEventListener(UI_EVENT_GET_WXLOGIN_FAIL, uiListener)
    end
    if getClickLoginState() == LOGIN_STATE_WX_LOGIN then
        setClickLoginState(0)
    end
end

function onPause()
    if (uiListener  ~= nil) then
        mJavaBridge:removeUIEventListener(UI_EVENT_ONESHOT_CLEAN_CAL_SCORE_END, uiListener)
    end
    if getClickLoginState() == LOGIN_STATE_WX_LOGIN then
        setClickLoginState(0)
    end
end

function itemClick()
    local function_id = Rapid:getData("function_id")
    if (function_id  ~= FOCUS_ITEM_TYPE) then
        return
    end


    if getAccountSecurityState() == 3 then
        setClickLoginState(LOGIN_STATE_CLICKED)
        return
    end
    mJavaBridge:setAccountSecurityCheckTime()
    local lastJump = getJumpUrl(jumpUrlOri)
    mJavaBridge:Log("AccountSecurityManager", "--lua--get score:lastJump000:" ..  lastJump)
    if lastJump == "" then 
        send_toast("微信登录态失效，请重新登录后再试")
        mPhotonView:getParser():getBinder():update("jump_url", "")
        return
    end

    local URLEncoder = luajava.bindClass('java.net.URLEncoder')
    lastJump = URLEncoder:encode(lastJump)
    lastJump = "tmast://webview?url=" .. lastJump .. "&navStyle=1&navStyleMaskStyle=1&showTitleWhenTrans=1"
    mPhotonView:getParser():getBinder():update("jump_url", lastJump)

    mJavaBridge:Log("AccountSecurityManager", "--lua--get score:lastJump:" ..  lastJump)
end



function setClickLoginState(state)
    mJavaBridge:setSettingsDataAsync("ass_account_click_state", state)
end

function getClickLoginState()
    return tonumber(mJavaBridge:getSettingsData("ass_account_click_state", "0"))
end

function send_toast(text)
    local toastData = {}
    toastData["value"] = text
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("toastaction", toastData, nil)
end