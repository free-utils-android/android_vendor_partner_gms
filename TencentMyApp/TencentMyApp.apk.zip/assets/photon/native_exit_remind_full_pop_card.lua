local mPhotonView, mJavaBridge = ...

local mContainer

function fillValue()
    mContainer = mPhotonView:getParser():getChildView('container')
    local viewName = mPhotonView:getParser():getBinder():get('xp_exit_remind_view_name')
    local dataMap = mPhotonView:getParser():getBinder():getDataMap()
    local pageData = {}
    if (viewName == 'xp_video_recommend_card_v2') then
        pageData['padding'] = '20,170,20,0'
    elseif (viewName == 'exit_remind_img_card') then
        pageData['padding'] = '46,176,46,0'
    elseif (viewName == 'exit_remind_text_img_card') then
        pageData['padding'] = '30,191,30,0'
    else
        pageData['padding'] = '20,0,20,0'
        -- 子View居中展示
        mContainer:getParser():update('gravity', '17')
    end
    mPhotonView:getParser():getBinder():update(pageData)

    mJavaBridge:addPlaceHolderView(viewName, 'container', nil, dataMap, mPhotonView:getParser():getListener())
end
