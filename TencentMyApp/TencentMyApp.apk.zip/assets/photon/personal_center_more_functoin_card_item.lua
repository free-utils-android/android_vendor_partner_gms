local mPhotonView, mJavaBridge = ...

local TAG = "lua_personal_center_more_functoin_card_item"

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")
end