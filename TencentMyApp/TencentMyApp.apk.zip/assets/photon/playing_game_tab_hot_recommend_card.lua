local mRapidView, mJavaBridge = ...

local TAG = "multi"
local DEBUG = true
local mViewNameList = {}
local mViewDataList = {}
local mTotalNum = 0
local mRecyclerView = nil
local mAppStubComponent = nil
-- appstate list
local APP_UPDATE = 0
local APP_DOWNLOADING = 1
local APP_PAUSED = 3
local APP_DOWNLOADED = 4
local APP_INSTALLED = 5
local APP_DOWNLOAD = 9
local mState = APP_DOWNLOAD
local mJoinView = nil

--load的时候运行
function loadFinish()
    logForDebug(TAG, " loadFinish")
    mRecyclerView = mRapidView:getParser():getChildView("id_media_rv"):getView()
end

function init()
    logForDebug(TAG, "reset data:")
    initCommon()
    mJoinView = mRapidView:getParser():getChildView("id_join"):getView()
end

--数据更新后，卡片入口主方法
function main()
    logForDebug(TAG, "update main")
    local booking = tostring(Rapid:getData("is_validate_booking_game"))
    initAppStateListener()
    if "1" == booking then
        Rapid:setData("jump_text", "预约")
        Rapid:setData("jump_text_eng", "booking")          
    else
        updateButtonText(mState)
    end 

    refreshRecycleView()
end

function initAppStateListener() 

    local appModel =  Rapid:getData("app_model")
    if appModel ~= nil then
        print("multi set mAppStubComponent :" .. tostring(mAppStubComponent))
        mAppStubComponent:setAppModel(appModel)
    end

    print("multi mAppStubComponent :" .. tostring(mAppStubComponent))

    mState = mAppStubComponent:getAppState()
    updateTextColor()
end

IAppStateChangeListener = {}
function IAppStateChangeListener.onState(state)
    mState = state
    updateButtonText(mState)
    updateTextColor()
    logForDebug(TAG, "IAppStateChangeListener pkg:" .. tostring(pkg_name) .. "appState:" .. tostring(state) )
end

function updateButtonText(state)
    local pkg_name = Rapid:getData("pkg_name")
    logForDebug(TAG, "pkg:" .. tostring(pkg_name) .. "appState:" .. tostring(state))
    if state == nil then
        Rapid:setData("jump_text", "下载")  
        Rapid:setData("jump_text_eng", "download")  
        return
    end
    if APP_DOWNLOADED == state then  -- 安装
        Rapid:setData("jump_text", "安装")  
        Rapid:setData("jump_text_eng", "install")  
    elseif APP_INSTALLED == state then   -- 打开
        Rapid:setData("jump_text", "打开")  
        Rapid:setData("jump_text_eng", "open")  
    elseif APP_UPDATE == state then   --更新
        Rapid:setData("jump_text", "更新")  
        Rapid:setData("jump_text_eng", "update")  
    else
        Rapid:setData("jump_text", "下载")  
        Rapid:setData("jump_text_eng", "download")  
    end
end

function jumpMorePage(url)
    if url == nil then
        return
    end
    local params = {}
    params["tmast"] = tostring(url)
    mRapidView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end

function clickedDownload()
    logForDebug(TAG, "openApp")
    if APP_INSTALLED == mState then
        openapp()
    else
        local url = mRapidView:getParser():getBinder():get("game_detail_url")
        if url == nil then
            return
        end
        jumpMorePage(url)
    end
end

function openapp()
    local pkgname = mRapidView:getParser():getBinder():get("pkg_name")
    mJavaBridge:Log(TAG, tostring(pkgname))
   
    if pkgname ~= nil then
        mJavaBridge:startAppByPackageName(pkgname)
    else
        mJavaBridge:showToast("应用打开失败!", 1000)
    end

end

function updateTextColor()
    local isJoined = Rapid:getData("is_join")
    local Color = luajava.bindClass('android.graphics.Color')
    if "1" == isJoined then
        mJoinView:setText("已加入")
        mJoinView:setTextColor(Color:parseColor("#590080FF"))
    else
        mJoinView:setText("加入圈子")
        mJoinView:setTextColor(Color:parseColor("#0080FF"))
    end
end

function refreshRecycleView()
    mViewNameList = {}
    mViewDataList = {}
    mTotalNum = tonumber(Rapid:getData("item_num"))
    for i = 1, mTotalNum do
        local itemData = mRapidView:getParser():getBinder():get("item_data_" .. i)
        if itemData == nil then
            return    
        end
        -- card param
        itemData:put("sourcescene", mJavaBridge:create("var", tostring(Rapid:getData("sourcescene"))))
        itemData:put("sourcesceneslotid", mJavaBridge:create("var", tostring(Rapid:getData('sourcesceneslotid'))))
        itemData:put("modeltype", mJavaBridge:create("var", tostring(Rapid:getData('modeltype'))))
        itemData:put("scene", mJavaBridge:create("var", tostring(Rapid:getData('scene'))))
        itemData:put("slotid", mJavaBridge:create("var", Rapid:getData("slotid")))
        itemData:put("recommendid", mJavaBridge:create("var", tostring(itemData:get("recommendid"))))

        itemData:put("total_time", mJavaBridge:create("var", tostring(itemData:get("total_time"))))
        itemData:put("click_url", mJavaBridge:create("var", tostring(itemData:get("click_url"))))
        itemData:put("content_url", mJavaBridge:create("var", tostring(itemData:get("content_url"))))
        itemData:put("video_title", mJavaBridge:create("var", tostring(itemData:get("video_title"))))
        itemData:put("subposition", mJavaBridge:create("var", tostring(i)))
        itemData:put("uni_channel_appid", mJavaBridge:create("var", Rapid:getData("uni_channel_appid")))
        itemData:put("app_id", mJavaBridge:create("var", tostring(Rapid:getData('app_id'))))

        mViewDataList[i] = itemData
        mViewNameList[i] = "playing_game_tab_hot_recommend_card_item.xml"
    end
    mRecyclerView:clear()
    mRecyclerView:updateData(mViewNameList, mViewDataList)
end

function initCommon()
    mAppStubComponent = mJavaBridge:createAppStubComponent()

    local appStateListener = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.IAppStubComponent$IAppStateChangeListener",
            IAppStateChangeListener
    )
    mAppStubComponent:registerAppStateChangeListener(appStateListener)
end

-----------------------------------------------------------
--debug的时候打印日志的方法
function logForDebug(logTag, logMsg)
    if not DEBUG then
        return
    end
    mJavaBridge:Log(TAG .. "::" .. logTag, logMsg)
end