local mPhotonView, mJavaBridge = ...

local TAG = "lua_cloud_game_video_card"

local mVideoView
local mMuteIcon
local mPlayerListener
local IPlayerStateChangeListener = {}

function showMuteIcon(show)
    if show then
        mMuteIcon:setAttr("visibility", "visible")
    else
        mMuteIcon:setAttr("visibility", "invisible")
    end
end

-- 播放按钮被点击
function IPlayerStateChangeListener.onPlayButtonClick(videoView, isPlaying)
end

-- 播放开始
function IPlayerStateChangeListener.onPlayStart(videoView)
    mJavaBridge:Log(TAG, 'IPlayerStateChangeListener.onPlayStart')
    showMuteIcon(true)
end

-- 播放停止
function IPlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    mJavaBridge:Log(TAG, 'IPlayerStateChangeListener.onPlayStop, currentPosition='..currentPosition)
    showMuteIcon(false)
end

-- 播放暂停
function IPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    mJavaBridge:Log(TAG, 'IPlayerStateChangeListener.onPlayStop, currentPosition='..currentPosition..',reason='..reason)
    showMuteIcon(false)
end

-- 播放继续
function IPlayerStateChangeListener.onPlayContinue(videoView, currentPosition)
    mJavaBridge:Log(TAG, 'IPlayerStateChangeListener.onPlayStop, currentPosition='..currentPosition)
    showMuteIcon(true)
end

-- 播放完成
function IPlayerStateChangeListener.onPlayComplete(videoView)
    mJavaBridge:Log(TAG, 'IPlayerStateChangeListener.onPlonPlayComplete')
    showMuteIcon(false)
end

-- 播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    mJavaBridge:Log(TAG, 'IPlayerStateChangeListener.onError,errorCode='..errorCode)
end

-- 播放器静音状态改变
function IPlayerStateChangeListener.onMute(videoview, mute, changeByUser)
    -- mJavaBridge:Log(TAG, 'IPlayerStateChangeListener.onMute,mute='..tostring(mute))
    updateMuteIcon(mute)
end

function IPlayerStateChangeListener.onProgressUpdate(mVideoView, progress)
    updateVideoJumpUrl(progress)
end

function addPlayerListener()
    mJavaBridge:Log(TAG, 'addPlayerListener')

    mPlayerListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IPlayerStateChangeListener)
    mVideoView:getView():registerIPlayerStateChangeListener(mPlayerListener)
end

function loadFinish()
    mJavaBridge:Log(TAG, "lua_cloud_game_video_card: loadFinish")

    mVideoView = Rapid:getChild('video_view')
    mMuteIcon = Rapid:getChild('mute_icon')
    addPlayerListener()
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "lua_cloud_game_video_card: afterUpdateData")
    updateTitleArea()
    updateMuteIcon(mVideoView:getView():isMute())
    updateAppLabels()
    updateVideoLabels()
    updateVideoJumpUrl(0)
end

function updateMuteIcon(isMute)
    if isMute then
        Rapid:setData("mute_icon", "https://yybcms.gtimg.com/android_cms/gzskin/9965898f4c1e213299c09e01ab38d933.png")
    else
        Rapid:setData("mute_icon", "https://yybcms.gtimg.com/android_cms/gzskin/9460dba248c953442f7ecb494058b282.png")
    end
end

-- 切换静音
function switchMute()
    local isMute = mVideoView:getView():isMute()
    if isMute then
        mVideoView:getView():setMuteToGlobal(false, true, true)
        updateMuteIcon(false)
    else
        mVideoView:getView():setMuteToGlobal(true, true, true)
        updateMuteIcon(true)
    end
end

-- 控制显示标题栏
function updateTitleArea()
    local title = Rapid:getData('title', '')
    if (title == '') then 
        Rapid:setData('title_visible', 'gone')
    else
        Rapid:setData('title_visible', 'visible')
    end
end

-- 控制显示app label
function updateAppLabels()
    for index = 1, 4 do
        local app_label = Rapid:getData('app_label_'..index, '')
        mJavaBridge:Log(TAG, "lua_cloud_game_video_card: "..app_label)

        if (app_label == '') then 
            Rapid:setData('app_label_'..index..'_visible', 'gone')
        else
            Rapid:setData('app_label_'..index..'_visible', 'visible')
        end
    end
end

-- 控制显示video label
function updateVideoLabels()
    for index = 1, 4 do
        local video_tag = Rapid:getData('video_tag_'..index, '')
        mJavaBridge:Log(TAG, "lua_cloud_game_video_card: "..video_tag)

        if (video_tag == '') then 
            Rapid:setData('video_tag_'..index..'_visible', 'gone')
        else
            Rapid:setData('video_tag_'..index..'_visible', 'visible')
        end
    end
end

-- 更新视频落地页跳转链接，携带当前视频的播放进度
function updateVideoJumpUrl(progress)
    local jump_url = Rapid:getData('jump_url', '')
    local vid = Rapid:getData('vid')
    Rapid:setData('jump_vid_url', jump_url.."&extra_video_uri="..vid.."&extra_progress="..tostring(progress))
end