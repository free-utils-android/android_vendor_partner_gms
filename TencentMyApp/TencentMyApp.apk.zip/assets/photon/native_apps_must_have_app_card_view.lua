local mPhotonView,mJavaBridge = ...

function main()
	local binder = mPhotonView:getParser():getBinder()
	local index = -1

	if( binder == nil)
	then
		return
	end

	index = binder:get('card_index')
	if( index == nil )
	then
		index= -1
	end

	binder:update('card_index1', "0"..index.."_001")
	binder:update('card_index2', "0"..index.."_002")
	binder:update('card_index3', "0"..index.."_003")
	binder:update('card_index4', "0"..index.."_004")
end