local mPhotonView, mJavaBridge = ...

local TAG = "ass_oprt_card"
local UI_EVENT_START_UPDATE_MANAGER_ACTIVITY = 1332

local redDotNumView
local iconView1
local iconView2
local iconView3
local rightTextView
local hasGetAppNum
local rightCorView

function init()
    mJavaBridge:Log(TAG, "init--lua--")
    redDotNumView = Rapid:getChild("card_text_red_num")
    iconView1 = Rapid:getChild("card_icon_right_1")
    iconView2 = Rapid:getChild("card_icon_right_2")
    iconView3 = Rapid:getChild("card_icon_right_3")
    rightTextView = Rapid:getChild("card_text_right")
    rightCorView = Rapid:getChild("card_icon_right")
    mJavaBridge:registeAppUpdate(eventUpdateCallback)
    hasGetAppNum = false
end


function onResume()
    mJavaBridge:Log(TAG, "------lua--ass_oprt_card---onResume")
    refreshData()
    mJavaBridge:registeAppUpdate(eventUpdateCallback)
end


function onPause()
    mJavaBridge:Log(TAG, "------AppUpdateServiceProxy---eventUpdateCallback---unRegisteAppUpdate--onPause")
    mJavaBridge:unRegisteAppUpdate()
end

function onDestory()
    mJavaBridge:Log(TAG, "------AppUpdateServiceProxy---eventUpdateCallback---unRegisteAppUpdate--onDestory")
    mJavaBridge:unRegisteAppUpdate()
end

function refreshData()
    mJavaBridge:Log(TAG, "refreshData--lua--1:")
    local redDotNum = mJavaBridge:getUpdateAppNums()
    mJavaBridge:Log(TAG, "refreshData--lua--2:")
    if redDotNum == 0 and hasGetAppNum == false  and mJavaBridge:isAppUpdateRequesting() then
        rightCorView:getView():setVisibility(8)
        redDotNumView:getView():setVisibility(8)
        return
    end
    mJavaBridge:Log(TAG, "refreshData--lua--redDotNum:" .. redDotNum)
    local icons = mJavaBridge:getUpdateAppIcons()

    --处理红点的逻辑
    if(redDotNum > 0) then
        redDotNumView:getView():setVisibility(0)
        rightTextView:getView():setVisibility(8)
        rightCorView:getView():setVisibility(0)
    else
        redDotNumView:getView():setVisibility(8)
        rightTextView:getView():setVisibility(0)
        rightTextView:getView():setText("所有应用都是最新版")
        rightCorView:getView():setVisibility(8)
    end

    if(redDotNum > 99) then
        redDotNumView:getView():setText("99+") 
    else
        redDotNumView:getView():setText(tostring(redDotNum)) 
    end

    ---处理icon的逻辑
    if redDotNum == 0 then
        iconView1:getView():setVisibility(8)
        iconView2:getView():setVisibility(8)
        iconView3:getView():setVisibility(8)
    end

    if redDotNum == 1 then
        iconView1:getView():setVisibility(0)
        local icon1 = icons["updateAppArea1"]
        iconView1:getView():updateImageView(icon1)
        iconView2:getView():setVisibility(8)
        iconView3:getView():setVisibility(8)
    end

    if redDotNum == 2 then
        local icon1 = icons["updateAppArea1"]
        local icon2 = icons["updateAppArea2"]
        iconView1:getView():setVisibility(0)
        iconView1:getView():updateImageView(icon1)
        iconView2:getView():setVisibility(0)
        iconView2:getView():updateImageView(icon2)
        iconView3:getView():setVisibility(8)
    end
    if redDotNum >= 3 then
        local icon1 = icons["updateAppArea1"]
        local icon2 = icons["updateAppArea2"]
        local icon3 = icons["updateAppArea3"]
        iconView1:getView():setVisibility(0)
        iconView1:getView():updateImageView(icon1)
        iconView2:getView():setVisibility(0)
        iconView2:getView():updateImageView(icon2)
        iconView3:getView():setVisibility(0)
        iconView3:getView():updateImageView(icon3)
    end
    
    --mJavaBridge:Log(TAG, "refreshData--lua--icon_0:" .. icon1)

end

function itemClick()
    mJavaBridge:sendEvent(UI_EVENT_START_UPDATE_MANAGER_ACTIVITY, nil, nil, nil)
end

function eventUpdateCallback(result_code, method, data)
    if method == "updateAppArea" then
        mJavaBridge:Log(TAG, "eventUpdateCallback--lua--icon_0:" .. method)
        hasGetAppNum = true
        refreshData()
    end

end



