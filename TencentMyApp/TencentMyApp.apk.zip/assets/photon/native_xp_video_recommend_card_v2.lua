local mPhotonView,mJavaBridge = ...
-- TODO 这种多状态可交互控件怎么写比较好
-- CREATED BY VIMERZHAO in 2019-06-01 11:28
-- 统一初始化，不要放在脚本外面，否则每次luaaction都会执行，降低性能
-- 因为不同的luaaction都会用到，直接用global级别变量
function init()
    TAG = "ExternalCallFramewrok"
    isCardClicked = false -- 卡片是否点击过，保证下载日志小位置报的是第一次点击的卡片索引
    mBinder = mPhotonView:getParser():getBinder()
    -- 当前被点击的卡片，-1表示下载按钮或其他事件导致的变化
    gClickedCardIndex = -1
    playUrl = "http://3gimg.qq.com/cafeteria/xp/play.png"
    pauseUrl = "http://3gimg.qq.com/cafeteria/xp/stop.png"

    -- 五个基础的下载任务状态
    DOWNLOAD = "download"
    DOWNLOADING = "downloading"
    PAUSED = "paused"
    DOWNLOADED = "downloaded"
    INSTALLED = "installed"
    ILLEGAL = "illegal"

    -- CREATED BY VIMERZHAO in 2019-05-31 16:49
    -- 终端代码的类即使命名、位置不合理，也不能随便修改，不至于会影响多少逻辑~~~~
    -- 这个过程耗时如何
    AppDownloadMiddleResolver = luajava.bindClass('com.tencent.pangu.download.AppDownloadMiddleResolver')
    DownloadInfo = luajava.bindClass('com.tencent.pangu.download.DownloadInfo')
    AppRelatedDataProcesser = luajava.bindClass('com.tencent.assistant.module.AppRelatedDataProcesser')
    AppStateUIProxy =luajava.bindClass('com.tencent.assistant.manager.AppStateUIProxy')
    DownloadProxy = luajava.bindClass('com.tencent.pangu.manager.DownloadProxy')
    --737以前混淆导致，TODO 如何避免这种版本问题
    -- actionFlag=0 isImmediately=false,logType=6 packageName:  appId: 0 searchId:0
    -- 06-14 17:41:48.691 18368 18368 W System.err: org.luaj.vm2.LuaError: 
    -- @xp_video_recommend_card_v2.lua:37 vm error: java.lang.ClassNotFoundException: com.tencent.nucleus.applink.AppLinkActionTask
    --AppLinkActionTask = luajava.bindClass('com.tencent.nucleus.applink.AppLinkActionTask')
    hasWriteDeepLink = false

    -- CREATED BY VIMERZHAO in 2019-05-31 15:15
    -- 构建统计信息
    mSimpleAppModel = mBinder:get('appModel')
    mStatInfo = luajava.newInstance('com.tencent.assistant.st.model.StatInfo')
    mStatInfo.scene = mBinder:get('scene')
    mStatInfo.slotId = '24_2'
    mStatInfo.sourceScene = -1000
    mStatInfo.callerVia= mBinder:get('callervia')
    -- TODO 这个怎么处理
    local recommendId = mBinder:get('recommendId')
    local recommendIdVar =  mJavaBridge:create('Var', recommendId)
    mStatInfo.recommendId = recommendIdVar:getObject()

    mDownloadInfo = DownloadProxy:getInstance():getAppDownloadInfo(mSimpleAppModel);
    if mDownloadInfo == nil or mDownloadInfo:needReCreateInfo(mSimpleAppModel) then
        mDownloadInfo = DownloadInfo:createDownloadInfo(mSimpleAppModel, mStatInfo)
    end

    UIStateListener = {}
    function UIStateListener.onAppStateChange(ticket, state)
        local formatState = string.lower(tostring(state))
        refreshUI(formatState)
    end
    uiStateListener = luajava.createProxy('com.tencent.assistant.manager.AppStateUIProxy$UIStateListener', UIStateListener)
    AppStateUIProxy:get():addDownloadUIStateListener(mDownloadInfo.downloadTicket, uiStateListener)

    -- 视频封面标题需要调整高度
    if mBinder:get('coverTitle_1') ~= nil and mBinder:get('coverTitle_2') ~= nil and mBinder:get('coverTitle_3') ~= nil then
        mPhotonView:getParser():getChildView('card_item_1'):getParser():update('height', '166')
        mPhotonView:getParser():getChildView('card_item_2'):getParser():update('height', '166')
        mPhotonView:getParser():getChildView('card_item_3'):getParser():update('height', '166')
        mPhotonView:getParser():getChildView('cover_title_1'):getParser():update('visibility', 'visible')
        mPhotonView:getParser():getChildView('cover_title_2'):getParser():update('visibility', 'visible')
        mPhotonView:getParser():getChildView('cover_title_3'):getParser():update('visibility', 'visible')
        mPhotonView:getParser():update('height', '260')
    end

    -- cardTip需要调整高度
    if not isEmpty(mBinder:get('cardTip')) then
        mPhotonView:getParser():update('height', '270')
        mPhotonView:getParser():getChildView('app_area'):getParser():update('margintop', '20')
        mPhotonView:getParser():getChildView('card_tip'):getParser():update('visibility', 'visible')
    end

    local param = {}
    -- 后台带了就用后台的
    if mBinder:get('pauseIconUrl') ~= nil and mBinder:get('pauseIconUrl') ~= "" then
        pauseIconUrl = mBinder:get('pauseIconUrl')
    end
    if mBinder:get('playIconUrl') ~= nil and mBinder:get('playIconUrl') ~= "" then
        playIconUrl = mBinder:get('playIconUrl')
    end
    -- 这里也要更新，防止后台传空串
    param['pauseIconUrl'] = pauseIconUrl
    param['playIconUrl'] = playIconUrl

    -- 如果有Gif要优先显示，放在这里触发一次datachange
    gif1 = mBinder:get('coverGifUrl_1')
    gif2 = mBinder:get('coverGifUrl_2')
    gif3 = mBinder:get('coverGifUrl_3')
    -- 如果是动态图
    if  gif1 ~= nil and gif1 ~= '' and gif2 ~= nil and gif2 ~= '' and gif3 ~= nil and gif3 ~= '' then
        param['coverGifUrl_1'] = gif1
        param['coverGifUrl_2'] = gif2
        param['coverGifUrl_3'] = gif3
    else-- 如果是静态图则显示按钮和文字，无论当前是否已开始下载，都显示没下载时的文案
        mPhotonView:getParser():getChildView('play_btn_1'):getParser():update('visibility', 'visible')
        mPhotonView:getParser():getChildView('play_btn_2'):getParser():update('visibility', 'visible')
        mPhotonView:getParser():getChildView('play_btn_3'):getParser():update('visibility', 'visible')
        -- 不加下面三行部分机型会有问题
        mPhotonView:getParser():getChildView('play_btn_1'):getParser():update('url', playUrl)
        mPhotonView:getParser():getChildView('play_btn_2'):getParser():update('url', playUrl)
        mPhotonView:getParser():getChildView('play_btn_3'):getParser():update('url', playUrl)
        param['coverDesc_1'] = mBinder:get('downloadTip_1')
        param['coverDesc_2'] = mBinder:get('downloadTip_2')
        param['coverDesc_3'] = mBinder:get('downloadTip_3')
        mPhotonView:getParser():getChildView('cover_desc_1'):getParser():update('visibility', 'visible')
        mPhotonView:getParser():getChildView('cover_desc_2'):getParser():update('visibility', 'visible')
        mPhotonView:getParser():getChildView('cover_desc_3'):getParser():update('visibility', 'visible')
    end
    mBinder:update(param)
    -- For微视详情页，已经有下载按钮了，就不显示卡片的
    if mBinder:get('showAppArea')~=nil and mBinder:get('showAppArea')=='false' then
        mPhotonView:getParser():getChildView('app_area'):getParser():update('visibility', 'gone')
        mPhotonView:getParser():update('height', '240')
    end

    -- 进入卡片的时候不一定是下载，所以这里更新下
    local formatState = downloadInfo2formatState()
    syncUI(formatState)
end

-- CREATED BY VIMERZHAO in 2019-06-20 16:27
-- 背景是 com.tencent.assistant.module.AppRelatedDataProcesser#getAppState这个坑逼方法在待下载和已安装的时候都会返回illegal
-- 所以需要处理下,99%这么做都是对的
function handleIllegal(info)
    if mJavaBridge.isPkgInstalled ~= nil and mJavaBridge:isPkgInstalled(mDownloadInfo.packageName)~=0 then
        return INSTALLED
    end
    return DOWNLOAD
end

function downloadInfo2formatState()
    local formatState = string.lower(tostring(AppRelatedDataProcesser:getAppState(mDownloadInfo)))
    if formatState == ILLEGAL then
        formatState = handleIllegal(mDownloadInfo)
    end
    return formatState
end

function refreshUI(formatState)
    if gClickedCardIndex == nil or tonumber(gClickedCardIndex) < 0 then
        if DOWNLOADED == formatState then
            writeDeepLink('1')
        end
        return
    end
    if DOWNLOAD == formatState then
        onDownload()
    elseif DOWNLOADING == formatState then
        onDownloading()
    elseif PAUSED == formatState then
        onPaused()
    elseif DOWNLOADED == formatState then
        onDownloaded()
    elseif INSTALLED == formatState then
        onInstalled()
    else -- 其他状态
        --onException() -- 为了优化，暂时不显示
    end
end

-- CREATED BY VIMERZHAO in 2019-05-31 15:14
-- 点击视频封面
function onCoverClick(i)
    if mDownloadInfo == nil then
        init()
    else
        -- For 下载日志。一个潜在问题：第一张卡触发了下载，退出后第二张卡触发继续下载，这样下载日志就乱了，需产品侧决策
        if not isCardClicked then
            isCardClicked = true
            mDownloadInfo.statInfo.subPosition = '00'..i
        end
    end

    -- CREATED BY VIMERZHAO in 2019-06-20 15:04
    -- 这里有个很坑的地方，回调里面的状态对应的是com.tencent.assistant.AppConst.AppState
    -- DownloadInfo 自己有一个状态字段，对应的是com.tencent.pangu.download.SimpleDownloadInfo.DownloadState
    -- 由于两个都要用到，所以需要映射一下，方便统一
    -- 造成这种情况就是因为代码质量没人把关，搞得什么垃圾东西
    local formatState = downloadInfo2formatState()
    -- 如果已经安装了，直接跳DeepLink，这里可能状态为illegal，所有做两重检查
    if formatState==INSTALLED then
        goDeeplink(i)
        resetUI(i)
        return
    end

    resetUI(i)
    if tonumber(gClickedCardIndex) == -1 then -- 第一次点击
        gClickedCardIndex = i
        onButtonClick(formatState, -1)
    elseif tonumber(gClickedCardIndex) == tonumber(i) then -- 点击同一卡片
        onButtonClick(formatState, 0)
    else --点击其他卡片,根据当前状态决定行为
        gClickedCardIndex = i
        if formatState ~= DOWNLOADING then
            onButtonClick(formatState, 1)
        end
        -- 下载中的时候点击了其他卡片，更新下UI不要停
    end
end

-- CREATED BY VIMERZHAO in 2019-06-04 14:26
-- 没有使用YYB的DeepLink，不能做版本控制，直接跳
function goDeeplink(index)
    local deeplink = mBinder:get('jumpUrl_'..index)
    if deeplink == nil or deeplink == '' then
        deeplink = 'weishi://feed?=feed_id=1'
    end
    local intent                        = luajava.newInstance('android.content.Intent','android.intent.action.VIEW')
    local uri                           = luajava.bindClass('android.net.Uri')
    uri = uri:parse(deeplink)
    if(uri:getScheme() == "tmast") then
        local data ={}
        data["tmast"] = uri:toString()
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction",data,data)
    else
        intent:setData(uri)
        local context = mPhotonView:getView():getContext()
        context:startActivity(intent)
    end
end

-- clickType: -1/首次点击；0/点击同一卡片；1/点击另一张卡片
function onButtonClick(formatState, clickType)
    if formatState == 'queuing' then
        local toast = luajava.bindClass('android.widget.Toast')
        toast:makeText(mPhotonView:getView():getContext(), '排队中', 0):show()
        return
    end

    if formatState == DOWNLOADING and clickType ~= -1 then --避免第一次点击导致暂停
        AppDownloadMiddleResolver:getInstance():cancelDownloadByUser(mDownloadInfo.downloadTicket)
        return
    end

    if formatState == ILLEGAL then
        onException()
        return
    else-- 开始下载，继续下载，下载完成后触发打开都可以，但还需要确认这么调用会不会有隐藏问题
        doDownload()
    end
end

function doDownload()
    AppDownloadMiddleResolver:getInstance():downloadNormalApk(mDownloadInfo)
end

-- 响应下载任务状态的改变
function onDownload()
    setIconPlayState()
    updateTargetData('coverDesc_'..gClickedCardIndex, 'downloadTip_'..gClickedCardIndex)
end

function onDownloading()
    -- 不要在点击的时候刷新，要在动作真正发生的回调里刷新，虽然会有点滞后，但是可以避免异常Case
    setIconPauseState()
    updateTargetData('coverDesc_'..gClickedCardIndex, 'downloadingTip_'..gClickedCardIndex)
end

function onPaused()
    setIconPlayState()
    updateTargetData('coverDesc_'..gClickedCardIndex, 'pauseTip_'..gClickedCardIndex)
end

function onDownloaded()
    setIconPlayState()
    updateTargetData('coverDesc_'..gClickedCardIndex, 'downloadedTip_'..gClickedCardIndex)
    writeDeepLink(gClickedCardIndex)
end

function onInstalled()
    setIconPlayState()
    updateTargetData('coverDesc_'..gClickedCardIndex, 'installedTip_'..gClickedCardIndex)
end

function onException()
    local updateData = {}
    updateData["value"] = "发生异常，重新点击"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("toastaction",updateData,updateData)
    setIconPlayState()
end

function updateTargetData(key, dataKey)
    if mBinder:get(dataKey) ~= nil then
        mBinder:update(key, mBinder:get(dataKey))
    else
    end

end

function setIconPlayState()
    if tonumber(gClickedCardIndex) < 0 then
        return
    end
    mPhotonView:getParser():getChildView('play_btn_'..gClickedCardIndex):getParser():update('url', playUrl)
    mPhotonView:getParser():getChildView('cover_shader_'..gClickedCardIndex):getParser():update('visibility', 'visible')
end

function setIconPauseState()
    if tonumber(gClickedCardIndex) < 0 then
        return
    end
    mPhotonView:getParser():getChildView('play_btn_'..gClickedCardIndex):getParser():update('url', pauseUrl)
    mPhotonView:getParser():getChildView('cover_shader_'..gClickedCardIndex):getParser():update('visibility', 'visible')
    -- 点击后就把Gif置为静态图片
    mPhotonView:getParser():getChildView('cover_'..gClickedCardIndex):getParser():update('gifurl', 'data@coverUrl_'..gClickedCardIndex)
end

function resetUI(cur)
    if tonumber(cur) > 0 and tonumber(cur) < 4 then
        mPhotonView:getParser():getChildView('play_btn_'..cur):getParser():update('visibility', 'visible')
        mPhotonView:getParser():getChildView('cover_desc_'..cur):getParser():update('visibility', 'visible')
        local param = {}
        param['coverGifUrl_'..cur] = mBinder:get('coverUrl_'..cur)
        mBinder:update(param)
    end
    for i=1,3 do
        if i ~= tonumber(cur) then -- 当前点击的封面不处理
            mPhotonView:getParser():getChildView('play_btn_'..i):getParser():update('url', playUrl)
            mPhotonView:getParser():getChildView('cover_shader_'..i):getParser():update('visibility', 'invisible')
        end
    end
end

-- onResume的时候更新三张卡的文案
function syncUI(formatState)
    local keyPrefix = 'downloadTip_'
    local isDownloading = false

    if formatState==DOWNLOADING then
        isDownloading = true
        keyPrefix = 'downloadingTip_'
    elseif formatState == PAUSED then
        keyPrefix = 'pauseTip_'
    elseif formatState == DOWNLOADED then
        keyPrefix = 'downloadedTip_'
    elseif formatState == INSTALLED then
        keyPrefix = 'installedTip_'
    end

    for i=1,3 do
        updateTargetData('coverDesc_'..i, keyPrefix..i)
    end

    if not isDownloading and gClickedCardIndex ~= -1 and gClickedCardIndex ~= nil then
        mPhotonView:getParser():getChildView('play_btn_'..gClickedCardIndex):getParser():update('url', playUrl)
    end

end
function isEmpty(str)
    return str == nil or str==''
end

function writeDeepLink(index)
    if hasWriteDeepLink then
        return
    end
    local deepLink = mBinder:get('jumpUrl_'..index)
    if not isEmpty(deepLink) then
        --deepLink = 'weishi://feed?feed_id=6YE81HNxx1Hq0Brxc'
        --AppLinkActionTask:getInstance():addActionTask(mDownloadInfo.packageName, mDownloadInfo.versionCode, deepLink)
        writeClipboard(deepLink)
        hasWriteDeepLink = true
    end
end


-- CREATED BY VIMERZHAO in 2019-06-12 17:21
-- 通用能力：写剪切板，方便微视启动时跳转指定界面
function writeClipboard(deepLink)
    Context = luajava.bindClass('android.content.Context')
    ClipData = luajava.bindClass('android.content.ClipData')
    mClipboardManager = mPhotonView:getParser():getContext():getSystemService(Context.CLIPBOARD_SERVICE)
    -- 为什么要加个后缀?因为不加后缀微视不解析，理论上应该设计的足够通用，以后别人接就方便些，不知道他们怎么想的......
    mClipboardManager:setPrimaryClip(ClipData:newPlainText('Label', deepLink..'&from=yyb-converge-traffic'))
end

-- CREATED BY VIMERZHAO in 2019-06-20 14:33
-- 框子框架自动触发
-- 在详情页的时候发现UI不在前台的时候，不能响应安装返回后的结果和删除时的状态，所以在此处理
function onResume()
    -- 这里可能被删除，所以需要重新获取一下
    if mSimpleAppModel ~= nil and DownloadProxy ~= nil then
        mDownloadInfo = DownloadProxy:getInstance():getAppDownloadInfo(mSimpleAppModel);
        if mDownloadInfo == nil or mDownloadInfo:needReCreateInfo(mSimpleAppModel) then
            mDownloadInfo = DownloadInfo:createDownloadInfo(mSimpleAppModel, mStatInfo)
        end
        -- TODO 安装包被删除后无法准确获取，极限操作下的Bug
        local formatState = downloadInfo2formatState()
        syncUI(formatState)
    end
end
