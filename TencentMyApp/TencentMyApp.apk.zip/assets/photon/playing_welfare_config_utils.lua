local mRapidView, mJavaBridge = ...
ConfigUtils = {}
function ConfigUtils.useV3Style()
    local afterV210615 = Rapid:getData("is_update", "0") == "1" --需求865857563，1用新样式。0用老样式
    return afterV210615
end