local mPhotonView,javaBridge = ...

function addMulAppListView()
	local size =mPhotonView:getParser():getBinder():get("bottom_app_size")
	if ( size == nil or tonumber(size) <1 )
	then
		javaBridge:Log('Lua', "No Need Add View")
		return
	end
	--自动调整view的高度
	if (tonumber(size) <  5)
	then 
		local mulAppView=mPhotonView:getParser():getChildView("mul_app_view_zone")
		if (mulAppView ~= nil and mulAppView:getView() ~= nil )
		then
			local layoutPara= mulAppView:getView():getLayoutParams()
			layoutPara.height=-2
		end
	end

	for i=0,tonumber(size)-1 do
		local key = "app_item_"..i
		local v = mPhotonView:getParser():getBinder():get(key)
		if (v ~= nil)
		then 
			local data={}
			data["scene"]=200898
			data["sourcescene"]=mPhotonView:getParser():getBinder():get("sourcescene")
			if ( i < 9 )
			then
				data["sourcesceneslotid"]="16_".."00"..tostring(i+1)
				data["sourcesceneslotid"]="16_".."00"..tostring(i+1)
			else
				data["sourcesceneslotid"]="16_".."0"..tostring(i+1)
			end
			data["subposition"]="03"
			data["bottom_recommendId"] = mPhotonView:getParser():getBinder():get("bottom_recommendId")
			data["sourcemodeltype"]=mPhotonView:getParser():getBinder():get("sourcemodeltype")
			data["item_icon"]=mPhotonView:getParser():getBinder():get("item_icon_"..i)
			data["item_size"]=mPhotonView:getParser():getBinder():get("item_file_size_"..i)
			data["item_name"]=mPhotonView:getParser():getBinder():get("item_name_"..i)
			data["item_desc"]=mPhotonView:getParser():getBinder():get("item_desc_"..i)
			--data["item_desc"]="发撒旦法撒旦发的付了款就撒旦开两份加快老地方拉克丝大家发撒了看到立刻就的"
			data["item_file_size"]=mPhotonView:getParser():getBinder():get("item_file_size_"..i)
			data["app_item"] = v
			data["bg_color"] = "ffffffff"
			data["desc_visiable"]="visible"
			data["download_margin_right"]="12"
			data["desc_margin_top"]="19"
			data["img_margin"]="12"
			data["item_tag"]=mPhotonView:getParser():getBinder():get("app_tag"..i)
			--控制描述是否展示
			if (data["item_desc"] == nil or string.len(tostring(data["item_desc"])) < 1)
			then 
				data["desc_visiable"]="gone"
			end
			--控制标签是否展示
			data["item_tag"] = mPhotonView:getParser():getBinder():get("app_tag_"..i)
			--data["item_tag"] ="旅游摄影"
			data["tag_visiable"] = "visible"
			if ( data["item_tag"] == nil or string.len(data["item_tag"]) < 1 )
			then 
				data["tag_visiable"]="gone"
			end
			local view = javaBridge:addView('native_content_detail_app_item.xml', 'app_list_contain', nil, nil, nil)
			view:getParser():getBinder():update(data)
		end
	end
end
function onKeyBack()
	local mulRootView = mPhotonView:getParser():getChildView("app_root")
	if (mulRootView ~= nil and mulRootView:getView():getVisibility() == 0)
	then
		mulRootView:getView():setVisibility(8)
		local titleView = mPhotonView:getParser():getChildView("title_view_zone")
		if ( titleView ~= nil )
		then
			titleView:getView():setVisibility(0)
			return true
		end
	end 
	return false
end