local mPhotonView,mJavaBridge = ...


local mBookRecyclerView = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil
local mRid = nil

local mIntentData = nil

function main()
    mBookRecyclerView = mPhotonView:getParser():getChildView('rv_book')
end

function jumpMore()
    -- 先收集卡片的所有书本数据给到落地页
    mJavaBridge:callModuleWithParams("NovelManager", "writeThemePhotonData", {mIntentData})
    local cardConfig = {}

    cardConfig["card_title"] = Rapid:getData("card_title", "玄爽酷文")
    cardConfig["item_num"] = Rapid:getData("item_num", 0)
    cardConfig["report_context"] = Rapid:getData("report_context")

    mJavaBridge:callModuleWithParams("NovelManager", "writeThemeTitle", {cardConfig})

    -- 跳转落地页
    local tmastParams = {
        ["tmast"] = 'tmast://appdemo?photonid=301638174418947&params=scene:10308,sourcescene:10293&enable_page_in_out_report=1&preActivitySlotTagName='.. Rapid:getData('slotid', '') .. '_-1_-1' ..'&preActivityModelTypeName=' .. Rapid:getData('modeltype', '') .. '&preActivityTagName=10293' .. '&sourcemodeltype=' .. Rapid:getData('modeltype', '')
    }
    Rapid:execAction("tmastaction", tmastParams, tmastParams)
end

function updateData()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    mRid = Rapid:getData("recommend_card")

    updateAppList()
end

function updateAppList()
    mIntentData = luajava.newInstance("java.util.ArrayList")
    local dataArrayList = luajava.newInstance("java.util.ArrayList")
    local viewNameList = luajava.newInstance("java.util.ArrayList")

    local showCount = tonumber(Rapid:getData('showCount', '0'))
    local itemCount = tonumber(Rapid:getData('item_num', '0'))
    
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        -- 这里塞给二级页数据
        mIntentData:add(itemData)

        -- 这里塞给卡片数据
        if showCount <= 0 or i <= showCount then
            -- showCount表示需要限制的外显个数，showCount <= 0表示不需要限制外显个数
            if showCount > 0 and showCount < itemCount then
                fillItemData(itemData, i, showCount)
            else
                fillItemData(itemData, i, itemCount)
            end
            dataArrayList:add(itemData)
            viewNameList:add('novel_tab_book_theme_card_item.xml')
        end
    end

    mBookRecyclerView:getView():removeAllViews()
    mBookRecyclerView:getView():updateData(dataArrayList, viewNameList, true)
end

function fillItemData(itemData, index, itemCount)
    putReportElement(itemData)
    putMapData(itemData, "subPosition", index)
    if index == 1 then
        putMapData(itemData, "marginLeft", 16)
        putMapData(itemData, "marginRight", 12)
    elseif index == itemCount then
        putMapData(itemData, "marginLeft", 0)
        putMapData(itemData, "marginRight", 16)
    else
        putMapData(itemData, "marginLeft", 0)
        putMapData(itemData, "marginRight", 12)
    end
end

function putReportElement(mapData)
    putMapData(mapData, "scene", mScene)
    
    putMapData(mapData, "sourcescene", mSourcescene)
    putMapData(mapData, "sourceScene", mSourcescene)
    
    putMapData(mapData, "modeltype", mModeltype)
    putMapData(mapData, "modelType", mModeltype)
    
    putMapData(mapData, "sourcesceneslotid", mSourceslotid)
    putMapData(mapData, "sourceSceneSlotId", mSourceslotid)
    
    putMapData(mapData, "slotid", mSlotid)
    putMapData(mapData, "slotId", mSlotid)

    putMapData(mapData, "recommend_card", mRid)
end

function putMapData(map, key, value)
    if ((map ~= nil) and (key ~= nil) and (value ~= nil)) then
        local var = mJavaBridge:create("var", value)
        map:put(key, var)
    end
end