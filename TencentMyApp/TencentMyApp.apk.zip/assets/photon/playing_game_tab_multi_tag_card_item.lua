local mRapidView, mJavaBridge = ...

local TAG = "playing_game_tab_multi_tag"
local DEBUG = true
local MAX_ITEM = 9
local mScreenWidth = nil
local mTotalItem = 0

function loadFinish( ... )
    -- body
end

function jump(index)
    printf("enter jump index:" .. tostring(index))
    local key = "jump_url_" .. tostring(index)
    local url = mRapidView:getParser():getBinder():get(key)
    jumpMorePage(url)
end

function jumpMorePage(url)
    printf("enter jump url:" .. tostring(url))
    if url == nil then
        return
    end

    local params = {}
    params["tmast"] = tostring(url)
    mRapidView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end

-----------------------------------------------------
function printf(str)
    if DEBUG then
        print(TAG .. " " .. tostring(str))
    end
end