local mPhotonView,mJavaBridge = ...


local ITEM_TYPE_COUPONS = 1
local ITEM_TYPE_GIFT = 2


local mRecyclerView = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil

local mQueryWord = nil
local mSearchScene = nil
local mSourceQuery = nil
local mSearchId = nil
local mSearchSession = nil

function main()
    mRecyclerView = mPhotonView:getParser():getChildView('recyclerView')
end

function initCardContentFromType(itemType)
    local showCount = tonumber(Rapid:getData('inner_item_num', '0'))
    local typeStr = ''
    if itemType == ITEM_TYPE_COUPONS then
        typeStr = '宝劵'
        Rapid:setData('inner_title', '宝劵')
        
    elseif itemType == ITEM_TYPE_GIFT then
        typeStr = '礼包'
        Rapid:setData('inner_title', '游戏礼包')
    end

    local subCardTotalCount = tonumber(Rapid:getData('inner_card_count', '0'))
    if showCount == 1 and subCardTotalCount == 1 then
        -- 当卡片全局只有一个宝劵子卡或者一个礼包子卡时展示
        Rapid:setData('text_more', '更多' .. typeStr .. '正在骑马赶来...')
        Rapid:getChild('inner_card_view'):setAttr('width', '93.33%x')
    else
        Rapid:setData('text_more', '共' .. showCount .. '个')
        Rapid:getChild('inner_card_view'):setAttr('width', 'wrap_content')
    end
end

function loadData()
    local itemType = tonumber(Rapid:getData('item_type', '0'))
    initCardContentFromType(itemType)

    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    mQueryWord = Rapid:getData("queryWord")
    mSearchScene = Rapid:getData("searchScene")
    mSourceQuery = Rapid:getData("sourceQuery")
    mSearchId = Rapid:getData("searchId")
    mSearchSession = Rapid:getData("searchsession")
    local cardJumpUrl = Rapid:getData('card_jump_url', '')

    local dataList = {}
    local viewNameList = {}
    local itemCount = tonumber(Rapid:getData('inner_item_num', '0'))
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        fillItemData(itemData, i, cardJumpUrl)
        dataList[i] = itemData
        if itemType == ITEM_TYPE_COUPONS then
            viewNameList[i] = 'search_result_welfare_card_coupons_item.xml'
        elseif itemType == ITEM_TYPE_GIFT then
            viewNameList[i] = 'search_result_welfare_card_gift_item.xml'
        else
            viewNameList[i] = ''
        end
    end

    mRecyclerView:getView():updateData(viewNameList, dataList, true)
end

function fillItemData(itemData, index, cardJumpUrl)
    if itemData == nil then
        return
    end
    putBaseReportText(itemData)
    itemData:put("subPosition", mJavaBridge:create("Var", index))
    itemData:put("card_jump_url", mJavaBridge:create("Var", cardJumpUrl))

    if mQueryWord ~= nil then
        itemData:put("queryWord", mJavaBridge:create("Var", mQueryWord))
    end
    if mSearchScene ~= nil then
        itemData:put("searchScene", mJavaBridge:create("Var", mSearchScene))
    end
    if mSourceQuery ~= nil then
        itemData:put("sourceQuery", mJavaBridge:create("Var", mSourceQuery))
    end
    if mSearchId ~= nil then
        itemData:put("searchId", mJavaBridge:create("Var", mSearchId))
    end
    if mSearchSession ~= nil then
        itemData:put("searchsession", mJavaBridge:create("Var", mSearchSession))
        itemData:put("searchSession", mJavaBridge:create("Var", mSearchSession))
    end
end

function putBaseReportText(itemData)
    if itemData == nil then
        return
    end

    if mScene ~= nil then
        local var_scene = mJavaBridge:create("Var", mScene)
        itemData:put("scene", var_scene)
    end
    
    if mSourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create("Var", mSourcescene)
        itemData:put("sourcescene", var_sourcescene)
        itemData:put("sourceScene", var_sourcescene)
    end
    
    if mModeltype ~= nil then
        local var_modeltype = mJavaBridge:create("Var", mModeltype)
        itemData:put("modeltype", var_modeltype)
        itemData:put("modelType", var_modeltype)
    end
    
    if mSourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create("Var", mSourceslotid)
        itemData:put("sourcesceneslotid", var_sourceslotid)
        itemData:put("sourceSceneSlotId", var_sourceslotid)
    end
    
    if mSlotid ~= nil then
        local var_slotid = mJavaBridge:create("Var", mSlotid)
        itemData:put("slotid", var_slotid)
        itemData:put("slotId", var_slotid)
    end
end