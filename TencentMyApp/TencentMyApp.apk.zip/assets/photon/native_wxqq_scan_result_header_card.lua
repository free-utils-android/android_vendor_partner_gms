local mPhotonView,mJavaBridge = ...

function updateValue()
  local clean_size = mPhotonView:getParser():getBinder():get("selected_size")
  local subnotice = mPhotonView:getParser():getBinder():get("sub_notice_text_color")
   
 

  local bgColor = mPhotonView:getParser():getBinder():get("rubbishSizeColor")

  local Color = luajava.bindClass('android.graphics.Color')
  mPhotonView:getParser():getChildView("rootView"):getView():setBackgroundColor(Color:parseColor(bgColor))

  
  local rubbishSize = mPhotonView:getParser():getBinder():get("rubbishSize")
  mPhotonView:getParser():getChildView("rubbishSize"):getView():setText(rubbishSize)

  local rubbishSizeUnit = mPhotonView:getParser():getBinder():get("rubbishSizeUnit")
  mPhotonView:getParser():getChildView("rubbishUnit"):getView():setText(rubbishSizeUnit)

end

function finish()
    mJavaBridge:finish()
    --mJavaBridge:switchRubbishCleanModel(0X08)
end
