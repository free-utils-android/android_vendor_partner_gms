local mRapidView,mJavaBridge = ...

local VIEWNAME = "app_manage_center_message_card_item"
local FORMAT_KEY = "app_manage_center_message_card"
local MESSAGE_ID = "message_id"
local TAG = "shxinliu - "..VIEWNAME

-- 是否可取新的安装包扫描结果: "1"：是 "0"：否
local PKG_SCAN_STATUS_YES = "1"
local PKG_SCAN_STATUS_NO = "0"
local UI_EVENT_START_UPDATE_MANAGER_ACTIVITY = 1332

-- call java
local mCall = {}

-- 局部方法

-- 检查是否有nil
local function checkNil(...)
    local args = {...}
    for i = 1, select('#', ...) do
        if args[i] == nil then
            return true
        end
    end
    return false
end

-- key标志
local function formatKey(mode, key)
    return string.format(FORMAT_KEY.."."..mode.."."..key)
end

-- 存储本地数据
local function settingsDataAsync(mode, key, value)
    if checkNil(mode, key) then
        return
    end
    mJavaBridge:setSettingsDataAsync(formatKey(mode, key), value)
end

-- 获取本地数据
local function getSettingsData(mode, key, def)
    if checkNil(mode, key) then
        return
    end
    return mJavaBridge:getSettingsData(formatKey(mode, key), def)
end

-- 设置是否可取新的安装包扫描结果
--   @param state "1"：是 "0"：否
function mCall:setPkgScanStatus(state)
    return mJavaBridge:callModuleWithParams("AppManager", "setPkgScanStatus", {state})
end

-- 获取是否可取新的安装包扫描结果
function mCall:getPkgScanStatus()
    return mJavaBridge:callModule("AppManager", "getPkgScanStatus")
end

-- 全局方法

function jumpClick()
    local msgType = Rapid:getData('item_data_message_type', '')
    -- 新版本 & 应用更新
    if msgType == '1' or msgType == '2' then
        -- 打开更新管理页面
        mJavaBridge:sendEvent(UI_EVENT_START_UPDATE_MANAGER_ACTIVITY, nil, nil, nil)
    -- 安装包清理消息
    elseif msgType == '3' then
        -- 设置最新安装包状态
        mCall:setPkgScanStatus(PKG_SCAN_STATUS_NO)
    -- 人工运营消息
    elseif msgType == '4' then
        local msgId = Rapid:getData('item_data_message_id', '')
        settingsDataAsync(MESSAGE_ID, msgId, true)
    end
end