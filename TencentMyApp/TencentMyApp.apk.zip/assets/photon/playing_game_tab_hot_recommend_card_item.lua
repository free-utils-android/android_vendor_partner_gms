local mRapidView, mJavaBridge = ...

local TAG = "playing_game_tab_hot_recommend_card"
local DEBUG = true

--load的时候运行
function loadFinish()
    logForDebug(TAG, " loadFinish")
end

function init()
    logForDebug(TAG, "reset data:")
end

--数据更新后，卡片入口主方法
function main()
    logForDebug(TAG, "update main")
end

function clickVideo() 
    local url = mRapidView:getParser():getBinder():get("click_url")
    logForDebug(TAG, "clickVideo url:" .. tostring(url))
    jumpMorePage(url)
end

function jumpMorePage(url)
    if url == nil then
        return
    end
    local params = {}
    params["tmast"] = tostring(url)
    mRapidView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end

-----------------------------------------------------------
--debug的时候打印日志的方法
function logForDebug(logTag, logMsg)
    if not DEBUG then
        return
    end
    mJavaBridge:Log(TAG .. "::" .. logTag, logMsg)
end

function updateData()
    logForDebug(TAG, " updateData url")
end