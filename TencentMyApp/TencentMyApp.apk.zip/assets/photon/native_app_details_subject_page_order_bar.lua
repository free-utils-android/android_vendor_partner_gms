local mPhotonView,mJavaBridge = ...
local mSubscribing = false
local mLoginType = nil
local mJumpedLogin = false
local mAppId = nil

function onRequestListener(succeed, viewNameList, dataList)
	mSubscribing = false
	if( succeed ) then
		onRequestSucceed(viewNameList, dataList)
	else
		onRequestFailed()
	end

end

function onRequestSucceed(viewNameList, dataList)
	local resData = dataList:get(0)
	local bookCode = resData:get("bookingType")
	if bookCode ~= nil then
		bookCode = bookCode:getString()
	end
	if bookCode == "2" then
		mPhotonView:getParser():getTaskCenter():run("already_order_task")
	else
		mPhotonView:getParser():getTaskCenter():run("toast_success_task")
	end
	mPhotonView:getParser():getTaskCenter():run("disenable_sub_task")
end

function onRequestFailed()
	mPhotonView:getParser():getTaskCenter():run("toast_fail_task")
end

function clickSubscribeBtn(appid)
	mAppId = appid
	refreshLoginStatusAndSendSub()
end

function refreshLoginStatusAndSendSub()
	mJavaBridge:runJsBridge("getUserLoginToken", nil, getLoginStatusCallback)
end


function sendSub()
	if mLoginType ~= nil and mLoginType ~= "NONE" then
		mPhotonView:getParser():getTaskCenter():run("subscribing_task")		
		local params = {}
		params["appid"] = mAppId
		params["scene"] = mPhotonView:getParser():getBinder():get("scene")
		if not mSubscribing then
			mSubscribing = true
			mJavaBridge:request(2, params, onRequestListener)
		end
	else
		openLoginActivity()
	end
end

function getLoginStatusCallback(ret,data)
	if ret == 0 then

		local dataJSON = mJavaBridge:create('JSONObject', data)
		mLoginType = dataJSON:getString("logintype")
	else 
		mLoginType = nil
	end
	sendSub()
end

function openLoginActivity()
	mJumpedLogin = true

	local jsParams = {}
	jsParams['logintype'] = 'DEFAULT'
	mJavaBridge:registerJsBridgeNotify(loginCallback)
	mJavaBridge:runJsBridge("openLoginActivity", jsParams, nil)
end

function loginCallback(result_code,method,data)
	mJavaBridge:Log("test","loginCallback method:"..method)
	if method == "getUserLoginToken" then
		local dataJSON = mJavaBridge:create('JSONObject', data)
		mLoginType = dataJSON:getString("logintype")
		if mLoginType ~= nil and mLoginType ~= "NONE" and mJumpedLogin then
			mJumpedLogin = false
			mJavaBridge:registerJsBridgeNotify(nil)
			mPhotonView:getParser():getTaskCenter():run("login_success_task")
		end
	end
end


