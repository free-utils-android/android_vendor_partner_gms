local mPhotonView,mJavaBridge = ...

local mRecyclerView = nil
local mNavBar = nil
local mPageContext = nil
local mHasNext = "0"
local mAppID = nil
local mAppName = nil
local mRequsting = false
local mPxShaderHeight = 200
local mCurrentNavBarTrans = 0
local mRecyclerScrollTotalDy = 0
local mAnchorPoint = -1
local mColumnId = nil
local mActivityContext = nil
local mAutoAnchorPoint = -1
local mFloatWindow = nil

function main()
	mActivityContext =  mPhotonView:getView():getContext()
	local listView = mPhotonView:getParser():getBinder():get("first_view_name_list")
	local listData = mPhotonView:getParser():getBinder():get("first_data_list")
	local scene = mPhotonView:getParser():getBinder():get("scene")
	local sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
	local sourcesceneslotid = mPhotonView:getParser():getBinder():get("sourcesceneslotid")
	local sourcemodeltype = mPhotonView:getParser():getBinder():get("sourcemodeltype")
	local extradata = mPhotonView:getParser():getBinder():get("extradata")
	local commonData = nil


	if( listView == nil or listData == nil ) then
		return
	end

	initControl()
	initParams()

	local count = listData:size() - 1

	for i=0, count do
		if( listView:get(i) == "app_details_subject_page_context" ) then
			commonData = listData:get(i)

			listView:remove(i)
			listData:remove(i)
			break
		end
	end

	count = listData:size() - 1
	local floatWinData = nil
	for i=0, count do
		if( listView:get(i) == "app_details_subject_float_window" ) then
			floatWinData = listData:get(i)

			listView:remove(i)
			listData:remove(i)
			break
		end
	end

	if( commonData ~= nil ) then
		if(commonData:get("pageContext") ~= nil)then
			mPageContext = commonData:get("pageContext"):getString()
		end

		if(commonData:get("hasNext") ~= nil)then
			mHasNext = commonData:get("hasNext"):getString()
		end

		if(commonData:get("appId") ~= nil)then
			mAppID = commonData:get("appId"):getString()
		end

		if(commonData:get("appName") ~= nil)then
			mAppName = commonData:get("appName"):getString()
		end

		if(commonData:get("anchorPoint") ~= nil)then
			mAnchorPoint = commonData:get("anchorPoint"):getInt()
		end

		if(commonData:get("subscribecolumnid") ~= nil)then
			mColumnId = commonData:get("subscribecolumnid"):getString()
		end

		if(commonData:get("tmastAnchorPoint") ~= nil)then
			mAutoAnchorPoint = commonData:get("tmastAnchorPoint"):getInt()
		end
	end


	if( floatWinData ~= nil ) then
		if floatWinData:get("float_win_name") ~= nil then
			local floatViewName =  floatWinData:get("float_win_name"):getString()
			local floatViewUrl = ""
			if floatWinData:get("float_win_url") ~= nil then
				floatViewUrl  =  floatWinData:get("float_win_url"):getString()
			end
			local floatData = {}
			floatData["jump_url"] = floatViewUrl
			floatData["scene"] = scene
			floatData["sourcescene"] = sourcescene
			floatData["sourcesceneslotid"] = sourcesceneslotid
			floatData["sourcemodeltype"] = sourcemodeltype
			floatData["extradata"] = extradata
			add_float_window(floatViewName,floatData)
		end
	end

	count = listData:size() - 1

	for i=0, count do
		local data = listData:get(i)
		data:put("scene", mJavaBridge:create("var", scene))
		data:put("sourcescene", mJavaBridge:create("var", sourcescene))
		data:put("sourcesceneslotid", mJavaBridge:create("var", sourcesceneslotid))
		data:put("sourcemodeltype", mJavaBridge:create("var", sourcemodeltype))
		data:put("extradata", mJavaBridge:create("var", extradata))
		data:put("activityContext",mJavaBridge:create("var",mActivityContext))
		if mAppID ~= nil then
			data:put("appid",mJavaBridge:create("var", mAppID))
			data:put("appId",mJavaBridge:create("var",mAppID))
		end
	end


	if( mAppName ~= nil ) then
		mNavBar:getParser():getBinder():update("title", mAppName)
	end

	if( mColumnId ~= nil ) then
		mNavBar:getParser():getBinder():update("subscribecolumnid", mColumnId)
	end

	if( mHasNext == "1" ) then
		mRecyclerView:getView():showFooter()
	else
		mRecyclerView:getView():hideFooter()
	end

	mRecyclerView:getView():updateData(listData, listView, false)

	onAutoAnchorCard()
end

function initControl()
	mRecyclerView = mPhotonView:getParser():getChildView("main_recycler")
	mNavBar = mPhotonView:getParser():getChildView("nav_bar")

	mNavBar:getParser():update("title", mAppName)

	mRecyclerView:getView():setFooter("recyclerview_common_bottom_loading_view", nil)

	local bottomListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrollBottomListener', RecyclerBottomListener)
	local topListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrollTopListener', RecyclerTopListener)
	local scrollListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrolledListener', RecyclerScrolledListener)

	mRecyclerView:getView():setScrollBottomListener(bottomListener)
	mRecyclerView:getView():setScrollTopListener(topListener)
	mRecyclerView:getView():setScrolledListener(scrollListener)
end

function initParams()
	mPxShaderHeight = mJavaBridge:dip2px(mPxShaderHeight)
end

function loadNext()
	local params = {}

	params["pageContext"] = mPageContext
	params["appId"] = mAppID

	mRequsting = true

	mJavaBridge:request(4, params, reqListener)
end

function onAutoAnchorCard()
	if(  mRecyclerView == nil ) then
		mJavaBridge:Log("Lua", "no recyclerview")
		return
	end

	if( mAutoAnchorPoint == nil or mAutoAnchorPoint == -1 ) then
		mJavaBridge:Log("Lua", "no index")
		return
	end

	mRecyclerView:getView():getLayoutManager():scrollToPositionWithOffset(mAutoAnchorPoint, mJavaBridge:dip2px(59))
	mJavaBridge:postRun(onRefreshScrollLength)
end

function onAnchorCard()
	if(  mRecyclerView == nil ) then
		mJavaBridge:Log("Lua", "no recyclerview")
		return
	end

	if( mAnchorPoint == nil or mAnchorPoint == -1 ) then
		mJavaBridge:Log("Lua", "no index")
		return
	end

	mRecyclerView:getView():getLayoutManager():scrollToPositionWithOffset(mAnchorPoint, mJavaBridge:dip2px(59))
	mJavaBridge:postRun(onRefreshScrollLength)
end

function onRefreshScrollLength()
	mRecyclerScrollTotalDy = getScrollYDistance()
	onRefreshNavBar()
end

function getScrollYDistance()
	local manager = mRecyclerView:getView():getLayoutManager()
	local position = manager:findFirstVisibleItemPosition()
	local view = manager:findViewByPosition(position)
	local itemHeight = view:getHeight()

	return position * itemHeight - view:getTop()
end

function reqListener(succ, listView, listData)
	local commonData = nil
	local scene = mPhotonView:getParser():getBinder():get("scene")
	local sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
	local sourcesceneslotid = mPhotonView:getParser():getBinder():get("sourcesceneslotid")
	local sourcemodeltype = mPhotonView:getParser():getBinder():get("sourcemodeltype")
	local extradata = mPhotonView:getParser():getBinder():get("extradata")

	mRequsting = false

	if( succ == false or listView == nil or listData == nil ) then
		mRecyclerView:getView():hideFooter()
		return
	end

	local count = listData:size() - 1

	for i=0, count do
		if( listView:get(i) == "app_details_subject_page_context" ) then
			commonData = listData:get(i)

			listView:remove(i)
			listData:remove(i)
			break
		end
	end

	count = listData:size() - 1

	for i=0, count do
		local data = listData:get(i)
		data:put("scene", mJavaBridge:create("var", scene))
		data:put("sourcescene", mJavaBridge:create("var", sourcescene))
		data:put("sourcesceneslotid", mJavaBridge:create("var", sourcesceneslotid))
		data:put("sourcemodeltype", mJavaBridge:create("var", sourcemodeltype))
		data:put("extradata", mJavaBridge:create("var", extradata))
		if mAppID ~= nil then
			data:put("appid", mJavaBridge:create("var", mAppID))
			data:put("appId", mJavaBridge:create("var", mAppID))
		end
	end

	if( commonData ~= nil ) then
		if( commonData:get("pageContext") ~= nil ) then
			mPageContext = commonData:get("pageContext"):getString()
		end

		if( commonData:get("hasNext") ~= nil ) then
			mHasNext = commonData:get("hasNext"):getString()
		else
			mHasNext = "0"
		end

	end

	if( mHasNext == "0" ) then
		mRecyclerView:getView():hideFooter()
	else
		mRecyclerView:getView():showFooter()
	end

	mRecyclerView:getView():updateData(listData, listView, false)
end

RecyclerBottomListener = {}
function RecyclerBottomListener.onScrollToBottom()

	if( mHasNext == nil or mHasNext ~= "1" or mRequsting ) then
		mJavaBridge:Log("Lua", "滑动到底部并返回")
		return
	end

	loadNext()
end

RecyclerTopListener = {}
function RecyclerTopListener.onScrollToTop()
	if( mCurrentNavBarTrans == 0 ) then
		return
	end

	mRecyclerScrollTotalDy = 0
	mCurrentNavBarTrans = 0
	mNavBar:getParser():update("titletransparency", mCurrentNavBarTrans)
end

RecyclerScrolledListener = {}
function RecyclerScrolledListener.onScrolled(recyclerView, dx, dy)

	mRecyclerScrollTotalDy = mRecyclerScrollTotalDy + dy

	if( mCurrentNavBarTrans == 255 and mRecyclerScrollTotalDy > mPxShaderHeight ) then
		return
	end

	if( mRecyclerScrollTotalDy % 2 ~= 0 ) then
		return
	end

	onRefreshNavBar()


end


function onRefreshNavBar()
	mCurrentNavBarTrans = mRecyclerScrollTotalDy / mPxShaderHeight * 255
	if( mCurrentNavBarTrans > 255 )then
		mCurrentNavBarTrans = 255
	end

	if( mRecyclerScrollTotalDy == 0 ) then
		mCurrentNavBarTrans = 0
	end

	mNavBar:getParser():update("titletransparency", mCurrentNavBarTrans)
end

function add_float_window(view_name,data)
	mFloatWindow = mJavaBridge:createDraggableView(view_name,data,nil)
	local w = mPhotonView:getParser():getScreenWidth()
	local h = mPhotonView:getParser():getScreenHeight()
	local bottomBarHeight = h * 0.14
	local topBarHeight = h * 0.07
	mFloatWindow:setBounds(0,topBarHeight,w,h - bottomBarHeight)
	mFloatWindow:setDragPosition(w - mJavaBridge:dip2px(80),h * 0.2)
	local accelerateInterpolator = luajava.newInstance( "android.view.animation.AccelerateInterpolator")
	mFloatWindow:setSnapSpeed(0.7)
	mFloatWindow:getContentPhotonView():getParser():getBinder():update("self",mFloatWindow)
	mPhotonView:getParser():getChildView("content"):getView():addView(mFloatWindow)

	mFloatWindow:setXStrongMagnetic(true)
	mFloatWindow:setDraggable(true)

	if mAppID == nil then
		mFloatWindow:setDraggable(false)
		mFloatWindow:getContentPhotonView():getParser():getTaskCenter():run("start_animation")
		return
	end

	local firstShow = mJavaBridge:getSettingsData("float_window_" .. mAppID,"0")
	if firstShow == "0" then
		mFloatWindow:setDraggable(false)
		local mFloatWindowPhotonContent = mFloatWindow:getContentPhotonView()
		if mFloatWindowPhotonContent ~= nil then
			mFloatWindowPhotonContent:getParser():getTaskCenter():run("start_animation")
			mJavaBridge:setSettingsDataAsync("float_window_"..mAppID,"1")
		end
	end
end

