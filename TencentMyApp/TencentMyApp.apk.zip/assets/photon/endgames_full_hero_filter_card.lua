local mPhotonView, mJavaBridge = ...

local dataList = nil
local viewNameList = nil
local mRecyclerView = nil

local dataNum = nil

local SCENE = 10390
local PAGE_ID = "page_home_midgame_heroselection"

-- 进入页面后,英雄是否改变了
local hasChange = false
local authorize = require "endgames_full_hero_filter_authorize"

local TAG = "authorized_full_hero"

local mSourcescene = nil
local mSourceslotid = nil
local mPageOpenTime = nil

local mSystem = nil
local isAddUiListener = false
local uiListener = nil

local isInit = false

function init( ... )
    mJavaBridge:Log(TAG,"init")
    local rootView = Rapid:getChild("root"):getView()
    mJavaBridge:callModuleWithParams("VideoReport", "setPageId", {rootView, PAGE_ID})
    mJavaBridge:callModuleWithParams("VideoReport", "setPageContentId", {rootView, PAGE_ID})

    authorize.init(mPhotonView, mJavaBridge, Rapid)

    initRecyclerView()

    local height = mJavaBridge:px2dip(mJavaBridge:getScreenHeight()* 0.1)
    Rapid:setData("empty_height",height)
    mSystem = luajava.bindClass("java.lang.System")
    initUIEvent()

    isInit = true
end

function initRecyclerView( ... )
    mRecyclerView = Rapid:getChild("recyclerview"):getView()
    local manager = mRecyclerView:getLayoutManager()
    manager:setSpanSizeLookup(mJavaBridge:callModuleWithParams("View", "getSpanSizeLookup", {getSpanSize}))
    local actionListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonActionListener", IPhotonActionListener)
    mRecyclerView:setActionListener(actionListener)
end

function initUIEvent()
    if isAddUiListener then
        return
    end
    EventDispatcherEnum = luajava.bindClass("com.tencent.assistant.event.EventDispatcherEnum")
    uiListener = luajava.createProxy("com.tencent.assistant.event.listener.UIEventListener", UIEventListener)
    mJavaBridge:callModuleWithParams("EventListener", "addUIEventListener",{1088, uiListener})
    isAddUiListener = true
end

UIEventListener = {}
function UIEventListener.handleUIEvent(message)
    if message.what == 1088 then
        mJavaBridge:Log(TAG,"onLoginStatusChanged       s")
        authorize.onLoginStatusChanged()
        mJavaBridge:callModuleWithParams("EventListener", "removeUIEventListener",{1088, uiListener})
    end
end

function onResume( ... )
    mJavaBridge:Log(TAG,"onResume")
    if not isInit then
        init()
    end
    authorize.onResume()
end

function onShow( ... )
    mJavaBridge:Log(TAG,"onShow")
    if not isInit then
        init()
    end
    mPageOpenTime = mSystem:currentTimeMillis() 
    updateList()
    reportPage("2006")
    reportPage("100")
    hasChange = false
    authorize.onResume()
end

function finish( ... )
    reportPageOut()
    reportPageCancel()
    if hasChange then
        local param = {}
        param["key"] = "click_hero"
        param["value"] = tostring(mJavaBridge:getMemoryCache("endgames_hero_id"))
        Rapid:execAction("outeraction", param, param)
    end
    hasChange = false
    local param = {}
    param["key"] = "close_full_hero_card"
    param["value"] = ""
    Rapid:execAction("outeraction", param, param)
end

function afterUpdateData( ... )
    mSourcescene = Rapid:getData("sourcescene")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    updateList()
    updateAuthorized()
    authorize.afterUpdateData()
end

function authorized()
    mJavaBridge:Log(TAG, "authorized")
    authorize.receive()
end

function updateAuthorized( ... )
    local userName = Rapid:getData("username","")
    if userName == "" then
        Rapid:getChild("relation"):setAttr("visibility","visible")
        return
    end
    Rapid:getChild("relation"):setAttr("visibility","gone")
end

function updateList( ... )
    dataList = luajava.newInstance("java.util.ArrayList")
    viewNameList = luajava.newInstance("java.util.ArrayList")

    local itemNum = tonumber(Rapid:getData("item_num","0"))
    local subposition = 1
    local targetScrollIndex = 1
    local fixY = 0
    mJavaBridge:Log(TAG, "updateList")
    for i = 1, itemNum do
        local itemData = Rapid:getData("item_data_"..i, "")
        if itemData ~= "" then
            local mapData = fillTitleData( i, itemData )
            dataList:add(mapData)
            viewNameList:add("endgames_full_hero_filter_card_title.xml")
            local blockNum = tonumber(tostring(itemData:get("block_num"):getLuaValue()))
            local sixCount = getSixCount(blockNum)
            for j = 1, blockNum do
                local block = itemData:get("block_"..j):getLuaValue()
                block:put("hero_group",  mJavaBridge:create("Var", i))
                block:put("subposition",  mJavaBridge:create("Var", subposition))
                block:put("scene",  mJavaBridge:create("Var", SCENE))
                block:put("sourcescene",  mJavaBridge:create("Var", mSourcescene))
                block:put("sourcesceneslotid",  mJavaBridge:create("Var", mSourceslotid))
                block:put("slotid",  mJavaBridge:create("Var", "99_-1"))
                if i == 1 and j == 7 then
                    block:put("margintop",  mJavaBridge:create("Var", 6))
                elseif j <= 6 then
                    block:put("margintop",  mJavaBridge:create("Var", 6))
                else
                    block:put("margintop",  mJavaBridge:create("Var", 13))
                end
                if i == itemNum then
                    if j > sixCount * 6 then
                        block:put("marginbottom",  mJavaBridge:create("Var", 16))
                    else
                        block:put("marginbottom",  mJavaBridge:create("Var", 0))
                    end
                else
                    block:put("marginbottom",  mJavaBridge:create("Var", 0))
                end
                block:put("index",  mJavaBridge:create("Var", dataList:size()))
                -- 热门不加入
                if block:get("hero_id") ~= nil and tostring(block:get("hero_id")) ~= "-1" then
                    subposition = subposition + 1
                    if isFirstSelectItem(block) then
                        block:put("is_select",  mJavaBridge:create("Var", "1"))
                        targetScrollIndex = dataList:size()
                        if j<= 6 then
                            fixY = -280
                        else
                            fixY = -120
                        end
                    else
                        block:put("is_select",  mJavaBridge:create("Var", "0"))
                    end
                    dataList:add(block)
                    viewNameList:add("endgames_full_hero_filter_card_icon_item.xml")
                end
            end
        end
    end
    dataNum = dataList:size()
    mRecyclerView:removeAllViews()
    mRecyclerView:updateData(dataList, viewNameList, true)
    if targetScrollIndex > 7 then
        mRecyclerView:scrollToPosition(targetScrollIndex)
        mRecyclerView:scrollBy(0, fixY)
    end
end

-- 填充英雄分类标题行数据
function fillTitleData( i, itemData )
    local mapData = luajava.newInstance("java.util.HashMap")
    mapData:put("title", itemData:get("section_title"))
    if i == 1 then
        mapData:put("marginTop",  mJavaBridge:create("Var", 2))
        mapData:put("username",  mJavaBridge:create("Var", Rapid:getData("username","")))
    else
        mapData:put("marginTop",  mJavaBridge:create("Var", 23))
        mapData:put("username",  mJavaBridge:create("Var", ""))
    end
    mapData:put("sourcescene",  mJavaBridge:create("Var", mSourcescene))
    mapData:put("sourcesceneslotid",  mJavaBridge:create("Var", mSourceslotid))
    return mapData
end

-- 获取英雄分类除最后一行外，有几行
function getSixCount( blockNum )
    if blockNum % 6 == 0 then
        local count = blockNum / 6
        if count == 0 then
            return 0
        end
        return count - 1
    else
        return (blockNum - (blockNum % 6)) / 6
    end
end

function getSpanSize( position )
    if dataList == nil then
        return
    end
    local data = dataList:get(tonumber(position))
    if data ~= nil then
        if data:get("title") ~= nil then
            return 6
        else
            return 1
        end
    end
end

IPhotonActionListener = {}
function IPhotonActionListener.notify(key, value)
    if key == "authorized" then
        saveAuthorized(key, value)
        return
    end

    if key == "click_hero" then
        unselectLastHero()
        hasChange = true
        local curHero = splitString(tostring(value),",")
        lastSelectHeroGroup = curHero[1]
        lastSelectHeroId = curHero[2]
        clickIndex = curHero[3]
        mRecyclerView:getAdapter():updateItemData(tonumber(clickIndex),"is_select","1")
        mJavaBridge:putToMemoryCache("endgames_hero_group", curHero[1])
        mJavaBridge:putToMemoryCache("endgames_hero_id", curHero[2])
        -- 点击完后直接关闭
        mJavaBridge:delayRun(200, finish)
    end
end

function saveAuthorized( key, value )
    local param = {}
    param["key"] = "authorized"
    param["value"] = value
    Rapid:execAction("outeraction", param, param)
end

function unselectLastHero()
    if dataNum == nil then
        return
    end
    local lastHeroGroup = mJavaBridge:getMemoryCache("endgames_hero_group")
    local lastHeroId = mJavaBridge:getMemoryCache("endgames_hero_id")
    local index = findTargetIndex(lastHeroGroup, lastHeroId)
    if index == nil then
        return
    end
    mRecyclerView:getAdapter():updateItemData(tonumber(index),"is_select","0")
    mRecyclerView:getAdapter():notifyItemChanged(tonumber(index))
end

function findTargetIndex( heroGroup, heroId )
    if dataNum == nil then
        return nil
    end
    for i = 0, dataNum - 1 do
        local data = dataList:get(i)
        if tostring(data:get("hero_group")) == tostring(heroGroup) and tostring(data:get("hero_id")) == tostring(heroId) then
            return i
        end
    end
    return nil
end

-- 第一个选中的对象
function isFirstSelectItem( itemData )
    local heroGroup = mJavaBridge:getMemoryCache("endgames_hero_group")
    local heroId = mJavaBridge:getMemoryCache("endgames_hero_id")
    if heroGroup == nil or heroId == nil then
        return false
    end
    Rapid:Log(TAG,"selcet heroGroup: "..tostring(heroGroup)..", heroId: "..tostring(heroId))
    if tostring(heroGroup) == "" or tostring(heroId) == "" then
        return false
    end

    if tostring(itemData:get("hero_group")) == tostring(heroGroup) and tostring(itemData:get("hero_id")) == tostring(heroId) then
        return true
    end
    return false
end

function reportPage( actionid )
    local data = {}
    data["param"] = "slotid:-1,subposition:-1,scene:"..SCENE..",sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,sourcemodeltype:data@sourcemodeltype"
        ..",modeltype:-1,appid:0,actionid:"..actionid
    data["reportelement"] = "page"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, nil)
end

function reportPageOut( ... )
    local data = {}
    data["param"] = "slotid:-1,subposition:-1,scene:"..SCENE..",sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,sourcemodeltype:data@sourcemodeltype"
        ..",modeltype:-1,appid:0,actionid:2005"
    local pageDuration = mSystem:currentTimeMillis() - mPageOpenTime
    data["extendparam"] = "page_duration:"..tostring(pageDuration)
    data["reportelement"] = "page"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, nil)
end

function reportPageCancel( ... )
    local data = {}
    data["param"] = "slotid:-1,subposition:-1,scene:"..SCENE..",sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,sourcemodeltype:data@sourcemodeltype"
        ..",modeltype:-1,appid:0,actionid:201"
    data["extendparam"] ="uni_smoba_heroid:"..tostring(mJavaBridge:getMemoryCache("endgames_hero_id"))
    data["reportelement"] = "page"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, nil)
end

function splitString(strInput, sep)
    if sep == nil then
        sep = "%s"
    end
    local t = {}; i = 1
    for str in string.gmatch(strInput, "([^" .. sep .. "]+)") do
        t[i] = str
        i = i + 1
    end
    return t
end