local mPhotonView, mJavaBridge = ...

local TAG = "lua_app_channel_top_entry_card"

local ITEM_NUM_MAX = 5
local ITEM_QUERIES = {
    ['recommendid'] = '',
    ['report_context'] = '',
    ['name'] = '',
    ['icon_url'] = '',
    ['jump_url'] = '',
}

local function getItemDataValue(itemData, name, def)
    local value = itemData:get(name)
    if value == nil then
        return tostring(def)
    end
    if name == 'recommendid' then
        return value:getLuaValue()
    end
    return tostring(value)
end

local function initItemData(index)
    local itemData = Rapid:getData('item_data_'..index)
    if type(itemData) ~= 'userdata' then
        return
    end
    for name, def in pairs(ITEM_QUERIES) do
        local value = getItemDataValue(itemData, name, def)
        Rapid:setData(name..'_'..index, value)
    end
end

function afterUpdateData()
    local itemNum = tonumber(Rapid:getData('item_num', '0'))
    if itemNum > ITEM_NUM_MAX then
        itemNum = ITEM_NUM_MAX
    end
    for index=1, itemNum do
        initItemData(index)
    end
end