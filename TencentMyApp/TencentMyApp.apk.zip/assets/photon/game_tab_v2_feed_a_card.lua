local mPhotonView,mJavaBridge = ...

local TAG = "lua_game_tab_v2_feed_a_card"

local pagCard
local pagButton
local videoView
local IPlayerStateChangeListener = {}
local stateChangeListener 
local IRapidPagAnimationListener = {}
local pagAnimationListener
local button
local videoOnPlayPauseTime = 0
local pagShowEnable = true

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")
    pagCard = Rapid:getChild("pag_card"):getView()
    pagButton = Rapid:getChild("pag_button"):getView()
    registerPagGroup()

    videoView = Rapid:getChild("video_view"):getView()
    stateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener",     
        IPlayerStateChangeListener)
    videoView:registerIPlayerStateChangeListener(stateChangeListener)

    pagAnimationListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.pag.IRapidPagAnimationListener",         
        IRapidPagAnimationListener)
    pagCard:registerIRapidPagAnimationListener(pagAnimationListener)

    initPagWidth()
end

function beforeUpdateData()
    mJavaBridge:Log(TAG, "beforeUpdateData")
    initMute()
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")
    updateButton()
    updateLabel()
    updatePlayJumpUrl()
    updateGame()
    updatePag(false)
end

function onResume()
    mJavaBridge:Log(TAG, "onResume")
    updateButton()
    updateLabel()
    updateGame()
    updatePag(false)
end

function onPause()
    mJavaBridge:Log(TAG, "onPause")
    videoView:stop()
end

function initPagWidth()
    local currentWidth = mJavaBridge:px2dip(mJavaBridge:getScreenWidth())
    mJavaBridge:Log(TAG, "initPagWidth currentWidth: "..tostring(currentWidth))
    local marginbottom = -32
    pagShowEnable = currentWidth <= 420
    local pagCardWidthOffset = 0
    if currentWidth > 360 then
        pagCardWidthOffset = (360 - currentWidth) / 10
    end
    local pagCardWidth = tostring(currentWidth - pagCardWidthOffset)
    local marginHorizontal = pagCardWidthOffset / 2
    local pagCardMargin = tostring(marginHorizontal)..",0,"..tostring(marginHorizontal)..","..tostring(marginbottom)
    mJavaBridge:Log(TAG, "initPagWidth pagCardWidth: "..tostring(pagCardWidth))
    mJavaBridge:Log(TAG, "initPagWidth pagCardMargin: "..tostring(pagCardMargin))
    Rapid:setData('pag_card_width', pagCardWidth)
    Rapid:setData('pag_card_margin', pagCardMargin)
end

function exposeImageGroup()
    local index = Rapid:getData('index')
    local exposedKey = "exposed_image_"..index
    local exposed = RapidList:getItemData(index, exposedKey)
    mJavaBridge:Log(TAG, "exposedKey: "..tostring(exposedKey)..", exposed: "..tostring(exposed))
    if exposed ~= nil then
        return
    end
    RapidList:updateItemData(index, exposedKey, "exposed")

    exposeImage('pag_card', '卡片')
    exposeImage('pag_button', '按钮')
end

-- 特效曝光
function exposeImage(viewid, animeType)
    local reportParams = {}
    reportParams["viewid"] = viewid
    reportParams["dteventkey"] = "imp"
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:image,source_report_context:data@source_report_context,report_context:data@image_report_context,uni_effect_level:A,uni_only_cloudgame_check_status:data@is_only_show_free_play,uni_anime_type:"..animeType
    reportParams["recommendid"] = "data@app_recommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function updatePag(isStart)
    if not needShowButtonPag() then
        isStart = false
    end
    updatePagVisibility(isStart)
    updatePagState(isStart)
end

function updatePagVisibility(isShow)
    mJavaBridge:Log(TAG, "updatePagVisibility isShow: "..tostring(isShow))
    mJavaBridge:Log(TAG, "updatePagVisibility pagShowEnable: "..tostring(pagShowEnable))
    if isShow and pagShowEnable then
        pagCard:setVisibility(0)
        pagButton:setVisibility(0)
    else
        pagCard:setVisibility(8)
        pagButton:setVisibility(8)
    end
end

function updatePagState(isStart)
    mJavaBridge:Log(TAG, "updatePagState isStart: "..tostring(isStart))
    if isStart then
        pagCard:startPlay(true)
        pagButton:startPlay(true)
    else
        pagCard:stop()
        pagButton:stop()
    end
end

function updateGame()
    local gameScoreIsShow = Rapid:getData('game_score_is_show', '0')
    if tostring(gameScoreIsShow) == '1' then
        Rapid:setData('visible_game_score', 'visible')
    else
        Rapid:setData('visible_game_score', 'gone')
    end
end

function buttonApplyLinearStyle()
    if button ~= nil then
        button:applyLinearStyle()
    end
end

function buttonApplyFacetStyle()
    if button ~= nil then
        button:applyFacetStyle()
    end
end

function initMute()
    if videoView == nil then
        return
    end

    setMuteImage(videoView:isMute())
end

function switchMute()
    mJavaBridge:Log(TAG, "switchMute videoView: "..tostring(videoView == nil))
    if videoView == nil then
        return
    end

    local isMute = not videoView:isMute()
    videoView:setMuteToGlobal(isMute, true, true)
    setMuteImage(isMute)
end

function setMuteImage(isMute)
    if isMute then
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2022/04/29/1651225684664_9e768df2e274b4986d17999ea7294b0c.png")
    else
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2022/04/29/1651225688728_db4ec6100775c4b352a2f43bce59c11a.png")
    end
end

-- 如果当前时下载或者更新状态才显示 Pag
function needShowButtonPag()
    local gameStatus = Rapid:getData("game_status")
    if gameStatus == "0" then
        return mJavaBridge:callModuleWithParams("Download", "isDownloadOrUpdate", {getButton()})
    else
        return true
    end
end

function IRapidPagAnimationListener.onAnimationStart(component)
    mJavaBridge:Log(TAG, "onAnimationStart")
    buttonApplyLinearStyle()
    exposeImageGroup()
end

function IRapidPagAnimationListener.onAnimationEnd(component)
    mJavaBridge:Log(TAG, "onAnimationEnd")
    buttonApplyFacetStyle()
    updatePagVisibility(false)
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    setMuteImage(mute)
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart(videoView)
    mJavaBridge:Log(TAG, "onPlayStart")
    Rapid:getChild("mute_img"):setAttr("visibility", "visible")
    initMute()
    updatePag(true)
end

-- 视频继续播放回调
function IPlayerStateChangeListener.onPlayContinue(videoView, currentPosition)
    mJavaBridge:Log(TAG, "onPlayContinue")
    Rapid:getChild("mute_img"):setAttr("visibility", "visible")
    initMute()
    local videoOnPlayContinueTime = mJavaBridge:getServerTime()
    local videoOffsetTime = videoOnPlayContinueTime - videoOnPlayPauseTime
    mJavaBridge:Log(TAG, "onPlayPause videoOnPlayContinueTime: "..tostring(videoOnPlayContinueTime))
    mJavaBridge:Log(TAG, "onPlayContinue video time offset: "..tostring(videoOffsetTime))
    if videoOffsetTime <= 10 then
        updatePag(true)
    end
end

-- 视频重新播放回调
function IPlayerStateChangeListener.onRetryPlay(videoView)
    mJavaBridge:Log(TAG, "onRetryPlay")
    updatePag(true)
end

-- 视频播放进度回调
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    Rapid:setData("videoCurProgress", tostring(progress))
end

-- 视频暂停播放回调
function IPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    mJavaBridge:Log(TAG, "onPlayPause")
    videoEnd()
    videoOnPlayPauseTime = mJavaBridge:getServerTime()
    mJavaBridge:Log(TAG, "onPlayPause videoOnPlayPauseTime: "..tostring(videoOnPlayPauseTime))
end

-- 视频停止播放回调
function IPlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    mJavaBridge:Log(TAG, "onPlayStop")
    videoEnd()
end

-- 视频完成播放回调
function IPlayerStateChangeListener.onPlayComplete(videoView)
    if videoView ~= nil then
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
    mJavaBridge:Log(TAG, "onPlayComplete")
    videoEnd()
end

-- 播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    mJavaBridge:Log(TAG, "onError")
    videoEnd()
end

function videoEnd()
    Rapid:getChild("mute_img"):setAttr("visibility", "gone")
    buttonApplyLinearStyle()
    updatePag(false)
end

function registerPagGroup()
    mJavaBridge:callModuleWithParams("Pag", "registerPagComponent", {tostring(mPhotonView), pagCard})
    mJavaBridge:callModuleWithParams("Pag", "registerPagComponent", {tostring(mPhotonView), pagButton})
end

function getButton()
    local gameStatus = Rapid:getData("game_status")
    mJavaBridge:Log(TAG, "gameStatus: "..gameStatus)
    if gameStatus == "0" then
        mJavaBridge:Log(TAG, "下载按钮")
        return Rapid:getChild("download_button"):getView()
    elseif gameStatus == "1" then
        mJavaBridge:Log(TAG, "预约按钮")
        return Rapid:getChild("booking_button"):getView()
    elseif gameStatus == "2" then
        mJavaBridge:Log(TAG, "云玩按钮")
        return Rapid:getChild("cloud_play_button"):getView()
    end
    return nil
end

function setViewVisible(viewid)
    Rapid:getChild(viewid):setAttr("visibility", "visible")
    Rapid:getChild(viewid):getView():setVisibility(0)
end

function setViewGone(viewid)
    Rapid:getChild(viewid):setAttr("visibility", "gone")
    Rapid:getChild(viewid):getView():setVisibility(8)
end

function updateButton()
    mJavaBridge:Log(TAG, "updateButton")
    setViewGone('download_button')
    setViewGone('booking_button')
    setViewGone('cloud_play_button')
    updateButtonAttr()
    button = getButton()
    if button ~= nil then
        button:setVisibility(0)
    end
    buttonApplyLinearStyle()
end

function updateLabel()
    if Rapid:getData("game_label", "") == "" then
        setViewGone('game_label_icon')
        setViewGone('game_label')
        setViewVisible('rec_reason')
    else
        setViewVisible('game_label_icon')
        setViewVisible('game_label')
        setViewGone('rec_reason')
    end
end

function updateButtonAttr()
    updateColor("background_color", "22222e")
    updateColor("text_color", "ffffff")
    updateColor("button_final", "3f3f54")
    updateColor("button_color", "40ffffff")
    local textColor = Rapid:getData("text_color")
    local buttonFinal = Rapid:getData("button_final")
    local buttonColor = Rapid:getData("button_color")
    Rapid:setData("score_text_color", "cc"..textColor)
    Rapid:setData("after_btn_bg_color", buttonFinal)
    if Rapid:getData("shading_url", "") ~= "" then
        setViewVisible('shading')
        Rapid:setData("after_btn_bg_color", "33ffffff")
    else
        setViewGone('shading')
    end
    local isLight = Rapid:getData("light_or_deep_color", "1")
    if isLight == "1" then
        Rapid:setData("before_btn_text_color", "ffffff")
        Rapid:setData("before_btn_stroke_color", "40ffffff")
    elseif isLight == "0" then
        Rapid:setData("before_btn_text_color", textColor)
        Rapid:setData("before_btn_stroke_color", buttonColor)
    end
end

function updateColor(params, defaultColor)
    if Rapid:getData(params, "") == "" then
        Rapid:setData(params, defaultColor)
    end
end

function updatePlayJumpUrl()
    Rapid:setData('cloud_game_jump_url', jumpUrlJoinRid(Rapid:getData('cloud_game_jump_url'), 
        Rapid:getData('app_recommendid')))
end

function jumpUrlJoinRid(jumpUrl, recommendid)
    if jumpUrl == nil or jumpUrl == "" then
        return jumpUrl
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendid), "default")
    if rcdBase64 ~= nil and rcdBase64 ~= "" then
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
        mJavaBridge:Log("jumpUrlJoinRid", 'jumpUrl: '..tostring(jumpUrl))
    end
    return jumpUrl
end