local mPhotonView, mJavaBridge = ...

local TAG = "lua_personal_center_more_functoin_card"

local mRecyclerView

-- 检查是否有nil
local function checkNil(...)
    local args = {...}
    for i = 1, select("#", ...) do
        if args[i] == nil then
            return true
        end
    end
    return false
end

local function getPositionString(position)
    return string.format("%03d", position)
end

local function getValue(start, key, def)
    if start == nil then
        start = ''
    end
    if key == nil then
        key = ''
    end
    return Rapid:getData(tostring(start)..tostring(key), def)
end

local function queryData(start, params)
    local data = {}
    if type(params) == 'table' then
        for k, v in pairs(params) do
            data[k] = getValue(start, k, v)
        end
    end
    return data
end

local function queryItemData(index, params)
    if index == nil or params == nil then
        return {}
    end
    return queryData('item_data_'..tostring(index)..'_', params)
end

-- 填充数据
local function fillData(data, params, keys)
    if type(data) ~= 'table' or type(params) ~= 'table' then
        return
    end
    if keys == nil then
        for k, v in pairs(params) do
            data[k] = v
        end
    elseif type(keys) == 'table' then
        for i, key in pairs(keys) do
            if type(key) == 'string' then
                data[key] = params[key]
            end
        end
    end
end

local function onItemData(data, itemData)
    fillData(itemData, data, {
        'recomendid_card',
        'modeltype',
        'scene',
        'slotid',
        'sourcescene',
        'sourcesceneslotid',
    })
end

-- 填充视图和数据
local function fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    if checkNil(viewNameList, dataList, params, queries, itemQueries) then
        return
    end
    if checkNil(params["view_name"], params["item_count_name"]) then
        return
    end

    fillData(queries, {
        ["modeltype"] = "",
        ["scene"] = "",
        ["slotid"] = "",
        ["sourcescene"] = "",
        ["sourcesceneslotid"] = "",
        [params["item_count_name"]] = 0
    }, nil)

    local data = queryData("", queries)
    local itemCount = tonumber(data[params["item_count_name"]])
    if itemCount == nil or itemCount <= 0 then
        return
    end

    for i = 1, itemCount do
        table.insert(viewNameList, params["view_name"])
        local itemData = queryItemData(i, itemQueries)
        itemData['subposition'] = getPositionString(i)
        onItemData(data, itemData)
        table.insert(dataList, itemData)
    end
end

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")
    mRecyclerView = Rapid:getChild("recycler_view")
    mRecyclerView:getParser():update("layoutmanager", "gridlayoutmanager,4")
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")

    local viewNameList = {}
    local dataList = {}
    local params = {
        ["view_name"] = "personal_center_more_functoin_card_item.xml",
        ["item_count_name"] = "item_count",
    }
    local queries = {
        [params['item_count_name']] = 0,
        ['report_context'] = '',
        ['recomendid_card'] = '',
    }
    local itemQueries = {
        ["report_context_app"] = "",
        ["item_title"] = "",
        ["item_icon_url"] = "",
        ["item_jump_url"] = "",
    }
    fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    mRecyclerView:getView():updateData(viewNameList, dataList, true)
end
