local mPhotonView, mJavaBridge = ...
local TAG = "detail_welfare"
local DEBUG = true
local mCallbackObj = nil
local mIndex = 0
local AUTHORIZE_WELFARE_CALLBACK = "authorize_welfare_callback"

function close_dialog()
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:dismiss()
    end
end

function init()
    printf("init:")
end

function main()
    printf("main")
end

function tryAllAuthorize()
    printf("tryAllAuthorize mCallbackObj:" .. tostring(mCallbackObj))
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "one_key")
    dialogSelf:notifyEvent("ON_ONE_KEY_SELECTED")
    close_dialog()
end

function clickDetail()
    printf("clickDetail")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "detail")
    dialogSelf:notifyEvent("ON_DETAIL_SELECTED")
    close_dialog()
end

function clickCancel()
    printf("clickCancel")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "cancel")
    dialogSelf:notifyEvent("ON_CANCEL")
    close_dialog()
end

function clickClear()
    printf("clickClear")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "clear")
    dialogSelf:notifyEvent("ON_CLEAR_AUTHORIZE")
    close_dialog()
end

function printf(str)
    if DEBUG then
        print(TAG .. " " .. tostring(str))
    end
end