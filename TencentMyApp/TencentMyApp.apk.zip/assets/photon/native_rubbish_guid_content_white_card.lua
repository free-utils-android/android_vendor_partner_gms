local mPhotonView,mJavaBridge = ...
local Color = luajava.bindClass('android.graphics.Color')
local GB = 1073741824
local COLOR_NORMAL = Color:parseColor('#777777')
local COLOR_RED = Color:parseColor('#f42062')

local TAG = 'sxliu'
local CARD_STYLE_APP_DATA = '2'
local CARD_STYLE_SOFTWARE_CACHE = '20'
local CARD_STYLE_INSTALLER_CLEANUP = '21'
local DATA_KEY_APP_DATA = 'rubbish_app_data_size'
local DATA_KEY_SOFTWARE_CACHE = 'rubbish_software_cache_data_size'
local DATA_KEY_INSTALLER_CLEANUP = 'rubbish_installer_cleanup_data_size'

local hasGetAppNum

-- 选中数据
local function chooseMi(obj, def)
    if obj ~= nil then
        return obj
    else
        return def
    end
end

-- 获取存储key: 应用数据 or 软件缓存 or 安装包清理
local function getRubbishDataKey(cardStyle)
    if cardStyle == CARD_STYLE_APP_DATA then
        return DATA_KEY_APP_DATA
    elseif cardStyle == CARD_STYLE_SOFTWARE_CACHE then
        return DATA_KEY_SOFTWARE_CACHE
    elseif cardStyle == CARD_STYLE_INSTALLER_CLEANUP then
        return DATA_KEY_INSTALLER_CLEANUP
    end
    return nil
end

-- 检查是否有nil
local function checkNil(...)
    local args = {...}
    for i = 1, select("#", ...) do
        if args[i] == nil then
            return true
        end
    end
    return false
end

-- 获取本地数据
local function getNormalSettingsData(key, def)
    if checkNil(key) then
        return nil
    end
    return mJavaBridge:getNormalSettingsData(key, def)
end

-- 储存大小大于1G
local function greaterGB(dataSize)
    return tonumber(tonumber(dataSize, 10)) > GB
end

-- 获取垃圾数据
function getRubbishDataSize(dataKey)
    return getNormalSettingsData(dataKey, '0')
end

RubbishScanCallBack = {}
function RubbishScanCallBack.updateScanData(selectedSize,selectedSizeFormat,selectedSizeUnit,unSelectedSize,progress,selectedColor,unSelectedColor)
    local cardStyle = mPhotonView:getParser():getBinder():get("cardStyle")

    mJavaBridge:Log(TAG, "updateScanData cardStyle "..cardStyle)

    if cardStyle  ~= '6' then
        mPhotonView:getParser():getChildView("function_btn"):getView():setVisibility(8)
        mPhotonView:getParser():getChildView("progress_bar"):getView():setVisibility(0)
    end

end

function RubbishScanCallBack.doScanFinish(selectedSize,selectedSizeFormat,selectedSizeUnit,unSelectedSize,selectedColor,unSelectedColor)
    local cardStyle = mPhotonView:getParser():getBinder():get("cardStyle")
    local arrowText = mPhotonView:getParser():getBinder():get("arrow_text")
    if arrowText ~= nil and arrowText ~= '' then
        mPhotonView:getParser():getChildView("function_btn"):getView():setText(arrowText)
    else
        local dataKey = getRubbishDataKey(cardStyle)
        if dataKey ~= nil then
            local dataSize = getRubbishDataSize(dataKey)
            local functionBtn = mPhotonView:getParser():getChildView("function_btn"):getView()
            local dataSizeStr = mJavaBridge:formatSizeKorMorG(dataSize)
            functionBtn:setText(dataSizeStr)
            local dataSizeStrColor = COLOR_NORMAL
            if greaterGB(dataSize) then
                dataSizeStrColor = COLOR_RED
            end
            functionBtn:setTextColor(dataSizeStrColor)
            mJavaBridge:Log(TAG, "doScanFinish dataSizeStr "..chooseMi(dataSizeStr, ''))
        end
    end
    mPhotonView:getParser():getChildView("function_btn"):getView():setVisibility(0)
    mPhotonView:getParser():getChildView("progress_bar"):getView():setVisibility(8)
end

function init()
end

function onDestory()
end

function updateValue()

    local cardStyle = mPhotonView:getParser():getBinder():get("cardStyle")
    local scene = mPhotonView:getParser():getBinder():get("scene")
    if scene == 10123 then
        local rubbishCleanManager = luajava.bindClass("com.tencent.nucleus.manager.spacecleannew.RubbishCleanManager")
        rubbishScanCallBack = luajava.createProxy('com.tencent.nucleus.manager.spacecleannew.RubbishScanCallBack', RubbishScanCallBack)
        rubbishCleanManager:getInstance():registerScanListener(rubbishScanCallBack)
    end

    mPhotonView:getParser():getChildView("function_btn"):getView():setVisibility(0)
    mPhotonView:getParser():getChildView("progress_bar"):getView():setVisibility(8)
    hideUpdateAppIcon()

     --微信专清
     if cardStyle == '3' then
        local sizeStr = mJavaBridge:getWxQQRubbishSize(1)
        local appDataSize = mJavaBridge:getWxQQRubbishSize(1)
        local appDataSizeStr = mJavaBridge:formatSizeKorMorG(appDataSize)
        mPhotonView:getParser():getChildView("function_btn"):getView():setText(appDataSizeStr)

        if greaterGB(appDataSize) then
            mPhotonView:getParser():getChildView("function_btn"):getView():setTextColor(COLOR_RED)
        end

    end

     --大文件
     if cardStyle == '4' then

        local appDataSize = mJavaBridge:getNormalSettingsData("big_file_rubbish_size",'0')
        local appDataSizeStr = mJavaBridge:formatSizeKorMorG(appDataSize)
        mPhotonView:getParser():getChildView("function_btn"):getView():setText(appDataSizeStr)
        if greaterGB(appDataSize) then
            mPhotonView:getParser():getChildView("function_btn"):getView():setTextColor(COLOR_RED)
        end

    end

     --QQ专清
     if cardStyle == '5' then
        mJavaBridge:Log("chenjie_text","chenjie_text"..tostring(cardStyle))
        local appDataSize = mJavaBridge:getWxQQRubbishSize(0)
        local appDataSizeStr = mJavaBridge:formatSizeKorMorG(appDataSize)
        mPhotonView:getParser():getChildView("function_btn"):getView():setText(appDataSizeStr)

        if greaterGB(appDataSize) then
            mPhotonView:getParser():getChildView("function_btn"):getView():setTextColor(COLOR_RED)
        end

    end

    local arrowText = mPhotonView:getParser():getBinder():get("arrow_text")
    if arrowText ~= nil and arrowText ~= '' then
        mPhotonView:getParser():getChildView("function_btn"):getView():setText(arrowText)
        mPhotonView:getParser():getChildView("function_btn"):getView():setTextColor(COLOR_NORMAL)
    end

    --应用更新
    if cardStyle == '6' then
        updateUpdateAppIcon()
    end

    mJavaBridge:Log(TAG, "cardStyle "..cardStyle)

    local dataKey = getRubbishDataKey(cardStyle)
    if dataKey ~= nil then
        updateFunctionBtn(dataKey)
    end

end

-- 更新function_btn
function updateFunctionBtn(dataKey)
    local dataSize = getRubbishDataSize(dataKey)
    local dataSizeStr = mJavaBridge:formatSizeKorMorG(dataSize)
    mJavaBridge:Log(TAG, "updateFunctionBtn dataKey "..dataKey)
    mJavaBridge:Log(TAG, "updateFunctionBtn dataSizeStr "..dataSizeStr)
    local functionBtn = mPhotonView:getParser():getChildView("function_btn"):getView()
    functionBtn:setText(dataSizeStr)
    if greaterGB(dataSize) then
        functionBtn:setTextColor(COLOR_RED)
    end
end

function updateUpdateAppIcon()
    local redDotNum = mJavaBridge:getUpdateAppNums()
    mJavaBridge:Log("updateUpdateAppIcon","===redDotNum="..tostring(redDotNum))
    if redDotNum == 0 and hasGetAppNum == false and mJavaBridge:isAppUpdateRequesting() then
        return
    end

    local icon_uri1
    local icon_uri2
    local icon_uri3

    local icons = mJavaBridge:getUpdateAppIcons()
    if redDotNum == 1 then
        icon_uri1 = icons["updateAppArea1"]
        Rapid:setData('sub_icon_url1',tostring(icon_uri1))
    end
    if redDotNum == 2 then
        icon_uri1 = icons["updateAppArea1"]
        icon_uri2 = icons["updateAppArea2"]
        Rapid:setData('sub_icon_url1',tostring(icon_uri1))
        Rapid:setData('sub_icon_url2',tostring(icon_uri2))
    end
    if redDotNum >= 3 then
        icon_uri1 = icons["updateAppArea1"]
        icon_uri2 = icons["updateAppArea2"]
        icon_uri3 = icons["updateAppArea3"]
        Rapid:setData('sub_icon_url1',tostring(icon_uri1))
        Rapid:setData('sub_icon_url2',tostring(icon_uri2))
        Rapid:setData('sub_icon_url3',tostring(icon_uri3))
    end
    mJavaBridge:Log("updateUpdateAppIcon","===icon_uri1="..tostring(icon_uri1))
    mJavaBridge:Log("updateUpdateAppIcon","===icon_uri2="..tostring(icon_uri2))
    mJavaBridge:Log("updateUpdateAppIcon","===icon_uri3="..tostring(icon_uri3))

    if icon_uri1 ~= nil and icon_uri1 ~= "" then
        mPhotonView:getParser():getChildView("iv_rank_icon_1"):getView():setVisibility(0)
        mPhotonView:getParser():getChildView("function_btn"):getView():setVisibility(8)
    end

    if icon_uri2 ~= nil and icon_uri2 ~= "" then
        mPhotonView:getParser():getChildView("iv_rank_icon_2"):getView():setVisibility(0)
        mPhotonView:getParser():getChildView("function_btn"):getView():setVisibility(8)
    end

    if icon_uri3 ~= nil and icon_uri3 ~= "" then
      mPhotonView:getParser():getChildView("iv_rank_icon_3"):getView():setVisibility(0)
      mPhotonView:getParser():getChildView("function_btn"):getView():setVisibility(8)
    end
end

function hideUpdateAppIcon()
    mPhotonView:getParser():getChildView("iv_rank_icon_1"):getView():setVisibility(8)
    mPhotonView:getParser():getChildView("iv_rank_icon_2"):getView():setVisibility(8)
    mPhotonView:getParser():getChildView("iv_rank_icon_3"):getView():setVisibility(8)
end

function scanFinish()
    mPhotonView:getParser():getChildView("progress_bar"):getView():setVisibility(8)
end
