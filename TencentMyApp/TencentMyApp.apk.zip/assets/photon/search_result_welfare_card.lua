local mPhotonView,mJavaBridge = ...

local mRecyclerView = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil

local mQueryWord = nil
local mSearchScene = nil
local mSourceQuery = nil
local mSearchId = nil
local mSearchSession = nil

function main()
    mRecyclerView = mPhotonView:getParser():getChildView('rv')
end

-- 检查是否可以显示卡片
function isShowCard(lastAppModel)
    if lastAppModel == nil then
        return false
    end

    local appState = mJavaBridge:getAppState(lastAppModel)
    if appState == nil or appState == '' then
        return false
    end

    if appState == 'DOWNLOADING' or appState == 'PAUSED' 
    or appState == 'UPDATE' or appState == 'DOWNLOADED' 
    or appState == 'INSTALLED' then
        return true
    end
    return false
end

function onResume()
    if Rapid:getChild('card_container'):getView():getVisibility() ~= 0 then
        updateData()
    end
end

function updateData()
    local itemData1 = mPhotonView:getParser():getBinder():get("item_data_1")
    if itemData1 == nil then
        Rapid:getChild('card_container'):setAttr('height', '1px')
        mJavaBridge:postRun(markItemNoExposure)
        return
    end

    -- 后台因为实现原因不能把这个last_app_model放到卡片级，所以放在了这里处理第1个位置的数据。
    local lastAppModel = itemData1:get('last_app_model')
    if lastAppModel == nil or isShowCard(lastAppModel) == false then
        Rapid:getChild('card_container'):setAttr('height', '1px')
        mJavaBridge:postRun(markItemNoExposure)
        return
    end
    Rapid:getChild('card_container'):setAttr('height', 'wrap_content')

    local totalWelfWare = Rapid:getData('total_welfare', '0')
    local hintText = string.format("共<font color='#f79800'> %s </font>个礼包待领", totalWelfWare)
    local htmlClass = luajava.bindClass("android.text.Html")
    local title = htmlClass:fromHtml(hintText)
    Rapid:getChild("title"):getView():setText(title)
    
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    mQueryWord = Rapid:getData("queryWord")
    mSearchScene = Rapid:getData("searchScene")
    mSourceQuery = Rapid:getData("sourceQuery")
    mSearchId = Rapid:getData("searchId")
    mSearchSession = Rapid:getData("searchsession")
    local cardJumpUrl = Rapid:getData('card_jump_url', '')

    local dataList = {}
    local viewNameList = {}
    local itemCount = tonumber(Rapid:getData('item_num', '0'))
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        fillItemData(itemData, i, itemCount, cardJumpUrl)
        dataList[i] = itemData
        viewNameList[i] = 'search_result_welfare_card_item.xml'
    end

    mRecyclerView:getView():updateData(viewNameList, dataList, true)
end


function fillItemData(itemData, index, itemCount, cardJumpUrl)
    if itemData == nil then
        return
    end

    putBaseReportText(itemData)
    itemData:put("subPosition", mJavaBridge:create("Var", index))
    itemData:put("card_jump_url", mJavaBridge:create("Var", cardJumpUrl))
    itemData:put("inner_card_count", mJavaBridge:create("Var", itemCount))

    if index == itemCount then
        itemData:put("marginRight", mJavaBridge:create("Var", '12'))
    else
        itemData:put("marginRight", mJavaBridge:create("Var", '0'))
    end

    if mQueryWord ~= nil then
        itemData:put("queryWord", mJavaBridge:create("Var", mQueryWord))
    end
    if mSearchScene ~= nil then
        itemData:put("searchScene", mJavaBridge:create("Var", mSearchScene))
    end
    if mSourceQuery ~= nil then
        itemData:put("sourceQuery", mJavaBridge:create("Var", mSourceQuery))
    end
    if mSearchId ~= nil then
        itemData:put("searchId", mJavaBridge:create("Var", mSearchId))
    end
    if mSearchSession ~= nil then
        itemData:put("searchsession", mJavaBridge:create("Var", mSearchSession))
        itemData:put("searchSession", mJavaBridge:create("Var", mSearchSession))
    end
end

function putBaseReportText(itemData)
    if itemData == nil then
        return
    end

    if mScene ~= nil then
        local var_scene = mJavaBridge:create("Var", mScene)
        itemData:put("scene", var_scene)
    end
    
    if mSourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create("Var", mSourcescene)
        itemData:put("sourcescene", var_sourcescene)
        itemData:put("sourceScene", var_sourcescene)
    end
    
    if mModeltype ~= nil then
        local var_modeltype = mJavaBridge:create("Var", mModeltype)
        itemData:put("modeltype", var_modeltype)
        itemData:put("modelType", var_modeltype)
    end
    
    if mSourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create("Var", mSourceslotid)
        itemData:put("sourcesceneslotid", var_sourceslotid)
        itemData:put("sourceSceneSlotId", var_sourceslotid)
    end
    
    if mSlotid ~= nil then
        local var_slotid = mJavaBridge:create("Var", mSlotid)
        itemData:put("slotid", var_slotid)
        itemData:put("slotId", var_slotid)
    end
end

-- 在卡片被设置为gone的时候，移除卡片的曝光缓冲，避免卡片可见时缺失卡片曝光事件
function markItemNoExposure()
    local childView = Rapid:getChild('card_container'):getView()
    -- 获取placeholder对象
    local parentView = childView:getParent()
    if parentView ~= nil then
        local recyclerView = parentView:getParent()
        if recyclerView ~= nil then
            local position = Rapid:getData('position', '-1')
            if tonumber(position) >= 0 then
                recyclerView:removeExposureCache(tonumber(position), tonumber(position))
            end
        end
    end
end