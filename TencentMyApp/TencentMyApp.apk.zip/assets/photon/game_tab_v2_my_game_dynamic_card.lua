local mPhotonView, mJavaBridge = ...

local CARD_TYPE_LEFT = '1'
local CARD_TYPE_RIGHT_TOP = '2'
local CARD_TYPE_RIGHT_BOTTOM = '3'
local CARD_RIGHT_TOP_INDEX = 1
local CARD_RIGHT_BOTTOM_INDEX = 2

local bannerRecyclerView
local mIndicateView
local pageChangeListener

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil

local PageChangeListener = {}
function PageChangeListener.onPageChange(beforePageIndex, afterPageIndex)
    mIndicateView:setCurrentSelectedDotIndex(afterPageIndex)
end

function main()
    bannerRecyclerView = Rapid:getChild('banner'):getView()
    pageChangeListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IBannerPageChangeListener', 
            PageChangeListener)
    bannerRecyclerView:addPageChangeListener(pageChangeListener)
    mIndicateView = Rapid:getChild('indicate_view'):getView()
end

function handleCardSize()
    local screenWidth = mJavaBridge:px2dip(mPhotonView:getParser():getScreenWidth())
    local screenHeight = mJavaBridge:px2dip(mPhotonView:getParser():getScreenHeight())
    mJavaBridge:Log("qiwei","screenWidth===="..tostring(screenWidth))
    mJavaBridge:Log("qiwei","screenHeight===="..tostring(screenHeight))
    if screenWidth > screenHeight then
        -- 全屏后getScreenWidth接口可能会取反为屏幕高，所以对换一下
        screenWidth = screenHeight
    end
    local w = screenWidth - 16 - 10 - 16 --屏幕宽度减去视觉稿上的间距
    local l = 188 --视觉稿上左边大卡的宽度
    local s = 130 --视觉稿上右边小卡的宽度
    local h = 270 --视觉稿上卡片的高度
    local bit = l / (l + s)
    local l_w = w * bit --左边大卡的宽
    local l_h = l_w * h / l --左边大卡的高
    mJavaBridge:Log("qiwei","final screenWidth===="..tostring(screenWidth))
    mJavaBridge:Log("qiwei","bit===="..tostring(bit))
    mJavaBridge:Log("qiwei","l_w===="..tostring(l_w))
    mJavaBridge:Log("qiwei","l_h===="..tostring(l_h))
    Rapid:setData('l_w', tostring(l_w))
    Rapid:setData('l_h', tostring(l_h))
end

function updateData()
    handleCardSize()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    
    local dataList = {}
    local viewList = {}
    local itemNum = tonumber(tostring(Rapid:getData('item_num', '0')))
    local isNeedPlayBanner = true
    local bannerViewName
    local bannerItemNum = 0
    for i = 1, itemNum do
        local itemDataMap = Rapid:getData('item_data_' .. i)
        local cardType = tostring(itemDataMap:get('card_type'))
        if cardType == CARD_TYPE_LEFT then
            bannerItemNum = bannerItemNum + 1
            local bigCardType = tostring(itemDataMap:get('big_card_type'))
            putBaseReportText(itemDataMap)
            itemDataMap:put('banner_index', mJavaBridge:create("Var", bannerItemNum))
            itemDataMap:put('banner_item_width', mJavaBridge:create("Var", Rapid:getData('l_w')))
            dataList[i] = itemDataMap
            bannerViewName, isNeedPlayBanner = getBannerItemView(bigCardType)
            viewList[i] = bannerViewName

        elseif cardType == CARD_TYPE_RIGHT_TOP then
            setRightCardData(itemDataMap, CARD_RIGHT_TOP_INDEX)

        elseif cardType == CARD_TYPE_RIGHT_BOTTOM then
            setRightCardData(itemDataMap, CARD_RIGHT_BOTTOM_INDEX)
        end
    end
    
    if isNeedPlayBanner then
        Rapid:getChild('banner'):setAttr('autoplay', '1')
        Rapid:getChild('banner'):setAttr('cantouchscroll', '1')
        Rapid:getChild('indicate_view'):setAttr('visibility', 'visible')
        Rapid:setData('banner_item_num', bannerItemNum)
        local indicateMargin = mJavaBridge:dip2px(3)
        Rapid:setData('indicate_margin', indicateMargin)
    else
        Rapid:getChild('banner'):setAttr('autoplay', '0')
        Rapid:getChild('banner'):setAttr('cantouchscroll', '0')
        Rapid:getChild('indicate_view'):setAttr('visibility', 'gone')
    end
    
    bannerRecyclerView:updateData(viewList, dataList, true)
end

function setRightCardData(itemDataMap, index)
    Rapid:setData('right_label_icon_' .. index, tostring(itemDataMap:get('label_icon')))
    Rapid:setData('right_label_' .. index, tostring(itemDataMap:get('label')))
    Rapid:setData('right_label_color_' .. index, tostring(itemDataMap:get('label_color')))
    Rapid:setData('right_jump_url_' .. index, tostring(itemDataMap:get('jump_url')))
    Rapid:setData('right_cover_url_' .. index, tostring(itemDataMap:get('cover_url')))
    Rapid:setData('right_title_' .. index, tostring(itemDataMap:get('title')))
    Rapid:setData('right_app_name_' .. index, tostring(itemDataMap:get('app_name')))
    Rapid:setData('right_recommendid_' .. index, itemDataMap:get('recommendid'))
    Rapid:setData('right_report_context_' .. index, tostring(itemDataMap:get('report_context')))
end

-- bigCardType----1：S级（展示视频） 2：帖子（展示文本） 3：视频（展示文本）
-- 帖子和视频类型在卡片上长的一样，干的活也一样，只需要处理是否为1
function getBannerItemView(bigCardType)
    if bigCardType == '1' then
        return "game_tab_v2_my_game_dynamic_card_item_video.xml", false
    else
        return "game_tab_v2_my_game_dynamic_card_item_txt.xml", true
    end
end

function putBaseReportText(itemData)
    if mScene ~= nil then
        local var_scene = mJavaBridge:create("Var", mScene)
        itemData:put("scene", var_scene)
    end
    
    if mSourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create("Var", mSourcescene)
        itemData:put("sourcescene", var_sourcescene)
        itemData:put("sourceScene", var_sourcescene)
    end
    
    if mModeltype ~= nil then
        local var_modeltype = mJavaBridge:create("Var", mModeltype)
        itemData:put("modeltype", var_modeltype)
        itemData:put("modelType", var_modeltype)
    end
    
    if mSourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create("Var", mSourceslotid)
        itemData:put("sourcesceneslotid", var_sourceslotid)
        itemData:put("sourceSceneSlotId", var_sourceslotid)
    end
    
    if mSlotid ~= nil then
        local var_slotid = mJavaBridge:create("Var", mSlotid)
        itemData:put("slotid", var_slotid)
        itemData:put("slotId", var_slotid)
    end
end