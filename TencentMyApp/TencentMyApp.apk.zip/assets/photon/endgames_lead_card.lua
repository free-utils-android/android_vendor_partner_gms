local mPhotonView, mJavaBridge = ...

local welfare = require "end_games_lead_welfare"

local TAG = "lua_endgames_lead_card"
local WIDTH_STANDARD_SCREEN_DIP = 360
local WIDTH_STANDARD_SCREEN_PERCENTAGE = 100
local CLOUD_GAME_GAME_FINISH_EVENT = 36017
local UI_EVENT_LOGIN = 1088
local HEIGHT_HEAD_HEIGHT_STANDARD = 116
local HEIGHT_BACKGROUND_BIG_IMAGE = 435
local HEIGHT_BACKGROUND_SMALL_IMAGE = 236
local MARGIN_TOP_WAITING_CHALLENGE_CONTAINER = 12
local MARGIN_TOP_VIDEO_CONTAINER = 9
local MARGIN_TOP_VIDEO = 12
local MARGIN_TOP_VIDEO_CHALLENGE = -38 / 2
local MARGIN_HORIZONTAL_VIDEO = 24
local MARGIN_TOP_ALREADY_CHALLENGE_CONTAINER = 17
local MARGIN_TOP_CARD_NEXT = 16
local MARGIN_BOTTOM_WAITING_CHALLENGE_CONTAINER = 25
local MARGIN_BOTTOM_ALREADY_CHALLENGE_CONTAINER = 20
local PERCENTAGE_WAITING_CHALLENGE_CONTAINER = 74.17
local PERCENTAGE_ALREADY_CHALLENGE_CONTAINER = 20

local videoView
local IPlayerStateChangeListener = {}
local stateChangeListener
local mCurrentWidth
local mHeadHeight = 0
local mHeadHeightStandard = 0
local uiListener
local uiLoginListener
local EventDispatcherEnum
local isAddUiListener = false
WelfareCallback = {}

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")
    welfare.init(mPhotonView, mJavaBridge, Rapid, WelfareCallback)
    
    videoView = Rapid:getChild("video_view"):getView()
    stateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener",     
        IPlayerStateChangeListener)
    videoView:registerIPlayerStateChangeListener(stateChangeListener)
    videoView:setCloseAreaDetectFlag(true)

    mCurrentWidth = px2dip(mJavaBridge:getScreenWidth())
    mHeadHeightStandard = conversion(HEIGHT_HEAD_HEIGHT_STANDARD)
    mJavaBridge:Log(TAG, "loadFinish mHeadHeightStandard: "..tostring(mHeadHeightStandard))

    initUIEvent()
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")
    mJavaBridge:Log(TAG, "afterUpdateData() challenge_style: "..tostring(Rapid:getData('challenge_style')))
    Rapid:setData('jumpFlag', '0')
    welfare.afterUpdateData()
    updateAttr()
    updateVisibility()
    updateCardBackground()
end

function onResume()
    mJavaBridge:Log(TAG, "onResume")
    welfare.onResume()
    videoResume()
end

function onPause()
    mJavaBridge:Log(TAG, "onPause")
    videoPause()
end

function onRxpand()
    mJavaBridge:Log(TAG, "onRxpand")
    videoResume()
end

function onCompression()
    mJavaBridge:Log(TAG, "onCompression")
    videoPause()
end

function initUIEvent()
    if isAddUiListener then
        return
    end
    EventDispatcherEnum = luajava.bindClass("com.tencent.assistant.event.EventDispatcherEnum")
    uiListener = luajava.createProxy("com.tencent.assistant.event.listener.CommonEventListener", CommonEventListener)
    mJavaBridge:callModuleWithParams("EventListener", "addCommonEventListener",{CLOUD_GAME_GAME_FINISH_EVENT, uiListener})

    uiLoginListener = luajava.createProxy("com.tencent.assistant.event.listener.UIEventListener", UIEventListener)
    mJavaBridge:callModuleWithParams("EventListener", "addUIEventListener",{UI_EVENT_LOGIN, uiLoginListener})

    isAddUiListener = true
end

UIEventListener = {}
function UIEventListener.handleUIEvent(message)
    mJavaBridge:Log(TAG, "UIEventListener.handleUIEvent")
    if message.what == UI_EVENT_LOGIN then
        mJavaBridge:callModuleWithParams("EventListener", "removeUIEventListener",{UI_EVENT_LOGIN, uiLoginListener})
        onLoginStatusChanged()
    end
end

function checkRefreshPage(message)
    mJavaBridge:Log(TAG, "checkRefreshPage")
    local jumpFlag = tostring(Rapid:getData('jumpFlag'))
    local what = message.what
    local entranceid = "entranceid="..tostring(message.obj)
    local videoButtonJumpUrl = tostring(Rapid:getData('video_button_jump_url', ''))
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent jumpFlag: "..tostring(jumpFlag))
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent what: "..tostring(what))
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent entranceid: "..tostring(entranceid))
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent videoButtonJumpUrl: "..tostring(videoButtonJumpUrl))
    if jumpFlag ~= '2' then
        return false
    end
    if what ~= CLOUD_GAME_GAME_FINISH_EVENT then
        return false
    end
    if videoButtonJumpUrl == nil or string.find(videoButtonJumpUrl, entranceid) == nil then
        return false
    end
    return true
end

CommonEventListener = {}
function CommonEventListener.handleCommonEvent(message)
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent")
    if checkRefreshPage(message) then
        mJavaBridge:callModuleWithParams("EventListener", "removeCommonEventListener", {CLOUD_GAME_GAME_FINISH_EVENT, uiListener})
        Rapid:setData('jumpFlag', '0')
        outerRefreshPage()
    end
end

function videoResume()
    mJavaBridge:Log(TAG, "videoResume")
    if not isWaitingChallenge() then
        return
    end
    mJavaBridge:callModule('video', 'tryStopAllComponent')
    local canPlayNow = mJavaBridge:callModuleWithParams("video", "canPlayNow", {false})
    mJavaBridge:Log(TAG, "videoResume canPlayNow: "..tostring(canPlayNow))
    if not canPlayNow then
        return
    end
    videoView:tryContinueOrRestartPlay(false, false)
end

function videoPause()
    if videoView:isPlaying() then
        videoView:stop()
    end
end

function receiveJump()
    mJavaBridge:Log(TAG, "receiveJump")
    Rapid:setData('jumpFlag', '1')
    mJavaBridge:Log(TAG, "receiveJump jumpFlag: "..tostring(Rapid:getData('jumpFlag')))
    welfare.receive()
end

function videoChallengeJump()
    mJavaBridge:Log(TAG, "videoChallengeJump")
    Rapid:setData('jumpFlag', '2')
    mJavaBridge:Log(TAG, "videoChallengeJump jumpFlag: "..tostring(Rapid:getData('jumpFlag')))
    userLeadChallenge()
end

function onLoginStatusChanged()
    mJavaBridge:Log(TAG, "onLoginStatusChanged")
    if tostring(Rapid:getData('jumpFlag', '0')) ~= '1' then
        return
    end
    if tostring(mJavaBridge:getLoginType()) == "NONE" then
        return
    end
    welfare.onLoginSucceed()
end

function WelfareCallback.onSendGiftRequest(serverID, serverName, roleID, roleName)
    xLog('WelfareCallback.onSendGiftRequest', 'serverID', serverID)
    Rapid:setData('serverID', serverID)
    Rapid:setData('serverName', serverName)
    Rapid:setData('roleID', roleID)
    Rapid:setData('roleName', roleName)
end

function WelfareCallback.onUserLeadReceive(succeed, viewNameList, dataList)
    mJavaBridge:Log(TAG, "WelfareCallback.onUserLeadReceive succeed: "..tostring(succeed))
    local succ, toast = parseOnGetReplyList(succeed, viewNameList, dataList)
    mJavaBridge:showToast(toast, 1000)
    mJavaBridge:Log(TAG, "WelfareCallback.onUserLeadReceive succ: "..tostring(succ))
    mJavaBridge:Log(TAG, "WelfareCallback.onUserLeadReceive toast: "..tostring(toast))
    if succ then
        onGetReplyListSucceed()
    else
        onGetReplyListFailed()
    end
end

function onGetReplyListSucceed(msg)
    reportReceiveWelfare('103')
    outerAuthorized()
end

function onGetReplyListFailed(errorMsg)
    reportReceiveWelfare('104')
end

function checkListEmpty(list)
    return list == nil or list:size() < 1
end

function WelfareCallback.onWritePermissionSucceed()
    mJavaBridge:Log(TAG, "WelfareCallback.onWritePermissionSucceed")
    reportPermissionSucceed()
end

function parseRequestContext(viewNameList, dataList)
    xLog('parseReceiveGiftErrMsg', 'viewNameList', viewNameList)
    xLog('parseReceiveGiftErrMsg', 'dataList', dataList)
    if checkListEmpty(viewNameList) or checkListEmpty(viewNameList) then
        return nil
    end
    for i = 0, viewNameList:size() - 1 do
        local viewName = viewNameList:get(i)
        if viewName == 'request_context' then
            local data = dataList:get(i)
            if checkListEmpty(data) then
                return nil
            end
            return data
        end
    end
    return nil
end

function parseOnGetReplyList(succeed, viewNameList, dataList)
    local toast = nil
    local data = parseRequestContext(viewNameList, dataList)
    if data ~= nil then
        toast = data:get('receive_gift_err_msg')
        if succeed then
            succeed = tostring(data:get('ret')) == '0'
        end
    end
    if toast == nil or toast == '' then
        if succeed then
            toast = '领取礼包成功'
        else
            toast = '领取礼包失败，请稍后再试'
        end
    end
    return succeed, toast
end

function outerAuthorized()
    mJavaBridge:Log(TAG, "outerAuthorized")
    local serverID = tonumber(Rapid:getData('serverID'))
    mJavaBridge:Log(TAG, "serverID: "..tostring(serverID))
    if serverID == nil then
        mJavaBridge:Log(TAG, "Error: outerAuthorized serverID is nil")
        return
    end
    local value = tostring(serverID)
    if mRoleName == nil or mRoleName == "" then
        value = value..","
    else 
        value = value..","..tostring(mRoleName)
    end
    local param = {}
    param["key"] = "authorized"
    param["value"] = value
    xLog('outerAuthorized', 'param', param)
    Rapid:execAction("outeraction", param, param)
end

function outerRefreshPage()
    mJavaBridge:Log(TAG, "outerRefreshPage")
    local param = {}
    param["key"] = "refresh_page"
    xLog('outerRefreshPage', 'param', param)
    Rapid:execAction("outeraction", param, param)
end

function reportPermissionSucceed()
    local reportParams = {}
    reportParams["viewid"] = 'already_challenge_container'
    reportParams["dteventkey"] = "clck"
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:510,scene:data@scene,sourceScene:data@sourcescene,modeltype:-1,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:0,searchid:0"
    reportParams["extendparam"] = "report_element:permission,source_report_context:data@source_report_context,perm_source:newuser_guidance"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportReceiveWelfare(actionid)
    local reportParams = {}
    reportParams["viewid"] = 'welfare_container'
    reportParams["dteventkey"] = "clck"
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:"..actionid..",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:0,searchid:0"
    reportParams["extendparam"] = "report_element:welfare,source_report_context:data@source_report_context,report_context:data@receive_report_context,is_register:data@is_register,is_authorized:data@is_authorized"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function userLeadChallenge()
    local params = {}
    params['type'] = 'user_lead_challenge'
    mJavaBridge:request(3003, params, onUserLeadChallengeListener)
end

function onUserLeadChallengeListener(succeed, viewNameList, dataList)
    mJavaBridge:Log(TAG, "onUserLeadChallengeListener succeed: "..tostring(succeed))
end

function updateAttr()
    mHeadHeight = getTopSearchHeight()
    mJavaBridge:Log(TAG, "updateAttr mHeadHeight: "..tostring(mHeadHeight))

    local waitingChallengeContainerMarginTop = addHeadHeightConversion(MARGIN_TOP_WAITING_CHALLENGE_CONTAINER)
    Rapid:setData('waiting_challenge_container_margin', '0,'..waitingChallengeContainerMarginTop..',0,0')
    
    local waitingChallengeContainerHeight = conversionPercentage(PERCENTAGE_WAITING_CHALLENGE_CONTAINER)
    Rapid:setData('waiting_challenge_container_height', waitingChallengeContainerHeight)

    local videoContainerMarginTop = conversion(MARGIN_TOP_VIDEO_CONTAINER)
    Rapid:setData('video_container_margin', '0,'..videoContainerMarginTop..',0,0')

    local videoMarginTop = conversion(MARGIN_TOP_VIDEO)
    local videoMarginHorizontal = conversion(MARGIN_HORIZONTAL_VIDEO)
    Rapid:setData('video_margin', videoMarginHorizontal..','..videoMarginTop..','..videoMarginHorizontal..',0')
    Rapid:setData('mute_img_margin', videoMarginHorizontal..','..videoMarginTop..','..videoMarginHorizontal..',0')
    
    local videoChallengeMarginTop = conversion(MARGIN_TOP_VIDEO_CHALLENGE)
    Rapid:setData('video_challenge_margin', '0,'..videoChallengeMarginTop..',0,0')

    local alreadyChallengeContainerMarginTop = addHeadHeightConversion(MARGIN_TOP_ALREADY_CHALLENGE_CONTAINER)
    Rapid:setData('already_challenge_container_margin', '16,'..alreadyChallengeContainerMarginTop..',16,0')

    local alreadyChallengeContainerHeight = conversionPercentage(PERCENTAGE_ALREADY_CHALLENGE_CONTAINER)
    Rapid:setData('already_challenge_container_height', alreadyChallengeContainerHeight)

    local waitingChallengeCardHeight = sum(waitingChallengeContainerMarginTop, waitingChallengeContainerHeight, 
        MARGIN_BOTTOM_WAITING_CHALLENGE_CONTAINER, MARGIN_TOP_CARD_NEXT)
    mJavaBridge:Log(TAG, "waitingChallengeCardHeight: "..tostring(waitingChallengeCardHeight))
    local alreadyChallengeCardHeight = sum(alreadyChallengeContainerMarginTop, alreadyChallengeContainerHeight, 
        MARGIN_BOTTOM_ALREADY_CHALLENGE_CONTAINER, MARGIN_TOP_CARD_NEXT)
    mJavaBridge:Log(TAG, "alreadyChallengeCardHeight: "..tostring(alreadyChallengeCardHeight))
    if isWaitingChallenge() then
        Rapid:setData('card_container_height', waitingChallengeCardHeight)
    else
        Rapid:setData('card_container_height', alreadyChallengeCardHeight)
    end
end

function getTopSearchHeight()
    local topSearchHeight = px2dip(Rapid:getData('top_search_height', '0'))
    if topSearchHeight == nil or topSearchHeight <= 0 then
        return mHeadHeightStandard
    end
    return topSearchHeight
end

function updateVisibility()
    if isWaitingChallenge() then
        Rapid:setData('waiting_challenge_container_visibility', 'visible')
        Rapid:setData('already_challenge_container_visibility', 'gone')
    else
        Rapid:setData('waiting_challenge_container_visibility', 'gone')
        Rapid:setData('already_challenge_container_visibility', 'visible')
    end
end

function updateCardBackground()
    if isWaitingChallenge() then
        Rapid:setData('card_background_img_url', 'https://cms.myapp.com/yyb/2022/05/23/1653291329905_ca5f055d8dc67398a5ce604ef759e1a3.png')
    else
        Rapid:setData('card_background_img_url', 'https://cms.myapp.com/yyb/2022/05/23/1653291329777_d0b64568bb7dcc48ba9b79ca4fc1dce0.png')
    end
end

function initMute()
    if videoView == nil then
        return
    end

    setMuteImage(videoView:isMute())
end

function switchMute()
    mJavaBridge:Log(TAG, "switchMute videoView: "..tostring(videoView == nil))
    if videoView == nil then
        return
    end

    local isMute = not videoView:isMute()
    videoView:setMuteToGlobal(isMute, true, true)
    setMuteImage(isMute)
end

function setMuteImage(isMute)
    if isMute then
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2022/04/29/1651225684664_9e768df2e274b4986d17999ea7294b0c.png")
    else
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2022/04/29/1651225688728_db4ec6100775c4b352a2f43bce59c11a.png")
    end
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    setMuteImage(mute)
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart(videoView)
    mJavaBridge:Log(TAG, "onPlayStart")
    Rapid:getChild("mute_img"):setAttr("visibility", "visible")
    initMute()
end

-- 视频继续播放回调
function IPlayerStateChangeListener.onPlayContinue(videoView, currentPosition)
    mJavaBridge:Log(TAG, "onPlayContinue")
    Rapid:getChild("mute_img"):setAttr("visibility", "visible")
    initMute()
end

-- 视频重新播放回调
function IPlayerStateChangeListener.onRetryPlay(videoView)
    mJavaBridge:Log(TAG, "onRetryPlay")
end

-- 视频播放进度回调
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    Rapid:setData("videoCurProgress", tostring(progress))
end

-- 视频暂停播放回调
function IPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    mJavaBridge:Log(TAG, "onPlayPause")
    videoEnd()
end

-- 视频停止播放回调
function IPlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    mJavaBridge:Log(TAG, "onPlayStop")
    videoEnd()
end

-- 视频完成播放回调
function IPlayerStateChangeListener.onPlayComplete(videoView)
    if videoView ~= nil then
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
    mJavaBridge:Log(TAG, "onPlayComplete")
    videoEnd()
end

-- 播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    mJavaBridge:Log(TAG, "onError")
    videoEnd()
end

function videoEnd()
    Rapid:getChild("mute_img"):setAttr("visibility", "gone")
end

-- 是否待挑战
function isWaitingChallenge()
    return Rapid:getData('challenge_style', '0') == '0'
end

function conversionPercentage(percentage)
    return tostring(mCurrentWidth * percentage / WIDTH_STANDARD_SCREEN_PERCENTAGE)
end

function conversion(length)
    return tostring(mCurrentWidth * length / WIDTH_STANDARD_SCREEN_DIP)
end

function addHeadHeightConversion(length)
    return mHeadHeight + length
end

function conversionNumber(num)
    if type(num) ~= 'number' then
        num = tonumber(num)
    end
    if num == nil then
        num = 0
    end
    return num
end

function sum(...)
    local sum = 0
    for i, num in pairs({...}) do
        sum = sum + conversionNumber(num)
    end
    return sum
end

function dip2px(num)
    return mJavaBridge:dip2px(conversionNumber(num))
end

function px2dip(num)
    return mJavaBridge:px2dip(conversionNumber(num))
end

function xLog(fun, note, data)
    mJavaBridge:Log(TAG, tostring(fun).." "..tostring(note)..": "..tableToString(data))
end

function tableToString(data)
    if type(data) == 'table' then
        local text = ''
        for k, v in pairs(data) do
            if text == '' then
                text = '{\"'..tostring(k)..'\":\"'..tostring(v)..'\"'
            else
                text = text..',\"'..tostring(k)..'\":\"'..tostring(v)..'\"'
            end
        end
        if text ~= '' then
            text = text..'}'
        end
        return text
    else
        return tostring(data)
    end
end