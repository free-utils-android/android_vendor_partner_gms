local mPhotonView, mJavaBridge = ...
function updateData()
    local topicTag = Rapid:getData("app_hot_topic_tag")
    local appName = Rapid:getData("app_name")
    local appTag = Rapid:getData("app_hot_topic_txt")
    local app_hot_topic_tag_id = mPhotonView:getParser():getChildView("app_hot_topic_tag_id")
    local app_hot_topic_id = mPhotonView:getParser():getChildView("app_hot_topic_id")
    local app_hot_topic_txt_id = mPhotonView:getParser():getChildView("app_hot_topic_txt_id")

    if (topicTag ~= nil and topicTag ~= "") then
        app_hot_topic_tag_id:getParser():update("visibility", "visible")
        -- app_hot_topic_id:getParser():update("backgroundgradientdrawable", "cornerradius:30,color:ffe2eb")
    end
    if (appTag ~= nil and appTag ~= "") then
        app_hot_topic_txt_id:getParser():update("visibility", "visible")
        app_hot_topic_txt_id:getParser():update("text", appTag)
    end
    if (appName ~= nil and appName ~= "") then
        app_hot_topic_txt_id:getParser():update("visibility", "visible")
        app_hot_topic_txt_id:getParser():update("text", appName)
    end
    data = {}
    data["param"] = "scene:data@scene,actionid:100,slotid:data@slotId,subposition:data@subposition"
    data["recommendid"] = "data@recommendid"
    data["extendparam"] = "hotword:data@app_hot_topic_txt,hotwordtag:data@app_hot_topic_tag"
    data["reportelement"] = "hot_word"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, data)
end

function hotWordClick()
    local subposition = Rapid:getData("subposition")
    local slotId = Rapid:getData("slotId")
    local mhotWord = Rapid:getData("app_hot_topic_txt")
    if (mhotWord == nil or mhotWord == "") then
        mhotWord = Rapid:getData("app_name")
    end
    local actionurl = Rapid:getData("jump_hot_topic_detail_url")
    local slotId = Rapid:getData("slotId")
    local recommendId = Rapid:getData("recommendid")
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendId), "default")



    if (actionurl == "" or actionurl == nil) then
        local tmast = ""
        tmast = "tmast://search?key=" .. mhotWord .. "&sourceScene=2007&searchScene=200702&sourceSlotId=" .. slotId.."&subPosition="..subposition
        if(rcdBase64 ~= nil) then
            tmast = tmast.."&recommendId="..mJavaBridge:urlEncode(rcdBase64)
        end
        local params = {}
        params["tmast"] = tmast
        Rapid:execAction("tmastaction", params, nil)
    else
        local intent = luajava.newInstance('android.content.Intent', 'android.intent.action.VIEW')
        local uri = luajava.bindClass('android.net.Uri')
        uri = uri:parse(actionurl)
        if (uri:getScheme() == "tmast" or uri:getScheme() == "http" or uri:getScheme() == "https") then
            local data = {}
            data["tmast"] = uri:toString()

            mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", data, data)
        end
    end
end
