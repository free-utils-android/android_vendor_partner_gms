local mPhotonView, mJavaBridge = ...
local DEFAULT_HEADER_ICON = "https://cms.myapp.com/yyb/2021/09/28/1632815321201_64420bdf7bc9ec075e49b8cb30933f01.png"
local DEFAULT_BUFF_LEVEL = "https://cms.myapp.com/yyb/2021/09/28/1632816444741_3f0b2438cd0b5d4206776727e51743f9.png"

local lastUsedMethod = "NONE"

function init(...)
    mJavaBridge:registerJsBridgeNotify(loginCallback)
    initStyle()
    showLonginRedDot()
end

function initData()
    lastUsedMethod = mJavaBridge:getLastTimeLoginType()
    Rapid:setData("last_used_login_method", lastUsedMethod)
    if lastUsedMethod == "WX" then
        Rapid:setData("is_last_wx_login", true)
        Rapid:setData("is_last_qq_login", false)
    elseif lastUsedMethod == "MOBILEQ" then
        Rapid:setData("is_last_qq_login", true)
        Rapid:setData("is_last_wx_login", false)
    else
        Rapid:setData("is_last_wx_login", false)
        Rapid:setData("is_last_qq_login", false)
    end

    local isGameUser = Rapid:getData("is_game_user")
    if isGameUser ~= nil and isGameUser ~= "" then
        Rapid:runTask("tryShowLoginDialog")
    end

    mJavaBridge:Log("PersonalCenterUserInfoCard", "LastUsedMethod: " .. lastUsedMethod)
end

function initStyle(...)
    initData()
    if isLogin() then
        loginStyle()
    else
        logoutStyle()
    end
end

function loginStyle(...)
    local loginInfo = mJavaBridge:getLoginInfoHash()
    local dataJson = mJavaBridge:create("JSONObject", loginInfo)
    local iconUrl = tostring(dataJson:getString("user_icon"))
    local nickName = tostring(dataJson:getString("nick_name"))
    Rapid:setData("user_icon", iconUrl)
    Rapid:setData("nick_name", nickName)

    Rapid:getChild("userinfo"):setAttr("visibility", "visible")
    Rapid:getChild("notLoggedInView"):setAttr("visibility", "gone")
end

function logoutStyle(...)
    local useNewLogoutStyle = mJavaBridge:getSwitchConfigBoolean("key_use_new_user_center_not_logged_in_style")

    if useNewLogoutStyle then
        newLogoutStyle()
    else
        oldLogoutStyle()
    end
end

function oldLogoutStyle()
    mJavaBridge:Log("PersonalCenterUserInfoCard", "Use old logout style")

    Rapid:setData("user_icon", DEFAULT_HEADER_ICON)
    Rapid:setData("nick_name", "点击登录")
    Rapid:setData("buff_level_icon", DEFAULT_BUFF_LEVEL)
    Rapid:getChild("userinfo"):setAttr("visibility", "visible")
    Rapid:getChild("notLoggedInView"):setAttr("visibility", "gone")
end

function newLogoutStyle()
    mJavaBridge:Log("PersonalCenterUserInfoCard", "Use new logout style")

    Rapid:getChild("userinfo"):setAttr("visibility", "gone")
    Rapid:getChild("notLoggedInView"):setAttr("visibility", "visible")

    if lastUsedMethod == "WX" then
        Rapid:getChild("qq_last_used"):setAttr("visibility", "invisible")
        Rapid:getChild("wx_last_used"):setAttr("visibility", "visible")
    elseif lastUsedMethod == "MOBILEQ" then
        Rapid:getChild("qq_last_used"):setAttr("visibility", "visible")
        Rapid:getChild("wx_last_used"):setAttr("visibility", "invisible")
    else
        Rapid:getChild("qq_last_used"):setAttr("visibility", "invisible")
        Rapid:getChild("wx_last_used"):setAttr("visibility", "invisible")
    end
end

function isLogin(...)
    return tostring(mJavaBridge:getLoginType()) ~= "NONE"
end

function showLoginDialogWithType(type)
    local jsParams = {}
    jsParams["logintype"] = type
    mJavaBridge:runJsBridge("openLoginActivity", jsParams, nil)
end

function showLoginDialog(...)
    showLoginDialogWithType("DEFAULT")
end

function onDuplicateLogin()
    local params = {}
    params["tmast"] = ""
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end

function loginClick(...)
    if not isLogin() then
        local useNewLogoutStyle = mJavaBridge:getSwitchConfigBoolean("key_use_new_user_center_not_logged_in_style")
        if not useNewLogoutStyle then
            showLoginDialog()
        end
    else
        onDuplicateLogin()
    end
end

function onResume()
    mJavaBridge:delayRun(800, initStyle)
    showLonginRedDot()
end

function loginCallback(result_code, method, data)
    if method == "getUserLoginToken" then
        if isLogin() then
            initStyle()
        end
    end
end

function bufLoginClick(...)
    if not isLogin() then
        showLoginDialog()
    else
        local params = {}
        params["tmast"] = "tmast://webview?mode=0&url=https%3A%2F%2Fcdn.yyb.qq.com%2Fbuff-center%2Findex.html%3Ftab%3D1"
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
    end
end

function showLonginRedDot()
    local hasUserRedDot = mJavaBridge:callModule("AppManager", "hasUserRedDot")
    if hasUserRedDot ~= nil and hasUserRedDot and  not isLogin() then
        Rapid:getChild("unloginIconRed"):setAttr("visibility", "visible")
    else
        Rapid:getChild("unloginIconRed"):setAttr("visibility", "gone")
    end
end

function doWxLogin()
    if not isLogin() then
        showLoginDialogWithType("WX")
    else
        onDuplicateLogin()
    end
end

function doQqLogin()
    if not isLogin() then
        showLoginDialogWithType("QMOBILEQ")
    else
        onDuplicateLogin()
    end
end
