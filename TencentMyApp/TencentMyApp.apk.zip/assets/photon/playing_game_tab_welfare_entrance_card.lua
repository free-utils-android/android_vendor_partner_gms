local mPhotonView,mJavaBridge = ...
local TAG = "playing_game_tab_welfare_entrance_card_debug"
local mRecyclerView
local mPageSwitchLayout
local mTotalX
local mIndicator
local mTotalIndicatorX
local mTotalRvScrollX
local ITEM_WIDTH = 60
local mRightMarginDiff
local INDICATOR_WIDTH = 20
local MARGIN_SPACE = 5

function loadFinish()
    print("loadFinish")
    mRecyclerView = Rapid:getChild("rv_app")
    mIndicator = Rapid:getChild("indicator"):getView()
    mPageSwitchLayout = Rapid:getChild("indicator_root")
end

function afterUpdateData()
    print("indicatortest afterUpdateData")
    resetCardView()
    -- 大于5个入口才有分页展示
    local itemNum = tonumber(Rapid:getData("item_num", "0"))
    if itemNum > 5 then
        mPageSwitchLayout:setAttr("visibility", "visible")
        initIndicator(itemNum)
    else
        mPageSwitchLayout:setAttr("visibility", "gone")
    end

    -- 构建item数据
    local dataList = {}
    local viewNameList = {}
    local subViewName = "playing_game_tab_welfare_entrance_card_item.xml"
    local index = mPhotonView:getParser():getBinder():get("index")

    for i = 1, itemNum do
       local itemData = Rapid:getData("item_data_" .. i)
       itemData:put("modeltype", mJavaBridge:create("Var", Rapid:getData("modeltype")))
       itemData:put("slotid", mJavaBridge:create("Var", Rapid:getData("slotid")))
       itemData:put("scene", mJavaBridge:create("Var", Rapid:getData("scene")))
       itemData:put("sourcescene", mJavaBridge:create("Var", Rapid:getData("sourcescene")))
       itemData:put("sourcesceneslotId", mJavaBridge:create("Var", Rapid:getData("sourcesceneslotId")))
       itemData:put("uni_channel_appid", mJavaBridge:create("Var", Rapid:getData("uni_channel_appid")))
       itemData:put("small_position",mJavaBridge:create("Var", i))

       dataList[i] = itemData
       viewNameList[i] = subViewName
    end

    print("index="..tostring(cardPosition).."itemNum="..itemNum)
    mRecyclerView:getView():clear()
    mRecyclerView:getView():autoReport(tonumber(index), itemNum, RapidList:getController())
    mRecyclerView:getView():updateData(viewNameList, dataList)
end

function resetCardView()
    print("resetCardView")
    mTotalX = 0
    local screenWidth = mJavaBridge:px2dip(mJavaBridge:getScreenWidth())
    mRightMarginDiff = screenWidth - ITEM_WIDTH * 5 - MARGIN_SPACE
    print("indicatortest loadFinish screenWidth="..tostring(screenWidth))
    mRecyclerView:getView():scrollToPosition(0)
    mIndicator:setTranslationX(0)
end

function initIndicator(itemCount)
    local onScrollListener =
           luajava.createProxy(
           "com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrolledListener",
           OnScrollChangeListener
    )
    Rapid:getChild("indicator_root"):setAttr("visibility", "visible")
    mRecyclerView:getView():setScrolledListener(onScrollListener)
    local hideItemCount = (itemCount - 5)
    mTotalRvScrollX = mJavaBridge:dip2px(ITEM_WIDTH) * hideItemCount + MARGIN_SPACE * 2 - mRightMarginDiff
    mTotalIndicatorX = mJavaBridge:dip2px(INDICATOR_WIDTH)
end



OnScrollChangeListener = {}
function OnScrollChangeListener.onScrolled(mRecyclerView, dx, dy)
    mTotalX = mTotalX + dx
    local radio = mTotalX / mTotalRvScrollX
    if radio > 0.9 then
        radio = 1
    end
    local translationX = radio * mTotalIndicatorX
    mIndicator:setTranslationX(translationX)
    print("indicatortest scorll".."radio="..radio..", translationX=".. translationX..", mTotalX="..mTotalX..", mTotalRvScrollX="..mTotalRvScrollX)
end

function print(args)
    Rapid:Log(TAG, args)
end