local mPhotonView, mJavaBridge = ...

local stateChangeListener
local IPlayerStateChangeListener = {}

local videoPlaybackProgress
local videoView
local boolean errorHappenned = false

function init()
    Rapid:setData("app_label_1", "")
    Rapid:setData("app_label_2", "")
    Rapid:setData("app_label_3", "")
    initMute()
end

function fillValue()
    initDownloadTimes()

    initLabel()

    initAppScore()
    
    Rapid:setData("app_slotId", tostring(Rapid:getData("slotId")) .. "_-1_1")
    Rapid:getChild("progress"):setAttr("visibility", "visible")
    addListener()

    local leftTime = Rapid:getData("left_time")
    local leftTimeStr = getLeftString(leftTime)
    Rapid:setData("left_time_str", leftTimeStr)
end

-- 初始化评分
function initAppScore()
    local appScore = Rapid:getData("app_score")

    if appScore ~= nil then
        local len = string.len(appScore)
        -- 去掉appScore最后的“分”字，一个汉字用3个字符来表示，所以是 -3
        local realScore = string.sub(appScore, 0, len - 3)
        Rapid:setData("app_score", realScore)
    end
end

-- 初始化下载量
function initDownloadTimes()
    local showDownloadTimes = Rapid:getData("show_download_times", "false")

    if showDownloadTimes == "true" then
        Rapid:getChild("app_download_times"):setAttr("visibility", "visible")
    else
        Rapid:getChild("app_download_times"):setAttr("visibility", "gone")
    end
end

-- 初始化label
function initLabel()
    local app_label = tostring(Rapid:getData("app_label", ""))

    if app_label == nil or app_label == "" then
        Rapid:getChild("app_label_1"):setAttr("visibility", "gone")
        Rapid:getChild("app_label_2"):setAttr("visibility", "gone")
        Rapid:getChild("app_label_3"):setAttr("visibility", "gone")
    else
        local splitStrTable = splitStr(app_label)
        if splitStrTable ~= nil then
            for i, v in ipairs(splitStrTable) do
                -- 目前最多显示3个
                if i > 3 then
                    return
                end

                Rapid:getChild("app_label_"..i):setAttr("visibility", "visible")
                Rapid:getChild("app_label_"..i):setAttr("text", tostring(v))
            end
        end
    end
end

-- 分割字符串，“1|2|3|”
function splitStr(str)
    if (str == nil or str == "") then
        return {}
    end

    local last_start = 1
    local single_str = nil
    local index = 1
    local res = {}
    for k = 1, string.len(str) do
        if string.sub(str, k, k) == '|' then
            if (last_start < k) then
                single_str = string.sub(str, last_start, k - 1)
                res[index] = single_str
                index = index + 1
            end
            last_start = k + 1
        end
    end
    -- 不以 | 结尾，需要把最后的 type 计算进来
    if (last_start <= string.len(str)) then
        single_str = string.sub(str, last_start, string.len(str))
        res[index] = single_str
        index = index + 1
    end
    return res
end

-- 视频进度改变，显示的内容变化
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    if (videoView == nil) then
        return
    end
    
    local totalDuring = videoView:getTotalDuring()
    if (totalDuring < progress) then
        return
    end

    local leftTime = totalDuring - progress
    local leftSecond = leftTime / 1000
    local leftTimeStr = getLeftString(leftSecond)
    errorHappenned = false
    Rapid:getChild("progress"):setAttr("visibility", "visible")
    Rapid:setData("videoCurProgress", tostring(progress))
    Rapid:setData("left_time_str", tostring(leftTimeStr))
end

-- 时间格式转换
function getLeftString(leftSecond)
    if (leftSecond == nil) then
      return
    end

    leftSecond = tonumber(tostring(leftSecond))
    local min = math.floor(leftSecond / 60)
    local second = math.floor(leftSecond % 60)
    local secondStr = tostring(second)
    if (second < 10) then
      secondStr = '0' .. secondStr
    end

    local leftTimeStr = tostring(min) .. ':' .. secondStr
    return leftTimeStr
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    if(mute) then
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end

function IPlayerStateChangeListener.onPlayStart(...)
    Rapid:getChild("mute_img"):setAttr("visibility","visible")
    initMute()
end

function IPlayerStateChangeListener.onPlayContinue(...)
    Rapid:getChild("mute_img"):setAttr("visibility","visible")
    initMute()
end

function IPlayerStateChangeListener.onPlayStop(...)
    Rapid:getChild("mute_img"):setAttr("visibility","gone")

    if errorHappenned then
        handleVideoError()
    else 
        Rapid:getChild("progress"):setAttr("visibility", "visible")
    end
    
    local leftTime = Rapid:getData("left_time")
    local leftTimeStr = getLeftString(leftTime)
    Rapid:setData("left_time_str", leftTimeStr)
end

function IPlayerStateChangeListener.onPlayPause(...)
    Rapid:getChild("mute_img"):setAttr("visibility","gone")
end

function IPlayerStateChangeListener.onPlayComplete(videoView)
    Rapid:getChild("mute_img"):setAttr("visibility","gone")

    if videoView ~= nil then
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
end

-- 播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    errorHappenned = true
    handleVideoError()
end

function handleVideoError()
    Rapid:getChild("progress"):setAttr("visibility", "gone")
end

function addListener(...)
    videoView = mPhotonView:getParser():getChildView("video_view")
    stateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IPlayerStateChangeListener)

    if (videoView ~= nil and stateChangeListener ~= nil) then
        videoView:getView():registerIPlayerStateChangeListener(stateChangeListener)
    end
end

-- 设置静音
function setMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    if isMute then
        videoView:getView():setMuteToGlobal(false, true, true)
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    else
        videoView:getView():setMuteToGlobal(true, true, true)
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    end
end

-- 初始化静音按钮
function initMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    if isMute then
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end