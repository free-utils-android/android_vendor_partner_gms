local mPhotonView,mJavaBridge = ...
local scene
local sourcescene
local photoncmd
local layout_container


function load()
    local params = {}
    params["GetDownloadRelatedCardsRequest"]=mPhotonView:getParser():getBinder():get("GetDownloadRelatedCardsRequest")
    photoncmd = mPhotonView:getParser():getBinder():get("photoncmd")
    scene = mPhotonView:getParser():getBinder():get("scene")
    sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")

	mJavaBridge:request(tonumber(photoncmd), params, onRequestListener)
end

function reload()

    local params = {}
    params["GetDownloadRelatedCardsRequest"]= mPhotonView:getParser():getBinder():get("refresh_Page")
    photoncmd = mPhotonView:getParser():getBinder():get("photoncmd")
    scene = mPhotonView:getParser():getBinder():get("scene")
    sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
    if(params ~= nil) then
        mJavaBridge:request(tonumber(photoncmd), params, onRequestListener)
    end
end

function onRequestListener(succeed, viewNameList, dataList)
    local listSize = 0
	if( viewNameList ~= nil and dataList ~= nil ) then
	    listSize = viewNameList:size()
	end
	local result = succeed and viewNameList ~= nil and dataList ~= nil
    local param = {}
    param['key'] =  'PHOTON_RECOMMEND_REQUEST_RESULT'
    param['value'] = tostring(result)..","..listSize
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("outeraction",param,nil);

	if( succeed ) then
		onRequestSucceed(viewNameList, dataList)
	else
		onRequestFailed()
	end
end


function onRequestSucceed(viewNameList, dataList)

	if( viewNameList == nil or dataList == nil ) then
		onRequestFailed()
		return
	end

    layout_container = mPhotonView:getParser():getChildView("layout_containerx")

    if(layout_container ~= nil) then
        layout_container:getView():removeAllViews()
        layout_container:getView():invalidate()
    end

    count = viewNameList:size() - 1

    for i=0,count do

        if(scene ~= nil ) then
            local sceneVar = mJavaBridge:create("Var", scene)
            dataList:get(i):put("scene",sceneVar)
        end

        if(sourcescene ~= nil) then
            local sourcesceneVar = mJavaBridge:create("Var", sourcescene)
            dataList:get(i):put("sourcescene",sourcesceneVar)
        end

        if(dataList:get(i):get('download_related_number') ~= nil) then
            if(dataList:get(i):get('download_related_number'):getString() == "1") then
                local slotid_card = mJavaBridge:create("Var", "18_-1")
                local slotid = mJavaBridge:create("Var", "18")
                dataList:get(i):put("slotid_card",slotid_card)
                dataList:get(i):put("slotid",slotid)
            elseif(dataList:get(i):get('download_related_number'):getString() == "2") then
                local slotid_card = mJavaBridge:create("Var", "19_-1")
                local slotid = mJavaBridge:create("Var", "19")
                dataList:get(i):put("slotid_card",slotid_card)
                dataList:get(i):put("slotid",slotid)
            end
        end


        mJavaBridge:addPlaceHolderView(viewNameList:get(i),'layout_containerx',nil,dataList:get(i),nil);
    end
end


function onRequestFailed()
	mJavaBridge:Log("jarryzhang","Request Fail")
end

