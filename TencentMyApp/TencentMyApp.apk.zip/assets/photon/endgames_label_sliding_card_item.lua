local mPhotonView, mJavaBridge = ...

local selectedItem = nil
local unSelectedItem = nil
local isSelected = false

function init( ... )
    unSelectedItem = Rapid:getChild("unselect")
    selectedItem = Rapid:getChild("select")
end

function notifySelect( ... )
    local param = {}
    param["key"] = "select"
    param["value"] = Rapid:getData("label_id")
    Rapid:execAction("outeraction", param, param)
end

function select( ... )
    if isSelected then
        return
    end
    isSelected = true
    selectedItem:setAttr("visibility", "visible")
    unSelectedItem:setAttr("visibility", "gone")
    -- 首次选中不需要提醒,否则会导致页面刷新,陷入循环
    if not Rapid:getData("isFromBindViewHolder", false) then
        notifySelect()
        -- 上报点击
        reportClick()
    end
end

function unselect( ... )
    if not isSelected then
        return
    end
    isSelected = false
    selectedItem:setAttr("visibility", "gone")
    unSelectedItem:setAttr("visibility", "visible")
end

function reportClick( )
    local data = {}
    data["param"] = "slotid:data@slotid,subposition:data@subposition,scene:data@scene,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,sourcemodeltype:data@sourcemodeltype"
        ..",modeltype:data@modeltype,appid:0,actionid:250"
    data["extendparam"] ="is_register:data@is_register,is_authorized:data@is_authorized,report_context:data@report_context"
    data["reportelement"] = "mark"
    data["recommendid"] = "data@recommendid"
    data["dteventkey"] = "clck"
    data["viewid"] = "root"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, nil)
end