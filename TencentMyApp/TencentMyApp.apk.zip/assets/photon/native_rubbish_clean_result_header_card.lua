local mPhotonView,mJavaBridge = ...

function updateValue()
  local clean_size = mPhotonView:getParser():getBinder():get("selected_size")
  local subnotice = mPhotonView:getParser():getBinder():get("sub_notice_text_color")
  
  if clean_size == nil or clean_size == '' then
     mPhotonView:getParser():getChildView("title"):getView():setText("12")
     mPhotonView:getParser():getChildView("title"):getView():setText("手机很干净");
  else
     mPhotonView:getParser():getChildView("title"):getView():setText(clean_size.."垃圾已清理");
  end

  if subnotice ~= nil and subnotice ~= "" then
     mPhotonView:getParser():getChildView("subtitle"):getView():setText(subnotice);
  else
     mPhotonView:getParser():getChildView("subtitle"):getView():setText("试试其他功能吧!");
  end

end

function finish()
    mJavaBridge:finish()
    --mJavaBridge:switchRubbishCleanModel(0X08)
end
