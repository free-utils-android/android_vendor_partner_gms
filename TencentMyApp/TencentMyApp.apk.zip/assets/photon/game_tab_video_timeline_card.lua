local mRapidView, mJavaBridge = ...

local TAG = "timeline"
local TAG_CLOUD = "timeline_cloud"
local TAG_CLOUD_FLAG = "timeline_cloud_flag"
local TAG_ICON = "timeline_icon"
local TAG_APP_EXPOSURE = "timeline_app_exposure"
local DEBUG = false

local mTotalNum = 0
local mGiftRecyclerView = nil
local mTotalOffsetX = 0
local mLastIndex = -1
local mCurIndex = 0
local mDivider = nil
local mDividerMargin = mJavaBridge:dip2px(4) -- item到分割线的距离
local mDividerOffset = mJavaBridge:dip2px(5) --recycleview到屏幕距离
local mItemOffset = mJavaBridge:dip2px(5)
local mItemMarginLeft = mJavaBridge:dip2px(14) -- 第一个item到左边recycleview的距离
local mItemRealWidth = mJavaBridge:dip2px(64) -- item除开margin部分的宽高，也就是adapter_container的宽高
local mItemWidth = mItemRealWidth + 2 * mItemMarginLeft -- 56 + 14 * 14
local mAnimationDuration = 300

local mTimelineScaleRate = 1.20
local mScaleRate = 1.4
local mAlphaFocused = 0.85
local mAlphaSmall = 0.65
local mAlphaSubSmall = 0.45

local mLeftVisible = 0
local mLastVisible = -1

-- 缩放动画相关
local mLastImageContainer = nil
local mLastTimelineContainer = nil
local mLastTitleContainer = nil
local mLastButtonContainer = nil
local mAnimationCount = 0
local mViewNameList = {}
local mViewDataList = {}

-- 更多新游曝光特殊处理
local VISIBLE = 0
local mLastMoreItemVisibility = false
local mCurMoreItemVisibility = false

-- 埋点相关的数据
local CMD_CARD_SLIDE = 301
local CMD_EXPOSURE = 100
local CMD_EXPOSUREV2 = -100
local CMD_CLICK_JUMP = 200
local CMD_BUTTON_UNFOCUS_SELECTED = 250

-- 和视频播放相关
local IPlayerStateChangeListener = {}
local DURATION_ANIM = 300
local DURATION_SHOW_CLOUD_GAME = 10000
local mVideoView = nil
local mStateChangeListener = nil
local mNeedCloudAnimation = true
local mIsNeedPlayNext = false
local mIsStart = false
local mStartTimeMs = 0
local mIsCompleted = false
local mProcess = 0

-- 标记云玩黄条是否展示
local SCALE_BIG = "scale_big"
local mTableYellowFlag = {}
local TABLE_YELLOW_MAP = "table_yellow_map"
local CURRENT_ITEM_INDEX = "current_item_index" 

--load的时候运行
function loadFinish()
    logForDebug(TAG_ICON, " loadFinish")
    mGiftRecyclerView = mRapidView:getParser():getChildView("id_gift_rv"):getView()
end

function init()
    logForDebug(TAG_CLOUD_FLAG, "reset data:")
    Rapid:setData(CURRENT_ITEM_INDEX, tonumber(0))
    initCommon()
end

--数据更新后，卡片入口主方法
function main()
    logForDebug(TAG_CLOUD_FLAG, "update main")
    initGallery()
    addVideoListener()
    updateCard()
end

-- 更新卡片
function updateCard()
    --初始化数据
    initData()

    local index = Rapid:getData("index", "-1")
    local itemIndex = tonumber(Rapid:getData(CURRENT_ITEM_INDEX))
    logForDebug(TAG_CLOUD_FLAG, "initData index=" .. tostring(index) .. 
        " mTotalNum:" .. tostring(mTotalNum) .. " mCurIndex：" .. tostring(mCurIndex)
        .. " itemIndex:" .. tostring(itemIndex) .. " mLastIndex:" .. tostring(mLastIndex))
    if mLastIndex == -1 and mCurIndex == 0 then
        refreshRecycleView()
        anchorFirstItem()
        return
    end

    -- 滑动
    if itemIndex ~= 0 then 
        logForDebug(TAG_ICON,"force return as scroll")
        return
    end

    -- curIndex == 0的情况，就不知道是下拉刷新还是滑动更新的数据，统一的用刷新来处理了
    mCurIndex = tonumber(itemIndex)
    logForDebug(TAG_ICON, "force return as recycleview update data")

    refreshRecycleView()
    anchorCurrentItem()
    updateCardVideoExposure()
end

function initCommon()
    initMute()
end

--初始化数据
function initData()
    mTotalNum = tonumber(Rapid:getData("item_num"))
end

function refreshRecycleView()
    mViewNameList = {}
    mViewDataList = {}

    for i = 1, mTotalNum do
        local itemData = mRapidView:getParser():getBinder():get("item_data_" .. i)

        if itemData ~= nil then
            local report_context = itemData:get("report_context")
            if report_context ~= nil then
                Rapid:setData('report_context_'..i, tostring(report_context))
            end     

            local var_callback = mJavaBridge:create("var", CallbackObject)
            itemData:put("callback", var_callback)
            local title = tostring(itemData:get('title'))
            local booking = tostring(itemData:get('booking'))
            local smallposition = tostring(i)

            logForDebug(TAG, " itemData i:" .. i .. " booking:" .. tostring(itemData:get('booking')))
            -- card param
            itemData:put("sourcescene", mJavaBridge:create("var", tostring(Rapid:getData("sourcescene"))))
            itemData:put("sourcesceneslotid", mJavaBridge:create("var", tostring(Rapid:getData('sourcesceneslotid'))))
            itemData:put("modeltype", mJavaBridge:create("var", tostring(Rapid:getData('modeltype'))))
            itemData:put("scene", mJavaBridge:create("var", tostring(Rapid:getData('scene'))))
            itemData:put("card_report_context", mJavaBridge:create("var", Rapid:getData("card_report_context")))
            itemData:put("slotid", mJavaBridge:create("var", Rapid:getData("slotid")))
            -- item param
            itemData:put("order", mJavaBridge:create("var", tostring(itemData:get("order"))))
            itemData:put("videoid", mJavaBridge:create("var", itemData:get("videoid")))
            itemData:put("report_context", mJavaBridge:create("var", itemData:get("report_context")))
            itemData:put("subposition", mJavaBridge:create("var", smallposition))
            itemData:put("hot_url", mJavaBridge:create("var", tostring(itemData:get('hot_url'))))
            itemData:put("timeline_info", mJavaBridge:create("var", tostring(itemData:get('timeline_info'))))
            itemData:put("appid", mJavaBridge:create("var", tostring(itemData:get("appId"))))
            itemData:put("contentid", mJavaBridge:create("var", tostring(itemData:get("contentid"))))
            itemData:put("title", mJavaBridge:create("var", title))
            itemData:put("booking", mJavaBridge:create("var", booking))
            -- color
            itemData:put("normalbgcolor", mJavaBridge:create("var", tostring(Rapid:getData("normalbgcolor"))))
            itemData:put("normaltextcolor", mJavaBridge:create("var", tostring(Rapid:getData("normaltextcolor"))))
            itemData:put("normalstrokecolor", mJavaBridge:create("var", tostring(Rapid:getData("normalstrokecolor"))))
            itemData:put("progresscolor", mJavaBridge:create("var", tostring(Rapid:getData("progresscolor"))))
            itemData:put("installedbgcolor", mJavaBridge:create("var", tostring(Rapid:getData("installedbgcolor"))))
            itemData:put("installedtextcolor", mJavaBridge:create("var", tostring(Rapid:getData("installedtextcolor"))))
            itemData:put("installedstrokecolor", mJavaBridge:create("var", tostring(Rapid:getData("installedstrokecolor"))))
            itemData:put("bookedbgcolor", mJavaBridge:create("var", tostring(Rapid:getData("bookedbgcolor"))))
            itemData:put("bookedtextcolor", mJavaBridge:create("var", tostring(Rapid:getData("bookedtextcolor"))))
            itemData:put("bookedstrokecolor", mJavaBridge:create("var", tostring(Rapid:getData("bookedstrokecolor"))))

            if i == mTotalNum then
                itemData:put("uni_button_title", mJavaBridge:create("var", "更多新游"))
            end

            if i == mCurIndex + 1 then
                itemData:put(SCALE_BIG, mJavaBridge:create("var", "true"))
            else
                itemData:put(SCALE_BIG, mJavaBridge:create("var", "false"))
            end

            mViewDataList[i] = itemData
            mViewNameList[i] = "game_tab_video_timeline_card_item.xml"
        end
    end

    mGiftRecyclerView:clear()
    mGiftRecyclerView:updateData(mViewNameList, mViewDataList)
    initDividerItem()
end

function updateItemData()
    logForDebug(TAG, " updateItemData mLastIndex:" .. tostring(mLastIndex) ..
            "   mCurIndex:" .. tostring(mCurIndex))
    if mLastIndex ~= -1 then
        mGiftRecyclerView:getAdapter():updateItemData(mLastIndex, SCALE_BIG, "false")
    end
    mGiftRecyclerView:getAdapter():updateItemData(mCurIndex, SCALE_BIG, "true")
end

function isLastItemOnClick(dataIndex)
    logForDebug(
            TAG,
            "isLastItemOnClick mTotalNum:" .. tostring(mTotalNum) .. " dataIndex:" .. tostring(dataIndex)
    )
    return tonumber(mTotalNum) == tonumber(dataIndex)
end

--reset其他被点击的icon的显示效果
function resetUnfocusedAllAnimations()
    for i = 0, mTotalNum - 1 do
        if (mLastIndex == i) then
            startItemUnFocusedAnimation(i)
        end
    end
end

function startItemUnFocusedAnimation(index)
    resetUnfocusedImageAnimation(index)
    resetUnfocusedTimelineAnimation(index)
    resetUnfocusedTitleAnimation(index)
    resetUnfocusedButtonAnimation(index)
end

function startItemFocusedAnimation(index)
    startFocusedImageAnimation(index)
    startFocusedTimelineAnimation(index)
    startFocusedTitleAnimation(index)
    startFocusedButtonAnimation(index)
end

CallbackObject = {}
CallbackObject.onRefresh = function(index)
    logForDebug(TAG, "onRefresh")
    resetDefaultScale()
end

CallbackObject.onClickTag = function(index, isSelected)
    logForDebug(TAG, "index==" .. tostring(index) .. " index=" .. tostring(index)
            .. " buttonClicked:" .. tostring(isSelected))

    -- lua 默认从1开始
    local dataIndex = index + 1
    -- 点击focused item

    -- 点击更多
    if isLastItemOnClick(dataIndex) == true then
        local url = mViewDataList[tonumber(mTotalNum)]:get("jump_more_url")
        jumpMorePage(url)
        reportButtonClickToJump(dataIndex)
        resetUnfocusedAllAnimations()
        return
    end

    mLastIndex = mCurIndex
    mCurIndex = index
    saveCurrentItemIndex()

    if mLastIndex == index then
        local url = mViewDataList[tonumber(dataIndex)]:get("video_jump_url")
        local process = tostring(mProcess)
        local vid = tostring(mViewDataList[tonumber(dataIndex)]:get("videoid"))
        local jumpUrl = tostring(url) .. "&extra_video_uri=" .. tostring(vid) .. "&extra_progress=" .. tostring(process)
        logForDebug(TAG, "mCurIndex equals index:" .. tostring(index) .. " url:" .. tostring(jumpUrl))
        jumpMorePage(jumpUrl)
        if isSelected == false then
            reportPureClickToJump(dataIndex)
        end
        return
    end

    reportAppClickAction(dataIndex)

    scrollGalleryTo(index)
    resetUnfocusedAllAnimations()
    startItemFocusedAnimation(index)

    -- 放在下面动画的卡顿会好一些，这个地方后续看能否优化
    if mIsStart == false then
        -- 自然播放完成或者没有在播放的时候，点击的时候需要强制重新播放
        -- 哪怕是用户设置了流量关闭
        startPlay(dataIndex, false, true)
    else
        initVideo(dataIndex, true) -- 未播放完成就点击,等待播放停止以后再进行播放
    end
    mVideoView:getView():hideReplayView()
    mVideoView:getView():dismissRetryView()
    mVideoView:getView():hidePlayButton(true, true)

    updateCardVideoExposure()
    tryShowCloudGame()

    setBgBlur(dataIndex)
end

function isPlayingCompleted()
    return mIsStart == false and mIsCompleted == true
end

function jumpMorePage(url)
    if url == nil then
        return
    end
    local params = {}
    params["tmast"] = tostring(url)
    mRapidView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end

function initGallery()
    local scrollListener = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrolledListener",
            RecyclerScrolledListener
    )
    mGiftRecyclerView:setScrolledListener(scrollListener)

    local scrollStateListener = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrollStateChangedListener",
            RecyclerScrollStateChangedListener
    )
    mGiftRecyclerView:setScrollStateChangedListener(scrollStateListener)

    local actionListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonActionListener", PhotonActionListener)
    Rapid:getChild("id_gift_rv"):getParser():setListener(actionListener)
end

RecyclerScrolledListener = {}
function RecyclerScrolledListener.onScrolled(recyclerView, dx, dy)
    logForDebug(TAG, " onScrolled mLastIndex:" .. tostring(mLastIndex) ..
            "   mCurIndex:" .. tostring(mCurIndex))
    resetFocusItem(recyclerView, dx, dy)
end

function resetFocusItem(recyclerView, dx, dy)
    mTotalOffsetX = mTotalOffsetX + dx
    resetDefaultScale()
end

-- 设计item的并不一致，大小合alpha这里，所以在滑动过程中因为item的复用问题会造成显示不对
-- 所以这里要进行刷新
-- 开发中发现，复用item的visible或者unvisible会导致复用的item显示不出来，平时的recybleview
-- 并不会有这种特殊操作（更多新游item的影响，这里必须进行item复用的刷新操作）
function resetDefaultScale()
    for i = 0, mTotalNum - 1 do
        local targetView = mGiftRecyclerView:getLayoutManager():findViewByPosition(i)
        if targetView ~= nil and mAnimationCount == 0 then
            local containerImageView = getItemImageView(i)
            local containerTimelineView = getItemTimelineView(i)
            local containerTitleView = getItemTitleView(i)
            local containerButtonView = getItemButtonView(i)

            if containerImageView == nil or containerTimelineView == nil or containerTitleView == nil or
                    containerButtonView == nil then
                return
            end

            if i ~= mCurIndex then
                updateFocusItemProperty(containerImageView, 1.0, 1.0, 1)
                updateFocusItemProperty(containerTimelineView, 1.0, 1.0, mAlphaSmall)
                updateFocusItemProperty(containerTitleView, nil, nil, mAlphaSubSmall)
                updateFocusItemProperty(containerButtonView, nil, nil, 1)
            else
                updateFocusItemProperty(containerImageView, mScaleRate, mScaleRate, 1)
                updateFocusItemProperty(containerTimelineView, mTimelineScaleRate, mTimelineScaleRate, mAlphaFocused)
                updateFocusItemProperty(containerTitleView, nil, nil, mAlphaSmall)
                updateFocusItemProperty(containerButtonView, nil, nil, 1)
            end

            initButton(i)
            initTitle(i)

        end
    end
end

-- 滑动的时候动态调整view的属性
-- view: 对应的view
-- scaleX: 对应的scaleX
-- scaleY: 对应的scaleY
-- alpha: 对应的alpha
function updateFocusItemProperty(view, scaleX, scaleY, alpha)
    if view == nil then
        return
    end

    if scaleX ~= nil then
        view:setScaleX(scaleX);
    end

    if scaleY ~= nil then
        view:setScaleY(scaleY);
    end

    if alpha ~= nil then
        view:setAlpha(alpha);
    end
end

-- 初始化预约/下载按钮
function initButton(index, containerButton, bookingButton, downloadButton)
    local dataIndex = index + 1
    local appOnline = tostring(mViewDataList[tonumber(dataIndex)]:get("booking"))
    -- logForDebug(TAG, "initButton:" .. tostring(appOnline) .. " index==" .. tostring(index))

    local containerButton = getContainerButton(index)
    local bookingButton = getBookingButton(index)
    local downloadButton = getDownloadButton(index)

    if bookingButton == nil or bookingButton == nil or containerButton == nil then
        return
    end

    if appOnline == "nil" or appOnline == "" or appOnline == nil then
        containerButton:getParser():update("visibility", "gone")
        bookingButton:getParser():update("visibility", "gone")
        downloadButton:getParser():update("visibility", "gone")
        return
    end

    containerButton:getParser():update("visibility", "visible")
    if appOnline == "true" then
        downloadButton:getParser():update("visibility", "gone")
        bookingButton:getParser():update("visibility", "visible")
        return
    end

    downloadButton:getParser():update("visibility", "visible")
    bookingButton:getParser():update("visibility", "gone")
end

function initTitle(index)
    local dataIndex = index + 1
    local appOnline = tostring(mViewDataList[tonumber(dataIndex)]:get("booking"))
    local showHotUrl = tostring(mViewDataList[tonumber(dataIndex)]:get("hot_url"))

    -- logForDebug(TAG, "initTitle:" .. " index==" .. tostring(index) .. " showHotUrl:" .. tostring(showHotUrl))
    local containerTitle = getContainerTitle(index)
    local title = getTitle(index)
    local hoturl = getHotUrl(index)

    if containerTitle == nil or title == nil or hoturl == nil then
        return
    end

    if appOnline == nil or appOnline == "" then
        containerTitle:getParser():update("visibility", "gone")
        return
    end
    containerTitle:getParser():update("visibility", "visible")

    if showHotUrl == nil or showHotUrl == "" then
        hoturl:getParser():update("visibility", "gone")
    else
        hoturl:getParser():update("visibility", "visible")
    end
    title:getParser():update("visibility", "visible")
end

RecyclerScrollStateChangedListener = {}
function RecyclerScrollStateChangedListener.onScrollStateChanged(recyclerView, state)
    mLeftVisible = recyclerView:getLayoutManager():findFirstVisibleItemPosition()
    mLastVisible = recyclerView:getLayoutManager():findLastVisibleItemPosition()

    if state == 0 then
        --滑动结束
        reportCardSlide()
        updateMoreItem()
        logForDebug(
                TAG,
                "RecyclerScrollStateChangedListener" ..
                        " state:" ..
                        state ..
                        " mCurIndex:" ..
                        mCurIndex ..
                        " , mLeftVisible = " ..
                        tostring(mLeftVisible) .. " , mLastVisible = " .. tostring(mLastVisible)
        )
    end
end

function isVisible(index)
    if index < 0 then
        return false
    end
    if index < mLeftVisible or index > mLastVisible then
        return false
    end
    return true
end

function updateMoreItem()
    mLastMoreItemVisibility = mCurMoreItemVisibility
    mCurMoreItemVisibility = isVisible(mTotalNum - 1)
    if mLastMoreItemVisibility == false and mCurMoreItemVisibility == true then
        logForDebug(TAG, "invisible --> visible")
        reportButtonExposure()
    end
end

PhotonActionListener = {}
function PhotonActionListener.notify(key, value)
    logForDebug(TAG, "PhotonActionListener")
end

--强制滑动,使pos这个item居中的位置
function scrollGalleryTo(pos)
    logForDebug(TAG_ICON, "scrollGalleryTo pos:" .. pos .. " mCurIndex:" .. mCurIndex)
    if pos == nil then
        pos = mCurIndex
    end
    if mGiftRecyclerView == nil then
        return
    end

    local baseOffset = (mGiftRecyclerView:getWidth() - mItemWidth) / 2
    local targetView = mGiftRecyclerView:getLayoutManager():findViewByPosition(pos)
    logForDebug(
            TAG,
            "scrollGalleryTo getScreenWidth:" .. mRapidView:getParser():getScreenWidth() .. " mItemWidth:" .. mItemWidth
    )

    -- targetView:getLeft()这里获取的是相对于recleview开始的距离，可能是因为getLayoutManager的关系，是在recycleview内部的
    if targetView ~= nil then
        mGiftRecyclerView:smoothScrollBy(targetView:getLeft() - baseOffset, 0)
        return
    end

    -- 默认情况回到第一个item
    if pos == 0 then
        logForDebug(TAG, "scrollGalleryTo first item:" .. mTotalOffsetX)
        mGiftRecyclerView:smoothScrollBy(-mTotalOffsetX, 0)
    end
end

function isNewLaunched()
    return mLastIndex == -1
end

function startUnfocusedCommonAnimation(index, curAlpha, scaleListener, view, xParam, yParam, alphaParam, pivotY, duration)
    if view == nil or scaleListener == nil then
        return
    end

    if mLastVisible == -1 then
        mLeftVisible = mGiftRecyclerView:getLayoutManager():findFirstVisibleItemPosition()
        mLastVisible = mGiftRecyclerView:getLayoutManager():findLastVisibleItemPosition()
    end


    -- index 看不见，解决点击第一个，再点击倒数第二个item因为item复用最后一个item会变小的问题
    -- 这种情况需要单独再处理下，只能在下次显示滑动该item的时候变小，部分场景会看到变小的效果
    if index < mLeftVisible or index > mLastVisible then
        if mLastIndex < mLeftVisible or mLastIndex > mLastVisible then
            view:setAlpha(curAlpha)
            logForDebug(
                    TAG,
                    "resetUnfocusedImageAnimation force setIndex alpha index=" ..
                            index .. " mLastIndex:" .. mLastIndex .. " "
            )
            return
        end
    end

    if xParam ~= nil and yParam ~= nil then
        startCommonAnimation(index, scaleListener, view, xParam, yParam, alphaParam, pivotY, duration)
    else
        startCommonAlphaAnimation(index, scaleListener, view, alphaParam, duration)
    end
end

function startCommonAlphaAnimation(index, scaleListener, view, alphaParam, duration)
    if view == nil or scaleListener == nil then
        return
    end

    local objectAnimator = luajava.bindClass("android.animation.ObjectAnimator")
    local listener = luajava.createProxy("android.animation.Animator$AnimatorListener", scaleListener)
    local containerAnimSet = luajava.newInstance("android.animation.AnimatorSet")

    view:clearAnimation()
    local alphaAnim = objectAnimator:ofFloat(view, "alpha", alphaParam)

    local objParams = {}
    objParams[1] = alphaAnim
    containerAnimSet:setDuration(duration)
    containerAnimSet:playTogether(objParams)
    containerAnimSet:addListener(listener)
    containerAnimSet:start()
end

function startCommonAnimation(index, scaleListener, view, xParam, yParam, alphaParam, pivotY, duration)
    if view == nil or scaleListener == nil then
        return
    end

    local objectAnimator = luajava.bindClass("android.animation.ObjectAnimator")
    local listener = luajava.createProxy("android.animation.Animator$AnimatorListener", scaleListener)
    local containerAnimSet = luajava.newInstance("android.animation.AnimatorSet")

    view:clearAnimation()
    if pivotY ~= nil then
        view:setPivotY(pivotY)
    end

    local objScaleXAnim = objectAnimator:ofFloat(view, "scaleX", xParam)
    local objScaleYAnim = objectAnimator:ofFloat(view, "scaleY", yParam)
    local alphaAnim = objectAnimator:ofFloat(view, "alpha", alphaParam)

    local objParams = {}
    objParams[1] = objScaleXAnim
    objParams[2] = objScaleYAnim
    objParams[3] = alphaAnim
    containerAnimSet:setDuration(duration)
    containerAnimSet:playTogether(objParams)
    containerAnimSet:addListener(listener)
    containerAnimSet:start()
end

function createScaleAnimParam(start, after)
    local params = { start, after }
    return params
end

function createScaleAnimParamEnd(after)
    local params = {}
    params[1] = after
    return params
end

function createParam(start, after)
    local params = {}
    params[1] = start
    params[2] = after
    return params
end

function resetUnfocusedImageAnimation(index)
    if mLastImageContainer == nil then
        logForDebug(TAG, "failed resetUnfocusedImageAnimation index=" .. index)
        initItemContainers(index) -- 刚启动初始化的时候可能获取不到正确的值，这里再重新尝试获取container
        if mLastImageContainer == nil then
            return
        end
    end

    local containerView = mLastImageContainer -- mLastImageContainer可能会被修改，这里动画前先缓存到别的地方
    local param = prepareScaleSmallParam(containerView, mScaleRate)
    local alpha = prepareAlphaParam(containerView, 1)

    startUnfocusedCommonAnimation(
            index,
            mAlphaSmall,
            mImageScaleSmallListener,
            containerView,
            param,
            param,
            alpha,
            nil,
            mAnimationDuration
    )
end

-- 开始放大动画
function startFocusedImageAnimation(index)
    mLastImageContainer = getItemImageView(index)
    if mLastImageContainer == nil then
        return
    end

    local containerView = mLastImageContainer
    local param = prepareScaleBigParam(containerView, 1, mScaleRate)
    local alpha = prepareAlphaParam(containerView, 1)

    startCommonAnimation(index, mImageScaleSmallListener, containerView, param, param, alpha, nil, mAnimationDuration)
end

function resetUnfocusedTimelineAnimation(index)
    logForDebug(
            TAG,
            "resetUnfocusedTimelineAnimation index=" ..
                    index .. " mLeftVisible:" .. mLeftVisible .. " mLastVisible:" .. mLastVisible
    )

    if mLastTimelineContainer == nil then
        logForDebug(TAG, "failed resetUnfocusedTimelineAnimation index=" .. index)
        return
    end

    local containerView = mLastTimelineContainer
    local param = prepareScaleSmallParam(containerView, mTimelineScaleRate)
    local alpha = prepareAlphaParam(containerView, mAlphaSmall)
    local pivotY = mLastTimelineContainer:getHeight()

    startUnfocusedCommonAnimation(
            index,
            mAlphaSmall,
            mTimelineScaleSmallListener,
            containerView,
            param,
            param,
            alpha,
            pivotY,
            mAnimationDuration
    )
end

function startFocusedTimelineAnimation(index)
    -- -- 开始放大动画
    logForDebug(TAG, "startFocusedTimelineAnimation index=" .. index)
    mLastTimelineContainer = getItemTimelineView(index)
    if mLastTimelineContainer == nil then
        logForDebug(TAG, "failed startFocusedTimelineAnimation index=" .. index)
        return
    end

    local containerView = mLastTimelineContainer
    local param = prepareScaleBigParam(mLastTimelineContainer, 1, mTimelineScaleRate)
    local alpha = prepareAlphaParam(containerView, mAlphaFocused)
    local pivotY = containerView:getHeight()

    startCommonAnimation(
            index,
            mTimelineScaleBigListener,
            containerView,
            param,
            param,
            alpha,
            pivotY,
            mAnimationDuration
    )
end

function resetUnfocusedTitleAnimation(index)
    if mLastTitleContainer == nil then
        logForDebug(TAG, "failed resetUnfocusedTitleAnimation index=" .. index)
        return
    end

    local containerView = mLastTitleContainer
    local alpha = prepareAlphaParam(containerView, mAlphaSubSmall)

    startCommonAlphaAnimation(index, mTitleAlphaSmallListener, containerView, alpha, mAnimationDuration)
end

function startFocusedTitleAnimation(index)
    -- -- 开始放大动画
    mLastTitleContainer = getItemTitleView(index)
    if mLastTitleContainer == nil then
        return
    end

    local containerView = mLastTitleContainer
    local alpha = prepareAlphaParam(containerView, mAlphaSmall)

    startCommonAlphaAnimation(index, mTitleAlphaBigListener, containerView, alpha, mAnimationDuration)
end

function resetUnfocusedButtonAnimation(index)
    if mLastButtonContainer == nil then
        logForDebug(TAG, "failed resetUnfocusedButtonAnimation index=" .. index)
        return
    end

    local containerView = mLastButtonContainer
    local alpha = prepareAlphaParam(containerView, 1)

    startCommonAlphaAnimation(index, mButtonAnimSmallListener, containerView, alpha, mAnimationDuration)
end

function startFocusedButtonAnimation(index)
    -- -- 开始放大动画
    mLastButtonContainer = getItemButtonView(index)
    if mLastButtonContainer == nil then
        logForDebug(TAG, "failed startFocusedButtonAnimation index=" .. index)
        return
    end

    local containerView = mLastButtonContainer
    local alpha = prepareAlphaParam(containerView, 1)

    startCommonAlphaAnimation(index, mButtonAnimBigListener, containerView, alpha, mAnimationDuration)
end

-- param
-- after : alpha最后的值
function prepareAlphaParam(view, after)
    if view == nil then
        return
    end
    local start = view:getAlpha()
    view:clearAnimation()
    local param = createParam(start, after)
    return param
end

-- param
-- view: 动画view
-- max : 动画放大最大值
function prepareScaleSmallParam(view, max)
    if view == nil then
        return
    end
    view:clearAnimation()
    local scaleX = view:getScaleX()
    local rate = math.min(scaleX, max)
    logForDebug(TAG, "un Focused scaleX:" .. tostring(scaleX) .. " rate:" .. tostring(rate))
    local param = createScaleAnimParamEnd(1) -- 用这种方式可以规避lua framework的问题
    return param
end

-- param
-- view: 动画view
-- min : 动画放大最小值
-- max : 动画放大最大值
function prepareScaleBigParam(view, min, max)
    if view == nil then
        return
    end
    view:clearAnimation()
    local scaleX = view:getScaleX()
    local rate = math.max(scaleX, min)
    local param = createScaleAnimParam(rate, max)
    logForDebug(TAG, "Focused scaleX:" .. tostring(scaleX) .. " rate:" .. tostring(rate))
    return param
end

function getItemChildView(index, name)
    local child = getItemChild(index, name)
    if child == nil then
        return
    end

    return child:getView()
end

function getItemChild(index, name)
    if name == nil then
        return nil
    end

    local itemView = mGiftRecyclerView:getLayoutManager():findViewByPosition(index)
    if itemView == nil then
        return nil
    end

    local viewParser = itemView:getTag():getParser()
    local childView = viewParser:getChildView(name)

    if childView == nil then
        return nil
    end

    return childView
end

------------------------------------------------------------------
--- 动画监听相关
LayoutScaleAnimationListener = {}
function LayoutScaleAnimationListener.onAnimationStart(animator)
end
function LayoutScaleAnimationListener.onAnimationEnd(animator)
    logForDebug(TAG, "startFocusedImageAnimation end")
end

function LayoutScaleAnimationListener.onAnimationCancel(animator)
end

function LayoutScaleAnimationListener.onAnimationRepeat(animator)
end

-- 监听动画结束，目的在于recycleview item复用的原因，会去更新item的scaleX, scaleY
-- alpha等，如果在上一次动画还没有结束就去更新，会导致明显的动画缺陷，动画闪动
-- 由于会有item放大的效果，所有动画完成以后"必须"把item的属性进行更新

-- 注意：有一种特殊情况需要注意，就是因为item的复用问题，如果对隐藏的item进行缩放，
-- 可能会因为复用导致正在显示的item的属性跟着变化，主要是对scale放大影响
-- 所以对这种情况，需要再滑动到下次再显示的时候再进行处理，部分场景可能会看到缩小的效果
-- 但是也没有更好的办法
function checkAndHandleAnimationStop()
    if mAnimationCount == 0 then
        resetDefaultScale()
        updateItemData()
    end
end

function AnimCountAdd()
    mAnimationCount = mAnimationCount + 1
    checkAndHandleAnimationStop()
end

function AnimCountDec()
    mAnimationCount = mAnimationCount - 1
    checkAndHandleAnimationStop()
end

mImageScaleBigListener = {}
function mImageScaleBigListener.onAnimationStart(animator)
    logForDebug(TAG, " mImageScaleBigListener onAnimationStart ")
    AnimCountAdd()
end

function mImageScaleBigListener.onAnimationEnd(animator)
    logForDebug(TAG, " mImageScaleBigListener onAnimationEnd ")
    AnimCountDec()
end

mImageScaleSmallListener = {}
function mImageScaleSmallListener.onAnimationStart(animator)
    logForDebug(TAG, " mImageScaleSmallListener onAnimationStart ")
    AnimCountAdd()
end

function mImageScaleSmallListener.onAnimationEnd(animator)
    logForDebug(TAG, " mImageScaleSmallListener onAnimationEnd ")
    AnimCountDec()
end

mTimelineScaleBigListener = {}
function mTimelineScaleBigListener.onAnimationStart(animator)
    logForDebug(TAG, " mTimelineScaleBigListener onAnimationStart ")
    AnimCountAdd()
end

function mTimelineScaleBigListener.onAnimationEnd(animator)
    logForDebug(TAG, " mTimelineScaleBigListener onAnimationEnd ")
    AnimCountDec()
end

mTimelineScaleSmallListener = {}
function mTimelineScaleSmallListener.onAnimationStart(animator)
    logForDebug(TAG, " mTimelineScaleSmallListener onAnimationStart ")
    AnimCountAdd()
end

function mTimelineScaleSmallListener.onAnimationEnd(animator)
    logForDebug(TAG, " mTimelineScaleSmallListener onAnimationEnd ")
    AnimCountDec()
end

-- listener监听
mTitleAlphaBigListener = {}
function mTitleAlphaBigListener.onAnimationStart(animator)
    logForDebug(TAG, " mTitleAlphaBigListener onAnimationStart ")
    AnimCountAdd()
end

function mTitleAlphaBigListener.onAnimationEnd(animator)
    logForDebug(TAG, " mTitleAlphaBigListener onAnimationEnd ")
    AnimCountDec()
end

mTitleAlphaSmallListener = {}
function mTitleAlphaSmallListener.onAnimationStart(animator)
    logForDebug(TAG, " mTitleAlphaSmallListener onAnimationStart ")
    AnimCountAdd()
end

function mTitleAlphaSmallListener.onAnimationEnd(animator)
    logForDebug(TAG, " mTitleAlphaSmallListener onAnimationEnd ")
    AnimCountDec()
end

mButtonAnimBigListener = {}
function mButtonAnimBigListener.onAnimationStart(animator)
    logForDebug(TAG, " mButtonAnimBigListener onAnimationStart ")
    AnimCountAdd()
end

function mButtonAnimBigListener.onAnimationEnd(animator)
    logForDebug(TAG, " mButtonAnimBigListener onAnimationEnd ")
    AnimCountDec()
end

mButtonAnimSmallListener = {}
function mButtonAnimSmallListener.onAnimationStart(animator)
    logForDebug(TAG, " mButtonAnimSmallListener onAnimationStart ")
    AnimCountAdd()
end

function mButtonAnimSmallListener.onAnimationEnd(animator)
    logForDebug(TAG, " mButtonAnimSmallListener onAnimationEnd ")
    AnimCountDec()
end
--- 动画监听相关结束
------------------------------------------------------------------

function initDividerItem()
    mDivider = luajava.newInstance("android.graphics.drawable.GradientDrawable")
    mDivider:setColor(0xffebebeb)
    mDivider:setSize(-1, mJavaBridge:dip2px(1))
    local itemDecoration = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.IItemDecorationListener",
            IItemDecorationListener
    )
    mGiftRecyclerView:addItemDecoration(itemDecoration)
end

IItemDecorationListener = {}
function IItemDecorationListener.onDraw(c, parent, state)
    local childCount = parent:getChildCount()
    for i = 0, childCount - 2 do
        local child = parent:getChildAt(i)
        local params = child:getLayoutParams()
        -- getLeft是item的最左边
        local left = child:getLeft() + mItemRealWidth + mDividerMargin + mItemMarginLeft + mItemOffset

        -- left + 2 * mItemMarginLeft已经到下一个item里面，偏移是mDividerMargin,所以需要-2 * mDividerMargin才能确保分割线居中
        local right = left + 2 * mItemMarginLeft - 2 * mDividerMargin
        local top = child:getTop() + (child:getHeight() - mDivider:getIntrinsicHeight()) / 2 + mDividerOffset -- 没有居中
        local bottom = top + mDivider:getIntrinsicHeight()

        mDivider:setBounds(left, top, right, bottom)
        mDivider:draw(c)
    end
end

function IItemDecorationListener.onDrawOver(c, parent, state)
end

function IItemDecorationListener.getItemOffsets(outRect, view, parent, state)
    --outRect.top = mDivider:getIntrinsicHeight()
end

-----------------------------------------------------------
--debug的时候打印日志的方法
function logForDebug(logTag, logMsg)
    if not DEBUG then
        return
    end
    mJavaBridge:Log(TAG .. "::" .. logTag, logMsg)
end

function anchorFirstItem()
    mCurIndex = 0
    anchorCurrentItem()
end

function anchorCurrentItem()
    logForDebug(TAG_ICON, " anchor CurrentItem mCurIndex:" .. tostring(mCurIndex))
    saveCurrentItemIndex()
    scrollGalleryTo(mCurIndex)
    local dataIndex = mCurIndex + 1
    setBgBlur(dataIndex)
    initVideo(dataIndex, false)
    startPlay(dataIndex, true, false)
    initItemContainers(mCurIndex)
    tryShowCloudGame()
end

-----------------------------------------------------------
-- 以下是动画view相关
function getItemImageView(index)
    return getItemChildView(index, "adapter_container")
end

function getItemTimelineView(index)
    return getItemChildView(index, "id_timeline_desc")
end

function getItemTitleView(index)
    return getItemChildView(index, "id_title_container")
end

function getItemButtonView(index)
    return getItemChildView(index, "id_button")
end

-----------------------------------------------------------
-- 处理title复用问题
function getContainerTitle(index)
    return getItemChild(index, "id_title_container")
end

function getTitle(index)
    return getItemChild(index, "id_title")
end

function getHotUrl(index)
    return getItemChild(index, "icon_image")
end

-----------------------------------------------------------
-- 处理预约和下载组件复用问题
function getContainerButton(index)
    return getItemChild(index, "id_button")
end

function getBookingButton(index)
    return getItemChild(index, "booking_button")
end

function getDownloadButton(index)
    return getItemChild(index, "download_button")
end

function initItemContainers(index)
    mLastImageContainer = getItemImageView(index)
    mLastTimelineContainer = getItemTimelineView(index)
    mLastTitleContainer = getItemTitleView(index)
    mLastButtonContainer = getItemButtonView(index)
end

function onResume()
    logForDebug(TAG_CLOUD_FLAG, " onResume ==> mCurIndex:" .. mCurIndex)
end

function onPause()
    logForDebug(TAG, " onPause ==> mCurIndex:" .. mCurIndex)
end

--------------------以下是和埋点相关----------------------------------
local ACTIONID_TEMPLATE = "actionid:%s"
local SUB_POSITION = "subposition:%s"
local REPORT_ELEMENT = "report_element:%s"
local CONTEXT_FORMAT = "report_context:data@report_context_%s"
function reportItemCommon(cmd, element, context, index, extraStr)
    local actionStr = string.format(ACTIONID_TEMPLATE, cmd)
    local subPosStr = string.format(SUB_POSITION, index)
    local element = string.format(REPORT_ELEMENT, element)

    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid," .. subPosStr .. "," .. actionStr ..
            ",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid"
    reportParams["recommendid"] = "data@card_recommendid"
    reportParams["extendparam"] = element .. ",sourcereportcontext:data@source_report_context," .. context .. "," .. extraStr

    mRapidView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

-- CardSlide
function reportCardSlide()
    local cmd = CMD_CARD_SLIDE
    local context = "report_context:data@card_report_context"
    local element = "card"
    local index = -1
    local extraStr = ""
    reportItemCommon(cmd, element, context, index, extraStr)
end

function reportButtonExposure()
    local cmd = CMD_EXPOSURE
    local element = "button"
    local context = "report_context:data@card_report_context"
    local index = mTotalNum
    local extraStr = "uni_button_title:更多新游"
    reportItemCommon(cmd, element, context, index, extraStr)
end

function reportButtonClickToJump(dataIndex)
    local cmd = CMD_CLICK_JUMP
    local element = "button"
    local context = string.format(CONTEXT_FORMAT, dataIndex)
    local index = mTotalNum
    local extraStr = "uni_button_title:更多新游"
    reportItemCommon(cmd, element, context, index, extraStr)
end

function reportPureClickToJump(dataIndex)
    logForDebug(TAG, "reportPureClickToJump")
    local cmd = CMD_CLICK_JUMP
    local element = "app"
    local context = string.format(CONTEXT_FORMAT, dataIndex)
    local vid = tostring(mViewDataList[tonumber(dataIndex)]:get("videoid"))
    local extraStr = "videoid:" .. vid
    reportItemCommon(cmd, element, context, dataIndex, extraStr)
end

function reportAppClickAction(dataIndex)
    logForDebug(TAG, "reportAppClickAction")
    local cmd = CMD_BUTTON_UNFOCUS_SELECTED
    local element = "app"
    local context = string.format(CONTEXT_FORMAT, dataIndex)
    local vid = tostring(mViewDataList[tonumber(dataIndex)]:get("videoid"))
    local extraStr = "videoid:" .. vid
    reportItemCommon(cmd, element, context, dataIndex, extraStr)
end

function reportGameDemoExposure()
    local dataIndex = mCurIndex + 1
    local highLight = getCurHighLightFlag()
    logForDebug(TAG_CLOUD, "reportGameDemoExposure, dataIndex:" .. dataIndex .. " highLight:" .. tostring(highLight))
    
    local cmd = CMD_EXPOSURE
    local element = "button"
    local context = string.format(CONTEXT_FORMAT, dataIndex)
    local index = -1
    local extraStr = "uni_is_highlighted:" .. tostring(highLight) .. ",uni_button_title:game_demo"
    reportItemCommon(cmd, element, context, index, extraStr)
end

function reportGameDemoOnClick()
    local dataIndex = mCurIndex + 1
    local highLight = getCurHighLightFlag()
    logForDebug(TAG_CLOUD, "reportGameDemoOnClick, dataIndex:" .. dataIndex .. " highLight:" .. tostring(highLight))
    
    local cmd = CMD_CLICK_JUMP
    local element = "button"
    local context = string.format(CONTEXT_FORMAT, dataIndex)
    local index = -1
    local extraStr = "uni_is_highlighted:" .. tostring(highLight) .. ",uni_button_title:game_demo"
    reportItemCommon(cmd, element, context, index, extraStr)
end

function getCurHighLightFlag()
    local dataIndex = mCurIndex + 1
    return 0        -- 显示透明条
end

function updateCardVideoExposure()
    local dataIndex = mCurIndex + 1
    reportVideoExposure()
    reportVideoExposureV2()
end

function reportVideoExposure()
    local command = tostring(CMD_EXPOSURE)
    reportVideoExposureCommon(command)
end

function reportVideoExposureV2()
    local command = tostring(CMD_EXPOSUREV2)
    reportVideoExposureCommon(command)
end

function reportVideoExposureCommon(command)
    local dataIndex = mCurIndex + 1
    local cmd = command
    local element = "video"
    local context = string.format(CONTEXT_FORMAT, dataIndex)
    local index = -1
    local extraStr = "videoid:" .. tostring(mViewDataList[dataIndex]:get("videoid"))
    reportItemCommon(cmd, element, context, index, extraStr)
    logForDebug(TAG_APP_EXPOSURE, "reportVideoExposure:  dataIndex=" .. tostring(dataIndex))
end
---------------------------------------------以下和视频相关-------------------------------------
function addVideoListener()
    mVideoView = mRapidView:getParser():getChildView("video_view")
    mStateChangeListener = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener",
            IPlayerStateChangeListener
    )

    if (mVideoView ~= nil and mStateChangeListener ~= nil) then
        mVideoView:getView():registerIPlayerStateChangeListener(mStateChangeListener)
    end
end

function unRegistVideoListener()
    if (mVideoView ~= nil and mStateChangeListener ~= nil) then
        mVideoView:unregisterIPlayerStateChangeListener(mStateChangeListener)
    end
end

-- isNextPlay：是否需要播放下一个视频
function initVideo(index, isNextPlay)
    logForDebug(
            TAG,
            "  initVideo:" ..
                    index ..
                    " isPlaying:" ..
                    tostring(mVideoView:getView():isPlaying()) ..
                    " isPaused:" .. tostring(mVideoView:getView():isPaused())
    )
    if mVideoView:getView():isPlaying() == true or mVideoView:getView():isPaused() == true then
        mVideoView:getView():stop(false)
    end
    mIsNeedPlayNext = isNextPlay
    logForDebug(TAG, "  initVideo:" .. index)
end

-- index: play视频的item index
-- force: 是否检查播放
-- 不检查播放场景：
-- 1) 重新播放，切换时，不然会切换不成功
-- 2) 用户手动切换
-- 检查播放场景
-- 1) 设置了视频的wifi播放、关闭等场景

function startPlay(index, force, hidePlay)
    local video_vid = tostring(mViewDataList[index]:get("videoid"))
    local video_jump_url = tostring(mViewDataList[index]:get("video_jump_url"))
    local cover_image_url = tostring(mViewDataList[index]:get("cover_image_url"))
    local video_recommendid = tostring(mViewDataList[index]:get("video_recommendid"))
    local video_report_context = tostring(mViewDataList[index]:get("video_report_context"))
    local left_time = tostring(mViewDataList[index]:get("left_time"))
    logForDebug(TAG, "start play index:" .. index .. " left_time:" .. left_time .. " force:" .. tostring(force))

    local isLandscape = tostring(mRapidView:getParser():getBinder():get("is_landscape")) == "0"
    local layoutParams = mVideoView:getView():getLayoutParams()
    local screenWidth = mJavaBridge:getScreenWidth()
    local height
    local scaleType
    if isLandscape then
        height = screenWidth * 202 / 360
        scaleType = 2
    else
        height = screenWidth
        scaleType = 0
    end
    layoutParams.height = height
    mVideoView:getView():setLayoutParams(layoutParams)
    mVideoView:getView():setScaleType(scaleType)

    mVideoView:getView():setVid(video_vid)
    mVideoView:getView():setCoverImageUrl(cover_image_url)
    mVideoView:getView():setGaussBlurUrl(cover_image_url)
    mVideoView:getView():setJumpUrl(video_jump_url)
    mVideoView:getView():hidePlayButton(hidePlay, true)

    mVideoView:getView():tryContinueOrRestartPlay(false, force)
end

function IPlayerStateChangeListener.onPlayStart()
    logForDebug(TAG, "onPlayStart")
    mIsStart = true
    mIsCompleted = false
    local system = luajava.bindClass("java.lang.System")
    mStartTimeMs = system:currentTimeMillis()

    setMuteVisible()
    initMute()
end

-- 视频进度改变，显示的内容变化
function IPlayerStateChangeListener.onProgressUpdate(mVideoView, progress)
    if (mVideoView == nil) then
        return
    end

    -- logForDebug(TAG, "progress:" .. tostring(progress) .. " mIsStart:" .. tostring(mIsStart))
    mProcess = progress;
end

function saveCurrentItemIndex() 
    local index = Rapid:getData("index", "-1")
    RapidList:updateItemData(index, CURRENT_ITEM_INDEX, tonumber(mCurIndex))
    logForDebug(TAG_ICON, "11111 save item index:" .. tostring(index) .. " mCurIndex:" .. tostring(mCurIndex))
end

function IPlayerStateChangeListener.onPlayContinue()
    logForDebug(TAG, "onPlayContinue")
    setMuteVisible()
    initMute()
end

function IPlayerStateChangeListener.onPlayStop()
    logForDebug(TAG, "stopped play index:" .. tostring(mLastIndex + 1))
    setMuteInvisible()

    mIsStart = false

    -- 如果是用户主动点击
    if mIsNeedPlayNext == true then
        startPlay(mCurIndex + 1, false, true)
        mIsNeedPlayNext = false
        return
    end
    mVideoView:getView():hidePlayButton(false, true)
end

function IPlayerStateChangeListener.onPlayPause()
    logForDebug(TAG, "onPlayPause")
    setMuteInvisible()
end

function IPlayerStateChangeListener.onPlayComplete(videoView)
    logForDebug(TAG, "onPlayComplete")
    setMuteInvisible()
    mIsStart = false
    mIsCompleted = true

end

function IPlayerStateChangeListener.onMute(videoview, mute)
    updateMuteImage(mute)
end

function dismissCloudGame()
    logForDebug(TAG_CLOUD, "dismissCloudGame ")
    Rapid:getChild("layout_cloud_game"):setAttr("visibility", "gone")
    Rapid:getChild("cloud_game_black"):setAttr("visibility", "gone")
    Rapid:getChild("cloud_game_yellow"):setAttr("visibility", "gone")
end

function showTranCloudGame() 
    logForDebug(TAG_CLOUD, "showTranCloudGame ")

    Rapid:getChild("layout_cloud_game"):setAttr("visibility", "visible")
    Rapid:getChild("cloud_game_yellow"):setAttr("visibility", "gone")
    local shown = tonumber(Rapid:getChild("cloud_game_black"):getView():getVisibility())
    if shown ~= VISIBLE then    
        reportGameDemoExposure()
    end
    Rapid:getChild("cloud_game_black"):setAttr("visibility", "visible")
end

function tryShowCloudGame()
    -- 没有云玩
    if isCloudGameOnline() == false then
        dismissCloudGame()
        return
    end

    -- 显示透明条
    showTranCloudGame()
end

function getCurCloudUrl()
    local dataIndex = mCurIndex + 1
    local url = mViewDataList[tonumber(dataIndex)]:get("cloud_game_jump_url")
    return url
end

function isCloudGameOnline()
    local url = getCurCloudUrl()
    return url ~= nil
end

function jumpCloudGame()
    local dataIndex = mCurIndex + 1
    local url = tostring(mViewDataList[tonumber(dataIndex)]:get("cloud_game_jump_url"))
    if url == nil then
        logForDebug(TAG, "error jumpCloudGame url:" .. url)
        return
    end

    reportGameDemoOnClick()
    jumpMorePage(url)
end
-----------------------------------------------------
--- mute相关的功能
-- 初始化静音按钮
function initMute()
    if mVideoView == nil then
        return
    end

    local isMute = mVideoView:getView():isMute()
    updateMuteImage(isMute)
end

-- 设置静音
function setMute()
    if mVideoView == nil then
        return
    end

    local isMute = mVideoView:getView():isMute()
    if isMute then
        mVideoView:getView():setMuteToGlobal(false, true, true)
    else
        mVideoView:getView():setMuteToGlobal(true, true, true)
    end
    updateMuteImage(not isMute)
end

function updateMuteImage(mute)
    if mute then
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("mute_image", "https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end

function setMuteVisible()
    Rapid:getChild("mute_img"):setAttr("visibility", "visible")
end

function setMuteInvisible()
    Rapid:getChild("mute_img"):setAttr("visibility", "gone")
end
-----------------------------------------------------
--- 设置高斯模糊图片
function setBgBlur(dataIndex)
    local url = tostring(mViewDataList[dataIndex]:get("rv_bg_image"))
    if url == nil then
        return
    end
    logForDebug(TAG, "setBgBlur rv_bg_image:" .. url)
    Rapid:setData("rv_bg_image", url)
end