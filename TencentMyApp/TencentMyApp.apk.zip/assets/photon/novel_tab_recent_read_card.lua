local mPhotonView,mJavaBridge = ...


function main()
    local strokeWidth = mJavaBridge:dip2px(1)
    Rapid:getChild('tv_read'):setAttr('gradientdrawable', 'cornerradius:16,color:00ffffff,strokewidth:'.. strokeWidth ..',strokecolor:330080ff')
end