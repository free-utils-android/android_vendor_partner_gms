local mPhotonView,mJavaBridge = ...

function goDeeplink(deeplink)
    if (deeplink == nil or deeplink == "") then
        deeplink = mPhotonView:getParser():getBinder():get("app_url");
    end
    
    local intent                        = luajava.newInstance('android.content.Intent','android.intent.action.VIEW')
    local uri                           = luajava.bindClass('android.net.Uri')
    uri = uri:parse(deeplink)
    
    if(uri:getScheme() == "tmast") then
        local data ={}
        data["tmast"] = uri:toString()
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction",data,data)
    else
        intent:setData(uri)
        local card = mPhotonView:getParser():getChildView("card")
        local context = card:getView():getContext()
        context:startActivity(intent)
    end
end

function setDetailUrl(i)
    local videoView                     = mPhotonView:getParser():getChildView("video_"..i)
    local blankView                     = videoView:getView():getBlankView()
    local blankViewOnClickListener      = luajava.createProxy('android.view.View$OnClickListener',OnClickListener)
    blankView:setTag(i)
    blankView:setOnClickListener(blankViewOnClickListener)
end


OnClickListener = {}

function OnClickListener.onClick(view)
    local i = view:getTag()
    local position = mPhotonView:getParser():getBinder():get("position") + 1;
    local positionString = string.format( "%03d", position)
    local subposition = "40"..i
    subposition = getSubposition(subposition)

    local url = mPhotonView:getParser():getBinder():get("video_detail_url_"..i)
    url = url.."&preActivitySlotTagName=124_"..positionString.."_-1_"..subposition
    if (url ~= nil) then
        local param = {}
        param["key"] = "SaveCardInfo"
        param["value"] = mPhotonView:getParser():getBinder():get("position")
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("outeraction", param, param)

        local data ={}
        data["tmast"]=url
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction",data,data)

        itemClick(subposition)

    end
    
end

--曝光的上报
function itemShow(item)
    local position = mPhotonView:getParser():getBinder():get("position") + 1;
    local positionString = string.format( "%03d", position)
    local subposition = getSubposition(item)
    local data ={}
    data["param"] = "scene:data@scene,sourcescene:data@sourceScene,actionid:100,slotid:124_"..positionString..",subposition:"..subposition..",extradata:data@queryWord,appid:data@app_id,recommendid:data@recommendid,searchid:data@searchId,packagename:data@packageName"

    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
end

--点击的上报
function itemClick(item)
    local position = mPhotonView:getParser():getBinder():get("position") + 1;
    local positionString = string.format( "%03d", position)   
    local subposition = getSubposition(item)
    local data ={}
    data["param"] = "scene:data@scene,sourcescene:data@sourceScene,actionid:200,slotid:124_"..positionString..",subposition:"..subposition..",extradata:data@queryWord,appid:data@app_id,recommendid:data@recommendid,searchid:data@searchId,packagename:data@packageName"

    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
end

function getSubposition(item) 
    local vid = mPhotonView:getParser():getBinder():get("vid_0")
    if(item == "single" or item == "400") then
        if(vid ~= nil) then
            -- 单视频
            return "301"
        else 
            -- 单图
            return "201"
        end
    end

    -- 三视频或图片
    return item
end