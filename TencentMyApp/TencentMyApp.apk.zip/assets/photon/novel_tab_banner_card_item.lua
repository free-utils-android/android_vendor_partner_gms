local mPhotonView, mJavaBridge = ...

local mBgSwitcher
local mSwitchImageFirstRunnable

local mFadeInAnim
local mFadeOutAnim

local ViewUtils

function init()
    mBgSwitcher = Rapid:getChild("bg_switcher")
    local imageSwitcher = mBgSwitcher:getView()
    mFadeInAnim = luajava.newInstance("android.view.animation.AlphaAnimation", 1, 1)
    mFadeInAnim:setDuration(1000)
    imageSwitcher:setInAnimation(mFadeInAnim)

    mFadeOutAnim = luajava.newInstance("android.view.animation.AlphaAnimation", 1, 0)
    mFadeOutAnim:setDuration(1000)
    imageSwitcher:setOutAnimation(mFadeOutAnim)

    mSwitchImageFirstRunnable = luajava.createProxy("java.lang.Runnable", Runnable)

    ViewUtils = luajava.bindClass("com.tencent.assistant.utils.ViewUtils")
end

Runnable = {}
function Runnable.run(...)
    local isFirstVisible = Rapid:getData("is_first_visible", "false")
    if isFirstVisible ~= "true" then
        return
    end
    switchBgImage()
end

function fillValue()
    setImage()
    onFirstVisibleChange()

    local width = ViewUtils:dip2px(1.5)
end

function setImage()
    local mBgImageUrl = mPhotonView:getParser():getBinder():get("icon_url")
    Rapid:setData("bg_image_url_1", tostring(mBgImageUrl))
    Rapid:setData("bg_image_num", "1")
end

function loadDefauleBgImage()
    local bgImageNum = tonumber(Rapid:getData("bg_image_num", "0"))
    if bgImageNum <= 0 then
        mBgSwitcher:setAttr("visibility", "gone")
        return
    else
        mBgSwitcher:setAttr("visibility", "visible")
    end

    mBgSwitcher:getView():setInAnimation(nil)
    mBgSwitcher:getView():setOutAnimation(nil)
    local url = Rapid:getData("bg_image_url_1")
    mBgSwitcher:setAttr("url", url)
end

function onFirstVisibleChange()
    local bgImageNum = tonumber(Rapid:getData("bg_image_num", "0"))
    if bgImageNum <= 0 then
        return
    end

    local isFirstVisible = Rapid:getData("is_first_visible", "false")
    if isFirstVisible == "true" and isAnimRunning == "true" then
        return
    end

    loadDefauleBgImage()
    local switcher = Rapid:getChild("bg_switcher")
    if switcher ~= nil then
        local switcherView = switcher:getView()
        if switcherView ~= nil then
            switcherView:removeCallbacks(mSwitchImageFirstRunnable)
        end
    end
end

function doMoreImgSwitch()
    local bgImageNum = tonumber(Rapid:getData("bg_image_num", "0"))
    if bgImageNum <= 0 then
        return
    end

    Rapid:setData("bg_image_current_index", tostring(bgImageNum + 1))

    local switcher = Rapid:getChild("bg_switcher")
    if switcher ~= nil then
        local switcherView = switcher:getView()
        if switcherView ~= nil then
            switcherView:removeCallbacks(mSwitchImageFirstRunnable)
            switcherView:postDelayed(mSwitchImageFirstRunnable, 1000)
        end
    end
end

AnimationListenerMore = {}

function AnimationListenerMore.onAnimationRepeat(animation)
    local isFirstVisible = Rapid:getData("is_first_visible", "false")
    if isFirstVisible == "true" then
        switchBgImage()
    end
end

function switchBgImage()
    -- 修改之前，需要调整view的位置，防止动画失效
    local switchView = mBgSwitcher:getView()
    local nextView = switchView:getNextView()
    local nextIndex = switchView:indexOfChild(nextView)
    if nextIndex > 0 then
        switchView:removeView(nextView)
        switchView:addView(nextView, 0)
    end

    switchView:setInAnimation(mFadeInAnim)
    switchView:setOutAnimation(mFadeOutAnim)

    local currentIndex = getNextBgImageIndex() + 1
    local url = Rapid:getData("bg_image_url_" .. tostring(currentIndex))
    mBgSwitcher:setAttr("url", url)
end

function getNextBgImageIndex()
    local currentIndex = tonumber(Rapid:getData("bg_image_current_index"))
    local bgImageNum = tonumber(Rapid:getData("bg_image_num", "0"))
    if bgImageNum <= 0 then
        return 1
    end

    local result = currentIndex % bgImageNum
    currentIndex = currentIndex + 1
    Rapid:setData("bg_image_current_index", tostring(currentIndex))
    return result
end
