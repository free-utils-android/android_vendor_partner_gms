local mPhotonView,mJavaBridge = ...

local mAppRecyclerView = nil

local tag = "lua_second_play_recent_play_card"

function main()
    mAppRecyclerView = mPhotonView:getParser():getChildView('rv_app')
    mAppRecyclerView:getView():setClipToPadding(false)
    mAppRecyclerView:getView():setClipChildren(false)
end

function updateAppList()
    local recentplayVisible = Rapid:getData("recent_play_visible","0")
    local endGameVisible = Rapid:getData("midgame_challenge_visible","0")

    if endGameVisible ~= nil and endGameVisible == "1" then
        Rapid:getChild("midgame_challenge"):setAttr("visibility", "visible")
    else 
        Rapid:getChild("midgame_challenge"):setAttr("visibility", "gone")
    end
    if recentplayVisible == nil or recentplayVisible == "0" then
        Rapid:getChild("recent_play"):setAttr("visibility", "gone")
        return
    end
    Rapid:getChild("recent_play"):setAttr("visibility", "visible")

    local itemCount = tonumber(Rapid:getData("game_count", "0"))
    local allJumpUrl = tostring(Rapid:getData("all_jump_url",""))
    -- 全部按钮
    if allJumpUrl == "" then
        Rapid:getChild("rl_all"):setAttr("visibility", "gone")
    end
    -- 查看更多item
    local moreJumpUrl = tostring(Rapid:getData("more_jump_url", ""))
    if moreJumpUrl ~= "" then
        -- 增加一个尾部的查看更多item
        itemCount = itemCount + 1
    end
    mJavaBridge:Log(tag, "itemCount : "..itemCount)
    mJavaBridge:Log(tag, "title : "..Rapid:getData("title", ""))

    local dataList = {}
    local viewNameList = {}
    local subViewName = "second_play_recent_play_card_app_item.xml"
    for i = 1, itemCount do
        local itemData = Rapid:getData("item_data_" .. i)
        if i == itemCount and moreJumpUrl ~= "" then
            -- 最后一个item数据需要主动创建
            itemData = luajava.newInstance("java.util.HashMap")
            subViewName = "second_play_recent_play_card_more_item.xml"
            itemData:put("more_jump_url", mJavaBridge:create("Var", Rapid:getData("more_jump_url", "")))
            itemData:put("card_report_context", mJavaBridge:create("Var", Rapid:getData("card_report_context", "")))
            itemData:put("card_commendid", mJavaBridge:create("Var", Rapid:getData("card_recommendid")))
            local slotid = tostring(Rapid:getData("slotid", "")) .. "_00_" ..i
            itemData:put("more_slotid", mJavaBridge:create("Var", slotid))
        else
            itemData = Rapid:getData("item_data_" .. i)
            subViewName = "second_play_recent_play_card_app_item.xml"
        end
        if i == 1 then
            itemData:put("marginleft", mJavaBridge:create("Var", 4))
        end
        if (itemData ~= nil) then
            putJumpUrlJoinRid(itemData, 'app_play_url', 'app_recommendid')
            itemData:put("scene", mJavaBridge:create("Var", Rapid:getData("scene", "")))
            itemData:put("modeltype", mJavaBridge:create("Var", Rapid:getData("modeltype", "")))
            itemData:put("slotid", mJavaBridge:create("Var", Rapid:getData("slotid", "")))
            itemData:put("sourcescene", mJavaBridge:create("Var", Rapid:getData("sourcescene", "")))
            itemData:put("sourcesceneslotid", mJavaBridge:create("Var", Rapid:getData("sourcesceneslotid", "")))
            itemData:put("sourcemodeltype", mJavaBridge:create("Var", Rapid:getData("sourcemodeltype", "")))
            itemData:put("subposition", mJavaBridge:create("Var", i))
            dataList[i] = itemData
            viewNameList[i] = subViewName
        end
    end
    mJavaBridge:Log(tag, "updateAppList end")
    mAppRecyclerView:getView():removeAllViews()
    mAppRecyclerView:getView():updateData(viewNameList, dataList, true)
    mAppRecyclerView:getView():scrollToPosition(0)
end

function putJumpUrlJoinRid(itemData, jumpUrlKey, appRecommendidKey)
    if itemData ~= nil and itemData:get(jumpUrlKey) ~= nil and itemData:get(appRecommendidKey) ~= nil then
        itemData:put(jumpUrlKey, jumpUrlJoinRid(itemData:get(jumpUrlKey):getString(), 
            itemData:get(appRecommendidKey):getLuaValue()))
    end
end

function jumpUrlJoinRid(jumpUrl, recommendid)
    if jumpUrl == nil or jumpUrl == "" then
        return jumpUrl
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendid), "default")
    if rcdBase64 ~= nil and rcdBase64 ~= "" then
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
        mJavaBridge:Log("jumpUrlJoinRid", 'jumpUrl: '..tostring(jumpUrl))
    end
    return mJavaBridge:create("Var", jumpUrl)
end