local mRapidView,mJavaBridge = ...

local TAG = "realswitch"
local mActionListener
local mLayoutManager
local mScrollListener
local mScreenWidth
local mRecyclerView
local mCurrentAppIndex = 0
local mAnchorScrollCenterOffset
local ITEM_WIDTH_DP = 66
local VIEW_VISIBLE = 0
local VIEW_INVISIBLE = 4

local var_scene
local var_sourcescene
local var_modeltype
local var_sourceslotid 
--  非在玩推荐分配了一个特殊的appid
local RECOMMEND_GAME_ZONE_APPID = "-1000"
local RECOMMEND_BG = "https://cms.myapp.com/yyb/2021/12/06/1638788905534_f8c56a9a5c417fb19e594ae8cb45c188.png"
function main() 
    mRecyclerView = Rapid:getChild('switcher_list'):getView()
    mLayoutManager = mRecyclerView:getLayoutManager()
    mActionListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IPhotonActionListener', IActionListener)
    mRecyclerView:setActionListener(mActionListener)

    mScrollListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrolledListener', RecyclerScrolledListener)
    mRecyclerView:setScrolledListener(mScrollListener)

    local itemWidthPx = mJavaBridge:dip2px(ITEM_WIDTH_DP)
    mScreenWidth = mJavaBridge:getScreenWidth()
    mAnchorScrollCenterOffset = mScreenWidth / 2 - itemWidthPx /2


    local itemDecoration = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IItemDecorationListener', IItemDecorationListener)
    mRecyclerView:addItemDecoration(itemDecoration)
    
    fillData()
end


function fillData()
    local dataList = {}
    local viewNameList = {}
    local gameCount = tonumber(Rapid:getData('item_num','0'))
    local currentAppId = Rapid:getData('current_app_id',"")

    if currentAppId == "" then
        currentAppId = RECOMMEND_GAME_ZONE_APPID
    end
    Rapid:Log(TAG,"current_app_id " .. currentAppId)

    var_scene = mJavaBridge:create("Var",Rapid:getData('scene',''))
    var_sourcescene = mJavaBridge:create("Var",Rapid:getData('sourcescene',''))
    var_modeltype =  mJavaBridge:create("Var",Rapid:getData('modeltype',''))
    var_sourceslotid = mJavaBridge:create("Var", Rapid:getData('sourcesceneslotid',''))

    for i = 1, gameCount do
        local itemData = Rapid:getData("item_data_" .. i)
        local appID = tostring(itemData:get("tab_key"))
        local gameInfo = parserGameInfo(itemData)
        if appID == currentAppId then
            selectAppAndScroll(i - 1)
            initAppBackground(gameInfo)
            Rapid:Log(TAG,"initAppBackground " .. tostring(gameInfo))

        end
        itemData:put("subposition",mJavaBridge:create("Var",tonumber(i)))
        addReportData(itemData)
        dataList[i] = itemData
        viewNameList[i] = 'playing_game_tab_switcher_card_item.xml'
    end

    if gameCount == 1 and currentAppId == RECOMMEND_GAME_ZONE_APPID then
        initRecommendAppZone()
        return
    end

    Rapid:getChild('tv_rmd'):setAttr("visibility","gone")
    mRecyclerView:setVisibility(VIEW_VISIBLE)
    mRecyclerView:updateData(viewNameList, dataList, true)
end

function addReportData(itemData)
    itemData:put("scene",var_scene)
    itemData:put("sourcescene",var_sourcescene)
    itemData:put("sourceScene",var_sourcescene)
    itemData:put("modeltype",var_modeltype)
    itemData:put("modelType",var_modeltype)
    itemData:put("sourcesceneslotid",var_sourceslotid)
    itemData:put("sourceSceneSlotId",var_sourceslotid)
end


function initRecommendAppZone()
    Rapid:getChild('tv_rmd'):setAttr("visibility","visible")
    mRecyclerView:setVisibility(VIEW_INVISIBLE)
end

function selectAppAndScroll(index)
    mCurrentAppIndex = index
    mJavaBridge:postRun(doPostSelect)
end

function doPostSelect()
    moveSelectedAppToCenter(mCurrentAppIndex)
    setItemAnchorVisibleWithRecyclerView()
end

function parserGameInfo(itemData)
    if itemData == nil then
        return ""
    end

    local appID = tostring(itemData:get("tab_key"))
    local iconUrl = itemData:get("icon")
    local appName = itemData:get("name")
    local gameInfo = mJavaBridge:create("jsonobject")
    gameInfo:putOpt("appID", tostring(appID))

    gameInfo:putOpt("bgUrl", tostring(iconUrl))
    gameInfo:putOpt("iconUrl", tostring(iconUrl))

    if appID == RECOMMEND_GAME_ZONE_APPID then
        gameInfo:putOpt("bgUrl", tostring(RECOMMEND_BG))
        gameInfo:putOpt("iconUrl", tostring(""))
    end


    gameInfo:putOpt("appName", tostring(appName))

    Rapid:Log(TAG," parserGameInfo appID switch " .. tostring(gameInfo))

    return tostring(gameInfo)
end

function sendSwitchAppRequest(appPos)
    local itemData = Rapid:getData("item_data_" .. (appPos + 1))
    local gameInfo = parserGameInfo(itemData)

    local params = {}
    params["key"] = "switchApp"
    params["value"] = gameInfo

    Rapid:Log(TAG,"appID switch "  .. "appPos" .. appPos .. tostring(gameInfo))
    Rapid:execAction('outeraction',params,nil)
end


function initAppBackground(gameInfo)
    local params = {}
    params["key"] = "initApp"
    params["value"] = gameInfo

    Rapid:Log(TAG,"initApp "  .. tostring(gameInfo))
    Rapid:execAction('outeraction',params,nil)
end

IActionListener = {}
function IActionListener.notify(key, value)
    Rapid:Log(TAG,"IActionListener " .. value)
    if (key == "clickApp") then
        local index = tonumber(value)
        sendSwitchAppRequest(index)
        selectAppAndScroll(index)
        return
    end

    if mRapidView == nil then
        return
    end
    mRapidView:getParser():getListener():notify(key,value)
end

RecyclerScrolledListener = {}
function RecyclerScrolledListener.onScrolled(recyclerView, dx, dy)
    setItemAnchorVisibleWithRecyclerView()
end

function moveSelectedAppToCenter(index)
    if mLayoutManager == nil then
        return
    end
    mLayoutManager:scrollToPositionWithOffset(index, mAnchorScrollCenterOffset)
end

function setItemAnchorVisibleWithRecyclerView()
    Rapid:Log("realhexxx","setItemAnchorVisibleWithRecyclerView")
    if mLayoutManager == nil then
        Rapid:Log("realhexxx","mLayoutManager nil")
        return
    end
    local targetItemView = mLayoutManager:findViewByPosition(mCurrentAppIndex)

    if targetItemView ~= nil then
        if targetItemView:getLeft() < 0 or targetItemView:getRight() > mScreenWidth then
            hideAnchor()
        else
            showAnchor()
        end
    end


    local childCount = mRecyclerView:getChildCount()
    for i=0,childCount do
        local itemView = mRecyclerView:getChildAt(i)
        local itemPos = -1
        if itemView ~= nil and itemView:getLayoutParams() ~= nil then
            itemPos = mLayoutManager:getPosition(itemView)
        end
        Rapid:Log("realhexxx","itemPos i:" .. tostring(i) .. " pos:" .. tostring(itemPos))

        if itemPos ~= mCurrentAppIndex then
            setItemAnchorVisible(itemView,VIEW_INVISIBLE)
        else
            setItemAnchorVisible(itemView,VIEW_VISIBLE)
        end
    end
end

function isViewMatchPosition(view,position)
    if view == nil or view:getTag() == nil then
        return nil
    end

    local rapidParser = view:getTag():getParser()
end

function setItemAnchorVisible(view,visibity)
    if view == nil or view:getTag() == nil then
        return
    end

    local rapidParser = view:getTag():getParser()
    local anchorView = rapidParser:getChildView("anchor")

    if anchorView == nil or anchorView:getView() == nil then
        return 
    end

    anchorView:getView():setVisibility(visibity)
end

-- 设置选中下标和选中外框的显隐
function setItemAnchorVisible(view,visibity)
    local anchorLayout= getChildRapidViewFromView(view,"anchor")
    if anchorLayout == nil then
        return
    end
    anchorLayout:getView():setVisibility(visibity)
end

-- 单独设置选中下标的显隐，为了避免下标快出屏幕时，跟两侧的下圆角冲突
function hideAnchor( )
    local targetItemView = mLayoutManager:findViewByPosition(mCurrentAppIndex)

    local bottomAnchor = getChildRapidViewFromView(targetItemView,"bottom_anchor")
    if bottomAnchor == nil then
        return
    end
    bottomAnchor:getView():setVisibility(VIEW_INVISIBLE)
end

function showAnchor(  )
    local targetItemView = mLayoutManager:findViewByPosition(mCurrentAppIndex)

    local bottomAnchor = getChildRapidViewFromView(targetItemView,"bottom_anchor")
    if bottomAnchor == nil then
        return
    end
    bottomAnchor:getView():setVisibility(VIEW_VISIBLE)
end

function getChildRapidViewFromView(view,id)
    if view == nil or view:getTag() == nil then
        return nil
    end

    local rapidParser = view:getTag():getParser()
    local childRapidView = rapidParser:getChildView(id)
    if childRapidView == nil or childRapidView:getView() == nil then
        return nil
    end
    return childRapidView
end

IItemDecorationListener = {}
function IItemDecorationListener.onDraw(c, parent, state)
end

function IItemDecorationListener.onDrawOver(c, parent, state)
end

function IItemDecorationListener.getItemOffsets(outRect, view, parent, state)
    local index = parent:getChildPosition(view)

    if (index == 0) then
        outRect.left = mJavaBridge:dip2px(7)
    else
        outRect.left = mJavaBridge:dip2px(0)
    end
end
