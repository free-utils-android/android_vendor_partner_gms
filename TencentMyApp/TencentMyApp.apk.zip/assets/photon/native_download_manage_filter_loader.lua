local mPhotonView,mJavaBridge = ...

function load()
    local mBinder = mPhotonView:getParser():getBinder()
    local appCount = tonumber(mBinder:get("appCount"))

    local cureentDisplayCount = 0
    for i = 0, appCount-1 do
        if(cureentDisplayCount >= 6) then
            break
        end

        local data = {}
        data['appId'] = mBinder:get('appId_' .. i)
        data['pkgName'] = mBinder:get('pkgName_' .. i)
        data['appName'] = mBinder:get('appName_' .. i)
        data['iconUrl'] = mBinder:get('iconUrl_' .. i)
        data['desc'] = mBinder:get('desc_' .. i)
        data['sizeStr'] = mBinder:get('sizeStr_' .. i)
        data['AppSimpleDetail'] = mBinder:get('AppSimpleDetail_' .. i)
        data['recommendid'] = mBinder:get('recommendid_' .. i)
        data['scene'] = mBinder:get('scene')
        data['sourcescene'] = mBinder:get('sourcescene')

        local filtermap = {}
        filtermap['package'] = data['pkgName']
        local hasDownloaded = mPhotonView:getParser():getTaskCenter():getFilterRunner():run("downloadfilter",filtermap,nil)

        if not hasDownloaded then
            data['slotid'] = mBinder:get('slotid') .. '_00' .. (cureentDisplayCount + 1)
            local index = cureentDisplayCount
            Rapid:getChild('place_holder_'..index):getView():loadData(data)
            Rapid:getChild('place_holder_'..index):getView():setViewName('download_manage_recommend_card_item')
            Rapid:getChild('place_holder_'..index):getView():load()
            cureentDisplayCount = cureentDisplayCount + 1
        end
    end

    if(cureentDisplayCount < 3) then
        Rapid:getChild('recommend_card'):setAttr('visibility','gone')
    elseif (cureentDisplayCount < 6 and cureentDisplayCount >=3) then
        Rapid:getChild('recommend_line2'):setAttr('visibility','gone')
    end
end






