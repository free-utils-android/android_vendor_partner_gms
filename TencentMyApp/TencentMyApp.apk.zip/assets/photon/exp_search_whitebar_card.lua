local mPhotonView, mJavaBridge = ...

local TAG = "lua_exp_search_whitebar_card"

local mCloudPlayName
local mCloudPlayNameMaxWidth 

local mDownloadButtonAnimationEnable
local mRunnable
local mDownloadAnimSet

local function checkEnable(key)
    return tostring(Rapid:getData(key, '0')) == '1'
end

local function checkAdvertisingStyleEnable()
    return checkEnable('advertising_style_enable')
end

local function checkCloudPlayEnable()
    return checkEnable('show_cloud_bar') and checkEnable('cloud_play_enable')
end

local function checkOmaEnable()
    return checkEnable('oma_enable')
end

local function checkRelevantCardEnable()
    return checkEnable('relevant_card_enable')
end

local function removeData(key)
    mPhotonView:getParser():getBinder():removeData(key)
end

local function initColor()
    setValue('strokecolor', 'download_button_transparent_color', '595186EE')
    setValue('normalbgcolor', 'download_button_bg_color', '00ffffff')
    setValue('normaltextcolor', 'download_button_text_color', '1d82ff')
    setValue('normalstrokecolor', 'download_button_transparent_color', '595186EE')
    setValue('prrogresscolor', 'download_button_bg_color', '595186EE')
    setValue('progresstextcolor', 'download_button_text_color', '1d82ff')
    setValue('progressstrokecolor', 'download_button_progress_bg_color', '595186EE')
    setValue('progressoutcolor', 'download_button_progress_bg_color', '00ffffff')
    setValue('progressouttextcolor', 'download_button_text_color', '1d82ff')
    setValue('installedbgcolor', 'download_button_bg_color', '00ffffff')
    setValue('installedtextcolor', 'download_button_text_color', '1d82ff')
    setValue('installedstrokecolor', 'download_button_transparent_color', '595186EE')
    setValue('downloadedbgcolor', 'download_button_bg_color', '00ffffff')
    setValue('downloadedtextcolor', 'download_button_text_color', '1d82ff')
    setValue('downloadedstrokecolor', 'download_button_transparent_color', '595186EE')
end

function setValue(dstKey, srcKey, def)
    if Rapid:getData(srcKey, '') == '' then
        Rapid:setData(dstKey, def)
    else
        Rapid:setData(dstKey, Rapid:getData(srcKey))
    end
end

local function updateAdvertisingStyle()
    if checkAdvertisingStyleEnable() then
        -- 广告样式，目前一共3,5两种样式，默认值为广告样式3
        local advertisingStyle = Rapid:getData('advertising_style', '3')
        -- 广告样式3标签背景颜色
        local tagBgColor = '73ff8600'
        if advertisingStyle == '5'  then
            tagBgColor = Rapid:getData('advertising_tag_color', '73ff8600')
            Rapid:getChild('card_container'):setAttr('gradientdrawable', '')
            Rapid:getChild('app_container'):setAttr('padding', '12,10,0,10')
            Rapid:getChild('icon_card_bg'):setAttr('visibility', 'visible')

            Rapid:setData('download_button_transparent_color', '00ffffff')
            Rapid:setData('download_button_text_color', 'ffffffff')
        else
            Rapid:getChild('card_container'):setAttr('gradientdrawable', 'cornerradius:8,color:14ff8600')
            Rapid:getChild('app_container'):setAttr('padding', '12,10,0,0')
            Rapid:getChild('icon_card_bg'):setAttr('visibility', 'gone')
        end
        Rapid:setData('advertising_style_visible', 'visible')
        -- 广告标签文案:不为空则直接展示;否则展示”广告“
        local advertisingTagText = Rapid:getData('advertising_tag_text', '')
        if advertisingTagText ~= nil and advertisingTagText ~= '' then
            Rapid:getChild('advertising_style_3'):setAttr('text', advertisingTagText)
        else
            Rapid:getChild('advertising_style_3'):setAttr('text', '广告')
        end
        Rapid:getChild('card_container'):setAttr('margin', '12,10,12,2')
        Rapid:getChild('cloud_play_container'):setAttr('margin', '68,3,12,0')
        Rapid:getChild('advertising_style_3'):setAttr('gradientdrawable', 'cornerradius:2,color:' .. tagBgColor)

        -- 广告样式隐藏appstubbutton组件，展示自定义下载按钮
        Rapid:getChild('app_button'):setAttr('visibility', 'gone')
        Rapid:getChild('app_download'):setAttr('visibility', 'visible')

        mDownloadButtonAnimationEnable = true
        runShakeAnim()
    else
        Rapid:setData('advertising_style_visible', 'gone')
        Rapid:getChild('card_container'):setAttr('gradientdrawable', 'cornerradius:0,color:00ff8600')
        Rapid:getChild('card_container'):setAttr('margin', '0,0,0,0')
        Rapid:getChild('app_container'):setAttr('padding', '16,10,12,0')
        Rapid:getChild('cloud_play_container'):setAttr('margin', '72,3,24,0')
        Rapid:getChild('icon_card_bg'):setAttr('visibility', 'gone')
        removeData('download_button_transparent_color')
        removeData('download_button_text_color')
        removeData('download_button_bg_color')
        removeData('download_button_progress_bg_color')
        mDownloadButtonAnimationEnable = false

        -- 普通样式展示appstubbutton组件，隐藏自定义下载按钮
        Rapid:getChild('app_button'):setAttr('visibility', 'visible')
        Rapid:getChild('app_download'):setAttr('visibility', 'gone')
    end
    initColor()
end

local function updateTextViewWidth()
    local cloudPlayName = Rapid:getData('cloud_play_name', '')
    local cloudPlayNameTextWidth = mJavaBridge:px2dip(mCloudPlayName:getView():getPaint():measureText(cloudPlayName))
    if cloudPlayNameTextWidth > mCloudPlayNameMaxWidth then
        cloudPlayNameTextWidth = mCloudPlayNameMaxWidth
    end
    Rapid:setData('cloud_play_button_width', cloudPlayNameTextWidth + 48)
end

local function checkCloudPlay()
    -- 云玩功能是否可用
    if not checkCloudPlayEnable() then
        return false
    end
    return true
end

local function updateAppState() 
    local appModel = Rapid:getData("app_model")
    if appModel == nil then
        return nil
    end
    local appState = mJavaBridge:getAppState(appModel)
    Rapid:setData('buttonstatus', appState)
    return appState
end

local function downloadPlugin()
    mJavaBridge:Log(TAG, "downloadPlugin")
    local params = {}
    params["packagename"] = "com.tencent.assistant.plugin.cloudgame"
    mJavaBridge:runJsBridge("downloadPlugin", params, nil)
end

local function jumpAction(tmast)
    mJavaBridge:Log(TAG, "downloadPlugin tmast: "..tostring(tmast))
    local params = {}
    params["tmast"] = tmast
    Rapid:execAction("tmastaction", params, nil)
end

local function getPositionString(position)
    return string.format("%03d", position)
end

local function updateCloudPlay()
    if not checkCloudPlay() then
        Rapid:setData('cloud_play_visible', 'gone')
        return
    end
    Rapid:setData('cloud_play_visible', 'visible')
    updateTextViewWidth()
end

local function jumpAppDetailByUrl(jumpUrl)
    local param = {
        ["tmast"] = jumpUrl,
        ["extra"] = "sourcemodeltype:data@modeltype,searchsession:data@searchsession"
    }
    Rapid:execAction("tmastaction", param, param)
end

local function jumpAppDetailByAppModel()
    local param = {
        ["appsimpledetail"] = "data@app_model",
        ["pageid"] = "data@scene",
        ["sourceslot"] = "data@slotid",
        ["sourceslotsubposition"] = "001",
        ["searchid"] = "data@searchId",
        ["orderurl"] = "data@order_jump_url",
        ["extradata"] = "data@queryWord",
        ["modeltype"] = "data@modeltype",
        ["extra"] = "searchsession:data@searchsession",
        ["extendparam"] = "report_context:data@app_report_context,searchquery:data@queryWord,sourcequery:data@sourceQuery,search_scene:data@searchScene"
    }
    Rapid:execAction("jumpappdetailaction", param, param)
end

local function jumpAppDetail()
    local appJumpUrl = Rapid:getData("app_jump_url")
    if appJumpUrl ~= nil and appJumpUrl ~= "" then
        jumpAppDetailByUrl(appJumpUrl)
    else
        jumpAppDetailByAppModel()
    end
end

-- 获取卡片依附的recyclerview对象
local function getOuterRecyclerView()
    local childView = Rapid:getChild('card_container'):getView()
    -- 获取placeholder对象
    local parentView = childView:getParent()
    if parentView ~= nil then
        return parentView:getParent()
    end
    return nil
end

-- 通知展示相关卡片
local function showRelativeCard()
    local recyclerView = getOuterRecyclerView()
    if recyclerView ~= nil then
        local adapter = recyclerView:getAdapter()
        if adapter ~= nil then
            -- 修改标记位
            Rapid:setData('canNotifyRelevantCardShow', "false")
            local position = Rapid:getData('position', '-1')
            local posInt = tonumber(position) + 1
            adapter:notifyItemChanged(posInt)
        end
    end
end

-- 检查是否可以显示相关卡片
local function isRelevantCardShow()
    local appState = updateAppState()
    if appState == 'DOWNLOADING' or appState == 'PAUSED' or appState == 'UPDATE' or appState == 'DOWNLOADED' or appState == 'INSTALLED' then
        return true
    end
    return false
end

-- 出oma时，是否可以通知相关卡片展示
local function canNotifyRelevantCardShow()
    if checkRelevantCardEnable() then
        if isRelevantCardShow() then
            return "false"
        else
            return "true"
        end
    end
    return "false"
end

local function updateCanNotifyRelevantCardShow()
    Rapid:setData('canNotifyRelevantCardShow', canNotifyRelevantCardShow())
end

local function checkOmtEnable()
    -- 当关闭oma功能时，不展示oma
    if not checkOmaEnable() then
        return false
    end
    -- 当显示广告样式时，则不展示oma
    if checkAdvertisingStyleEnable() then
        return false
    end
    -- 当列表存在相关卡片时，则不展示oma
    if checkRelevantCardEnable() then
        return false
    end
    return true
end

-- 下载预约按钮循环抖动
local Runnable = {}
function Runnable.run()
    runShakeAnim()
end

function loadFinish()
    mCloudPlayName = Rapid:getChild('cloud_play_name')
    mCloudPlayNameMaxWidth = mJavaBridge:px2dip(mCloudPlayName:getView():getPaint():measureText("云玩游戏"))
    mRunnable = luajava.createProxy('java.lang.Runnable', Runnable)

    setClipAttr(Rapid:getChild('button_container'):getView())
    setClipAttr(Rapid:getChild('app_container'):getView())
    setClipAttr(Rapid:getChild('card_container'):getView())
end

-- 设置允许子view超出父容器范围
function setClipAttr(view)
    view:setClipChildren(false)
    view:setClipToPadding(false)
end

function afterUpdateData()
    updateAdvertisingStyle()
    updateCloudPlay()
    updateCanNotifyRelevantCardShow()
    updateAppState()
end

function onResume()
    if checkRelevantCardEnable() then
        updateCanNotifyRelevantCardShow()
    end 
end

function showOmt()
    if checkOmtEnable() then
        local params = {}
        params['key'] = 'showPhotonOMT'
        params['value'] = 'id:omt_container,appModelKey:app_model'
        mPhotonView:getParser():getTaskCenter():getActionRunner():run('outeraction', params, nil)
        return
    end
    if tostring(Rapid:getData('canNotifyRelevantCardShow', 'false')) == "true" then
        mJavaBridge:delayRun(200, showRelativeCard)
    end
end

function appJump()
    jumpAppDetail()
end

function trialJump()
    updateAppState()
    jumpAction(Rapid:getData('cloud_play_jump'))
end

-- 创建缩放动画的参数
local function createScaleAnimParam()
    local params = {}
    params[1] = 1.25
    params[2] = 1.0
    return params
end

-- 创建抖动动画的参数
local function createShakeAnimParam()
    local params = {}
    params[1] = 0.0
    params[2] = 5.0
    params[3] = -5.0
    params[4] = 5.0
    params[5] = -5.0
    params[6] = 5.0
    params[7] = -5.0
    params[8] = 5.0
    params[9] = -5.0
    params[10] = 5.0
    params[11] = -5.0
    params[12] = 5.0
    params[13] = -5.0
    params[14] = 0.0
    return params
end

local function removeCallbacks(view)
    if mRunnable ~= nil then
        view:removeCallbacks(mRunnable)
    end
end

local function startDownloadButtonAnimation()
    local view = Rapid:getChild('app_download'):getView()
    pcall(removeCallbacks, view) -- 移除Callback，避免crash
    if mDownloadButtonAnimationEnable then
        view:postDelayed(mRunnable, 3000)
    end
end

-- 下载按钮抖动监听
local DownloadAnimationListener={}
function DownloadAnimationListener.onAnimationStart(animator)
end

function DownloadAnimationListener.onAnimationEnd(animator)
    startDownloadButtonAnimation()
end

function DownloadAnimationListener.onAnimationCancel(animator)
end

function DownloadAnimationListener.onAnimationRepeat(animator)
end

local function createDownloadButtonAnimation(downloadbutton)
    local downloadAnimSet = luajava.newInstance('android.animation.AnimatorSet')
    local ObjectAnimator = luajava.bindClass("android.animation.ObjectAnimator")
    local listener = luajava.createProxy('android.animation.Animator$AnimatorListener', DownloadAnimationListener)

    local objScaleXAnim = ObjectAnimator:ofFloat(downloadbutton, 'scaleX', createScaleAnimParam())
    objScaleXAnim:setDuration(200)
    local objScaleYAnim = ObjectAnimator:ofFloat(downloadbutton, 'scaleY', createScaleAnimParam())
    objScaleYAnim:setDuration(200)
    local objDouAnim = ObjectAnimator:ofFloat(downloadbutton, 'rotation', createShakeAnimParam())
    objDouAnim:setDuration(600)

    local objParams = {}
    objParams[1] = objScaleXAnim
    objParams[2] = objDouAnim
    objParams[3] = objScaleYAnim

    downloadAnimSet:playTogether(objParams)
    downloadAnimSet:addListener(listener)

    return downloadAnimSet
end

function runShakeAnim()
    if not mDownloadButtonAnimationEnable then
        return
    end
    local downloadbutton = Rapid:getChild('app_download'):getView()
    downloadbutton:clearAnimation()
    if  mDownloadAnimSet == nil then
        mDownloadAnimSet = createDownloadButtonAnimation(downloadbutton)
    end
    mDownloadAnimSet:start()
end