local mRapidView, mJavaBridge = ...
local recyclerView
local indicator
local totalX = 0
local totalIndicatorX
local totalRvScrollX
local itemWidth = 72
local indicatorWidth = 20
local leftMargin
local imageWidth
local scoreChangeListener
local TAG = "personal_center_one_shot_optimization_card"
local ONE_HOUR = 3600000
local animationWidth
local tvRubbish
local isAnimationEnd = false
local hasScan = false
local tvCanDeleteRubbish
local memoryUtils
local totalRubbishSize = 0
local background
local foreground
local currentScore = 100
local hundred
local ten
local one
local scoreMap = {}
local hasCleanRubbish = false
local defaultRepeatCount = 2
local deletePathList = luajava.newInstance("java.util.ArrayList")
local mSystem = luajava.bindClass("java.lang.System")
local lastcleanTime = 1

function init(...)
    local screenWidth = mJavaBridge:px2dip(mJavaBridge:getScreenWidth())
    itemWidth = screenWidth * 0.2
    leftMargin = screenWidth * 0.022
    imageWidth = screenWidth * 0.11
    memoryUtils = luajava.bindClass("com.tencent.assistant.utils.MemoryUtils")
    initScoreMap()
end

function loadData(...)
    recyclerView = Rapid:getChild("recyclerview")
    indicator = Rapid:getChild("indicator"):getView()
    tvRubbish = Rapid:getChild("tv_rubbish"):getView()
    tvCanDeleteRubbish = Rapid:getChild("tv_can_delete_rubbish"):getView()
    lastcleanTime = mSystem:currentTimeMillis()
    hundred = Rapid:getChild("hundred")
    ten = Rapid:getChild("ten")
    one = Rapid:getChild("one")

    local itemCount = tonumber(Rapid:getData("item_count"))

    local arrayList = luajava.newInstance("java.util.ArrayList")
    local dataList = luajava.newInstance("java.util.ArrayList")
    for i = 1, itemCount do
        local mapData = luajava.newInstance("java.util.HashMap")
        local itemData = Rapid:getData("item_data_" .. tostring(i))
        putMapData(mapData, "item_title", Rapid:getData("item_data_" .. tostring(i) .. "_item_title"))
        putMapData(mapData, "item_icon_url", Rapid:getData("item_data_" .. tostring(i) .. "_item_icon_url"))
        putMapData(mapData, "item_jump_url", Rapid:getData("item_data_" .. tostring(i) .. "_item_jump_url"))
        putMapData(mapData, "item_type", Rapid:getData("item_data_" .. tostring(i) .. "_item_type"))
        putMapData(mapData, "report_context_app", Rapid:getData("item_data_" .. tostring(i) .. "_report_context_app"))

        putMapData(mapData, "scene", Rapid:getData("scene"))
        putMapData(mapData, "sourcescene", Rapid:getData("sourcescene"))
        putMapData(mapData, "modelType", Rapid:getData("modeltype"))
        putMapData(mapData, "sourcesceneslotid", Rapid:getData("sourcesceneslotid"))
        putMapData(mapData, "slotid", Rapid:getData("slotid"))
        putMapData(mapData, "small_position", i)
        putMapData(mapData, "recomendid_card", Rapid:getData("recomendid_card"))
        putMapData(mapData, "permission_status", Rapid:getData("permission_status"))
        putMapData(mapData, "uni_manage_score", Rapid:getData("uni_manage_score"))

        putMapData(mapData, "item_width", tostring(itemWidth))
        putMapData(mapData, "left_margin", tostring(leftMargin))
        local rightMargin = 0
        if i == itemCount and itemCount > 4 then
            rightMargin = leftMargin
        end
        putMapData(mapData, "right_margin", tostring(rightMargin))
        putMapData(mapData, "image_width", tostring(imageWidth))
        arrayList:add("personal_center_one_shot_optimization_list_item.xml")
        dataList:add(mapData)
    end
    recyclerView:getView():updateData(dataList, arrayList, true)
    if itemCount > 4 then
        local onScrollListener =
            luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrolledListener",
            OnScrollChangeListener
        )
        Rapid:getChild("indicator_root"):setAttr("visibility", "visible")
        recyclerView:getView():setScrolledListener(onScrollListener)
        local hideItemCount = (itemCount - 4)
        totalRvScrollX =
            mJavaBridge:dip2px(itemWidth) * hideItemCount + (hideItemCount * mJavaBridge:dip2px(leftMargin))
        totalIndicatorX = mJavaBridge:dip2px(indicatorWidth)
    end
    scoreChangeListener =
        luajava.createProxy(
        "com.tencent.rapidview.deobfuscated.control.IManagerScoreChangedListener",
        IManagerScoreChangedListener
    )
    mJavaBridge:calcFinalScoreAsync(scoreChangeListener)
    scan()
end

function requestPermission(...)
    return mJavaBridge:callModuleWithParams("AppManager", "requestPermission", {permissionCallback})
end

function permissionCallback(perrmission, results)
    if mJavaBridge:hasPermissionGranted(9) then
        jumpToAccelerate()
    end
end

function onResume(...)
    mSystem = luajava.bindClass("java.lang.System")
    local duration = mSystem:currentTimeMillis() - tonumber(lastcleanTime)
    if duration > ONE_HOUR then
        resetCleanState()
    end
    mJavaBridge:calcFinalScoreAsync(scoreChangeListener)
    Rapid:Log(TAG, "permission " .. tostring(mJavaBridge:hasPermissionGranted(9)))
end

function scan(...)
    if hasScan then
        return
    end
    Rapid:Log(TAG, "startRubbishScan")
    mJavaBridge:callModuleWithParams("AppManager", "startRubbishScan", {onScanFinish, onRubbishFound})
    tvRubbish:setText("正在扫描:/sdcard/Android/data")
    doScanAnimation()
    hasScan = true
end

function onLottieLoad(...)
    --scan()
end

function playLottie(...)
    lottie:getView():playAnimation()
end

function doScanAnimation(...)
    lottie = Rapid:getChild("lottie")
    --mJavaBridge:delayRun(10, playLottie)
    playLottie()
    Rapid:getChild("firstLottieFrame"):setAttr("visibility", "gone")
    background = Rapid:getChild("background"):getView()
    foreground = Rapid:getChild("foreground"):getView()

    animationWidth = mJavaBridge:getScreenWidth() - mJavaBridge:px2dip(32)
    local valueAnimatorClass = luajava.bindClass("android.animation.ValueAnimator")
    local params = {}
    params[0] = 0
    params[1] = 2 * animationWidth

    Rapid:getChild("foreground"):getView():setTranslationX(-animationWidth)
    local foregroundAnim = valueAnimatorClass:ofInt(params)
    foregroundAnim:setDuration(1000)
    local animatorUpdateListener =
        luajava.createProxy("android.animation.ValueAnimator$AnimatorUpdateListener", AnimatorUpdateListener)
    local animatorListener = luajava.createProxy("android.animation.Animator$AnimatorListener", AnimationListener)
    local interpolator = mJavaBridge:createNewInstance("android.view.animation.AccelerateDecelerateInterpolator", nil)
    foregroundAnim:setInterpolator(interpolator)
    foregroundAnim:addUpdateListener(animatorUpdateListener)
    foregroundAnim:addListener(animatorListener)
    foregroundAnim:setRepeatCount(defaultRepeatCount)
    foregroundAnim:start()
end

function disappearAnimation(...)
    local tvScanTips = Rapid:getChild("tv_scan_tips"):getView()
    local alphaParams = {}
    alphaParams[0] = 1
    alphaParams[1] = 0
    alphaAnimation(background, alphaParams, 170)
    alphaAnimation(foreground, alphaParams, 170)
    alphaAnimation(tvScanTips, alphaParams, 200)
    alphaAnimation(tvRubbish, alphaParams, 200)
    alphaAnimation(Rapid:getChild("lottie"):getView(), alphaParams, 100)
    local params = {}
    params[0] = 0
    params[1] = mJavaBridge:dip2px(30)
    transalteAnimation(tvScanTips, params, 200)
    transalteAnimation(tvRubbish, params, 200)
end

function enterAnimation(...)
    local scoreContainer = Rapid:getChild("score_container"):getView()
    local scoreTips = Rapid:getChild("score_tips"):getView()
    local oneShot = Rapid:getChild("oneshot"):getView()
    local alphaParams = {}
    alphaParams[0] = 0
    alphaParams[1] = 1
    alphaAnimation(scoreContainer, alphaParams, 400)
    alphaAnimation(scoreTips, alphaParams, 400)
    if currentScore == 100 then
        alphaAnimation(Rapid:getChild("tv_full_score"):getView(), alphaParams, 400)
        fullScoreTickAnimation()
    else
        alphaAnimation(oneShot, alphaParams, 400)
    end

    elementEnterTranslateAnimation()
    scoreChangeAnimation()
end
local fullScoreTickWidth = 300
function fullScoreTickAnimation(...)
    fullScoreTickWidth = mJavaBridge:dip2px(61)
    local valueAnimatorClass = luajava.bindClass("android.animation.ValueAnimator")
    local params = {}
    params[0] = 0
    params[1] = fullScoreTickWidth

    local anim = valueAnimatorClass:ofInt(params)
    anim:setDuration(400)
    local animatorUpdateListener =
        luajava.createProxy("android.animation.ValueAnimator$AnimatorUpdateListener", FullScoreUpdateListener)
    anim:addUpdateListener(animatorUpdateListener)
    anim:start()
end

local animationEnd = 100
function scoreChangeAnimation(...)
    local valueAnimatorClass = luajava.bindClass("android.animation.ValueAnimator")
    animationEnd = currentScore + 20
    if animationEnd > 100 then
        animationEnd = 100
    end
    local params = {}
    params[0] = 0
    params[1] = animationEnd - currentScore

    local anim = valueAnimatorClass:ofInt(params)
    anim:setDuration(400)
    local animatorUpdateListener =
        luajava.createProxy("android.animation.ValueAnimator$AnimatorUpdateListener", ScoreUpdateListener)
    anim:addUpdateListener(animatorUpdateListener)
    anim:start()
end

function elementEnterTranslateAnimation(...)
    local valueAnimatorClass = luajava.bindClass("android.animation.ValueAnimator")
    local params = {}
    params[0] = 0
    params[1] = mJavaBridge:dip2px(30)

    local foregroundAnim = valueAnimatorClass:ofInt(params)
    foregroundAnim:setDuration(400)
    local animatorUpdateListener =
        luajava.createProxy("android.animation.ValueAnimator$AnimatorUpdateListener", AnimatorUpdateListener)
    foregroundAnim:addUpdateListener(animatorUpdateListener)
    local interpolator = mJavaBridge:createNewInstance("android.view.animation.AccelerateDecelerateInterpolator", nil)
    foregroundAnim:setInterpolator(interpolator)
    foregroundAnim:start()
end

function transalteAnimation(view, params, duration)
    local objAnimatorClass = luajava.bindClass("android.animation.ObjectAnimator")
    local anim = objAnimatorClass:ofFloat(view, "translationX", params)
    local interpolator = mJavaBridge:createNewInstance("android.view.animation.AccelerateDecelerateInterpolator", nil)
    anim:setInterpolator(interpolator)
    anim:setDuration(duration)
    anim:start()
end

function alphaAnimation(view, params, duration)
    local objAnimatorClass = luajava.bindClass("android.animation.ObjectAnimator")

    local anim = objAnimatorClass:ofFloat(view, "alpha", params)
    anim:setDuration(duration)
    local interpolator = mJavaBridge:createNewInstance("android.view.animation.AccelerateDecelerateInterpolator", nil)
    anim:setInterpolator(interpolator)
    anim:start()
end

FullScoreUpdateListener = {}
function FullScoreUpdateListener.onAnimationUpdate(animation)
    local value = animation:getAnimatedValue()
    Rapid:getChild("tv_full_score"):getView():setTranslationX(fullScoreTickWidth - value)
end

ScoreUpdateListener = {}
function ScoreUpdateListener.onAnimationUpdate(animation)
    local value = animation:getAnimatedValue()
    updateScore(animationEnd - tonumber(value))
end

AnimatorUpdateListener = {}
function AnimatorUpdateListener.onAnimationUpdate(animation)
    local value = animation:getAnimatedValue()
    if isAnimationEnd then
        local scoreContainer = Rapid:getChild("score_container"):getView()
        local scoreTips = Rapid:getChild("score_tips"):getView()
        local oneShot = Rapid:getChild("oneshot"):getView()
        local offset = mJavaBridge:dip2px(30)
        scoreContainer:setTranslationX(value - offset)
        scoreTips:setTranslationX(value - offset)
        if currentScore ~= 100 then
            oneShot:setTranslationX(offset - value)
        end
    else
        foreground:setTranslationX(value - animationWidth)
    end
end
local repeatCount = 0
AnimationListener = {}
function AnimationListener.onAnimationStart(animation)
end

function AnimationListener.onAnimationRepeat(animation)
    repeatCount = repeatCount + 1
    if repeatCount == defaultRepeatCount then
        doScanBackgroundAlphaAnimation(tonumber(currentScore))
    end
end

function AnimationListener.onAnimationCancel(animation)
end

function AnimationListener.onAnimationEnd(animation)
    isAnimationEnd = true
    disappearAnimation()
    enterAnimation()
    updateStyle(currentScore)
    updateScore(currentScore)
end

function doScanBackgroundAlphaAnimation(score)
    if score >= 80 then
        return
    end
    if score >= 30 then
        Rapid:getChild("background"):setAttr("gradientdrawable", "startcolor:00ffffff,endcolor:4cf08c00,angle:90")
        Rapid:getChild("foreground"):setAttr("gradientdrawable", "startcolor:00ffffff,endcolor:4cf08c00,angle:0")
    else
        Rapid:getChild("background"):setAttr("gradientdrawable", "startcolor:4cf05046,endcolor:00ffffff,angle:270")
        Rapid:getChild("foreground"):setAttr("gradientdrawable", "startcolor:4cf05046,endcolor:00ffffff,angle:0")
    end
    local alphaParams = {}
    alphaParams[0] = 0
    alphaParams[1] = 1
    alphaAnimation(background, alphaParams, 200)
    alphaAnimation(foreground, alphaParams, 200)
end

function convertRubbishSize(size)
    return memoryUtils:formatSizeKorMorG(size)
end

function onScanFinish(totalSize)
    Rapid:Log(TAG, "onScanFinish " .. tostring(totalSize))
    totalRubbishSize = totalSize
    if totalRubbishSize == 0 then
        tvCanDeleteRubbish:setText("一键告别卡慢")
    else
        tvCanDeleteRubbish:setText("可清理垃圾" .. tostring(convertRubbishSize(totalRubbishSize)))
    end
end
local hasSetEndText = false
function onRubbishFound(pathList, suggestPathList, totalSize)
    totalRubbishSize = totalSize
    deletePathList:addAll(suggestPathList)
    if isAnimationEnd then
        if not hasSetEndText then
            tvCanDeleteRubbish:setText("可清理垃圾" .. tostring(convertRubbishSize(totalRubbishSize)))
            hasSetEndText = true
        end
        return
    end

    Rapid:Log(TAG, "onRubbishFound totalSize " .. tostring(totalSize) .. tostring(pathList))
    local rubbishPath = tostring(pathList:get(0))
    if rubbishPath ~= nil then
        local fileName = getFileName(rubbishPath)
        if fileName ~= nil then
            tvRubbish:setText("正在扫描:" .. fileName)
        end
    end
end

--获取文件名
function getFileName(filename)
    return string.match(filename, ".+/([^/]*%.%w+)$")
end

function resetCleanState(...)
    hasCleanRubbish = false
    updateStyle(currentScore)
end

function updateStyle(score)
    local tvStatus = Rapid:getChild("tv_status")
    local oneShotParser = Rapid:getChild("oneshot")
    local ivCleanImage = Rapid:getChild("iv_has_clean")
    tvStatus:setAttr("visibility", "visible")
    Rapid:getChild("tv_no_permission"):setAttr("visibility", "gone")
    tvCanDeleteRubbish:setVisibility(0)
    if hasCleanRubbish then
        ivCleanImage:setAttr("visibility", "visible")
        oneShotParser:setAttr("visibility", "gone")
        local totalDeleteSize = mJavaBridge:callModule("AppManager", "getDeleteRubbishSize")
        if totalDeleteSize == 0 then
            tvCanDeleteRubbish:setText("已经完成清理")
        else
            tvCanDeleteRubbish:setText(
                "今日累积清理垃圾" .. tostring(convertRubbishSize(mJavaBridge:callModule("AppManager", "getDeleteRubbishSize")))
            )
        end
    else
        ivCleanImage:setAttr("visibility", "gone")
        oneShotParser:setAttr("visibility", "visible")
    end
    oneShotParser:setAttr("text", "一键清理")
    if score == 100 then
        tvStatus:setAttr("text", "极致满分，请继续保持")
        ivCleanImage:setAttr("visibility", "visible")
        oneShotParser:setAttr("visibility", "gone")
        tvCanDeleteRubbish:setVisibility(8)
    elseif score >= 80 then
        if hasCleanRubbish then
            tvStatus:setAttr("text", "状态良好，请继续保持")
        else
            tvStatus:setAttr("text", "状态良好，可继续提升")
            oneShotParser:setAttr("text", "立即提升")
        end

        oneShotParser:setAttr("gradientdrawable", "startcolor:0080FF,endcolor:0080FF,cornerradius:16,angle:0")
    elseif score >= 31 then
        mJavaBridge:callModuleWithParams("AppManager", "getSdcardSpaceInfo", {onGetSdcardInfoSuccess})
        oneShotParser:setAttr("gradientdrawable", "startcolor:F08C00,endcolor:F08C00,cornerradius:16,angle:0")
    else
        checkNoPermissionStyle()
        oneShotParser:setAttr("gradientdrawable", "startcolor:F05046,endcolor:F05046,cornerradius:16,angle:0")
    end
end

function onGetSdcardInfoSuccess(availableSize, totalSize)
    local usedSize = totalSize - availableSize
    local percentage = usedSize / totalSize * 100
    local result = tostring(math.ceil(percentage)) .. "%"
    Rapid:getChild("tv_status"):setAttr("text", "占用手机空间" .. result)
end

function tryJumpToAccelerate(...)
    if mJavaBridge:hasPermissionGranted(9) then
        jumpToAccelerate()
        mJavaBridge:callModuleWithParams("AppManager", "deleteRubbishFile", {deletePathList, totalRubbishSize})
        lastcleanTime = mSystem:currentTimeMillis()
        mJavaBridge:delayRun(ONE_HOUR, resetCleanState)
    else
        requestPermission()
    end
end

function jumpToAccelerate(...)
    hasCleanRubbish = true
    local params = {}
    params["tmast"] = "tmast://optimize"
    params["extra"] =
        "pageId:data@scene,sourceSceneSlotId:data@slotid,status:-1,subPosition:-1,sourceModelType:data@modeltype"
    Rapid:execAction("tmastaction", params, params)
end

function checkNoPermissionStyle(...)
    local hasStoragePermission = mJavaBridge:hasPermissionGranted(9)
    if not hasStoragePermission then
        local noPermission = Rapid:getChild("tv_no_permission")
        noPermission:setAttr("visibility", "visible")
        noPermission:setAttr("text", "开启存储权限，\n一键清理手机内存")
        tvCanDeleteRubbish:setVisibility(8)
        Rapid:getChild("tv_status"):getView():setVisibility(8)
    end
end

function updateScore(score)
    if score == 100 then
        hundred:setAttr("visibility", "visible")
        ten:setAttr("visibility", "visible")
        one:setAttr("visibility", "visible")
        hundred:setAttr("image", scoreMap["1"])
        ten:setAttr("image", scoreMap["0"])
        one:setAttr("image", scoreMap["0"])
    elseif score >= 10 then
        hundred:setAttr("visibility", "gone")
        ten:setAttr("visibility", "visible")
        one:setAttr("visibility", "visible")
        local tenNum = math.modf(score / 10)
        local oneNum = math.fmod(score, 10)
        ten:setAttr("image", scoreMap[tostring(tenNum)])
        one:setAttr("image", scoreMap[tostring(oneNum)])
    else
        hundred:setAttr("visibility", "gone")
        ten:setAttr("visibility", "gone")
        one:setAttr("visibility", "visible")
        one:setAttr("image", scoreMap[tostring(score)])
    end
end

function initScoreMap(...)
    scoreMap["0"] = "personalcenter_num_0.png"
    scoreMap["1"] = "personalcenter_num_1.png"
    scoreMap["2"] = "personalcenter_num_2.png"
    scoreMap["3"] = "personalcenter_num_3.png"
    scoreMap["4"] = "personalcenter_num_4.png"
    scoreMap["5"] = "personalcenter_num_5.png"
    scoreMap["6"] = "personalcenter_num_6.png"
    scoreMap["7"] = "personalcenter_num_7.png"
    scoreMap["8"] = "personalcenter_num_8.png"
    scoreMap["9"] = "personalcenter_num_9.png"
end

IManagerScoreChangedListener = {}
function IManagerScoreChangedListener.onScoreChanged(score)
    if not mJavaBridge:hasPermissionGranted(9) then
        score = 30
    end
    Rapid:Log(TAG, "score " .. tostring(score))
    currentScore = score
    if isAnimationEnd then
        updateStyle(score)
        updateScore(score)
    end
end

OnScrollChangeListener = {}
function OnScrollChangeListener.onScrolled(recyclerView, dx, dy)
    totalX = totalX + dx
    local radio = totalX / totalRvScrollX
    local translationX = radio * totalIndicatorX
    indicator:setTranslationX(translationX)
end

function putMapData(map, key, value)
    if ((key ~= nil) and (value ~= nil)) then
        local var = mJavaBridge:create("var", value)
        map:put(key, var)
    end
end
