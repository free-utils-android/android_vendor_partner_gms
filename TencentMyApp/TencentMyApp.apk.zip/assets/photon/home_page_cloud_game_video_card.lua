local mPhotonView,mJavaBridge = ...

local cloudPlayBtn = nil
local videoView = nil
local IPlayerStateChangeListener = {}
local stateChangeListener

function main()
    cloudPlayBtn = mPhotonView:getParser():getChildView("cloud_play_button")
    cloudPlayBtn:getView():setText('秒玩')
    videoView = mPhotonView:getParser():getChildView("video_view")
    stateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IPlayerStateChangeListener)
    videoView:getView():registerIPlayerStateChangeListener(stateChangeListener)
    initMute()
end

function updateData()
    local appLabel = Rapid:getData('app_label','')
    local result = ''
    local labels = splitStr(appLabel)
    if labels ~= nil then
        local len = #labels
        for i = 1, len do
            -- 目前最多显示3个
            if i <= 3 then
                result = result .. labels[i] .. ' '
            end
        end
    end

    Rapid:getChild('tv_app_label'):setAttr('text', result)

    local title1 = Rapid:getData('operating_label_data_1_title', '')
    local title2 = Rapid:getData('operating_label_data_2_title', '')
    local title3 = Rapid:getData('operating_label_data_3_title', '')
    if title1 == '' and title2 == '' and title3 == '' then
        Rapid:getChild("rl_op"):setAttr("visibility","gone")
        Rapid:getChild("tv_app_name"):setAttr("margintop","11")
    else
        Rapid:getChild("rl_op"):setAttr("visibility","visible")
        Rapid:getChild("tv_app_name"):setAttr("margintop","5")
    end
end

function handleButton()
    Rapid:getChild("cloud_play_button"):setAttr("visibility","gone")
    Rapid:getChild("download_button"):setAttr("visibility","gone")
    Rapid:getChild("booking_button"):setAttr("visibility","gone")
    local cloud_game_jump_url = Rapid:getData('cloud_game_jump_url', '')
    if cloud_game_jump_url ~= '' then
        -- 防止上报buttonstatus
        Rapid:setData('ordered', '')
        Rapid:setData('app_model', '')
        Rapid:getChild("cloud_play_button"):setAttr("visibility","visible")
        return
    end
    local app_online = Rapid:getData('app_online', '')
    if app_online == '1' then
        Rapid:setData('ordered', '')
        Rapid:getChild("download_button"):setAttr("visibility","visible")
    else
        Rapid:getChild("booking_button"):setAttr("visibility","visible")
    end
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    updateMuteImage(mute)
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart(videoView)
    Rapid:getChild("iv_mute"):setAttr("visibility","visible")
    initMute()
end

function IPlayerStateChangeListener.onPlayContinue(videoView, currentPosition)
    Rapid:getChild("iv_mute"):setAttr("visibility","visible")
    initMute()
end

-- 视频播放进度回调
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    Rapid:setData("videoCurProgress", tostring(progress))
end

-- 视频暂停播放回调
function IPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
end

-- 视频停止播放回调
function IPlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
end

-- 视频完成播放回调
function IPlayerStateChangeListener.onPlayComplete(videoView)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
    if videoView ~= nil then
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
end

-- 播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
end

-- 设置静音
function setMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    if isMute then
        videoView:getView():setMuteToGlobal(false, true, true)
    else
        videoView:getView():setMuteToGlobal(true, true, true)
    end
    updateMuteImage(isMute)
end

-- 初始化静音按钮
function initMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    updateMuteImage(isMute)
end

-- 更新静音图标显示
function updateMuteImage(isMute)
    if isMute then
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end

-- 分割字符串，“1|2|3|”
function splitStr(str)
    if (str == nil or str == "") then
        return nil
    end

    local lastStart = 1
    local singleStr = nil
    local index = 1
    local res = {}
    for k = 1, string.len(str) do
        if string.sub(str, k, k) == '|' then
            if (lastStart < k) then
                singleStr = string.sub(str, lastStart, k - 1)
                res[index] = singleStr
                index = index + 1
            end
            lastStart = k + 1
        end
    end
    -- 不以 | 结尾，需要把最后的 type 计算进来
    if (lastStart <= string.len(str)) then
        singleStr = string.sub(str, lastStart, string.len(str))
        res[index] = singleStr
        index = index + 1
    end
    return res
end