local mPhotonView,mJavaBridge = ...
local TAG = "app_manager_center_entrance_card_lua_item"
local item_data_fuction_id
local item_data_red_num
local mRedDotView
local ENTRANCE_UPDATE = 0
local ENTRANCE_DOWNLOAD = 1
local isFromUpdateCallback
local mAppDownloadState
local DEFAULT_FUNCTION_ID = -1
local DEFAULT_RED_NUM = 0
local UI_EVENT_START_UPDATE_MANAGER_ACTIVITY = 1332
local DEBUG_LIFECYCLE = false
local DEBUG_REFRESH_UI = false
local DEBUG_CALLBACK = false

-- 应用下载监听
IAppDownloadStateListener = {}
function IAppDownloadStateListener.onState(state)
    Log(DEBUG_CALLBACK, "IAppDownloadStateListener.onState()")

    refreshDownloadRedDot()
end

-- 应用更新监听
function eventUpdateCallback(result_code, method, data)

   if method == "updateAppArea" then
       Log(DEBUG_CALLBACK, "eventUpdateCallback()")
       isFromUpdateCallback = true
       refreshUpdateRedDot()
   end
end

function loadFinish()
    Log(DEBUG_LIFECYCLE, "loadFinish()")

    mRedDotView = Rapid:getChild('red_num_tv')
end

function afterUpdateData()
    Log(DEBUG_LIFECYCLE, "afterUpdateData()")
    
    item_data_fuction_id = Rapid:getData("item_data_fuction_id")
    item_data_red_num    = Rapid:getData("item_data_red_num")

    -- 接口数据容错
    if item_data_function_id == nil then
       item_data_function_id = DEFAULT_FUNCTION_ID
    end

    if item_data_red_num == nil then
       item_data_red_num = DEFAULT_RED_NUM
    end

    isFromUpdateCallback = false

    -- 首次卡片加载小红点刷新
    if item_data_red_num > 99 then
        setOvalStyle()
        mRedDotView:getView():setText("99+")
    end

    registerAppUpdateListener()
    registerAppDownloadingListener()
end

function onResume()
    Log(DEBUG_LIFECYCLE, "onResume()")

    refreshDownloadRedDot()
    refreshUpdateRedDot()
end

function onDestory()
    Log(DEBUG_LIFECYCLE, "onDestory()")

    unregisterAppUpdateListener()
end

function itemClick()
    if ENTRANCE_UPDATE == tonumber(item_data_fuction_id) then
        mJavaBridge:sendEvent(UI_EVENT_START_UPDATE_MANAGER_ACTIVITY, nil, nil, nil)
    end
end

-- 下载管理入口注册应用下载监听
function registerAppDownloadingListener()
    if ENTRANCE_DOWNLOAD == tonumber(item_data_fuction_id) then

        mAppDownloadState = mJavaBridge:createAppDownloadState()

        local appDownloadStateListener = luajava.createProxy("com.tencent.assistant.component.IAppDownloadStateListener", IAppDownloadStateListener)
        if mAppDownloadState ~= nil and appDownloadStateListener ~= nil then
            Log(DEBUG_CALLBACK, "registerAppDownloadingListener() ,fuctionId:"..item_data_fuction_id)

            mAppDownloadState:registerAppDownloadStateListener(appDownloadStateListener)
        end
    end
end

-- 应用更新入口注册应用更新监听
function registerAppUpdateListener()  
    if ENTRANCE_UPDATE == tonumber(item_data_fuction_id) then
        Log(DEBUG_CALLBACK, "registerAppUpdateListener() ,fuctionId:"..item_data_fuction_id)

        mJavaBridge:registeAppUpdate(eventUpdateCallback)
    end
end

-- 应用更新入口注销应用更新监听
function unregisterAppUpdateListener()
    if ENTRANCE_UPDATE == tonumber(item_data_fuction_id) then
        Log(DEBUG_CALLBACK, "unregisterAppUpdateListener() ,fuctionId:"..item_data_fuction_id)

        mJavaBridge:unRegisteAppUpdate()
    end
end

-- 刷新下载管理小红点
function refreshDownloadRedDot()
    if ENTRANCE_DOWNLOAD == tonumber(item_data_fuction_id) then
       item_data_red_num = mJavaBridge:callModule('AppManager', 'getDownloadingApkCount')
       local item_pause_num = mJavaBridge:callModule('AppManager', 'getDownloadPauseApkCount')

       if item_data_red_num == nil then
          item_data_red_num = 0
       end

       if item_pause_num == nil then
          item_pause_num = 0
       end

       item_data_red_num = item_data_red_num + item_pause_num

       updateRedDotView()

       Log(DEBUG_REFRESH_UI, "refreshDownloadRedDot() ,fuctionId:"..item_data_fuction_id.." ,getDownloadingApkCount:"..item_data_red_num)
    end
end

-- 刷新应用更新小红点
function refreshUpdateRedDot()
    if ENTRANCE_UPDATE == tonumber(item_data_fuction_id) and isFromUpdateCallback and mJavaBridge:isAppUpdateRequesting() == false then
        item_data_red_num = mJavaBridge:getUpdateAppNums()
        if item_data_red_num == nil then
           item_data_red_num = 0
        end
        updateRedDotView()

        Log(DEBUG_REFRESH_UI, "refreshUpdateRedDot() ,fuctionId:"..item_data_fuction_id.." ,getUpdateAppNums:"..item_data_red_num)
    end   
end

-- 刷新小红点控件视图
function updateRedDotView()
    if item_data_red_num > 0 then
        if item_data_red_num <= 99 then
            setCircleStyle()
            mRedDotView:getView():setText(tostring(item_data_red_num))
        else
            setOvalStyle()
            mRedDotView:getView():setText("99+")
        end
        mRedDotView:getView():setVisibility(0)
    else
        mRedDotView:getView():setVisibility(8)
    end
end

-- 2位数以内小红点设置圆形样式
function setCircleStyle()
    mRedDotView:setAttr("padding", "0,0,0,0")
end

-- 三位数简写为99+，设置为椭圆形样式
function setOvalStyle()
    mRedDotView:setAttr("padding", "5,0,5,0")
end

function Log(debugType, args)
    if debugType then
        Rapid:Log(TAG, args)
    end
end