local mPhotonView, mJavaBridge = ...

local mBgSwitcher
local mMoreImgAnim = nil
local mSingleImgAnim = nil
local MAX_APP_NUM = 6
local mSwitchImageFirstRunnable

local mAppNum = 0 --app的个数
local mBgImageNum = 0  --背景图片的个数
local mAppIconList  --app的图标存放列表
local mBgImageList   --背景图片的存放列表
local VISIBLE = 0
local GONE = 8

local mFadeInAnim
local mFadeOutAnim

local ViewUtils

function init()
    mBgSwitcher = Rapid:getChild('bg_switcher')
    local imageSwitcher = mBgSwitcher:getView()
    mFadeInAnim = luajava.newInstance('android.view.animation.AlphaAnimation', 1, 1)
    mFadeInAnim:setDuration(1000)
    imageSwitcher:setInAnimation(mFadeInAnim)

    mFadeOutAnim = luajava.newInstance('android.view.animation.AlphaAnimation', 1, 0)
    mFadeOutAnim:setDuration(1000)
    imageSwitcher:setOutAnimation(mFadeOutAnim)

    mSwitchImageFirstRunnable = luajava.createProxy('java.lang.Runnable', Runnable)

    ViewUtils = luajava.bindClass('com.tencent.assistant.utils.ViewUtils')
end

Runnable = {}
function Runnable.run(...)
    local isFirstVisible = Rapid:getData('is_first_visible', 'false')
    if isFirstVisible ~= 'true' then
        return
    end

    switchBgImage()

    local scaleAnimation =
        luajava.newInstance('android.view.animation.ScaleAnimation', 1, 1.25, 1, 1.25, 1, 0.5, 1, 0.5)
    local listener = luajava.createProxy('android.view.animation.Animation$AnimationListener', AnimationListenerMore)
    scaleAnimation:setAnimationListener(listener)
    scaleAnimation:setDuration(2000)
    scaleAnimation:setRepeatCount(-1)
    scaleAnimation:setRepeatMode(1)
    scaleAnimation:setFillAfter(true)
    Rapid:getChild('anim_help'):getView():startAnimation(scaleAnimation)
    mMoreImgAnim = scaleAnimation
end

function fillValue()
    local sub_title = Rapid:getData('title')
    countImageNum()
    loadIconImage()
    mMoreImgAnim = nil
    mSingleImgAnim = nil
    onFirstVisibleChange()

    local width = ViewUtils:dip2px(1.5)
    Rapid:getChild('click_jump_btn'):setAttr('gradientdrawable', 'cornerradius:12,color:00ffffff,alpha:255,strokewidth:'..tostring(width)..',strokecolor:ffffff')
end

function onResume()
    local sub_title = Rapid:getData('title')
    mJavaBridge:Log("zyclua","--onResume--"  .. sub_title)    
end

--先计算图片资源
function countImageNum()
    mAppIconList = luajava.newInstance('java.util.ArrayList')
    mBgImageList = luajava.newInstance('java.util.ArrayList')

    local imageNum = tonumber(Rapid:getData('image_url_num', '0'))
    mJavaBridge:Log("zyclua","--countImageNum--" .. imageNum)
    if imageNum == 0 then
        mAppNum = 0 
        mBgImageNum = 0 
        Rapid:setData("bg_image_num", "0")
        return
    end

    for i = 1, imageNum do
        local itemData = mPhotonView:getParser():getBinder():get('item_data_' .. i)
        local urlType = itemData:get("url_type"):getString()
        mJavaBridge:Log("zyclua","--countImageNum-2-index:" .. i .. ", urlType:" .. urlType)
        local tempImageUrl = itemData:get("url"):getString()
        if urlType == "1" then
            mAppIconList:add(tempImageUrl)
        else
            mBgImageList:add(tempImageUrl)
            Rapid:setData("bg_image_url_"..tostring(mBgImageList:size()),tostring(tempImageUrl))
        end
    end
    mAppNum = mAppIconList:size()
    mBgImageNum = mBgImageList:size()
    Rapid:setData("bg_image_num", tostring(mBgImageNum))
    --最多展示6个App图标
    if mAppNum > MAX_APP_NUM then
        mAppNum = MAX_APP_NUM
    end
end

function loadIconImage()
    Rapid:getChild("app_icon_1"):setAttr("visibility", "gone")
    Rapid:getChild("app_icon_2"):setAttr("visibility", "gone")
    Rapid:getChild("app_icon_3"):setAttr("visibility", "gone")
    Rapid:getChild("app_icon_4"):setAttr("visibility", "gone")
    Rapid:getChild("app_icon_5"):setAttr("visibility", "gone")
    Rapid:getChild("app_icon_6"):setAttr("visibility", "gone")
    Rapid:getChild("app_name"):setAttr("visibility", "gone")

    if mAppNum == 0 then
        Rapid:getChild("click_jump_btn"):setAttr("visibility", "visible")
        switchButton(false)
    elseif mAppNum == 1 then
        Rapid:getChild("click_jump_btn"):setAttr("visibility", "gone")

        ----这里由于download_button的appmodel有问题，导致点击跳转失效
        switchButton(true)
        Rapid:getChild("app_icon_1"):setAttr("visibility", "visible")
        Rapid:getChild("app_name"):setAttr("visibility", "visible")
        fillAppNameAndIcon()
    elseif mAppNum >= 2 then
        Rapid:getChild("click_jump_btn"):setAttr("visibility", "visible")
        switchButton(false)
        fillIcons(mAppNum)
    end

    if tonumber(Rapid:getData('style_type')) ~= 1 then
        Rapid:getChild("click_jump_btn"):setAttr("visibility", "gone")
        switchButton(false)
    end
end

-- 下载按钮和预约按钮切换逻辑
function switchButton(visiblity)
    if not visiblity then
        Rapid:getChild("download_button"):setAttr("visibility", "gone")
        pcall(setViewVisible,"booking_button","gone")
        return
    end

    local showBookingButton = Rapid:getData('show_booking_button', '0')
    if showBookingButton ~= '1' then
        Rapid:getChild("download_button"):setAttr("visibility", "visible")
        pcall(setViewVisible,"booking_button","gone")
    else
        Rapid:getChild("download_button"):setAttr("visibility", "gone")
        pcall(setViewVisible,"booking_button","visible")
    end
end

function setViewVisible(id,visibility)
    if Rapid:getChild(id) == nil then
        return
    end
    Rapid:getChild(id):setAttr("visibility", visibility)
end

function fillAppNameAndIcon()
    mPhotonView:getParser():getBinder():update("app_url_1", mAppIconList:get(0))
end

function fillIcons(iconNum)
    local MIN_COUNT = 2
    if iconNum < MIN_COUNT then
       return
    end
    for i = MIN_COUNT - 1, iconNum do
        Rapid:getChild('app_icon_' .. i):getView():setVisibility(VISIBLE)
        Rapid:getChild('app_icon_' .. i):getView():updateImageView(mAppIconList:get(i - MIN_COUNT + 1))
    end

end

function loadDefauleBgImage()
    local bgImageNum = tonumber(Rapid:getData('bg_image_num', '0'))
    if bgImageNum <= 0 then
        mBgSwitcher:setAttr('visibility', 'gone')
        return
    else
        mBgSwitcher:setAttr('visibility', 'visible')
    end

    mBgSwitcher:getView():setInAnimation(nil)
    mBgSwitcher:getView():setOutAnimation(nil)
    local url = Rapid:getData('bg_image_url_1')
    mBgSwitcher:setAttr('url', url)
end

function getIndex()
    local index = Rapid:getData('index')
    return tostring(index)
end

function onFirstVisibleChange()
    local bgImageNum = tonumber(Rapid:getData('bg_image_num', '0'))
    if bgImageNum <= 0 then
        return
    end

    local isFirstVisible = Rapid:getData('is_first_visible', 'false')
    local isAnimRunning = Rapid:getData('is_anim_running', 'false')
    if isFirstVisible == 'true' and isAnimRunning == 'true' then
        return
    end

    loadDefauleBgImage()
    cancelAnims()
    local switcher = Rapid:getChild('bg_switcher')
    if switcher ~= nil then
        local switcherView = switcher:getView()
        if switcherView ~= nil then
            switcherView:removeCallbacks(mSwitchImageFirstRunnable)
        end
    end
    if isFirstVisible == 'true' then
        if bgImageNum <= 1 then
            doSingleImgAnim()
        else
            doMoreImgSwitch()
        end
    end
end

function cancelAnims()
    if mMoreImgAnim ~= nil then
        mMoreImgAnim:cancel()
    end
    if mSingleImgAnim ~= nil then
        mSingleImgAnim:cancel()
    end
    Rapid:setData('is_anim_running', 'false')
end

function doSingleImgAnim()
    local scaleAnimation =
        luajava.newInstance('android.view.animation.ScaleAnimation', 1, 1.25, 1, 1.25, 1, 0.5, 1, 0.5)
    local listener = luajava.createProxy('android.view.animation.Animation$AnimationListener', AnimationListenerSingle)
    scaleAnimation:setAnimationListener(listener)
    scaleAnimation:setDuration(7000)
    scaleAnimation:setRepeatCount(-1)
    scaleAnimation:setRepeatMode(2)
    scaleAnimation:setFillAfter(true)
    mBgSwitcher:getView():startAnimation(scaleAnimation)
    mSingleImgAnim = scaleAnimation
end

function doMoreImgSwitch()
    local bgImageNum = tonumber(Rapid:getData('bg_image_num', '0'))
    if bgImageNum <= 0 then
        return
    end

    Rapid:setData('bg_image_current_index', tostring(bgImageNum + 1))

    local switcher = Rapid:getChild('bg_switcher')
    if switcher ~= nil then
        local switcherView = switcher:getView()
        if switcherView ~= nil then
            switcherView:removeCallbacks(mSwitchImageFirstRunnable)
            switcherView:postDelayed(mSwitchImageFirstRunnable, 1000)
        end
    end
end

AnimationListenerMore = {}
function AnimationListenerMore.onAnimationStart(animation)
    Rapid:setData('is_anim_running', 'true')
end

function AnimationListenerMore.onAnimationRepeat(animation)
    local isFirstVisible = Rapid:getData('is_first_visible', 'false')
    if isFirstVisible == 'true' then
        switchBgImage()
    end
end

function AnimationListenerMore.onAnimationEnd(animation)
    Rapid:setData('is_anim_running', 'false')
end

function switchBgImage()
    -- 修改之前，需要调整view的位置，防止动画失效
    local switchView = mBgSwitcher:getView()
    local nextView = switchView:getNextView()
    local nextIndex = switchView:indexOfChild(nextView)
    if nextIndex > 0 then
        switchView:removeView(nextView)
        switchView:addView(nextView, 0)
    end

    switchView:setInAnimation(mFadeInAnim)
    switchView:setOutAnimation(mFadeOutAnim)

    local currentIndex = getNextBgImageIndex() + 1
    local url = Rapid:getData('bg_image_url_' .. tostring(currentIndex))
    mBgSwitcher:setAttr('url', url)
end

function getNextBgImageIndex()
    local currentIndex = tonumber(Rapid:getData('bg_image_current_index'))
    local bgImageNum = tonumber(Rapid:getData('bg_image_num', '0'))
    if bgImageNum <= 0 then
        return 1
    end

    local result = currentIndex % bgImageNum
    currentIndex = currentIndex + 1
    Rapid:setData('bg_image_current_index', tostring(currentIndex))
    return result
end

AnimationListenerSingle = {}
function AnimationListenerSingle.onAnimationStart(animation)
    Rapid:setData('is_anim_running', 'true')
end

function AnimationListenerSingle.onAnimationRepeat(animation)
end

function AnimationListenerSingle.onAnimationEnd(animation)
    Rapid:setData('is_anim_running', 'false')
end
