local mPhotonView,mJavaBridge = ...
local selectedStatus = 1
function normal_click1()
   local selected = mPhotonView:getParser():getChildView("goroup_selector_checked_1")
   local unselected = mPhotonView:getParser():getChildView("goroup_selector_unchecked_1")

   local op = "0"
   if selected:getView():getVisibility() == 0 then
      selected:getView():setVisibility(8)
      unselected:getView():setVisibility(0)
      local fullStopButtonBg = "color:661c81ff,strokecolor:FF0000,cornerradius:45,shape:0"
      Rapid:getChild("clean_button"):setAttr("backgroundgradientdrawable",tostring(fullStopButtonBg))
      selectedStatus = 0
   else
      selected:getView():setVisibility(0)
      unselected:getView():setVisibility(8)
      local fullStopButtonBg = "color:1c81ff,strokecolor:FF0000,cornerradius:45,shape:0"
      Rapid:getChild("clean_button"):setAttr("backgroundgradientdrawable",tostring(fullStopButtonBg))
      selectedStatus = 1
   end

   local cleanType  = mPhotonView:getParser():getBinder():get("clean_type")
   mJavaBridge:switchWxCleanModel(5,cleanType)

end

function cleanRubbish()
   if selectedStatus == 1 then
      local cleanType  = mPhotonView:getParser():getBinder():get("clean_type")
      mJavaBridge:switchWxCleanModel(2,cleanType)
   end
end

function updateValue()
   local rubbishSize = mPhotonView:getParser():getBinder():get("selectedRubbishSizeStr")
   rubbishSize = "放心清理（"..tostring(rubbishSize).."）"
   mPhotonView:getParser():getChildView("clean_button"):getView():setText(rubbishSize)

   local hideDelete = mPhotonView:getParser():getBinder():get("hideSelectedRubbishSizeDelete")

   local selected = mPhotonView:getParser():getChildView("goroup_selector_checked_1")
   local unselected = mPhotonView:getParser():getChildView("goroup_selector_unchecked_1")

   if hideDelete == '1' then
      -- body
      selected:getView():setVisibility(8)
      unselected:getView():setVisibility(0)
      local fullStopButtonBg = "color:661c81ff,strokecolor:FF0000,cornerradius:45,shape:0"
      Rapid:getChild("clean_button"):setAttr("backgroundgradientdrawable",tostring(fullStopButtonBg))
      selectedStatus = 0
   end

end
