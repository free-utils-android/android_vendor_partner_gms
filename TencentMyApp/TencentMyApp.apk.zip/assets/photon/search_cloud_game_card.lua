local mPhotonView,mJavaBridge = ...

function prepareTagText()
    local screenWidth = mPhotonView:getParser():getScreenWidth()
    local appNameMaxW = screenWidth - mJavaBridge:dip2px(80+80+8)
    local tagText = Rapid:getData('tag_text')
    if( tagText ~= nil and tagText ~= "" ) then
        Rapid:getChild('app_tag'):setAttr('visibility', "visible")

        local paint = Rapid:getChild('app_tag'):getView():getPaint()
        local tagWidth = paint:measureText(tagText) + mJavaBridge:dip2px(12)
        local tagMaxWidth
        if tagWidth >= mJavaBridge:dip2px(60) then
            tagMaxWidth = mJavaBridge:dip2px(60)
        else
            tagMaxWidth = tagWidth
        end
        Rapid:getChild('app_tag'):setAttr('maxwidth', mJavaBridge:px2dip(tagMaxWidth))
        Rapid:getChild('app_name'):setAttr('maxwidth', mJavaBridge:px2dip(appNameMaxW - tagMaxWidth))
    else
        Rapid:getChild('app_tag'):setAttr('visibility', "gone")
        Rapid:getChild('app_name'):setAttr('maxwidth', mJavaBridge:px2dip(appNameMaxW))
    end
end