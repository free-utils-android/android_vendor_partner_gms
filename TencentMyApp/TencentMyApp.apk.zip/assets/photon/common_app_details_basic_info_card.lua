
local TAG = "common_app_details_basic_info_card"
local mPhotonView, mJavaBridge = ...



local hundred = "百"
local thousand = "千"
local tenThousand = "万"
local oneMillion = "百万"
local tenMillion = "千万"
local oneHundredMillion = "亿"
local trillion = "兆"


function initValue()
    Rapid:Log(TAG,"start initValue")


    local appScoreIcon = Rapid:getData('app_score_icon')
    Rapid:Log(TAG," appScoreIcon : " .. tostring(appScoreIcon))
    

    local cardBgColor = Rapid:getData('cardBgColor')
    Rapid:Log(TAG," cardBgColor : " .. tostring(cardBgColor))
    if(cardBgColor ~= nil and tostring(cardBgColor) ~= '')then
        Rapid:getChild('rl_bottom_view'):setAttr('gradientdrawable',"cornerradius:8,color:" .. tostring(cardBgColor) .. ",alpha:255,strokewidth:0,strokecolor:009688")
    end


    Rapid:setData("app_score_desc",tostring(FormatUnits(Rapid:getData("app_score_desc",'0人评分')) .. "人评分"))
    

    Rapid:setData("app_score",string.gsub(Rapid:getData('app_score'),"分",""))
    local downloadCount =  tostring(Rapid:getData('app_download_count',""))
    Rapid:setData("app_download_count",string.gsub(Rapid:getData('app_download_count'),"亿",""))
    Rapid:setData("app_download_count",string.gsub(Rapid:getData('app_download_count'),"万",""))
    Rapid:setData("app_download_count",string.gsub(Rapid:getData('app_download_count'),"次",""))
    Rapid:setData("app_download_count",string.gsub(Rapid:getData('app_download_count'),"下载",""))

    
    if(string.match(downloadCount,"亿") ~= nil)then
        Rapid:getChild("tv_download_count_unit"):setAttr('text',"亿")
        else if(string.match(downloadCount,"万") ~= nil)then
            Rapid:getChild("tv_download_count_unit"):setAttr('text',"万")
        end
    end

    
    
    local colorBgList = {'1a00f872','1fffd000','0fff296c','140080ff'}
    local colorList = {'ff1fb564','fff26700','ffee3875','ff0080ff'}
    


    -- 徽章数
    local badgeNum = 2
    -- 标签书
    local tagNum = 4
    -- 限定最大字数
    local maxems = 13

    local colorModeValue = Rapid:getData('colorMode')

    Rapid:Log(TAG,"colorModeValue:" .. tostring(colorModeValue))

    local reportSubPosition = 0




    for i = 0, badgeNum - 1 do
        local index  = i + 1
        local appBadgeText = Rapid:getData('app_badge_text_' .. index)

        

        Rapid:Log(TAG,'app_badge_text_' .. index .. tostring(appBadgeText))

        if (appBadgeText == nil or tostring(appBadgeText) == '') then
            Rapid:getChild('tv_app_badge_name_' .. index):setAttr('visibility','gone')
        else
            reportSubPosition = index
            Rapid:setData('bgSubPosition_'..index ,tostring(reportSubPosition))
            Rapid:getChild('tv_app_badge_name_' .. index):setAttr('visibility','visible')
            maxems = maxems - 3
            Rapid:getChild('tv_app_name'):setAttr('maxems',tostring(maxems))

            
            if(index == 1)then
                Rapid:getChild('tv_app_badge_name_1'):setAttr('marginright','0')
            else 
                 Rapid:getChild('tv_app_badge_name_1'):setAttr('marginright','8')
                 Rapid:getChild('tv_app_badge_name_2'):setAttr('marginright','0')
            end

            if (colorModeValue == 'default') then
                if(appBadgeText == '王卡免流')then
                    Rapid:getChild('tv_app_badge_name_' .. index):setAttr('gradientdrawable','cornerradius:4,color:EBEBEB,alpha:255,strokewidth:0,strokecolor:00000000')
                    Rapid:getChild('tv_app_badge_name_' .. index):setAttr('textcolor','525252')
                    else
                        Rapid:getChild('tv_app_badge_name_' .. index):setAttr('textcolor','FFFFFF')
                        Rapid:getChild('tv_app_badge_name_' .. index):getView():setOnClickListener(nil)
                end
            else
                if(appBadgeText == '王卡免流')then
                    Rapid:getChild('tv_app_badge_name_' .. index):setAttr('gradientdrawable','cornerradius:4,color:424751,alpha:255,strokewidth:0,strokecolor:00000000')
                    else
                        Rapid:getChild('tv_app_badge_name_' .. index):getView():setOnClickListener(nil)
                end
                    Rapid:getChild('tv_app_badge_name_' .. index):setAttr('textcolor','FFFFFF')
                   
            end
        end
    end


    for i = 0, tagNum - 1 do
        local index  = i + 1
        
        local appTagText = Rapid:getData('app_tag_text_' .. index)
        local appTagTextBgColor = Rapid:getData('app_tag_text_bg_color_' .. index, '1A00F872')

        Rapid:Log(TAG,'app_tag_text_' .. index .. ' : '.. tostring(appTagText))
        

        if (appTagText == nil or tostring(appTagText) == '') then
            Rapid:getChild('tv_tag_' .. index):setAttr('visibility','gone')
        else
            reportSubPosition = reportSubPosition + 1
            Rapid:setData('tagSubPosition_'..index ,tostring(reportSubPosition))
            Rapid:getChild('tv_tag_' .. index):setAttr('visibility','invisible')

            local appTagTextBgColorValue
            if (colorModeValue == 'default') then
                appTagTextBgColor = tostring(colorBgList[index])
                appTagTextBgColorValue = 'cornerradius:10,color:' .. appTagTextBgColor .. ',alpha:255,strokewidth:0,strokecolor:00000000'
                Rapid:getChild('tv_tag_' .. index):setAttr('textcolor', colorList[index])
            else
                appTagTextBgColor = '73ffffff'
                appTagTextBgColorValue = 'cornerradius:10,color:00000000,alpha:255,strokewidth:2,strokecolor:4dffffff'
                Rapid:getChild('tv_tag_' .. index):setAttr('textcolor', appTagTextBgColor)
            end
            Rapid:getChild('tv_tag_' .. index):setAttr('gradientdrawable', appTagTextBgColorValue)
        end

    end

    mJavaBridge:postRun(checkTagUi)


    Rapid:Log(TAG,"end initValue")

end

function checkTagUi( ... )
    local width =  Rapid:getChild('fl_tags'):getView():getWidth()
    if(width ~= nil)then
          -- 标签除了第一个超过范围就隐藏
       for i = 1, 4 do
        Rapid:Log(TAG,'tv_tag_' .. tostring(i))
        local childWidth = Rapid:getChild('tv_tag_' .. tostring(i)):getView():getWidth()
        if(childWidth ~= nil)then
            width = tonumber(width) - tonumber(childWidth)
            Rapid:Log(TAG," Width=" .. tostring(Width) .. " childWidth=" .. tostring(childWidth))
            if(width < 120 and i ~= 1)then
                Rapid:getChild('tv_tag_' .. tostring(i)):setAttr('visibility','gone')
            else if(childWidth > 0)then
                Rapid:getChild('tv_tag_' .. tostring(i)):setAttr('visibility','visible')
            end
            end
    end
    end
    end
end






function FormatUnits(num, gap, unitsStr)    
    if type(num) == "string" then
        num = GetStrNumber(num)        
    end    

    if num == nil then
        return
    end

    local integer = 0
    local part = 0
    local unitsFunc = function(num, gap, unitsStr)        
        integer = math.floor(num / gap)
        part = math.floor((num % gap) / (gap / 10))
        if part == 0 then
            return integer .. unitsStr
        else
            return integer .. "." .. part .. unitsStr
        end        
    end

    if num >= 100000000 then        
        return unitsFunc(num, 100000000, oneHundredMillion)

    elseif num >= 10000 then       
        return unitsFunc(num, 10000, tenThousand)        
    else
        return tostring(math.floor(num))
    end    
end

function GetStrNumber(str)
    local _, _, num = string.find(str, "(%d+)")
    return num ~= nil and tonumber(num) or nil
end
