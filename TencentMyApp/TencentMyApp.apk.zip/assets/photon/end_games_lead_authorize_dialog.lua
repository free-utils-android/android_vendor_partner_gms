local mPhotonView, mJavaBridge = ...

local TAG = "lua_authorize_dialog"

local mCallbackObj = nil
local mIndex = 0

function closeDialog()
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:dismiss()
    end
end

function tryAllAuthorize()
    mJavaBridge:Log(TAG, "tryAllAuthorize")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "one_key")
    dialogSelf:notifyEvent("ON_ONE_KEY_SELECTED")
    closeDialog()
end

function clickDetail()
    mJavaBridge:Log(TAG, "clickDetail")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "detail")
    dialogSelf:notifyEvent("ON_DETAIL_SELECTED")
    closeDialog()
end

function clickCancel()
    mJavaBridge:Log(TAG, "clickCancel")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "cancel")
    dialogSelf:notifyEvent("ON_CANCEL")
    closeDialog()
end

function clickClear()
    mJavaBridge:Log(TAG, "clickClear")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "clear")
    dialogSelf:notifyEvent("ON_CLEAR_AUTHORIZE")
    closeDialog()
end