local mPhotonView, mJavaBridge = ...

function init( ... )
    local recyclerView = Rapid:getChild("recyclerview"):getView()
    local viewNmae = "endgames_histor_card_empty_item.xml"
    local dataList = luajava.newInstance("java.util.ArrayList")
    local viewNameList = luajava.newInstance("java.util.ArrayList")
    for i = 1, 3 do
        dataList:add(luajava.newInstance("java.util.HashMap"))
        viewNameList:add(viewNmae)
    end
    recyclerView:updateData(dataList, viewNameList, true)
end