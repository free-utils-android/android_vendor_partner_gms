local mPhotonView,mJavaBridge = ...

function main()
	local binder = mPhotonView:getParser():getBinder()
	local index = -1
	
	if( binder == nil)
	then
		return
	end
	
	index = binder:get('index')
	if( index == nil )
	then
		index= -1
	end
	
	binder:update('show_slotid', "1_" .. index)
	binder:update('title_slotid', "1_" ..index)
	binder:update('button_slotid', "1_" ..index)
	binder:update('image_slotid', "1_" ..index)
end