local mPhotonView,mJavaBridge = ...

local mRecyclerView = nil
local mPageContext = nil
local mHasNext = "0"
local mAppID = nil
local mRequsting = false
local mAnchorPoint = -1
local mPkgName = nil
local mWebUrl = ""
local mActivityContext = nil
local mRecyclerScrollTotalDy = 0

function main()
	mActivityContext =  mPhotonView:getView():getContext()
	local listView = mPhotonView:getParser():getBinder():get("first_view_name_list")
	local listData = mPhotonView:getParser():getBinder():get("first_data_list")
	local scene = mPhotonView:getParser():getBinder():get("scene")
	local sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
	local sourcesceneslotid = mPhotonView:getParser():getBinder():get("sourcesceneslotid")
	local sourcemodeltype = mPhotonView:getParser():getBinder():get("sourcemodeltype")
	local extradata = mPhotonView:getParser():getBinder():get("extradata")
	local commonData = nil

	if( listView == nil or listData == nil ) then
		return
	end

	initControl()

	local count = listData:size() - 1

	for i=0, count do
		if( listView:get(i) == "app_details_subject_page_context" ) then
			commonData = listData:get(i)

			listView:remove(i)
			listData:remove(i)
			break
		end
	end

	count = listData:size() - 1

	if( commonData ~= nil ) then
		if(commonData:get("pageContext") ~= nil)then
			mPageContext = commonData:get("pageContext"):getString()
		end

		if(commonData:get("hasNext") ~= nil)then
			mHasNext = commonData:get("hasNext"):getString()
		end

		if(commonData:get("appId") ~= nil)then
			mAppID = commonData:get("appId"):getString()
		end

		if(commonData:get("anchorPoint") ~= nil)then
			mAnchorPoint = commonData:get("anchorPoint"):getInt()
		end

		if(commonData:get("packageName") ~= nil)then
			mPkgName = commonData:get("packageName"):getString()
		end

		if(commonData:get("webUrl") ~= nil)then
			mWebUrl = commonData:get("webUrl"):getString()
		end

	end

	if( mWebUrl ~= "" )then
		loadWebView(mWebUrl)
		return
	end

	for i=0, count do
		local data = listData:get(i)
		data:put("scene", mJavaBridge:create("var", scene))
		data:put("sourcescene", mJavaBridge:create("var", sourcescene))
		data:put("sourcesceneslotid", mJavaBridge:create("var", sourcesceneslotid))
		data:put("sourcemodeltype", mJavaBridge:create("var", sourcemodeltype))
		data:put("extradata", mJavaBridge:create("var", extradata))
		data:put("activityContext",mJavaBridge:create("var",mActivityContext))
		data:put("parent_recyclerview", mJavaBridge:create("var", mRecyclerView))
		if mAppID ~= nil then
			data:put("appid", mJavaBridge:create("var", mAppID))
			data:put("appId",mJavaBridge:create("var",mAppID))
		end
	end

	if( mHasNext == "1" ) then
		mRecyclerView:getView():showFooter()
	else
		mRecyclerView:getView():hideFooter()
	end

	mRecyclerView:getView():updateData(listData, listView, false)
end

function loadWebView(url)
	local stub = mPhotonView:getParser():getChildView("webview_stub")
	stub:getParser():update("visibility", "visible")


	if mJavaBridge:isFlatStyleBar() then
		local statusHeight = mJavaBridge:getStatusBarHeight()
		mPhotonView:getParser():getChildView('status_bar_margin'):getParser():update("height",mJavaBridge:px2dip(statusHeight))
	end
	local data = {}
	data["web_url"] = 	url
	local webview = mJavaBridge:addView("native_home_tab_subject_page_webview.xml","web_container",nil,nil,data)
end

function initControl()
	mRecyclerView = mPhotonView:getParser():getChildView("main_recycler")
	mRecyclerView:getView():setFooter("recyclerview_common_bottom_loading_view", nil)

	local bottomListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrollBottomListener', RecyclerBottomListener)
	local topListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrollTopListener', RecyclerTopListener)
	local scrollListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrolledListener', RecyclerScrolledListener)

	mRecyclerView:getView():setScrollBottomListener(bottomListener)
	mRecyclerView:getView():setScrollTopListener(topListener)
	mRecyclerView:getView():setScrolledListener(scrollListener)
end

function loadNext()
	local params = {}

	params["pageContext"] = mPageContext
	params["appId"] = mAppID

	mRequsting = true

	mJavaBridge:request(4, params, reqListener)
end

function onAnchorCard()
	if(  mRecyclerView == nil ) then
		return
	end

	if( mAnchorPoint == nil or mAnchorPoint == -1 ) then
		return
	end

	mRecyclerView:getView():getLayoutManager():scrollToPositionWithOffset(mAnchorPoint, mJavaBridge:dip2px(59))
end

function reqListener(succ, listView, listData)
	local commonData = nil
	local scene = mPhotonView:getParser():getBinder():get("scene")
	local sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
	local sourcesceneslotid = mPhotonView:getParser():getBinder():get("sourcesceneslotid")
	local sourcemodeltype = mPhotonView:getParser():getBinder():get("sourcemodeltype")
	local extradata = mPhotonView:getParser():getBinder():get("extradata")

	mRequsting = false

	if( succ == false or listView == nil or listData == nil ) then
		mRecyclerView:getView():hideFooter()
		return
	end

	local count = listData:size() - 1

	for i=0, count do
		if( listView:get(i) == "app_details_subject_page_context" ) then
			commonData = listData:get(i)

			listView:remove(i)
			listData:remove(i)
			break
		end
	end

	count = listData:size() - 1

	for i=0, count do
		local data = listData:get(i)
		data:put("scene", mJavaBridge:create("var", scene))
		data:put("sourcescene", mJavaBridge:create("var", sourcescene))
		data:put("sourcesceneslotid", mJavaBridge:create("var", sourcesceneslotid))
		data:put("sourcemodeltype", mJavaBridge:create("var", sourcemodeltype))
		data:put("extradata", mJavaBridge:create("var", extradata))
		data:put("activityContext",mJavaBridge:create("var",mActivityContext))
		data:put("parent_recyclerview", mJavaBridge:create("var", mRecyclerView))
		if mAppID ~= nil then
			data:put("appid", mJavaBridge:create("var", mAppID))
			data:put("appId",mJavaBridge:create("var",mAppID))
		end
	end

	if( commonData ~= nil ) then
		if( commonData:get("pageContext") ~= nil ) then
			mPageContext = commonData:get("pageContext"):getString()
		end

		if( commonData:get("hasNext") ~= nil ) then
			mHasNext = commonData:get("hasNext"):getString()
		else
			mHasNext = "0"
		end

	end

	if( mHasNext == "0" ) then
		mRecyclerView:getView():hideFooter()
	else
		mRecyclerView:getView():showFooter()
	end

	mRecyclerView:getView():updateData(listData, listView, false)
end

RecyclerBottomListener = {}
function RecyclerBottomListener.onScrollToBottom()

	if( mHasNext == nil or mHasNext ~= "1" or mRequsting ) then
		return
	end

	loadNext()
end


RecyclerTopListener = {}
function RecyclerTopListener.onScrollToTop()
	mRecyclerScrollTotalDy = 0
end

RecyclerScrolledListener = {}
function RecyclerScrolledListener.onScrolled(recyclerView, dx, dy)
	mRecyclerScrollTotalDy = mRecyclerScrollTotalDy + dy
	mPhotonView:getParser():getListener():notify("on_page_scrolling","0," .. dy .. ",0," .. mRecyclerScrollTotalDy)
end
