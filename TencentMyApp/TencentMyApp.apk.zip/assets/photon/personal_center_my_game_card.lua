local mPhotonView, mJavaBridge = ...

local TAG = "lua_personal_center_my_game_card"

local MAX_BOOK_APP_NAME_LENGTH = 14

local mRecyclerView
local mActionListener = {}

-- 检查是否有nil
local function checkNil(...)
    local args = {...}
    for i = 1, select("#", ...) do
        if args[i] == nil then
            return true
        end
    end
    return false
end

local function getPositionString(position)
    return string.format("%03d", position)
end

local function getValue(start, key, def)
    if start == nil then
        start = ''
    end
    if key == nil then
        key = ''
    end
    return Rapid:getData(tostring(start)..tostring(key), def)
end

local function getItemValue(index, key, def)
    if index == nil or key == nil then
        return def
    end
    return getValue('item_data_'..tostring(index)..'_', tostring(key), def)
end

local function queryData(start, params)
    local data = {}
    if type(params) == 'table' then
        for k, v in pairs(params) do
            data[k] = getValue(start, k, v)
        end
    end
    return data
end

local function queryItemData(index, params)
    if index == nil or params == nil then
        return {}
    end
    return queryData('item_data_'..tostring(index)..'_', params)
end

-- 填充数据
local function fillData(data, params, keys)
    if type(data) ~= 'table' or type(params) ~= 'table' then
        return
    end
    if keys == nil then
        for k, v in pairs(params) do
            data[k] = v
        end
    elseif type(keys) == 'table' then
        for i, key in pairs(keys) do
            if type(key) == 'string' then
                data[key] = params[key]
            end
        end
    end
end

local function updateGridlayoutmanager(hasFourApp)
    if checkNil(mRecyclerView, hasFourApp) then
        return
    end
    if tostring(hasFourApp) == 'true' then
        mRecyclerView:getParser():update('layoutmanager', 'gridlayoutmanager,4')
    else
        mRecyclerView:getParser():update('layoutmanager', 'gridlayoutmanager,3')
    end
end

local function getTmastAction(type)
    -- 我的福利
    if type == '1' then
        return 'logintmastaction'
    end
    return 'tmastaction'
end

-- 气泡、红点、三角显示
local function updataBubbleVisible(itemData, show)
    if show then
        itemData['item_red_dot_visible'] = 'visible'
        itemData['item_subscript_visible'] = 'visible'
        return
    end
    itemData['item_red_dot_visible'] = 'invisible'
    itemData['item_subscript_visible'] = 'invisible'
end

-- 获取预约APP信息
function getBookAppInfo()
    return mJavaBridge:callModuleWithParams("AppManager", "getBookAppInfo", {MAX_BOOK_APP_NAME_LENGTH})
end

local function onBookingItemData(itemData)
    -- 预约
    local bookingAppInfo = getBookAppInfo()
    if bookingAppInfo == nil or bookingAppInfo['item_count'] == nil or tonumber(bookingAppInfo['item_count']) <= 0 then
        Rapid:setData('bubble_visible', 'gone')
        return
    end
    Rapid:setData('bubble_visible', 'visible')
    updataBubbleVisible(itemData, true)
    -- 预约红点数量
    local bookingAppNums = tonumber(bookingAppInfo['item_count'])
    itemData['uni_is_redpoint'] = '2'
    itemData['redpoint_num'] = tostring(bookingAppNums)
    -- 预约红点文案显示
    if bookingAppNums > 99 then
        itemData['item_red_dot_num'] = '99+'
    else
        itemData['item_red_dot_num'] = bookingAppNums
    end
    -- 气泡文案显示
    if bookingAppNums == 1  then
        Rapid:setData('bubble_name', '预约的《'..tostring(bookingAppInfo['app_name_1'])..'》可下载')
    else
        Rapid:setData('bubble_name', tostring(itemData['item_red_dot_num'])..'款预约的游戏可下载')
    end
    -- 预约气泡icon列表
    for i = 1, 3 do
        if i <= bookingAppNums then
            Rapid:setData('icon_app_'..i..'_url', bookingAppInfo['app_icon_url_'..tostring(i)])
            Rapid:setData('icon_app_'..i..'_visible', 'visible')
        else
            Rapid:setData('icon_app_'..i..'_visible', 'gone')
        end
    end
    -- 跳转链接
    Rapid:setData('bubble_jump_index', itemData['item_index'])
end

local function onItemData(data, itemData)
    fillData(itemData, data, {
        'recomendid_card',
        'modeltype',
        'scene',
        'slotid',
        'sourcescene',
        'sourcesceneslotid',
    })
    itemData['uni_is_redpoint'] = '0'
    itemData['redpoint_num'] = '0'
    updataBubbleVisible(itemData, false)
    local itemType = itemData['item_type']
    if itemType == '3' then
        onBookingItemData(itemData)
        return
    end
end

-- 填充视图和数据
local function fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    if checkNil(viewNameList, dataList, params, queries, itemQueries) then
        return
    end
    if checkNil(params['view_name'], params['item_count_name']) then
        return
    end

    -- queries填充其他固定参数
    fillData(queries, {
        ['modeltype'] = '',
        ['scene'] = '',
        ['slotid'] = '',
        ['sourcescene'] = '',
        ['sourcesceneslotid'] = '',
    }, nil)

    local data = queryData('', queries)
    local itemCount = tonumber(data[params['item_count_name']])
    mJavaBridge:Log(TAG, 'itemCount: '..tostring(itemCount))
    if itemCount == nil or itemCount <= 0 then
        return
    end

    local itemMax = tonumber(params['item_max'])
    if itemMax ~= nil and itemCount > itemMax then
        itemCount = itemMax
    end

    local hasFourApp = Rapid:getData('hasFourApp', 'false')
    if itemCount >= 4 then
        hasFourApp = 'true'
    end
    updateGridlayoutmanager(data['hasFourApp'])

    for i = 1, itemCount do
        table.insert(viewNameList, params['view_name'])
        local itemData = queryItemData(i, itemQueries)
        itemData['subposition'] = getPositionString(i)
        itemData['item_index'] = i
        onItemData(data, itemData)
        table.insert(dataList, itemData)
    end
end

local function addActionListener()
    local actionListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IPhotonActionListener', mActionListener)
    mRecyclerView:getView():setActionListener(actionListener)
end

local function refreshData()
    local viewNameList = {}
    local dataList = {}
    local params = {
        ['view_name'] = 'personal_center_my_game_card_item.xml',
        ['item_count_name'] = 'item_count',
        ['item_max'] = 4,
    }
    local queries = {
        [params['item_count_name']] = 0,
        ['hasFourApp'] = '0',
        ['report_context'] = '',
        ['recomendid_card'] = '',
    }
    local itemQueries = {
        ['report_context_app'] = '',
        ['item_title'] = '',
        ['item_icon_url'] = '',
        ['item_jump_url'] = '',
        ['item_type'] = '',
    }
    fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    mRecyclerView:getView():updateData(viewNameList, dataList, true)
end

-- 跳转
function jump(itemIndex)
    mJavaBridge:Log(TAG, "jump itemIndex: "..tostring(itemIndex))
    itemIndex = tonumber(itemIndex)
    if itemIndex == nil then
        return
    end
    local itemType = getItemValue(itemIndex, 'item_type')
    local itemJumpUrl = getItemValue(itemIndex, 'item_jump_url')
    mJavaBridge:Log(TAG, "jump itemType: "..tostring(itemType))
    mJavaBridge:Log(TAG, "jump itemJumpUrl: "..tostring(itemJumpUrl))
    mJavaBridge:Log(TAG, "jump tmastAction: "..tostring(getTmastAction(itemType)))
    local tmastParams = {
        ['tmast'] = itemJumpUrl
    }
    Rapid:execAction(getTmastAction(itemType), tmastParams, tmastParams)
end

function mActionListener.notify(key, value)
    mJavaBridge:Log(TAG, "notify key: "..tostring(key)..", value: "..tostring(value))
    if key == 'itemJump' then
        jump(value)
        return
    end
end

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")

    mRecyclerView = Rapid:getChild('recycler_view')
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")

    addActionListener()
    refreshData()
end

function onResume()
    mJavaBridge:Log(TAG, "onResume")

    refreshData()
end