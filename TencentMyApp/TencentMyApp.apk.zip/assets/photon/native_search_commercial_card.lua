local mPhotonView, mJavaBridge = ...

function goDeeplink(deeplink, subposition)
    if (deeplink == nil) then
        return
    end

    local intent = luajava.newInstance('android.content.Intent', 'android.intent.action.VIEW')
    local uri = luajava.bindClass('android.net.Uri')
    uri = uri:parse(deeplink)

    if (uri:getScheme() == "tmast") then
        local data = {}
        local searchId = mPhotonView:getParser():getBinder():get("searchId")
        local subpositionString = getSubposition(subposition)
        data["tmast"] = uri:toString() .. "&sourcesceneslotid=123_001_-1_" .. subpositionString .. "&searchId=" .. searchId
        -- mJavaBridge:Log("joe", data["tmast"])

        data["extendparam"] = "searchquery:data@queryWord,appid:data@appid,sourcequery:data@sourceQuery,tagname:data@tagName"
        data["extra"] = "stInfoExtraData:data@queryWord"
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", data, data)
    else
        intent:setData(uri)
        local card = mPhotonView:getParser():getChildView("card")
        local context = card:getView():getContext()
        context:startActivity(intent)
    end
end

function setDetailUrl(i)
    local videoView = mPhotonView:getParser():getChildView("video_" .. i)
    local blankView = videoView:getView():getBlankView()
    local blankViewOnClickListener = luajava.createProxy('android.view.View$OnClickListener', OnClickListener)
    blankView:setTag(i)
    blankView:setOnClickListener(blankViewOnClickListener)
end


OnClickListener = {}

function OnClickListener.onClick(view)
    local i = view:getTag()
    local position = mPhotonView:getParser():getBinder():get("position") + 1;
    local positionString = string.format("%03d", position)
    local subposition = "40" .. i
    subposition = getSubposition(subposition)

    local url = mPhotonView:getParser():getBinder():get("video_detail_url_" .. i)
    url = url .. "&preActivitySlotTagName=123_" .. positionString .. "_-1_" .. subposition
    if (url ~= nil) then
        local param = {}
        param["key"] = "SaveCardInfo"
        param["value"] = mPhotonView:getParser():getBinder():get("position")
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("outeraction", param, param)

        local data = {}
        data["tmast"] = url
        mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", data, data)

        itemClick(subposition, "video")
    end
end

--曝光的上报
function itemShow(item, type)

    local position = mPhotonView:getParser():getBinder():get("position") + 1;
    local positionString = string.format("%03d", position)
    local subposition = getSubposition(item)
    local data = {}
    data["param"] = "scene:data@scene,sourcescene:data@sourceScene,modeltype:1149,actionid:100,slotid:123_" .. positionString .. ",subposition:" .. subposition .. ",extradata:data@queryWord,appid:data@app_id,searchid:data@searchId,packagename:data@packageName"
    data["extendparam"] = "searchquery:data@queryWord,appid:data@appid,sourcequery:data@sourceQuery,tagname:data@tagName"
    data["reportelement"] = getReportElement(type)
    local recommendid = mPhotonView:getParser():getBinder():get("recommend_id")
    if (recommendid ~= nil) then
        data["recommendid"] = "data@recommend_id"
    else
        data["recommendid"] = "data@recommendid"
    end
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, data)
end

--点击的上报
function itemClick(item, type)
    local position = mPhotonView:getParser():getBinder():get("position") + 1;
    local positionString = string.format("%03d", position)
    local subposition = getSubposition(item)
    local data = {}
    data["param"] = "scene:data@scene,sourcescene:data@sourceScene,modeltype:1149,actionid:200,slotid:123_" .. positionString .. ",subposition:" .. subposition .. ",extradata:data@queryWord,appid:data@app_id,searchid:data@searchId,packagename:data@packageName"
    data["extendparam"] = "searchquery:data@queryWord,appid:data@appid,sourcequery:data@sourceQuery,tagname:data@tagName"
    data["reportelement"] = getReportElement(type)
    local recommendid = mPhotonView:getParser():getBinder():get("recommend_id")
    if (recommendid ~= nil) then
        data["recommendid"] = "data@recommend_id"
    else
        data["recommendid"] = "data@recommendid"
    end

    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", data, data)
end

function getReportElement(type)
    if(type == "link" or type == "app" or type == "video" or type == "image") then
        return type
    elseif(type ~= nil and type ~= '') then
        return "video"
    else
        return "image"
    end
end

function getSubposition(item)
    local vid = mPhotonView:getParser():getBinder():get("vid_0")
    if (item == "single" or item == "400") then
        if (vid ~= nil) then
            -- 单视频
            return "301"
        else
            -- 单图
            return "201"
        end
    end

    -- 三视频或图片
    return item
end