local mPhotonView,mJavaBridge = ...

local mRecyclerView = nil
local KEY_VIEW_SHOW_FLAG = "view_show_flag_"
local Color = luajava.bindClass('android.graphics.Color')

function init()

end

function updateValue()
    local btnText = Rapid:getData("button_clean_text")

    local rubbishSize = mPhotonView:getParser():getBinder():get("oldFileSize")
    if rubbishSize ~=nil and rubbishSize ~= "" then
        rubbishSize = tostring(btnText).."（"..tostring(rubbishSize).."）"
    else
        rubbishSize = tostring(btnText)
    end
    mPhotonView:getParser():getChildView("clean_button"):getView():setText(rubbishSize)

    --清理钮背景色
    local button_clean_bg_color = mPhotonView:getParser():getBinder():get("button_clean_bg_color")
    local button_clean_edge_color = mPhotonView:getParser():getBinder():get("button_clean_edge_color")

    local button_clean_bg_color_format = "color:ffffff"
    if button_clean_bg_color ~=nil and button_clean_bg_color~= "" then
        button_clean_bg_color_format = "color:"..tostring(button_clean_bg_color)
    end

    local button_clean_edge_color_format = ",strokecolor:ffffff"
    if button_clean_edge_color ~=nil and  button_clean_edge_color ~="" then
        button_clean_edge_color_format = ",strokecolor:"..tostring(button_clean_edge_color)
    end
    local fullStopButtonBg ='strokewidth:4,'..tostring(button_clean_bg_color_format)..tostring(button_clean_edge_color_format)..",cornerradius:45,shape:0"
    Rapid:getChild("clean_button"):setAttr("backgroundgradientdrawable",fullStopButtonBg)

    --清理文案色值 根据背景颜色值来展示
    local button_clean_text_color = mPhotonView:getParser():getBinder():get("button_clean_text_color")
    if button_clean_text_color ~=nil and button_clean_text_color ~= "" then
        Rapid:getChild("clean_button"):getView():setTextColor(Color:parseColor("#"..tostring(button_clean_text_color)))
    end

end

function getReportPosition(position)
    return string.format( "%03d", position )
end