local mPhotonView,mJavaBridge = ...
local isNegativeFeedbackSelected = 0

function init()
    local main_title = Rapid:getData('main_title', '')
    Rapid:getChild('tv_main_title'):setAttr('htmltext', resolveText(main_title))

    local system_trush_limit = tonumber(Rapid:getData('system_trush_limit', '0'))
    local total_rubbish_size = tonumber(Rapid:getData('total_rubbish_size_raw', '0'))

    if total_rubbish_size / 1024 >= system_trush_limit then
        local app_rubbish_size = tonumber(Rapid:getData('app_rubbish_size_raw', '0'))
        local scan_rubbish_size = tonumber(app_rubbish_size) + tonumber(total_rubbish_size)
        local sub_title = Rapid:getData('sub_title_1', '')
        Rapid:getChild('tv_sub_title'):setAttr('htmltext', string.gsub(sub_title, '${scan_rubbish_size}', formatSize(scan_rubbish_size), 1))
        Rapid:setData('uni_show_type', '1')
    else
        local sub_title_2 = Rapid:getData('sub_title_2', '')
        Rapid:getChild('tv_sub_title'):setAttr('htmltext', resolveText(sub_title_2))
        Rapid:setData('uni_show_type', '2')
    end

    local enable_negative_feedback = Rapid:getData('enable_negative_feedback', '1')
    if enable_negative_feedback == '0' then
        Rapid:getChild('ll_negative_feedback'):setAttr('visibility', 'gone')
    else 
        Rapid:getChild('ll_negative_feedback'):setAttr('visibility', 'visible')
    end
end

function resolveText(content)
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        return dialogSelf:resolveText(content)
    end
    return content
end

function formatSize(byteNum)
    local MemoryUtils = luajava.bindClass('com.tencent.assistant.utils.MemoryUtils')
    return MemoryUtils:formatSize(byteNum)
end

function clickNegativeFeedback()
    -- 点击负反馈
    if isNegativeFeedbackSelected == 1 then
        isNegativeFeedbackSelected = 0
        Rapid:getChild('iv_negative_feedback'):setAttr('gifurl', 'https://cms.myapp.com/yyb-img-75056/2020/05/13/1589373567833_c087074c1f95cbb0cc7d74f510d8feda47723077.png')
    else
        isNegativeFeedbackSelected = 1
        Rapid:getChild('iv_negative_feedback'):setAttr('gifurl', 'https://cms.myapp.com/yyb-img-75056/2020/05/13/1589373499607_299db5d050c8e64fd81a05cfbdfba0bfe7eb2fb2.png')
    end
end

function clickOutside()
    local enable_click_outside = Rapid:getData('enable_click_outside', '0')
    if enable_click_outside == '0' then
        return
    end
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        -- 点击弹窗外取消类型为6
        dialogSelf:dismiss(6, 0)
    end
end

function clickLeftButton()
    local left_button_action = Rapid:getData('left_button_action')
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:executeClickAction(left_button_action)
    end
end

function clickRightButton()
    local right_button_action = Rapid:getData('right_button_action')
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:executeClickAction(right_button_action)
        -- 跳转取消类型为5
        dialogSelf:dismiss(5, 0)
    end
end

function onPageOut(stayDuration)
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:2000,slotid:-1_-1,actionid:2005,subposition:-1,modeltype:-1"
    params1["extendparam"] = "report_element:page,stay_duration:"..stayDuration
    actionRunner:run("reportaction", params1, nil)
end

function onDismiss(dismissType)
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:2000,slotid:99_001,actionid:201,subposition:001,modeltype:data@modeltype"
    params1["extendparam"] = "report_element:pop,uni_popid:data@uni_popid,uni_pop_type:data@uni_pop_type,uni_pop_configid:data@uni_pop_configid,uni_monitor_event_code:data@uni_monitor_event_code,uni_show_type:data@uni_show_type,uni_cancel_type:"..dismissType..",uni_check_status:"..tostring(isNegativeFeedbackSelected)
    params1["recommendid"] = "data@R1"
    actionRunner:run("reportaction", params1, nil)
end