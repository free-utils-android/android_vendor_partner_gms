local mPhotonView, mJavaBridge = ...



local UI_EVENT_START_UPDATE_MANAGER_ACTIVITY = 1332


function updateData()
    local redDotNum = Rapid:getData('item_data_red_num', '0')
    if tonumber(redDotNum) > 0 then
        Rapid:setData('uni_is_redpoint', '2')
        Rapid:setData('redpoint_num', redDotNum)
        Rapid:getChild('tv_red_num'):setAttr('visibility', 'visible')
        if tonumber(redDotNum) > 9 then
            setRedDotWidth('18')
            if tonumber(redDotNum) > 99 then
                Rapid:getChild('tv_red_num'):setAttr('text', '99+')
                setRedDotWidth('26')
            end
        else
            setRedDotWidth('16')
        end
    else
        Rapid:setData('uni_is_redpoint', '0')
        Rapid:getChild('tv_red_num'):setAttr('visibility', 'gone')
    end
end

function jump()
    clearManageTabRedDotData()
end

-- 清空管理tab红点数据
function clearManageTabRedDotData()
    mJavaBridge:sendEvent(UI_EVENT_START_UPDATE_MANAGER_ACTIVITY, nil, nil, nil)
end

-- 设置红点宽度
function setRedDotWidth(w)
    Rapid:getChild('tv_red_num'):setAttr("width", w)
end