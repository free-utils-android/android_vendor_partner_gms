local mPhotonView,mJavaBridge = ...


function upateValue()    
    mPhotonView:getParser():getChildView("view_contain"):getView():removeAllViews()

    local binder =  mPhotonView:getParser():getBinder() 
    local total = tonumber(binder:get("totoal_size"))

    mJavaBridge:Log("zishengli", "upateValue"..total)

    for index=1,total do

        local params = {}
        local gift = binder:get("gift"..index)
        params["gift"] = gift

        local text = binder:get("btn_title"..index)
        params["btn_title"] = text

        local jump_detail = binder:get("jump_detail"..index)
        params["detail_tmast"] = jump_detail

        local receive_gift = binder:get("receive_gift"..index)
        params["receive_gift_tmast"] = receive_gift

        mJavaBridge:addView("native_oma_game_around_card_item.xml", "view_contain", "", nil, params, nil)

    end
end
