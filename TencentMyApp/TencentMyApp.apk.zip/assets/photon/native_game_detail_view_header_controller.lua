local mPhotonView,mJavaBridge = ...
local mHeaderView

function main()
	local puppet = mPhotonView:getParser():getChildView("puppet")

	mHeaderView = mPhotonView:getParser():getChildView("header")

	local headListener = luajava.createProxy('android.view.View$OnTouchListener', mHeaderListener)
	if( puppet ~= nil ) then
		puppet:getView():setOnTouchListener(headListener)
	end
end

mHeaderListener = {}
function mHeaderListener.onTouch(view, event)
	if( mHeaderView == nil ) then
		return false
	end

	mHeaderView:getView():dispatchTouchEvent(event)
	return true
end