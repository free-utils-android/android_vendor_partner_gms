local mRapidView, mJavaBridge = ...

local TAG = "playing_game_tab_base_info_card"
local DEBUG = true
local mAppStubComponent = nil
-- appstate list
local APP_UPDATE = 0
local APP_DOWNLOADING = 1
local APP_PAUSED = 3
local APP_DOWNLOADED = 4
local APP_INSTALLED = 5
local APP_DOWNLOAD = 9
local mState = APP_DOWNLOAD

--load的时候运行
function loadFinish()
    logForDebug(TAG, " loadFinish")
end

function init()
    logForDebug(TAG, "reset data:")
    initComponent()
end

function initComponent()
    mAppStubComponent = mJavaBridge:createAppStubComponent()

    --local appStateListener = luajava.createProxy(
    --        "com.tencent.rapidview.deobfuscated.control.IAppStubComponent$IAppStateChangeListener",
    --        IAppStateChangeListener
    --)
    --mAppStubComponent:registerAppStateChangeListener(appStateListener)
end

--数据更新后，卡片入口主方法
function main()
    logForDebug(TAG, "update main")
    initAppState()
    Rapid:setData("five_visibility", "visible")
    Rapid:setData("app_version_suffix", Rapid:getData("app_version") .. " 版本")
    --“1”表示是是预约游戏用预约按钮， “0”用下载按钮
    local booking = tostring(Rapid:getData("is_validate_booking_game"))
    if "1" == booking then
        Rapid:setData("five_visibility", "gone")
    else
        updateFiveElement(mState)
    end
    local index = Rapid:getData("index", "0")
end

function jumpDetail()

end

function initAppState()
    local appModel = Rapid:getData("app_model")
    logForDebug(TAG, "appModel:" .. tostring(appModel))
    if appModel ~= nil then
        print("multi set mAppStubComponent :" .. tostring(mAppStubComponent))
        mAppStubComponent:setAppModel(appModel)
    end

    print("multi mAppStubComponent :" .. tostring(mAppStubComponent))

    mState = mAppStubComponent:getAppState()
end

IAppStateChangeListener = {}
function IAppStateChangeListener.onState(state)
    mState = state
    updateFiveElement(mState)
end

-- 应用未安装和需要更新时，展示五要素面板
function updateFiveElement(state)
    local pkg_name = Rapid:getData("pkg_name")
    logForDebug(TAG, "pkg:" .. tostring(pkg_name) .. " appState:" .. tostring(state))
    local visibility = "visible"
    if state == nil then
        visibility = "visible"
    end
    if APP_INSTALLED == state then
        -- 已安装/打开
        visibility = "gone"
    end
    if Rapid:getData("five_visibility", "visible") ~= visibility then
        Rapid:setData("five_visibility", visibility)
        Rapid:getChild("five_card_view"):setAttr("visibility", visibility)
        logForDebug(TAG, "set visibility:" .. visibility)
    end
    logForDebug(TAG, "visibility:" .. visibility)
end

function showPermissions()
    Rapid:Log(TAG, " showPermissions ")
    mJavaBridge:showAppPermissionInfo(Rapid:getData('app_permissions', '权限说明'))
end

-----------------------------------------------------------
--debug的时候打印日志的方法
function logForDebug(logTag, logMsg)
    if not DEBUG then
        return
    end
    mJavaBridge:Log(TAG .. "::", logMsg)
end