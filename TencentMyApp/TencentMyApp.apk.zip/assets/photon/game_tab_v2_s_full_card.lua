local mPhotonView,mJavaBridge = ...

local pagFull = nil

local IRapidPagAnimationListener = {}
local pagAnimationListener

function main( ... )
    pagFull = Rapid:getChild("pag_full"):getView()

    pagAnimationListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.pag.IRapidPagAnimationListener", IRapidPagAnimationListener)
    pagFull:registerIRapidPagAnimationListener(pagAnimationListener)
end

function onResume( ... )
    mJavaBridge:Log("game_tab_v2_feed_s_card","onResume")
    pagFull:setVisibility(0)
    pagFull:startPlay(true)
    exposeImage("pag_full","全屏")
end

function onPause()
    mJavaBridge:Log("game_tab_v2_feed_s_card","onPause")
    mJavaBridge:postRun(stopPapg)
end

function stopPapg( ... )
    pagFull:stop()
    pagFull:setVisibility(8)
end

function delayStartAnimation( ... )
    startAnimation()
end

-- 特效曝光
function exposeImage(viewid, animeType)
    local reportParams = {}
    reportParams["viewid"] = viewid
    reportParams["dteventkey"] = "imp"
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:-100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:image,source_report_context:data@source_report_context,report_context:data@image_report_context,uni_effect_level:S,uni_only_cloudgame_check_status:data@is_only_show_free_play,uni_anime_type:"..animeType
    reportParams["recommendid"] = "data@app_recommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function startAnimation( ... )
    local animationNum = tonumber(Rapid:getData("animation_num", 0))
    if animationNum <= 0 then
        mJavaBridge:Log("game_tab_v2_feed_s_card","no animation")
        return
    end

    local animationSet = luajava.newInstance("android.animation.AnimatorSet")    
	local aniList = luajava.newInstance("java.util.ArrayList")
    local lastX = 0
    local lastY = 0
    for i = 1, animationNum do 
        local animation = Rapid:getData("animation_data_"..i)
        local targetX = tonumber(animation:get("translationX"))
        local targetY = tonumber(animation:get("translationY"))
        local time = tonumber(animation:get("time"))
        local bezier_params = splitString(tostring(animation:get("bezier_params")),",")
        local objectAnimator = createAnimation(time, lastX, targetX, lastY, targetY, bezier_params[1], bezier_params[2], bezier_params[3], bezier_params[4])
        lastX = targetX
        lastY = targetY
        aniList:add(objectAnimator)
    end
    -- local animation = createAnimation(90, 0, 0, 0, 100, 0.42, 0.00 , 0.58,1.00 )
    -- local animation2 = createAnimation(80, 0, 0, 100, 0,  0.58,1.00 , 0.42,0.00  )
    -- aniList:add(animation)
    -- aniList:add(animation2)
    animationSet:playSequentially(aniList)
    animationSet:start()

    mJavaBridge:callModuleWithParams("Hardware", "vibrate",{2000})
end

function createAnimation( time, lastX, curX, lastY, curY, x1, y1, x2, y2)
    local PropertyValuesHolder = luajava.bindClass('android.animation.PropertyValuesHolder')
    local params = {}
    params[1] = lastX
    params[2] = curX

    local transX = PropertyValuesHolder:ofFloat("translationX", params)

    params[1] = lastY
    params[2] = curY
    local transY = PropertyValuesHolder:ofFloat("translationY", params)

    local transParams = {}
    transParams[1] = transX
    transParams[2] = transY

    local ObjectAnimator = luajava.bindClass("android.animation.ObjectAnimator")
    local objectAnimator = ObjectAnimator:ofPropertyValuesHolder(gameInfoCard, transParams)
    objectAnimator:setDuration(time)
    local interpolator = luajava.newInstance("com.tencent.assistant.animation.rebound.EaseCubicInterpolator", x1, y1, x2, y2)
    objectAnimator:setInterpolator(interpolator)
    return objectAnimator
end

function hideCard( ... )
    local param = {}
    param["key"] = "full_screen_photon_view_visible"
    param["value"] = "false"
    Rapid:execAction("outeraction", param, param)
end

function IRapidPagAnimationListener.onAnimationStart( component )

end

function IRapidPagAnimationListener.onAnimationEnd( component )
    if button ~= nil then
        button:applyFacetStyle()
    end
end

function IRapidPagAnimationListener.onAnimationCancel( component )
    -- body
end

function IRapidPagAnimationListener.onAnimationRepeat( component )
    -- body
end