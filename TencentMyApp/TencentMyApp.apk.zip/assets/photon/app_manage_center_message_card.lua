local mPhotonView, mJavaBridge = ...

local VIEWNAME = "app_manage_center_message_card"
local TAG = "shxinliu - "..VIEWNAME
local FORMAT_KEY = "app_manage_center_message_card"
local MESSAGE_ID = "message_id"
local MANAGE_MSG_THRESHOLD_DEF = 5

-- 现有最大指示器数
local MAX_COUNT_INDICATE = 5
-- 现有指示器数
local mIndicateCount = MAX_COUNT_INDICATE
-- 指示器样式：未选中
local STYLE_INDICATE = "shape:1,color:77777777"
-- 指示器样式：选中
local STYLE_INDICATE_SELECTED = "shape:1,color:FF777777"
-- 是否可取新的安装包扫描结果: "1"：是 "0"：否
local PKG_SCAN_STATUS_YES = "1"
local PKG_SCAN_STATUS_NO = "0"
-- call java
local mCall = {}

-- 默认切换时间：5秒
local mCardPlayInterval = 5000
-- 阈值
local mManageMsgThreshold
-- 配置信息
local mConfigData

local mIndicateView
local mViewFlipper
local mCardRootView

-- 是否为王卡用户
local mKingCard = false
-- 获取可清理的安装包数量
local mApkSizeByClear
-- 获取可清理的安装包列表包体积总大小
local mTotalApkMemorySizeByClear

-- 局部方法

-- 检查对象类型
local function checkType(obj, tname)
    if tname ~= nil and type(obj) == tname then
        return true
    end
    return false
end

-- 检查是否有nil
local function checkNil(...)
    local args = {...}
    for i = 1, select("#", ...) do
        if args[i] == nil then
            return true
        end
    end
    return false
end

-- 检查是否为nil或长度为0
local function checkNilOrEmpty(text)
    if text == nil or #text == 0 then
        return true
    end
    return false
end

-- 检查table是否为空
local function checkTableNilOrEmpty(tab)
    if tab == nil or next(tab) == nil then
        return true
    end
    return false
end

local function choose(bol, obj, def)
    if bol then
        return obj
    else
        return def
    end
end

local function chooseMi(obj, def)
    if obj ~= nil then
        return obj
    else
        return def
    end
end

local function toNumber(text, def)
    local type = type(text)
    if type == 'number' then
        return text
    elseif type == 'string' then
        local num = tonumber(text)
        if num ~= nil then
            return num
        end
    end
    return def
end

-- key标志
local function formatKey(mode, key)
    return string.format(FORMAT_KEY.."."..mode.."."..key)
end

-- 存储本地数据
local function settingsDataAsync(mode, key, value)
    if checkNil(mode, key) then
        return
    end
    mJavaBridge:setSettingsDataAsync(formatKey(mode, key), value)
end

-- 获取本地数据
local function getSettingsData(mode, key, def)
    if checkNil(mode, key) then
        return
    end
    return mJavaBridge:getSettingsData(formatKey(mode, key), def)
end

-- 获取单个字符长度
local function getCharSize(char)
    if not char then
        return 0
    elseif char > 240 then
        return 4
    elseif char > 225 then
        return 3
    elseif char > 192 then
        return 2
    else
        return 1
    end
end

-- 获取中文字符长度
local function getUtf8Len(str)
    if str == nil then
        return 0
    end
    local len = 0
    local currentIndex = 1
    while currentIndex <= #str do
        local char = string.byte(str, currentIndex)
        currentIndex = currentIndex + getCharSize(char)
        len = len + 1
    end
    return len
end

-- 截取中文字符串
local function strUtf8Sub(str, startChar, numChars)
    local startIndex = 1
    while startChar > 1 do
        local char = string.byte(str, startIndex)
        startIndex = startIndex + getCharSize(char)
        startChar = startChar - 1
    end
    local currentIndex = startIndex
    while numChars > 0 and currentIndex <= #str do
        local char = string.byte(str, currentIndex)
        currentIndex = currentIndex + getCharSize(char)
        numChars = numChars - 1
    end
    return string.sub(str, startIndex, currentIndex - 1)
end

-- 如不超过max直接返回str，如超过返回str前max位+...
local function strCut(str, max)
    if max <= 0 then
        return ""
    elseif getUtf8Len(str) > max then
        return string.format("%s...", strUtf8Sub(str, 0, max))
    else
        return str
    end
end

-- put数据
local function putTable(data, params)
    if checkType(data, "table") and checkType(params, "table") then
        for k, v in pairs(params) do
            data[k] = v
        end
    end
end

-- 安全替换
function gsubString(temp, from, to)
    if checkNil(temp, from, to) then
        return temp
    end
    return string.gsub(temp, from, to)
end

-- 按start rule[table：key: 查询后缀名，value：默认值['nil'为nil]]规则查询数据返回table
local function queryRuleData(rule, start)
    local data = {}
    for k, v in pairs(rule) do
        local queryKey = chooseMi(start, "")..k
        local queryValue = mPhotonView:getParser():getBinder():get(queryKey)
        if queryValue == nil and v ~= "nil" then
            queryValue = v
        end
        data[k] = queryValue
    end
    return data
end

-- 全局方法

-- java辅助方法

-- 是否是王卡
function mCall:isKingCard()
    return mJavaBridge:callModule("AppManager", "isKingCard")
end

-- 获取推荐可清理的安装包数量
function mCall:getApkSizeByRecommendClear()
    return mJavaBridge:callModule("AppManager", "getApkSizeByRecommendClear")
end

-- 获取推荐清理的安装包垃圾大小
function mCall:getTotalApkMemorySizeByRecommendClear()
    return mJavaBridge:callModule("AppManager", "getTotalApkMemorySizeByRecommendClear")
end

-- 判断应用是否已忽略
function mCall:isIgnoreApp(packageName)
    return mJavaBridge:callModuleWithParams("AppManager", "isIgnoreApp", {chooseMi(packageName, '')})
end

-- 计算加减乘除
--   @param type 加:add 减:subtract 乘:multiple 除:divide
function mCall:calculate(type, number1, number2)
    return mJavaBridge:callModuleWithParams("Math", "calculate", {chooseMi(type, ''), chooseMi(number1, '0'), chooseMi(number2, '0')})
end

-- 显示M或者G，不足1M显示0
function mCall:formatSizeMorG(size)
    return mJavaBridge:callModuleWithParams("Math", "formatSizeMorG", {chooseMi(size, '')})
end

-- 设置是否可取新的安装包扫描结果
--   @param state "1"：是 "0"：否
function mCall:setPkgScanStatus(state)
    return mJavaBridge:callModuleWithParams("AppManager", "setPkgScanStatus", {chooseMi(state, '')})
end

-- 获取是否可取新的安装包扫描结果
function mCall:getPkgScanStatus()
    return mJavaBridge:callModule("AppManager", "getPkgScanStatus")
end

-- 辅助方法

-- 单icon布局/双icon布局的显示 positive: true显示单icon，false显示双icon
local function insertVisibleTable(data, positive)
    putTable(data, {
        ["item_visible_positive"] = choose(positive, "VISIBLE", "INVISIBLE"),
        ["item_visible_anti"] = choose(positive, "INVISIBLE", "VISIBLE")
    })
end

-- 文字替换：appName、appCount、flowSaveSize
local function toTemplate(params, temp)
    if checkNil(params, temp) then
        return temp
    end
    -- 取应用名的前六位
    local appName = strCut(params["app_name"], 6)
    local appCount = toNumber(params["app_msg_count"], 0)
    local flowSize = params["flow_save_size"]
    local offsetW = params["_offset_w"]
    local offsetFw = params["_offset_fw"]

    if params["msg_type"] == '1' or params["msg_type"] == '2' then
        flowSize = choose(mKingCard, offsetW, offsetFw)
    end

    local text = temp
    -- 是否已经替换应用名称
    local appCountNumExpend = true
    -- 应用更新
    if params["msg_type"] == "2" then
        -- 替换应用名称：&appName --- 当应用数大于1
        if toNumber(appCount, 0) > 1 and appName ~= nil then
            text = gsubString(text, "&appName", appName.."等")
            appCountNumExpend = false
        end
    end
    mJavaBridge:Log(TAG.." flowSize", flowSize)
    -- 替换清理流量单位：&flowSaveSize
    if toNumber(flowSize, 0) <= 0 then
        text = gsubString(text, "&flowSaveSize", "更新速度更快")
    else
        local korMorG = mCall:formatSizeMorG(flowSize)
        mJavaBridge:Log(TAG.." korMorG", korMorG)
        if korMorG == '0M' then
            text = gsubString(text, "&flowSaveSize", "更新速度更快")
        else
            text = gsubString(text, "&flowSaveSize", "节省"..korMorG.."流量")
        end
    end
    -- 替换应用名称：&appName
    if appCountNumExpend then
        text = gsubString(text, "&appName", appName)
    end
    -- 替换应用数量：&appCount
    text = gsubString(text, "&appCount", appCount)
    return text
end

-- 插入标题、副标题、按钮
--  kingCardEnable：是否启用王卡判定
local function putHeaderView(itemData, params, kingCardEnable)
    local cho = (kingCardEnable and mKingCard) or (not kingCardEnable)
    putTable(itemData, {
        ["item_title"] = toTemplate(params, choose(cho, params["app_msg_title_1"], params["app_msg_title_2"])),
        ["item_sub_title"] = toTemplate(params, choose(cho, params["item_sub_title_1"], params["item_sub_title_2"])),
        ["item_operate"] = choose(cho, params["app_operate_1"], params["app_operate_2"])
    })
end

-- view、data插入数据
local function insertTable(views, data, params)
    if checkNil(views, data, params) and checkNil(params["msg_type"]) then
        return
    end

    -- 阈值控制
    if #views >= mManageMsgThreshold then
        mJavaBridge:Log(TAG.." insertTable() 超出阈值", string.format("#views: %d, mManageMsgThreshold: %d", #views, mManageMsgThreshold))
        return
    end

    local msgType = params["msg_type"]

    -- 填充数据
    local itemData = {}
    putTable(itemData, {
        ["item_icon_url_1"] = params["app_icon_1"],
        ["item_icon_url_2"] = params["app_icon_2"],
        ["item_jump_url"] = params["app_jump_url"],
        -- 上报使用
        ["modeltype"] = mConfigData["modeltype"],
        ["slotid"] = mConfigData["slotid"],
        ["scene"] = mConfigData["scene"],
        ["sourcescene"] = mConfigData["sourcescene"],
        ["sourcesceneslotid"] = mConfigData["sourcesceneslotid"],
        ["subposition"] = #views + 1,
        ["item_data_message_type"] = msgType,
        ["item_data_message_id"] = params["msg_id"],
        ["item_data_message_recommendid"] = params["item_recommendid"]
    })

    -- msgType：消息类型，1：新版本，2：应用更新，3：安装包清理，4：人工配置
    -- 1：新版本
    if msgType == "1" then
        insertVisibleTable(itemData, true)
        putHeaderView(itemData, params, true)
    -- 2：应用更新
    elseif msgType == "2" then
        insertVisibleTable(itemData, toNumber(params["app_msg_count"], 0) < 2)
        putHeaderView(itemData, params, true)
    -- 3：安装包清理
    elseif msgType == "3" then
        insertVisibleTable(itemData, true)
        putHeaderView(itemData, params, false)
    -- 4：人工配置
    elseif msgType == "4" then
        insertVisibleTable(itemData, true)
        putHeaderView(itemData, params, false)
    end

    -- button没文字时隐藏
    itemData["item_visible_operate"] = choose(checkNilOrEmpty(itemData["item_operate"]), "GONE", "VISIBLE")
    table.insert(views, "app_manage_center_message_card_item.xml")
    table.insert(data, itemData)
end

-- 辅助日志
function logHelper()
    mJavaBridge:Log(TAG.." logHelper() mCall:getApkSizeByRecommendClear", chooseMi(mCall:getApkSizeByRecommendClear(), 'nil'))
    mJavaBridge:Log(TAG.." logHelper() mCall:getTotalApkMemorySizeByRecommendClear", chooseMi(mCall:getTotalApkMemorySizeByRecommendClear(), 'nil'))
end

-- 业务逻辑方法

-- 生命周期

function onResume()
    loadData()
end

-- 业务方法

function init()
    initView()
    loadData()
end

local pageChangeListener
local PageChangeListener = {}
function PageChangeListener.onPageChange(beforePageIndex, afterPageIndex)
    mIndicateView:getView():setCurrentSelectedDotIndex(afterPageIndex)
end

function initView()
    Rapid:setData("card_flip_interval", mCardPlayInterval)
    mCardRootView = mPhotonView:getParser():getChildView("card_container")
    mViewFlipper = mPhotonView:getParser():getChildView("view_flipper")
    mIndicateView = mPhotonView:getParser():getChildView("indicate_view")
    pageChangeListener =
        luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IBannerPageChangeListener", PageChangeListener)
    mViewFlipper:getView():addPageChangeListener(pageChangeListener)
    Rapid:getChild("indicate_view"):setAttr("indicateinterval", tostring(mJavaBridge:dip2px(2)))
    Rapid:getChild("indicate_view"):setAttr("orientation", "vertical")

    -- 调整动画
    initAnimation()
end

-- 调整动画
function initAnimation()
    local mUnitTime = 400
    local mAlphaUnitTime = mUnitTime / 2

    local animationInSet = mJavaBridge:createAnimationSet("true")
    local translateInAnimation = luajava.newInstance("android.view.animation.TranslateAnimation", 0, 0, 0, 0, 2, -1, 0, 0)
    translateInAnimation:setDuration(mUnitTime)
    animationInSet:addAnimation(translateInAnimation)
    local alphaInAnimation = luajava.newInstance("android.view.animation.AlphaAnimation", 0, 1)
    alphaInAnimation:setDuration(mAlphaUnitTime)
    animationInSet:addAnimation(alphaInAnimation)
    mViewFlipper:getView():setInAnimation(animationInSet)

    local animationOutSet = mJavaBridge:createAnimationSet("true")
    local translateOutAnimation = luajava.newInstance("android.view.animation.TranslateAnimation", 0, 0, 0, 0, 0, 0, 2, 1)
    translateOutAnimation:setDuration(mUnitTime)
    animationOutSet:addAnimation(translateOutAnimation)
    local alphaOutAnimation = luajava.newInstance("android.view.animation.AlphaAnimation", 1, 0)
    alphaOutAnimation:setDuration(mAlphaUnitTime)
    animationOutSet:addAnimation(alphaOutAnimation)
    mViewFlipper:getView():setOutAnimation(animationOutSet)
end

-- 获取信息
function obtainData()
    obtainAppData()
    obtainPhotonConfigData()
end

-- 获取app信息
function obtainAppData()
    mKingCard = mCall:isKingCard()
    mApkSizeByClear = mCall:getApkSizeByRecommendClear()
    mTotalApkMemorySizeByClear = mCall:getTotalApkMemorySizeByRecommendClear()
end

-- 获取光子配置数据
function obtainPhotonConfigData()
    -- 配置data
    mConfigData = queryRuleData({
        ["card_recommendid"] = "nil",
        ["index"] = "nil",
        ["item_num"] = "nil",
        ["manage_msg_threshold"] = "nil",
        ["modeltype"] = "nil",
        ["position"] = "nil",
        ["scene"] = "nil",
        ["slotid"] = "nil",
        ["sourcescene"] = "nil",
        ["sourcesceneslotid"] = "nil"
    }, nil)
    -- 阈值
    mManageMsgThreshold = toNumber(mConfigData["manage_msg_threshold"], MANAGE_MSG_THRESHOLD_DEF)
end

-- 获取itemData光子数据
function getViewPhotonData()
    local itemNum = toNumber(mConfigData["item_num"], -1)
    mJavaBridge:Log(TAG.." getViewPhotonData() itemNum", tostring(itemNum))
    if itemNum < 0 then
        return
    end
    local photonViewData = {}
    for index = 1, itemNum do
        -- 是否添加
        local photoInsert = false
        local itemData = getPhotonItemData(index)
        if not checkTableNilOrEmpty(itemData) then
            -- 新版本首发
            if itemData["msg_type"] == '1' then
                photoInsert = checkNewVersionPhotonData(itemData)
            -- 应用更新
            elseif itemData["msg_type"] == '2' then
                photoInsert = checkValidUpdatePhotonData(itemData)
            -- 安装包清理
            elseif itemData["msg_type"] == '3' then
                photoInsert = checkInstallPackagePhotonData(itemData)
            -- 人工运营消息
            elseif itemData["msg_type"] == '4' then
                photoInsert = checkOperatePhotonData(itemData)
            end
        end
        if photoInsert then
            table.insert(photonViewData, itemData)
        else 
            mJavaBridge:Log(TAG.." getViewPhotonData() itemData", choose(checkNil(itemData), 'nil'
            , string.format("msg_id: %s, msg_type: %s 被过滤", itemData['msg_id'], itemData['msg_type'])))
        end
    end
    return photonViewData
end

-- 获取光子卡片item数据
function getPhotonItemData(index)
    local itemStart = "item_data_"..index.."_"
    local itemData = queryRuleData({
        ["item_recommendid"] = "nil",
        ["msg_id"] = "nil",
        ["msg_type"] = "nil",
        ["icon"] = "nil",
        ["jump_url"] = "nil",
        ["king_card_main_title"] = "nil",
        ["king_card_sub_title"] = "nil",
        ["king_card_button"] = "nil",
        ["other_card_main_title"] = "nil",
        ["other_card_sub_title"] = "nil",
        ["other_card_button"] = "nil",
        ["app_num"] = 0
    }, itemStart)
    itemData["_query_start"] = itemStart
    itemData["app_icon_1"] = itemData["icon"]
    return itemData
end

-- 获取应用光子数据
function getAppPhotonData(start, index)
    local itemStart = start.."item_data_"..index.."_"
    local itemData = queryRuleData({
        ["app_id"] = "nil",
        ["app_name"] = "nil",
        ["app_package_name"] = "nil",
        ["app_icon"] = "nil",
        ["app_version_code"] = "nil",
        ["apk_size"] = "nil",
        ["apk_diff_size"] = "nil",
        ["is_diff"] = "nil"
    }, itemStart)
    return itemData
end

-- 判断是否是有效安装包数据
function checkValidUpdate(itemData)
    if checkTableNilOrEmpty(itemData) then
        return false
    end

    -- 没获取到本地版本号，为已卸载或未安装
    local pkgVersion = toNumber(mJavaBridge:getPkgVersion(itemData["app_package_name"]), -1)
    if pkgVersion < 0 then
        return false
    end

    -- 是否过滤
    local ignoreApp = mCall:isIgnoreApp(itemData["app_package_name"])
    if ignoreApp then
        return false
    end

    -- 是否是最新版本
    local appVersionCode = toNumber(itemData["app_version_code"], 0)
    if pkgVersion >= appVersionCode then
        return false
    end

    -- 是否能省流更新:1.省
    if itemData["is_diff"] == "1" then
        itemData["_offset_fw"] = mCall:calculate("subtract", itemData["apk_size"], itemData["apk_diff_size"])
        itemData["_offset_w"] = itemData["apk_diff_size"]
    else
        itemData["_offset_w"] = itemData["apk_size"]
    end

    return true
end

-- 检测是否新版本首发数据
function checkNewVersionPhotonData(itemData)
    local item2Data = getAppPhotonData(itemData['_query_start'], 1)

    if not checkValidUpdate(item2Data) then
        return false
    end

    itemData["app_name"] = item2Data["app_name"]
    itemData["app_icon_1"] = item2Data["app_icon"]
    itemData["_offset_w"] = item2Data['_offset_w']
    itemData["_offset_fw"] = item2Data['_offset_fw']

    if itemData["jump_url"] ~= nil and item2Data['app_id'] ~= nil then
        itemData["jump_url"] = string.format("%s?appid=%s", itemData["jump_url"], item2Data['app_id'])
    end

    return true
end

-- 检测是否应用更新数据
function checkValidUpdatePhotonData(itemData)
    local app_name_1
    local app_icon_1
    local app_icon_2
    local app_id_1
    local app_id_2
    local validCount = 0
    local validSizeW = '0'
    local validSizeFw = '0'
    for index = 1, toNumber(itemData["app_num"], 0) do
        local item2Data = getAppPhotonData(itemData['_query_start'], index)
        -- 判断是否是有效安装包数据
        if checkValidUpdate(item2Data) then
            validCount = validCount + 1
            validSizeW = mCall:calculate("add", validSizeW, item2Data['_offset_w'])
            mJavaBridge:Log(TAG.." validSizeFw", validSizeFw)
            mJavaBridge:Log(TAG.." item2Data['_offset_fw']", item2Data['_offset_fw'])
            validSizeFw = mCall:calculate("add", validSizeFw, item2Data['_offset_fw'])
            if app_icon_1 == nil then
                app_icon_1 = item2Data['app_icon']
                app_name_1 = item2Data['app_name']
                app_id_1 = item2Data['app_id']
            elseif app_icon_2 == nil then
                app_icon_2 = item2Data['app_icon']
                app_id_2 = item2Data['app_id']
            end
        end
    end

    -- 过滤
    if validCount <= 0 then
        return false
    end

    itemData["app_name"] = app_name_1
    itemData["app_icon_1"] = app_icon_1
    itemData["app_icon_2"] = app_icon_2
    itemData["app_msg_count"] = validCount
    itemData["_offset_w"] = validSizeW
    itemData["_offset_fw"] = validSizeFw

    local endJumpUrl = app_id_1
    if endJumpUrl == nil then
        endJumpUrl = app_id_2
    elseif app_id_2 ~= nil then
        endJumpUrl = endJumpUrl..','..app_id_2
    end

    if itemData["jump_url"] ~= nil and endJumpUrl ~= nil then
        itemData["jump_url"] = string.format("%s?appid=%s", itemData["jump_url"], endJumpUrl)
    end

    return true
end

-- 检测是否安装包清理数据
function checkInstallPackagePhotonData(itemData)

    mJavaBridge:Log(TAG.." checkInstallPackagePhotonData()", "最新的安装包扫描状态 => "..chooseMi(mCall:getPkgScanStatus(), 'nil'))

    -- 是否是最新的安装包数据
    if mCall:getPkgScanStatus() ~= PKG_SCAN_STATUS_YES then
        mJavaBridge:Log(TAG.." checkInstallPackagePhotonData() 拦截：", "最新的安装包扫描状态 => "..chooseMi(mCall:getPkgScanStatus(), 'nil'))
        return false
    end

    -- 清理数量
    if toNumber(mApkSizeByClear, 0) <= 0 then
        mJavaBridge:Log(TAG.." checkInstallPackagePhotonData() 拦截：", "清理数量 => "..chooseMi(mApkSizeByClear, 'nil'))
        return false
    end

    -- 清理大小
    if toNumber(mTotalApkMemorySizeByClear, 0) <= 0 then
        mJavaBridge:Log(TAG.." checkInstallPackagePhotonData() 拦截：", "清理大小 => "..chooseMi(mTotalApkMemorySizeByClear, 'nil'))
        return false
    end
    
    itemData["app_msg_count"] = mApkSizeByClear
    itemData["flow_save_size"] = mTotalApkMemorySizeByClear

    return true
end

-- 检测是否人工运营消息
function checkOperatePhotonData(itemData)
    -- 是否已经触发过
    if getSettingsData(MESSAGE_ID, itemData["msg_id"], "false") == "true" then
        return false
    end
    return true
end

-- 填入视图和数据
function fillViewOrDataList(viewList, dataList)
    local viewPhotonData = getViewPhotonData()
    mJavaBridge:Log(TAG.." fillViewOrDataList() viewPhotonData", choose(checkNil(viewPhotonData), 'nil', #viewPhotonData))
    if checkTableNilOrEmpty(viewPhotonData) then
        return
    end
    for index, itemData in pairs(viewPhotonData) do
        insertTable(viewList, dataList, {
            ["msg_id"] = itemData["msg_id"],
            ["msg_type"] = itemData["msg_type"],
            ["app_name"] = itemData["app_name"],
            ["app_msg_count"] = itemData["app_msg_count"],
            ["flow_save_size"] = itemData["flow_save_size"],
            ["_offset_w"] = itemData["_offset_w"],
            ["_offset_fw"] = itemData["_offset_fw"],
            ["app_icon_1"] = itemData["app_icon_1"],
            ["app_icon_2"] = itemData["app_icon_2"],
            ["app_msg_title_1"] = itemData["king_card_main_title"],
            ["app_msg_title_2"] = itemData["other_card_main_title"],
            ["item_sub_title_1"] = itemData["king_card_sub_title"],
            ["item_sub_title_2"] = itemData["other_card_sub_title"],
            ["app_operate_1"] = itemData["king_card_button"],
            ["app_operate_2"] = itemData["other_card_button"],
            ["app_jump_url"] = itemData["jump_url"],
            ["item_recommendid"] = itemData["item_recommendid"]
        })
    end
end

-- 清理并更新数据
function clearAndUpdateData(viewList, dataList)
    Rapid:setData("card_page_count", #viewList)
    if #dataList > 1 then
        Rapid:setData("card_indicate_visibility", "visible")
    else
        Rapid:setData("card_indicate_visibility", "gone")
    end
    -- 没数据时隐藏整个card
    Rapid:getChild("card_container"):setAttr("visibility", choose(checkTableNilOrEmpty(dataList), "gone", "visible"))

    -- setWhichChild()方法在updateData之前才有效
    mViewFlipper:getView():setWhichChild(0)
    mViewFlipper:getView():updateData(viewList, dataList)
    Rapid:getChild("indicate_view"):setAttr("selecteddotindex", "0")
end

-- 加载数据
function loadData()
    Rapid:Log("realhe","loadData trace")
    logHelper()
    obtainData()
    local viewList = {}
    local dataList = {}
    -- 填入视图和数据
    fillViewOrDataList(viewList, dataList)
    -- 清理并更新数据
    clearAndUpdateData(viewList, dataList)
end