require("playing_game_welfare_ui_style")
local mPhotonView, mJavaBridge = ...

local recyclerView

function refreshData(...)
    recyclerView = Rapid:getChild("recyclerview")
    local itemCount = tonumber(Rapid:getData("item_count"))
    local viewName = "playing_game_gift_rv_item.xml"
    local viewNameList = {}
    local dataList = {}
    local index = 1
    for i = 0, itemCount - 1 do
        local data = {}
        data["gift_tag"] = Rapid:getData("gift_tag_" .. index)
        data["icon_url"] = Rapid:getData("icon_url_" .. index)
        data = WelfareStyleCfg.mergeToTable(data, WelfareStyleCfg.gameGiftItemStyle())
        local visibility = "visible"
        if data["gift_tag"] == nil or data["gift_tag"] == "" then
            visibility = "gone"
        end
        data["visibility"] = visibility

        --设置子卡的上报信息
        data["gift_report_context"] = Rapid:getData("gift_report_context", "")
        data["card_report_context"] = Rapid:getData("card_report_context", "")
        data["source_report_context"] = Rapid:getData("source_report_context", "")
        data["recommendid"] = Rapid:getData("recommendid", "")

        data["scene"] = Rapid:getData("scene", "")
        data["slotid"] = Rapid:getData("slotid", "")
        data["subposition"] = Rapid:getData("subposition", "")
        data["sourcescene"] = Rapid:getData("sourcescene", "")
        data["sourcesceneslotid"] = Rapid:getData("sourcesceneslotid", "")
        data["sourcemodeltype"] = Rapid:getData("sourcemodeltype", "")
        data["modeltype"] = Rapid:getData("modeltype", "")
        data["uni_channel_appid"] = Rapid:getData("uni_channel_appid", "")

        table.insert(viewNameList, viewName)
        table.insert(dataList, data)
        index = index + 1
    end
    local actionListner =
        luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonActionListener", IActionListener)
    recyclerView:getView():setActionListener(actionListner)
    recyclerView:getView():updateData(viewNameList, dataList, true)
end
IActionListener = {}
function IActionListener.notify(key, value)
    if (key == "go_detail") then
        goDetail()
    end
end
function goDetail(...)
    Rapid:runTask("jump_more_gift")
end
