local mPhotonView,mJavaBridge = ...

function init()
    -- appid数据设置
    local app_icon_count = tonumber(Rapid:getData('app_icon_count','0'))
    local uni_related_appid = ""
    for i=1,app_icon_count do
        local appid = Rapid:getData('app_id_' .. i,'')
        uni_related_appid = uni_related_appid .. appid

        if i ~= app_icon_count and appid ~= "" then
            uni_related_appid = uni_related_appid .. ";"
        end
    end
    Rapid:setData('uni_related_appid',uni_related_appid)

    -- 标题富文本检测
    local title = Rapid:getData('title','')
    if string.find( title, "<") ~= nil then
        Rapid:getChild('tv_title'):setAttr("htmltext",title)
    else
        Rapid:getChild('tv_title'):setAttr("text",title)
    end

end

function doGoForward()
    local url = Rapid:getData('jump_url')
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:tmastJumpWithCaller(url)
        dialogSelf:dismiss(5,0)
    end
end

function close()
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:dismiss(1,0)
    end
end


function onPageOut(stayDuration)
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:2000,slotid:-1_-1,actionid:2005,subposition:-1,modeltype:-1"
    params1["extendparam"] = "report_element:page,stay_duration:"..stayDuration
    actionRunner:run("reportaction", params1, nil)
end

function onDismiss(dismissType)
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:2000,slotid:99_001,actionid:201,subposition:001,modeltype:data@modeltype"
    params1["extendparam"] = "report_element:pop,uni_popid:data@uni_popid,uni_pop_type:data@uni_pop_type,uni_pop_configid:data@uni_pop_configid,uni_monitor_event_code:data@uni_monitor_event_code,uni_condition:data@uni_condition_key,uni_related_appid:data@uni_related_appid,uni_cancel_type:"..dismissType
    params1["recommendid"] = "data@R1"
    actionRunner:run("reportaction", params1, nil)
end