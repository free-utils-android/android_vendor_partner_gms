local mPhotonView, mJavaBridge = ...

local mRecyclerView
local cardSlotId
local num

function init()
    mRecyclerView = mPhotonView:getParser():getChildView('recyclerView')
end

function updateValue()
    local totalSubViewNum = mPhotonView:getParser():getBinder():get('totalSubViewNum')
    local totalItem = mPhotonView:getParser():getBinder():get('totalItem')

    local binder = mPhotonView:getParser():getBinder()
    local newSlotId = binder:get('slotId')
    cardSlotId = newSlotId
    -- 点击“全部按钮”时，带到落地页的sourcesceneslotid
    local btnAllTmastSlotId = newSlotId .. '_-1_-1_999'
    mPhotonView:getParser():getBinder():update('btn_all_tmast_slotid', btnAllTmastSlotId)

    num = tonumber(totalItem)
    if (num == nil or num == 0) then
        return
    end

    mRecyclerView:getView():clear()
    mRecyclerView:getView():setMaxFlingCount(5000)

    local realDataList = {}
    local realViewList = {}

    local keyIndex = 1
    for index = 1, num do
        local data = {}
        data['app_click_jump'] = binder:get('app_click_jump' .. index)
        data['item_icon'] = binder:get('item_icon' .. index)
        data['item_appName'] = binder:get('item_appName' .. index)
        data['item_appDesc'] = binder:get('item_appDesc' .. index)
        data['font_color'] = binder:get('font_color')
        data['appModel'] = binder:get('appModel' .. index)
        data['item_appId'] = binder:get('item_appId' .. index)
        data['packagename'] = binder:get('item_pkgName' .. index)
        data['recommendid'] = binder:get('R' .. index)
        local subposition = getReportPosition(keyIndex)
        data['subPosition'] = subposition
        data['newSlotId'] = newSlotId
        data['sourceScene'] = binder:get('sourcescene')
        data['sourceSceneSlotId'] = binder:get('sourcesceneslotid')

        data['sourcescene'] = binder:get('sourcescene')
        data['sourcesceneslotid'] = binder:get('sourcesceneslotid')
        data['tmastslotid'] = newSlotId .. '_-1_-1_' .. subposition

        data['scene'] = binder:get('scene')
        data['modeltype'] = binder:get('modeltype')
        realDataList[keyIndex] = data
        realViewList[keyIndex] = 'native_appdetail_horiscroll_item_card.xml'
        keyIndex = keyIndex + 1
    end

    mRecyclerView:getView():updateData(realViewList, realDataList)
end

function getReportPosition(position)
    local reportPosition
    reportPosition = '00' .. position
    if (position >= 10) then
        reportPosition = '0' .. position
    end
    return reportPosition
end

--当卡片滚动显示出来时曝光前五个应用
function reportFiveApp()
    if (num == nil or num == 0 or cardSlotId == nil) then
        return
    end
    for index = 1, 5 do
        local slotId = cardSlotId .. '_-1'
        local data = {}
        data['param'] =
            'slotid:' ..
            slotId ..
                ',actionid:100,subposition:' ..
                    getReportPosition(index) ..
                        ',scene:data@scene,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,appid:data@item_appId' ..
                            tostring(index) .. ',searchid:0,packagename:data@item_pkgName' .. tostring(index)
        data['recommendid'] = 'data@R' .. index
        mPhotonView:getParser():getTaskCenter():getActionRunner():run('reportaction', data, data)
    end
end
