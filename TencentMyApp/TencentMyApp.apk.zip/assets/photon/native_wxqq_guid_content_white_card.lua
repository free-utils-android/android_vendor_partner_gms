local mPhotonView,mJavaBridge = ...
local Color = luajava.bindClass('android.graphics.Color')
local GB = 1024*1024*1024

function updateValue()
  local showProgressBar = mPhotonView:getParser():getBinder():get("need_show_progress")
  local cardStyle = mPhotonView:getParser():getBinder():get("cardStyle")


  local textView = mPhotonView:getParser():getChildView("function_btn")
  local videoSize = mPhotonView:getParser():getBinder():get("videoSize")

  --mPhotonView:getParser():getChildView("function_btn"):getView():setText('338MB')

  if showProgressBar == '1' then
    mPhotonView:getParser():getChildView("progress_bar"):getView():setVisibility(0)
  else
    mPhotonView:getParser():getChildView("progress_bar"):getView():setVisibility(8)
    -- 视频 11； 图片 12； 音频 13； 文件14；
    if cardStyle == '11' then
      local videoSize = mPhotonView:getParser():getBinder():get("videoSize")
      local videoSizeStr = mJavaBridge:formatSizeKorMorG(videoSize)
      if videoSizeStr ~=nil and videoSizeStr ~= "" then
        textView:getView():setText(videoSizeStr)
      end
      if tonumber(tonumber(videoSize, 10)) > GB then
        textView:getView():setTextColor(Color:parseColor("#f86273"))
      end
    end

    if cardStyle == '12' then
      local picSize = mPhotonView:getParser():getBinder():get("picSize")
      local picSizeStr = mJavaBridge:formatSizeKorMorG(picSize)
      if picSizeStr ~=nil and picSizeStr ~= "" then
        textView:getView():setText(picSizeStr)
      end

      if tonumber(tonumber(picSize, 10)) > GB then
        textView:getView():setTextColor(Color:parseColor("#f86273"))
      end

    end

    if cardStyle == '13' then
      local voiceSize = mPhotonView:getParser():getBinder():get("voiceSize")
      local voiceSizeStr = mJavaBridge:formatSizeKorMorG(voiceSize)
      if voiceSizeStr ~=nil and voiceSizeStr ~= "" then
        textView:getView():setText(voiceSizeStr)
      end

      if tonumber(tonumber(voiceSize, 10)) > GB then
        textView:getView():setTextColor(Color:parseColor("#f86273"))
      end

    end

    if cardStyle == '14' then
      local fileSize = mPhotonView:getParser():getBinder():get("fileSize")
      local fileSizeStr = mJavaBridge:formatSizeKorMorG(fileSize)
      if fileSizeStr ~=nil and fileSizeStr ~= "" then
        textView:getView():setText(fileSizeStr)
      end

      if tonumber(tonumber(fileSize, 10)) > GB then
        textView:getView():setTextColor(Color:parseColor("#f86273"))
      end

    end

  end





end



