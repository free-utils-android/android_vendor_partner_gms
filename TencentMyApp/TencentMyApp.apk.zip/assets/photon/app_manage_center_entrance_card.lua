local mPhotonView,mJavaBridge = ...
local TAG = "app_manager_center_entrance_card_lua"
local mRecyclerView
local mCardContinerView
local ENTRANCE_UPDATE = 0
local ENTRANCE_DOWNLOAD = 1

function loadFinish()
    mRecyclerView     = Rapid:getChild('recycler_view')
    mCardContinerView = Rapid:getChild('card_container')
end

function afterUpdateData()
    local item_num = tonumber(Rapid:getData("item_num", "0"))
    -- 配置入口不等于4整个卡片不展示
    if item_num == 4 then
        mCardContinerView:getView():setVisibility(0)
    else
        mCardContinerView:getView():setVisibility(8)
    end
    
    local dataList = {}
    local viewNameList = {}
    local subViewName = 'app_manage_center_entrance_card_item.xml'
    local modeltype = Rapid:getData("modeltype")
    local card_recommendid = Rapid:getData("card_recommendid")
    local card_title = Rapid:getData("card_title")
    local slotid = Rapid:getData("slotid")
    local scene = Rapid:getData("scene")
    local sourcescene = Rapid:getData("sourcescene")
    local sourcesceneslotId = Rapid:getData("sourcesceneslotid")

    for i = 1,item_num do

        local item_data_fuction_id = Rapid:getData("item_data_"..i.."_function_id")
        local item_data_item_icon = Rapid:getData("item_data_"..i.."_item_icon")
        local item_data_item_title = Rapid:getData("item_data_"..i.."_item_title")
        local item_data_jump_url = Rapid:getData("item_data_"..i.."_jump_url")
        local item_data_entrance_recommendid = Rapid:getData("item_data_"..i.."_entrance_recommendid")
        local item_data_red_num = 0
        local itemData = {}

        itemData["scene"] = scene
        itemData["subposition"] = i
        itemData["slotid"] = slotid
        itemData["modeltype"] = modeltype
        itemData["sourcescene"] = sourcescene
        itemData["sourcesceneslotId"] = sourcesceneslotId
        itemData["item_data_fuction_id"] = item_data_fuction_id
        itemData["item_data_entrance_recommendid"] = item_data_entrance_recommendid
        itemData["item_data_item_icon"] = item_data_item_icon
        itemData["item_data_item_title"] = item_data_item_title
        itemData["item_data_jump_url"] = item_data_jump_url
       
        -- 下载管理首次页面加载数据获取
        if ENTRANCE_DOWNLOAD == tonumber(item_data_fuction_id) then
            item_data_red_num = mJavaBridge:callModule('AppManager', 'getDownloadingApkCount')
            local item_pause_num = mJavaBridge:callModule('AppManager', 'getDownloadPauseApkCount')

            if item_data_red_num == nil then
               item_data_red_num = 0
            end

            if item_pause_num == nil then
                item_pause_num = 0
            end

            item_data_red_num = item_data_red_num + item_pause_num

        -- 应用更新首次页面加载数据获取
        elseif ENTRANCE_UPDATE == tonumber(item_data_fuction_id) then
            item_data_red_num = mJavaBridge:getUpdateAppNums()
            if item_data_red_num == nil then
               item_data_red_num = 0
            end
            Rapid:Log(TAG, "getUpdateAppNums():"..item_data_red_num)
        end
        
        itemData["item_data_red_num"] = mJavaBridge:create("Var", item_data_red_num)

        if item_data_red_num > 0 then
            itemData["item_data_red_visible"] = "VISIBLE"
        else
            itemData["item_data_red_visible"] = "GONE"
        end

        dataList[i]     = itemData
        viewNameList[i] = subViewName
    end

    mRecyclerView:getView():clear()
    mRecyclerView:getView():updateData(viewNameList, dataList)
end