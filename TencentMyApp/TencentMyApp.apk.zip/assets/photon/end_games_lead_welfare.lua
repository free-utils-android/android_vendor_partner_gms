local mPhotonView, mJavaBridge = ...
local Rapid

local TAG = "lua_endgames_lead_welfare"
local GIFT_CAN_GET = "0"
local GIFT_CAN_TOMORROW_GET = "1"
local GIFT_LIMIT = "2"
local GIFT_HAS_GET = "3"
local GIFT_COUPON_TYPE = "3"
local AUTHORIZE_CMD = 306
local APP_TAG= "?appIds=%s"

local welfare = {}
local mAuthString = ""
local mAuthorize = false
local mAuthUrl = nil
local mAuthTable = {}
local mAppId = 0
local mNeedRole = false
local mNeedServer = true
local mServerDialogShowing = false
local mCallBack
local mAlreadyReceiveClick = false
local mSelectDialog
local isClickLoginPage = false

function welfare.init(photonView, javaBridge, rapid, callback)
    mPhotonView = photonView
    mJavaBridge = javaBridge
    Rapid = rapid
    mCallBack = callback
    mJavaBridge:Log(TAG, "welfare.init")
end

function welfare.afterUpdateData()
    mJavaBridge:Log(TAG, "welfare.afterUpdateData")
    isClickLoginPage = false
    initLoginFlag()
    initAuthorizeJumpFlag()
    initAuthorizeParam()
    parserAuthorize(mAuthString)
end

function welfare.onResume()
    mJavaBridge:Log(TAG, "welfare.onResume")
    requestQueryIfNeeded()
    updateAuthorizeJumpFlag()
end

function setSettingsData(key, value)
    mJavaBridge:setNormalSettingsData('lua_endgames_lead_card_'..tostring(key), value)
end

function getSettingsData(key, def)
    return mJavaBridge:getNormalSettingsData('lua_endgames_lead_card_'..tostring(key), def)
end

function initLoginFlag()
    mJavaBridge:Log(TAG, "initLoginFlag")
    setSettingsData('loginFlag', 0)
end

function getLoginFlag()
    return tonumber(getSettingsData('loginFlag', '0'))
end

function updateLoginFlag()
    local loginFlag = getLoginFlag()
    setSettingsData('loginFlag', loginFlag + 1)
    mJavaBridge:Log(TAG, "updateLoginFlag loginFlag: "..tostring(getLoginFlag()))
end

function initAuthorizeJumpFlag()
    mJavaBridge:Log(TAG, "initAuthorizeJumpFlag")
    setSettingsData('authorizeJumpFlag', 0)
end

function getAuthorizeJumpFlag()
    return tonumber(getSettingsData('authorizeJumpFlag', '0'))
end

function updateAuthorizeJumpFlag()
    local authorizeJumpFlag = getAuthorizeJumpFlag()
    setSettingsData('authorizeJumpFlag', authorizeJumpFlag + 1)
    mJavaBridge:Log(TAG, "updateAuthorizeJumpFlag authorizeJumpFlag: "..tostring(getAuthorizeJumpFlag()))
end

function requestQueryIfNeeded() 
    local mAuthorize = isCurrentAppAuthorized()
    mJavaBridge:Log(TAG, "requestQueryIfNeeded mAuthorize: "..tostring(mAuthorize))
    if mAuthorize then
        mJavaBridge:Log(TAG, "has been authorized before!")
        return
    end
    if getAuthorizeJumpFlag() > 0 then
        return
    end
    sendPermissionQueryRequest()
end

function welfare.onLoginSucceed()
    mJavaBridge:Log(TAG, "welfare.onLoginSucceed")
    if mJavaBridge:getLoginType() == "NONE" then
        return
    end
    if getLoginFlag() > 0 then
        return
    end
    updateLoginFlag()
    sendPermissionQueryRequest()
end

function welfare.receive()
    mJavaBridge:Log(TAG, "welfare.receive")
    -- 判断是否登录
    if mJavaBridge:getLoginType() == "NONE" then
        openLoginActivity()
        return
    end
    
    mAuthorize = isCurrentAppAuthorized()
    mJavaBridge:Log(TAG, "welfare.receive mAuthorize: "..tostring(mAuthorize))
    if not mAuthorize then
        showAuthorizeDialog()
        return
    end
    
    showServers()
end

function welfare.clearPermission()
    mJavaBridge:Log(TAG, "welfare.clearPermission")
    sendPermissionClearRequest()
end

function welfare.onUserLeadReceive(succeed, viewNameList, dataList)
    if mCallBack == nil then
        return
    end
    mCallBack.onUserLeadReceive(succeed, viewNameList, dataList)
end

function welfare.onWritePermissionSucceed()
    if mCallBack == nil then
        return
    end
    mCallBack.onWritePermissionSucceed()
end

function welfare.onSendGiftRequest(serverID, serverName, roleID, roleName)
    if mCallBack == nil then
        return
    end
    mCallBack.onSendGiftRequest(serverID, serverName, roleID, roleName)
end

function xLog(fun, note, data)
    mJavaBridge:Log(TAG, tostring(fun).." "..tostring(note)..": "..tableToString(data))
end

function tableToString(data)
    if type(data) == 'table' then
        local text = ''
        for k, v in pairs(data) do
            if text == '' then
                text = '{\"'..tostring(k)..'\":\"'..tostring(v)..'\"'
            else
                text = text..',\"'..tostring(k)..'\":\"'..tostring(v)..'\"'
            end
        end
        if text ~= '' then
            text = text..'}'
        end
        return text
    else
        return tostring(data)
    end
end

function initAuthorizeParam()
    mAuthString = Rapid:getData("personal_security_json", "")
    mAppId = tonumber(Rapid:getData("app_id", ""))
    mAuthUrl = Rapid:getData("auth_detail_jump_url")
end

function openLoginActivity()
    mJavaBridge:Log(TAG, "openLoginActivity")
    local jsParams = {}
    jsParams["logintype"] = "DEFAULT"
    mJavaBridge:runJsBridge("openLoginActivity", jsParams, nil)
    isClickLoginPage = true
    initLoginFlag()
end

function showServers()
    local params = {}
    params["pkgName"] = Rapid:getData("pkg_name", "")
    params["appid"] = Rapid:getData("app_id", "")
    xLog("showServers", "params", params)
    mJavaBridge:request(2198, params, onServerRequestListener)
end

function onServerRequestListener(succeed, viewNameList, dataList)
    mJavaBridge:Log(TAG, "onServerRequestListener")
    if (succeed) then
        showServerRoleSelectorDialog(dataList)
    else
        mJavaBridge:showToast("获取区服失败", 1000)
    end
end

function showServerRoleSelectorDialog(dataList)
    mJavaBridge:Log(TAG, "showServerRoleSelectorDialog")
    local defaultServer = ""
    local serversList = ""
    
    if dataList == nil or dataList:size() < 1 then
        mJavaBridge:showToast("获取区服信息失败", 1000)
        return
    end
    
    local dataMap = dataList:get(0)
    mJavaBridge:Log(TAG, "showServerRoleSelectorDialog ret: "..tostring(dataMap:get("ret")))
    mJavaBridge:Log(TAG, "showServerRoleSelectorDialog msg: "..tostring(dataMap:get("msg")))
    local retCode = tonumber(tostring(dataMap:get("ret")))
    local errorMsg = dataMap:get("msg")
    if retCode == nil then
        return
    end
    if retCode ~= 0 then
        if errorMsg == nil then
            errorMsg = "获取区服信息失败,错误码："..tostring(retCode)
        end
        mJavaBridge:showToast(tostring(errorMsg), 1000)
        return
    end

    local serverList = dataMap:get("partitionList")
    local defaultServer = dataMap:get("defaultServer")
    local defaultRole = dataMap:get("defaultRole")

    local dialogParams = {}
    dialogParams["default_server"] = tostring(defaultServer)
    dialogParams["default_role"] = tostring(defaultRole)
    dialogParams["servers"] = tostring(serverList)
    dialogParams["need_role"] = mNeedRole
    dialogParams["need_server"] = mNeedServer
    dialogParams["pkg_name"] = Rapid:getData("pkg_name", "")

    xLog("showServerRoleSelectorDialog", "dialogParams", dialogParams)

    if mServerDialogShowing then
        return
    end
    mServerDialogShowing = true

    if mSelectDialog ~= nil then
        mSelectDialog:dismiss()
    end
    mSelectDialog = mJavaBridge:showCustomDialogAsync("end_games_lead_server_selector_dialog.xml", 
        dialogParams, nil, "资源拉取失败，请稍后重试")
    local dialogListner = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",
        ServerRoleDialogEventListener)
    mSelectDialog:setPhotonDialogEventListener(dialogListner)
end

ServerRoleDialogEventListener = {}
function ServerRoleDialogEventListener.onDialogEvent(eventType, dialogData)
    mJavaBridge:Log(TAG, "ServerRoleDialogEventListener.onDialogEvent")
    initLoginFlag()
    if eventType == "ON_SERVER_ROLE_SELECTED" and dialogData ~= nil then
        local serverID = tostring(dialogData:get("selecetd_server_id"))
        local serverName = tostring(dialogData:get("selecetd_server_name"))
        local roleID = tostring(dialogData:get("selecetd_role_id"))
        local roleName = tostring(dialogData:get("selecetd_role_name"))
        sendGiftRequest(serverID, serverName, roleID, roleName)
    elseif eventType == "DISMISS" then
        mServerDialogShowing = false
    end
end

function sendGiftRequest(serverID, serverName, roleID, roleName)
    xLog('sendGiftRequest', 'serverID', serverID)
    xLog('sendGiftRequest', 'serverName', serverName)
    xLog('sendGiftRequest', 'roleID', roleID)
    xLog('sendGiftRequest', 'roleName', roleName)
    Rapid:setData('serverID', serverID)
    Rapid:setData('serverName', serverName)
    Rapid:setData('roleID', roleID)
    Rapid:setData('roleName', roleName)
    userLeadReceive(serverID)
    welfare.onSendGiftRequest(serverID, serverName, roleID, roleName)
end

function userLeadReceive(serverID)
    local params = {}
    params['type'] = 'user_lead_receive'
    params['platform_gift_id'] = Rapid:getData('platform_gift_id')
    params['gift_template_id'] = Rapid:getData('gift_template_id')
    params['present_type'] = Rapid:getData('present_type')
    params['partition'] = serverID
    xLog('userLeadReceive', 'params', params)
    mJavaBridge:request(3003, params, onUserLeadReceiveListener)
end

function onUserLeadReceiveListener(succeed, viewNameList, dataList)
    xLog('onUserLeadReceiveListener', 'succeed', succeed)
    welfare.onUserLeadReceive(succeed, viewNameList, dataList)
end

function showAuthorizeDialog()
    mJavaBridge:Log(TAG, "showAuthorizeDialog")
    local itemData = {}
    itemData["title"] = "王者荣耀信息授权申请"
    itemData["content"] = "应用宝申请使用您的王者荣耀游戏信息，用于#1）游戏福利发放；#2）常玩英雄内容推荐；#可在“管理>右上角设置>游戏信息授权管理”查看和修改授权信息，也可点击下方蓝字修改："
    itemData["prompt"] = "游戏信息授权管理"
    if mSelectDialog ~= nil then
        mSelectDialog:dismiss()
    end
    mSelectDialog = mJavaBridge:showCustomDialogAsync("end_games_lead_authorize_dialog.xml", itemData, nil, "授权弹窗")
    local dialogListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",     
        AuthorizeDialogEventListener)
    mSelectDialog:setPhotonDialogEventListener(dialogListener)
end

AuthorizeDialogEventListener = {}
function AuthorizeDialogEventListener.onDialogEvent(eventType, dialogData)
    mJavaBridge:Log(TAG, "AuthorizeDialogEventListener: eventType: "..tostring(eventType)
        ..", dialogData: "..tostring(dialogData))
    initLoginFlag()

    if eventType == "ON_ONE_KEY_SELECTED" then
        sendPermissionAuthorizeRequest()
        mAlreadyReceiveClick = false
    elseif eventType == "ON_DETAIL_SELECTED" then
        jumpPage()
        mAlreadyReceiveClick = true
        initAuthorizeJumpFlag()
    elseif eventType == "ON_CLEAR_AUTHORIZE" then
        sendPermissionClearRequest()
        mAlreadyReceiveClick = false
    end
    mJavaBridge:Log(TAG, "AuthorizeDialogEventListener.onDialogEvent mAlreadyReceiveClick set: "..tostring(mAlreadyReceiveClick))
end

function jumpPage()
    local jumpUrl = Rapid:getData('auth_detail_jump_url')
    if jumpUrl == nil then
        mJavaBridge:Log(TAG, "Error: jumpPage() jumpUrl is nil")
        return
    end
    local params = {}
    params["tmast"] = jumpUrl
    Rapid:execAction("tmastaction", params, nil)
end

function sendPermissionQueryRequest()
    mJavaBridge:Log(TAG, "sendPermissionQueryRequest")
    local params = {}
    params["action"] = "0" -- action == 0 查询授权
    params["data"] = Rapid:getData("personal_security_json", "")
    xLog('sendPermissionQueryRequest', 'AUTHORIZE_CMD', AUTHORIZE_CMD)
    xLog('sendPermissionQueryRequest', 'params', params)
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function sendPermissionAuthorizeRequest()
    mJavaBridge:Log(TAG, "sendPermissionAuthorizeRequest")
    local params = {}
    params["action"] = "1" -- action == 1 写授权
    params["data"] = Rapid:getData("personal_security_json", "")
    xLog('sendPermissionAuthorizeRequest', 'AUTHORIZE_CMD', AUTHORIZE_CMD)
    xLog('sendPermissionAuthorizeRequest', 'params', params)
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function sendPermissionClearRequest()
    mJavaBridge:Log(TAG, "sendPermissionClearRequest")
    local params = {}
    params["action"] = "2"  -- action == 2 清除授权
    params["data"] = Rapid:getData("personal_security_json", "")
    xLog('sendPermissionClearRequest', 'AUTHORIZE_CMD', AUTHORIZE_CMD)
    xLog('sendPermissionClearRequest', 'params', params)
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function onPermissionRequestListener(succeed, viewNameList, dataList)
    mJavaBridge:Log(TAG, "onPermissionRequestListener")
    if dataList == nil or dataList:size() == 0 then
         mJavaBridge:Log(TAG, "onPermissionRequestListener dataList error!")   -- 写这里返回了
         return
    end
    if (succeed) then
        mJavaBridge:Log(TAG, " onPermissionRequestListener success!")
        onPermissionSucceed(viewNameList, dataList)
    else
        mJavaBridge:Log(TAG, " onPermissionRequestListener failure!")
    end
end

function onPermissionQuerySucceed()
    mJavaBridge:Log(TAG, "onPermissionQuerySucceed mAuthorize: "..tostring(mAuthorize))
    mJavaBridge:Log(TAG, "onPermissionQuerySucceed mAlreadyReceiveClick: "..tostring(mAlreadyReceiveClick))
    if mAlreadyReceiveClick and mAuthorize then
        showServers()
        return
    end
    local loginFlag = getLoginFlag()
    mJavaBridge:Log(TAG, "onPermissionQuerySucceed loginFlag: "..tostring(loginFlag))
    mJavaBridge:Log(TAG, "onPermissionQuerySucceed isClickLoginPage: "..tostring(isClickLoginPage))
    if loginFlag == 1 and isClickLoginPage then
        if mAuthorize then
            showServers()
        else
            showAuthorizeDialog()
        end
        isClickLoginPage = false
    end
end

function onPermissionSucceed(viewNameList, dataList)
    if dataList == nil or dataList:size() < 1 then
        return
    end

    local dataMap = dataList:get(0)
    if dataMap == nil then
        mJavaBridge:Log(TAG, "is_authorize get Error!")
        return
    end

    local action = tostring(dataMap:get("action"))
    mJavaBridge:Log(TAG, "action :"..tostring(action)) 
    if action == "0" then -- action == 0 查询授权
        local result = tostring(dataMap:get("result"))
        mJavaBridge:Log(TAG, "action query result :"..result)
        if result == nil then
            return
        end
        mAuthString = result
        parserAuthorize(mAuthString)
        onPermissionQuerySucceed()
    elseif action == "1" then -- action == 1 写授权
        mJavaBridge:Log(TAG, "action write")
        mAuthorize = true
        -- 授权成功自动调起来选择区服
        showServers()
        welfare.onWritePermissionSucceed()
    else -- action == 2 清除授权
        mJavaBridge:Log(TAG, "action clear:"..tostring(action)) 
    end
end

function parserAuthorize(authInfo)
    mJavaBridge:Log(TAG, "playing_game_name_id authInfo: "..tostring(authInfo))
    if authInfo == nil then
        return
    end

    local jsonAuthInfo = mJavaBridge:create('JSONObject', authInfo)
    if jsonAuthInfo == nil then
        return
    end

    local giftNum = tonumber(jsonAuthInfo:optString("total_num", ""))
    mJavaBridge:Log(TAG, "playing_game_name_id total_num: "..tostring(giftNum))
    local playingGames = jsonAuthInfo:optJSONArray("playing_games")
    if playingGames == nil then
        mJavaBridge:Log(TAG, "playingGames nil")
        return
    end

    for i = 0, giftNum - 1 do
        mJavaBridge:Log(TAG, "enter for")
        local playingItem = playingGames:optJSONObject(i)
        if playingItem == nil then
            mJavaBridge:Log(TAG, " playingItem nil")
            break
        end

        mJavaBridge:Log(TAG, "playing_game_name_id playingItem: "..tostring(playingItem))
        local appId = tonumber(playingItem:optString("game_id", ""))
        local appName = tostring(playingItem:optString("name", ""))

        mJavaBridge:Log(TAG, "playing_game_name_id playingItem id: "..tostring(appId).." name: "..tostring(appName))

        local playingSences = playingItem:optJSONArray("scenes")
        parserScence(playingSences, appId, appName)
    end
end

function parserScence(scene, appId, appName)
    if scene == nil then
        mJavaBridge:Log(TAG, "playing_game_name_id sence null appid: "..tostring(mAppId))
        return
    end

    mAuthTable = {}
    for i = 0, 2 do
        local playingSenceItem = scene:optJSONObject(i)
        if playingSenceItem == nil then
            return
        end

        local content = playingSenceItem:optString("content")
        local visual = playingSenceItem:optString("visual")
        mAuthTable[i + 1] = tonumber(visual)
    
        mJavaBridge:Log(TAG, "playing_game_name_id content: "..tostring(content)..", visual: "..tostring(visual))
    end

    local isAuthorize = isCurrentAppAuthorized()
    
    if appId == mAppId then
        mAuthorize = isAuthorize
        mJavaBridge:Log(TAG, "mAuthorize: "..tostring(mAuthorize))
    end
end

function isCurrentAppAuthorized()
    mJavaBridge:Log(TAG, "isCurrentAppAuthorized")
    local length = #mAuthTable
    if length <= 0 then
        return false
    end
    mJavaBridge:Log(TAG, "current appid: "..tostring(mAppId).." len: "..tostring(length))
    for i = 1, 3 do  
        if mAuthTable[i] == 2 then   -- 0 全部  1 自己 2 取消
            mJavaBridge:Log(TAG, "isCurrentAppAuthorized false") 
            return false
        end
    end
    mJavaBridge:Log(TAG, "isCurrentAppAuthorized true") 
    return true
end

-- 最终返回
return welfare