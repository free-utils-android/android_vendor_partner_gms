local mPhotonView, mJavaBridge = ...

function refreshView()
    local itemNum = tonumber(Rapid:getData('item_num','0'))

    for i=1, itemNum do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)

        if itemData ~= nil then
            local image = itemData:get('image')
            local name = itemData:get('name')
            local jump_url = itemData:get('jump_url')
            local report_context = itemData:get('report_context')
            local recommendid = itemData:get('recommendid')
            
            if image ~= nil then
                Rapid:setData('image_'..i, tostring(image))
            end

            if name ~= nil then
                Rapid:setData('name_'..i, tostring(name))
            end
            
            if jump_url ~= nil then
                Rapid:setData('jump_url_'..i, tostring(jump_url))
            end
            
            if report_context ~= nil then
                Rapid:setData('report_context_'..i, tostring(report_context))
            end
            
            if recommendid ~= nil then
                Rapid:setData('recommendid_'..i, recommendid:getLuaValue())
            end
        end
    end
end