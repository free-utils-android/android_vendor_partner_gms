local mPhotonView, mJavaBridge = ...




function report()
    local score = mJavaBridge:calcFinalScore()

    mJavaBridge:Log("qiwei","score==="..score)

    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local param = {}
    param["param"] = "actionid:200,slotid:data@slotId,subposition:data@subPosition,scene:data@scene,modeltype:data@modelType,sourcescene:data@sourceScene,sourcesceneslotid:data@sourceSceneSlotId"
    param["extendparam"] = "report_element:entrance,uni_entrance_id:data@uni_entrance_id,uni_manage_score:" ..score.. ",uni_card_title:data@uni_card_title"
    param["recommendid"] = "data@entrance_recommendid"
    actionRunner:run("reportaction", param, nil)

end

function saveRedDotStatus()
    local identify_id = Rapid:getData('identify_id','')

    mJavaBridge:setSettingsDataAsync("other_used_card_"..tostring(identify_id), "1")
end
