local mPhotonView, mJavaBridge = ...

local TAG = "authorized_full_hero"

function afterUpdateData( ... )
    if Rapid:getData("username","") ~= "" then
        Rapid:getChild("authorized_user"):setAttr("visibility","visible")
    else
        Rapid:getChild("authorized_user"):setAttr("visibility","gone")
    end
end

function changeUser( ... )
    showServers()
end

function showServers()
    local params = {}
    params["pkgName"] = Rapid:getData("pkg_name", "com.tencent.tmgp.sgame")
    params["appid"] = Rapid:getData("app_id", "12127266")
    mJavaBridge:request(2198, params, onServerRequestListener)
end

function onServerRequestListener(succeed, viewNameList, dataList)
    if (succeed) then
        showServerRoleSelectorDialog(dataList)
    else
        mJavaBridge:showToast("获取区服失败", 1000)
    end
end

function showServerRoleSelectorDialog(dataList)
    local defaultServer = ""
    local serversList = ""

    if dataList == nil or dataList:size() < 1 then
        mJavaBridge:showToast("获取区服信息失败", 1000)
        return
    end

    local dataMap = dataList:get(0)
    local retCode = tonumber(tostring(dataMap:get("ret")))
    local errorMsg = dataMap:get("msg")
    if retCode ~= 0 then
        if errorMsg == nil then
            errorMsg = "获取区服信息失败,错误码："..tostring(retCode)
        end
        mJavaBridge:showToast(tostring(errorMsg), 1000)
        return
    end

    local serverList = dataMap:get("partitionList")
    local defaultServer = dataMap:get("defaultServer")
    local defaultRole = dataMap:get("defaultRole")

    local dialogParams = {}
    dialogParams["default_server"] = tostring(defaultServer)
    dialogParams["default_role"] = tostring(defaultRole)
    dialogParams["servers"] = tostring(serverList)
    dialogParams["need_role"] = Rapid:getData("need_role",false)
    dialogParams["need_server"] = true
    dialogParams["pkg_name"] = Rapid:getData("pkg_name", "com.tencent.tmgp.sgame")

    if mServerDialogShowing then
        return
    end
    mServerDialogShowing = true

    local selectDialog = mJavaBridge:showCustomDialogAsync("common_server_selector_dialog_v3.xml", 
        dialogParams, nil, "资源拉取失败，请稍后重试")
    local dialogListner = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",
        ServerRoleDialogEventListener)
    selectDialog:setPhotonDialogEventListener(dialogListner)
end

ServerRoleDialogEventListener = {}
function ServerRoleDialogEventListener.onDialogEvent(eventType, dialogData)
    if eventType == "ON_SERVER_ROLE_SELECTED" and dialogData ~= nil then
        mServerName = tostring(dialogData:get("selecetd_server_name"))
        mServerID = tostring(dialogData:get("selecetd_server_id"))
        mRoleName = tostring(dialogData:get("selecetd_role_name"))
        mRoleID = tostring(dialogData:get("selecetd_role_id"))
        reportPermissionSucceed()
        local value = mServerID
        if mRoleName == "nil" then
            value = value..","
        else 
            value = value..","..mRoleName
        end
        local param = {}
        param["key"] = "authorized"
        param["value"] = value
        Rapid:execAction("outeraction", param, param)
    elseif eventType == "DISMISS" then
        mServerDialogShowing = false
    end
end

function reportPermissionSucceed()
    local reportParams = {}
    reportParams["viewid"] = "already_challenge_container"
    reportParams["dteventkey"] = "clck"
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:510,scene:data@scene,sourceScene:data@sourcescene,modeltype:-1,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:0,searchid:0"
    reportParams["extendparam"] = "report_element:permission,source_report_context:data@source_report_context,perm_source:newuser_guidance"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end