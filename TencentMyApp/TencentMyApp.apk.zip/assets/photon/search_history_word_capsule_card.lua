local mPhotonView, mJavaBridge = ...

local TAG = "search_history_word_capsule_card"
local MAX_SEARCH_HISTORY_NUM = 10
local MAX_WIDTH_TEXT = "一二三四五"

local mRecyclerView
local mSearchHistory
local mActionListener
local mIActionListener = {}
local mSearchHistoryData
local mIPhotonActionListener
local mClearAllSearchHistoryDialog
local mTextPaint
local mTextMaxWidth

local function getTextMaxWidth(str, def)
    if str == nil or mTextPaint == nil or mTextMaxWidth == nil then
        return def
    end
    local textWidth = mJavaBridge:px2dip(mTextPaint:measureText(str))
    if textWidth > mTextMaxWidth then
        return mTextMaxWidth
    end
    return def
end

local function getPositionString(position)
    return string.format("%03d", position)
end

-- 填充数据
local function fillViewOrDataList(viewNameList, dataList, searchHistoryData)
    mSearchHistoryData = searchHistoryData
    if searchHistoryData == nil then
        return
    end

    local R1 = Rapid:getData('R1', '')
    local modeltype = Rapid:getData('modeltype', '')
    local scene = Rapid:getData('scene', '')
    local slotId = Rapid:getData('slotId', '')
    local sourceScene = Rapid:getData('sourceScene', '')
    local sourceSceneSlotId = Rapid:getData('sourceSceneSlotId', '')
    local position = Rapid:getData('position', 0)
    local subPosition = getPositionString(position + 1)

    for i = 1, #searchHistoryData do
        table.insert(viewNameList, "search_history_word_capsule_card_item_text.xml")
        local itemMarginLeft
        if i == 1 then
            itemMarginLeft = 16
        else
            itemMarginLeft = 8
        end
        table.insert(dataList, {
            ['search_history_word'] = searchHistoryData[i],
            ['search_history_index'] = i,
            ['search_history_max_width'] = getTextMaxWidth(searchHistoryData[i], 1000),
            ['item_margin_left'] = itemMarginLeft,
            ['R1'] = R1,
            ['modeltype'] = modeltype,
            ['scene'] = scene,
            ['slotId'] = slotId,
            ['subposition'] = i,
            ['sourceScene'] = sourceScene,
            ['sourceSceneSlotId'] = sourceSceneSlotId
        })
    end
    table.insert(viewNameList, "search_history_word_capsule_card_item_clear.xml")
    table.insert(dataList, {
        ['R1'] = R1,
        ['modeltype'] = modeltype,
        ['scene'] = scene,
        ['slotId'] = "99_"..subPosition,
        ['subposition'] = #searchHistoryData + 1,
        ['sourceScene'] = sourceScene,
        ['sourceSceneSlotId'] = sourceSceneSlotId    
    })
end

-- 获取历史数据
local function getSearchHistoryData()
    local searchHistoryWordStack = mSearchHistory:getInstance():cloneSearchHistoryStack()
    if (searchHistoryWordStack == nil) then
        return nil
    end
    local searchHistoryNum = searchHistoryWordStack:size()
    if searchHistoryNum <= 0 then
        return nil
    end

    if searchHistoryNum > MAX_SEARCH_HISTORY_NUM then
        searchHistoryNum = MAX_SEARCH_HISTORY_NUM
    end
    local searchHistoryWord = {}
    for i = 1, searchHistoryNum do
        searchHistoryWord[i] = searchHistoryWordStack:pop()
    end
    return searchHistoryWord
end

local function jump(searchHistoryIndex, searchHistory)
    if searchHistoryIndex == nil or searchHistory == nil then
        return
    end

    local params = {}
    params["key"] = "UpdateSourceScene"
    Rapid:execAction("outeraction", params)

    local slotId = Rapid:getData("slotId", '')
    local subPosition = string.format("%03d", searchHistoryIndex)
    local tmast = "tmast://search?key="..searchHistory.."&sourceScene=2007&searchScene=2007020&sourceSlotId="..slotId.."&subPosition="..subPosition
    local params = {}
    params["tmast"] = tmast
    Rapid:execAction("tmastaction", params, nil)
end

-- 点击搜索历史
local function clickSearchHistory(value)
    if value == nil or mSearchHistoryData == nil then
        return
    end
    local searchHistoryIndex = tonumber(value)
    local searchHistory = mSearchHistoryData[searchHistoryIndex]
    jump(searchHistoryIndex, searchHistory)
end

local function dialogReport(actionid, param, extendparam)
    local reportParams = {
        ["reportelement"] = "pop",
        ["param"] = "slotid:99_-1,actionid:"..actionid..",subposition:-1"..param,
        ["extendparam"] = "uni_pop_scene:1,uni_pop_type:225"..extendparam,
    }
    Rapid:execAction("reportaction", reportParams, nil)
end

local function showDialog()
    if mClearAllSearchHistoryDialog == nil then
        return false
    end
    mClearAllSearchHistoryDialog:show()
    return true
end

-- 清理历史词
local function clearAllSearchHistoryWord()
    local show = showDialog()
    if show then
        dialogReport(100, '', '')
    end
end

local function dismissDialog()
    if mClearAllSearchHistoryDialog == nil then
        return false
    end
    mClearAllSearchHistoryDialog:dismiss()
    return true
end

local function cancelDialog(cancelType)
    local dismiss = dismissDialog()
    if dismiss then
        dialogReport(201, '', ',uni_cancel_type:'..tostring(cancelType))
    end
end

local function confirmDialog()
    local dismiss = dismissDialog()
    if dismiss then
        dialogReport(200, '', ',uni_button_title:确定')
    end
    mSearchHistory:getInstance():clearHistory()
    refreshData()
end

-- 回调监听
function mIActionListener.notify(key, value)
    if key == 'clearAllSearchHistory' then
        clearAllSearchHistoryWord()
        return
    end
    if key == 'clickSearchHistory' then
        clickSearchHistory(value)
        return
    end
    if key == 'externalDialog' then
        cancelDialog('6')
        return
    end
    if key == 'cancelDialog' then
        cancelDialog('1')
        return
    end
    if key == 'confirmDialog' then
        confirmDialog()
        return
    end
    if mActionListener ~= nil then
        mActionListener:notify(key, value)
    end
end

local function initActionListener()
    mActionListener = mRecyclerView:getParser():getListener()
    mRecyclerView:getView():setActionListener(mIPhotonActionListener)
end

local function initClearAllHistoryDialog()
    local dialogParams = {}
    -- 埋点数据 begin
	dialogParams["scene"] = "10110"
	dialogParams["uni_pop_type"] = '201'
	dialogParams["slotId"] = '99_-1'
	dialogParams["slotid"] = '99_-1'
	dialogParams["report_button_text"] = 'confirm_btn'
	-- 埋点数据 end

    mClearAllSearchHistoryDialog = mJavaBridge:createCustomDialog("search_history_word_capsule_card_clear_all_dialog.xml", dialogParams, mIPhotonActionListener)
    mClearAllSearchHistoryDialog:getContentPhotonView():getParser():getBinder():update("self", mClearAllSearchHistoryDialog)
end

function loadFinish()
    mRecyclerView = Rapid:getChild("recycler_view")
    mSearchHistory = luajava.bindClass('com.tencent.nucleus.search.SearchHistoryManager')
    mIPhotonActionListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IPhotonActionListener', mIActionListener)
    mTextPaint = Rapid:getChild('text_helper'):getView():getPaint()
    mTextMaxWidth = mJavaBridge:px2dip(mTextPaint:measureText(MAX_WIDTH_TEXT)) + 12
    initClearAllHistoryDialog()
end

function afterUpdateData()
    initActionListener()
    refreshData()
end

function onResume()
    refreshData()
end

function refreshData()
    local viewNameList = {}
    local dataList = {}
    local searchHistoryData = getSearchHistoryData()
    fillViewOrDataList(viewNameList, dataList, searchHistoryData)
    mRecyclerView:getView():updateData(viewNameList, dataList, true)
end