local mPhotonView,mJavaBridge = ...


local mRecyclerView = nil
local mViewPager = nil

local mTabView = {}

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil

function main()
    mRecyclerView = mPhotonView:getParser():getChildView('rv_title_tag')
    mViewPager = mPhotonView:getParser():getChildView('view_pager')
    local viewPagerListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IViewPagerListener', ViewPagerListener)
	mViewPager:getView():setViewPagerListener(viewPagerListener)
end

ViewPagerListener = {}
function ViewPagerListener.onPause(pos, tag)
end

function ViewPagerListener.onResume(pos, tag)
end

function ViewPagerListener.onPageSelected(pos, tag, first)
    mJavaBridge:Log("qiwei","pos=="..tostring(pos)..",===tag=="..tostring(tag)..",==first=="..tostring(first))
	if mTabView[pos + 1] == nil then
		return
	end
    -- 切换为对应的榜单数据
    updateInnerCardData(pos + 1)
end

CallbackObject = {}
CallbackObject.onClickRank = function(rankIndex)
    if tonumber(rankIndex - 1) == mViewPager:getView():getCurrentItem() then
        -- 当前已选中
        return
    end
    updateRankCheckStatus(rankIndex)

    if mTabView[tonumber(rankIndex)] ~= nil then
        mViewPager:getView():setCurrentItem(tonumber(rankIndex - 1))
    end
end

-- 更新榜单选中之后的状态
function updateRankCheckStatus(index)
    local rankCount = tonumber(Rapid:getData('item_num', '0'))
    if rankCount <= 0 then
        return
    end
    for i = 1, rankCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        putMapData(itemData, "is_selected", tostring(i == index))
    end
    mRecyclerView:getView():notifyDataSetChanged()
end

function updateData()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    local viewList = {}
    local dataList = {}

    local rankCount = tonumber(Rapid:getData('item_num', '0'))
    if rankCount <= 0 then
        return
    end

    for i = 1, rankCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        putReportElement(itemData)
        putMapData(itemData, "callback", CallbackObject)
        putMapData(itemData, "rank_index", i)
        putMapData(itemData, "is_selected", tostring(i == 1))
        putMapData(itemData, "recommend_card", Rapid:getData('recommend_card',''))
        if i == 1 then
            putMapData(itemData, "marginLeft", 16)
        else
            putMapData(itemData, "marginLeft", 0)
        end

        dataList[i] = itemData
        viewList[i] = 'novel_tab_book_rank_tag_item.xml'

        initViewPagerItem(i, itemData)
    end

    -- 更新榜单数据
    mRecyclerView:getView():updateData(viewList, dataList, true)

    -- 刷新ViewPager的数据，并强制设置为显示第一个Item
    mViewPager:getView():getAdapter():refresh(mTabView)
    mViewPager:getView():setCurrentItem(0)
    -- 默认更新第1个榜单数据
    updateInnerCardData(1)
end

-- 初始化ViewPager的视图
function initViewPagerItem(index, itemData)
    if itemData == nil then
        return
    end
    mTabView[index] = mJavaBridge:loadView('novel_tab_book_rank_inner_card.xml', 'viewpagerparams', itemData)
end

-- 根据索引更新内层卡的数据
function updateInnerCardData(index)
    if mTabView[index] == nil then
        return
    end

    -- 加这个条件一是可以干掉不必要的刷新，二是防止列表重复曝光
    local itemCount = mTabView[index]:getParser():getChildView("recyclerview"):getView():getAdapter():getItemCount()
    mJavaBridge:Log("qiwei","内层卡itemCount==="..itemCount)
    if itemCount > 0 then
        mJavaBridge:Log("qiwei","已经更新列表")
        return
    end
    mJavaBridge:Log("qiwei","需要更新列表")

    local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. index)
    if itemData == nil then
        return
    end

    local viewList = {}
    local dataList = {}
    local bookCount = itemData:get("item_num"):getInt()
    local rid = Rapid:getData('recommend_card','')
    local rankTitle = itemData:get('rank_title',''):getString()
    for i = 1, bookCount do
        local appData = itemData:get("item_data_" .. i)
        putMapData(appData:getObject(), "recommend_card", rid)
        putMapData(appData:getObject(), "rank_title", rankTitle)
        putMapData(appData:getObject(), "subPosition", i)
        if i == bookCount then
            putMapData(appData:getObject(), "marginRight", '16')
        else
            putMapData(appData:getObject(), "marginRight", '4')
        end
        
        putReportElement(appData:getObject())

        dataList[i] = appData
        viewList[i] = 'novel_tab_book_rank_inner_book_item.xml'
    end

	mTabView[index]:getParser():getChildView("recyclerview"):getView():updateData(viewList, dataList, true)
end

function putReportElement(mapData)
    putMapData(mapData, "scene", mScene)
    
    putMapData(mapData, "sourcescene", mSourcescene)
    putMapData(mapData, "sourceScene", mSourcescene)
    
    putMapData(mapData, "modeltype", mModeltype)
    putMapData(mapData, "modelType", mModeltype)
    
    putMapData(mapData, "sourcesceneslotid", mSourceslotid)
    putMapData(mapData, "sourceSceneSlotId", mSourceslotid)
    
    putMapData(mapData, "slotid", mSlotid)
    putMapData(mapData, "slotId", mSlotid)
end

function putMapData(map, key, value)
    if ((map ~= nil) and (key ~= nil) and (value ~= nil)) then
        local var = mJavaBridge:create("var", value)
        map:put(key, var)
    end
end