local mRapidView, mJavaBridge = ...
local DEBUG = true
local TAG = "playing_game_tab_discuss"
local mPrefix = ""

--load的时候运行
function loadFinish()
    printf("loadFinish")
end

function handleFramePrefix()
    mPrefix = ""
    local spaceWidth = getTextWidth(" ", 16) -- 标题目前使用的是16号字体
    printf("one space width:" .. tostring(spaceWidth))
    local padding = getTotalPaddingWidth()
    local rest = padding / spaceWidth
    local total = 0
    if rest >= 0.5 * tonumber(spaceWidth) then
        total = padding + 0.5 * tonumber(spaceWidth)
    else
        total = padding;
    end
    printf("total width:" .. tostring(total))
    local index = 0
    for var = 0, total, spaceWidth do
        index = index + 1
        mPrefix = mPrefix .. " "

    end
    local title = mPrefix .. tostring(Rapid:getData("community_title", " "))
    Rapid:setData("card_title", title)
    printf("index:" .. tostring(index) .. "discuss cardtitle:" .. tostring(title))
end

function getTotalPaddingWidth()
    -- 置顶相关的像素点定义
    local totalWidth = 0
    local marginRight = 4
    local topWidth = 10

    local isTop = Rapid:getData("community_isTop")
    if 1 == tonumber(isTop) then
        totalWidth = topWidth + marginRight
    end
    printf("1 step total:" .. tostring(totalWidth))
    totalWidth = totalWidth + getTagWidth()
    return totalWidth
end

function getTagWidth()
    -- taglayout相关的像素点定义
    local marginLeft = 4
    local marginRight = 4
    local marginSpace = 4

    local tagText = Rapid:getData("community_tag_id_desc")
    if tagText == nil then
        printf("error:community_tag_id_desc nil")
        return 0
    end
    local tagWidth = getTextWidth(tagText, 10)
    printf("2 step text width:" .. tostring(tagWidth))
    tagWidth = marginLeft + marginRight + marginSpace + tagWidth
    printf("2 step total:" .. tostring(tagWidth))
    return tagWidth
end

-- 获取layout的宽度
-- 在有hot图片和没有的时候，显示的字数是不一样的，使用maxEms会是的显示的时候字体
-- 在部分机型的时候被切割，动态计算layout宽度，动态设置宽度能够解决这个问题
function getTextWidth(text, textsize)
    local mTextPaint = luajava.newInstance("android.text.TextPaint")
    Layout = luajava.bindClass("android.text.Layout")
    mTextPaint:setTextSize(textsize)
    local textWidth = Layout:getDesiredWidth(text, mTextPaint)
    printf("getTextWidth text:" .. text .. ", width:" .. textWidth)
    return textWidth
end

-- 图片显示隐藏
function updatePicVisibility()
    local mediaView = mRapidView:getParser():getChildView("id_media")
    local coverUrl = Rapid:getData("community_coverUrl")
    printf("community_coverUrl:" .. tostring(coverUrl))
    if coverUrl == nil or coverUrl == "" then
        dismissView(mediaView)
    end
end

function dismissView(view)
    if view == nil then
        return
    end
    view:getParser():update("visibility", "gone")
end

function showView(view)
    if view == nil then
        return
    end
    view:getParser():update("visibility", "visible")
end

function init()
    printf("reset data:")
    Rapid:setData(TAG, tonumber(0))
end

--数据更新后，卡片入口主方法
function main()
    printf("update main")

    handleFramePrefix()

    local replyNum = tonumber(Rapid:getData("community_replyNum"))
    local comment_text = "发表评论"
    if replyNum > 999 then
        comment_text = comment_text .. tostring("999+")
    elseif replyNum > 0 then
        comment_text = comment_text .. tostring(replyNum)
    end

    Rapid:setData("comment_show_text", comment_text)
    printf("comment_show_text end :" .. comment_text)

    updatePicVisibility()
end
-----------------------------------------------------------
function printf(str)
    if DEBUG then
        print(TAG .. " " .. tostring(str))
    end
end
