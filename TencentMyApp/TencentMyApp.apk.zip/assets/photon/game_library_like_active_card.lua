local mPhotonView,mJavaBridge = ...

local ViewUtils

function main()
    ViewUtils = luajava.bindClass('com.tencent.assistant.utils.ViewUtils')
    local strokeWidth = ViewUtils:dip2px(1.5)
    Rapid:getChild('btn_join'):setAttr('gradientdrawable', 'cornerradius:16,color:00ffffff,strokewidth:'.. strokeWidth ..',strokecolor:4DA6FF')
end

function updateData()
    local btnText = Rapid:getData('button_text', '')
    if btnText == '' then
        Rapid:setData('button_text', '参与活动')
    end
end