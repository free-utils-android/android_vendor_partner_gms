local mPhotonView, mJavaBridge = ...


local coverImgView
local scaleAnimation

function main()
    coverImgView = Rapid:getChild('cover_bg')
end


function afterUpdateData()
    cancelAnim()
    doScaleAnim()
end

function cancelAnim()
    if scaleAnimation ~= nil then
        scaleAnimation:cancel()
        scaleAnimation = nil
    end
end

function doScaleAnim()
    scaleAnimation =
        luajava.newInstance('android.view.animation.ScaleAnimation', 1, 1.1, 1, 1.1, 1, 0.5, 1, 0.5)
    local listener = luajava.createProxy('android.view.animation.Animation$AnimationListener', AnimationListener)
    scaleAnimation:setAnimationListener(listener)
    scaleAnimation:setDuration(4000)
    scaleAnimation:setRepeatCount(-1)
    scaleAnimation:setRepeatMode(1)
    scaleAnimation:setFillAfter(true)
    coverImgView:getView():startAnimation(scaleAnimation)
end

AnimationListener = {}
function AnimationListener.onAnimationStart(animation)
    
end

function AnimationListener.onAnimationRepeat(animation)
end

function AnimationListener.onAnimationEnd(animation)
    
end