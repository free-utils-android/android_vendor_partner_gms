
require "native_bit"

local mPhotonView,mJavaBridge,cutflag = ...

function init()
    cutflag = true
end
 
function onClickExpand()

	if( cutflag ) then
		mPhotonView:getParser():getChildView("description_txt"):getParser():update("cutflag","flase")
		mPhotonView:getParser():getChildView("version_num"):getParser():update("visibility","visible")
		mPhotonView:getParser():getChildView("update_time"):getParser():update("visibility","visible")
		mPhotonView:getParser():getChildView("author_title"):getParser():update("visibility","visible")
		mPhotonView:getParser():getChildView("permission_info"):getParser():update("visibility","visible")
		mPhotonView:getParser():getChildView("permission_link"):getParser():update("visibility","visible")
		mPhotonView:getParser():getChildView("expand_icon"):getParser():update("image","res@icon_close")	
		showFlagView()
		cutflag = false
	else
		mPhotonView:getParser():getChildView("description_txt"):getParser():update("cutflag","true")
		mPhotonView:getParser():getChildView("version_num"):getParser():update("visibility","gone")
		mPhotonView:getParser():getChildView("update_time"):getParser():update("visibility","gone")
		mPhotonView:getParser():getChildView("author_title"):getParser():update("visibility","gone")
		mPhotonView:getParser():getChildView("permission_info"):getParser():update("visibility","gone")
		mPhotonView:getParser():getChildView("permission_link"):getParser():update("visibility","gone")
		mPhotonView:getParser():getChildView("flag_novirus"):getParser():update("visibility","gone")	
		mPhotonView:getParser():getChildView("flag_noad"):getParser():update("visibility","gone")	
		mPhotonView:getParser():getChildView("flag_txcloud"):getParser():update("visibility","gone")	
		mPhotonView:getParser():getChildView("flag_usercare"):getParser():update("visibility","gone")	
		mPhotonView:getParser():getChildView("expand_icon"):getParser():update("image","res@icon_open")
		cutflag = true
	end
		
end

function showFlagView()
	local binder = mPhotonView:getParser():getBinder()
	if( binder == nil)
	then 
		return
	end 
	
	local flag  = binder:get('flag')
	mJavaBridge:Log("GameDetail"," showFlagView flag:"..flag)

	local value = 0
	local t = type(flag);
	if t=="number"then
		value = flag
	elseif t=="string"then
		local n = tonumber(flag);
		if n then
			value = n
		end
	end
	
	mJavaBridge:Log("GameDetail"," showFlagView value:"..tostring(value))
	
	mPhotonView:getParser():getChildView("flag_novirus"):getParser():update("visibility","visible")	

	mPhotonView:getParser():getChildView("flag_noad"):getParser():update("visibility","visible")	
	if(isHaveAd(value))then
		mPhotonView:getParser():getChildView("flag_noad_image"):getParser():update("image","res@icon_3_2")
		mPhotonView:getParser():getChildView("flag_noad_txt"):getParser():update("text","有广告：已通过腾讯手机管家、金山手机毒霸检查")
	else
		mPhotonView:getParser():getChildView("flag_noad_image"):getParser():update("image","res@icon_3_1")
		mPhotonView:getParser():getChildView("flag_noad_txt"):getParser():update("text","无广告：已通过腾讯手机管家、金山手机毒霸检查")
	end

	
	if(isTencentCloud(value))then
		mPhotonView:getParser():getChildView("flag_txcloud"):getParser():update("visibility","visible")	
	end

	if(isHaveUserCare(value))then
		mPhotonView:getParser():getChildView("flag_usercare"):getParser():update("visibility","visible")	
	end
end

function isHaveAd(flag)
	local ret = true

	bs = native_bit:_and(flag,3)
	mJavaBridge:Log("GameDetail"," isHaveAd value:"..tostring(bs))

	if(bs == 1)then
		ret = false
	end
	return ret
end
 

function isTencentCloud(flag)
	local ret = false
	
	bs = native_bit:_and(native_bit:_rshift(flag,21),1)
	mJavaBridge:Log("GameDetail"," isTencentCloud value:"..tostring(bs))

	if(bs == 1)then 
		ret = true 
	end
	return ret
end

function isHaveUserCare(flag)
	local ret = false

	bs = native_bit:_and(native_bit:_rshift(flag,14),1)
	mJavaBridge:Log("GameDetail"," isHaveUserCare value:"..tostring(bs))

	if(bs == 1)then 
		ret = true
	end
	return ret
end

function concatStr()
	local binder = mPhotonView:getParser():getBinder()
	
	if( binder == nil)
	then 
		return
	end 
	
	local versionName  = binder:get('versionName')
	if( versionName == nil )
	then
		versionName= "未知"
	end
	
	binder:update('ex_versionName', "版本: " .. versionName)

	local uptimeStr  = binder:get('uptimeStr')
	if( uptimeStr == nil )
	then
		uptimeStr= "未知"
	end
	
	binder:update('ex_uptimeStr', "更新时间: " .. uptimeStr)

	local author  = binder:get('author')
	if( author == nil )
	then
		author= "未知"
	end
	
	binder:update('ex_author', "开发者: " .. author)
	
end

