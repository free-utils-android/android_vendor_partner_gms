local mPhotonView, mJavaBridge = ...

local TAG = "search_recycle_view_bottom_view"
local PHOTON_ID = "301627444050311"

function jump()
    mJavaBridge:Log(TAG, "jump")
    local photonid = '301627444050311'
    local pageId = Rapid:getData('scene', '')
    local slotid = Rapid:getData('slotid', '')
    local searchId = Rapid:getData('searchId', '')
    local searchQuery = Rapid:getData('queryWord', '')
    local sourcequery = Rapid:getData('sourceQuery', '')
    local searchsession = Rapid:getData('searchsession', '')
    local searchScene = Rapid:getData('searchScene', '')
    local jumpUrl = "tmast://appdemo?photonid="..PHOTON_ID
        .."&translucent=true&full_screen=true&enable_page_in_out_report=1&selflink=1&scene=10263&sourcemodeltype=200034"
        .."&slotid="..slotid
        .."&slotId="..slotid
        .."&sourceSceneSlotId="..slotid.."_-1_-1"
        .."&sourcesceneslotid="..slotid.."_-1_-1"
        .."&sourceScene="..pageId
        .."&sourcescene="..pageId
        .."&searchId="..searchId
        .."&queryWord="..searchQuery
        .."&sourceQuery="..sourcequery
        .."&sourcequery="..sourcequery
        .."&searchScene="..searchScene
        .."&searchscene="..searchScene
        .."&searchsession="..searchsession
        .."&searchSession="..searchsession
    local params = {
        ["tmast"] = jumpUrl
    }
    Rapid:execAction("tmastaction", params, nil)
end