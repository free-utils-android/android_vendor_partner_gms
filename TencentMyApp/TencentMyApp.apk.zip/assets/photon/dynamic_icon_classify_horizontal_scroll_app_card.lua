local mPhotonView,mJavaBridge = ...


local mTagRecyclerView = nil
local mBannerIconView = nil
local mBannerCover

local _scene = nil
local _sourcescene = nil
local _modeltype = nil
local _sourceslotid = nil
local _slotid = nil


local IMAGE_WIDTH_DEF = '56'
local APP_TEXT_WIDTH_DEF = '72'
local ITEM_MARGIN_DEF = '8'
local MIN_IMAGE_WIDTH = 48 --设置这个尺寸的原因是不能小于下载按钮的尺寸

local ANIM_NARROW_SCALE_CENTER_X = 44.0
local ANIM_NARROW_SCALE_CENTER_Y = 44.0

local mIsCoverAnimationEnd = false -- 标记是否执行了封面动画
local mCurItemIndex = 1 --当前需要显示的icon的下标
local mAppDataList = {}
local mAppViewNameList = {}
local mMathRunnable --用来计算应用列表RecyclerView的高度
local mRecyclerView = nil


function main()
    mBannerIconView = Rapid:getChild('iv_top_icon'):getView()
    mBannerCover = Rapid:getChild('card_view')
    mRecyclerView = Rapid:getChild('rv_app'):getView()

    
    setClipAttr(mRecyclerView)
    setClipAttr(Rapid:getChild('rl_app'):getView())
    setClipAttr(Rapid:getChild('rl_card'):getView())

    mMathRunnable = luajava.createProxy('java.lang.Runnable', MathRunnable)

    local listener = luajava.createProxy('android.view.View$OnAttachStateChangeListener', OnAttachStateChangeListener)
    mBannerIconView:addOnAttachStateChangeListener(listener)
end

-- 设置允许子view超出父容器范围
function setClipAttr(view)
    view:setClipChildren(false)
    view:setClipToPadding(false)
end

function updateData()
    local iconWidth = Rapid:getData('icon_size','0')
    if tonumber(iconWidth) <= 0 then
        Rapid:setData('icon_size', IMAGE_WIDTH_DEF)
    else
        if tonumber(iconWidth) < MIN_IMAGE_WIDTH then
            Rapid:setData('icon_size', MIN_IMAGE_WIDTH)
        end
    end

    _scene = Rapid:getData("scene")
    _sourcescene = Rapid:getData("sourcescene")
    _modeltype = Rapid:getData("modeltype")
    _sourceslotid = Rapid:getData("sourcesceneslotid")
    _slotid = Rapid:getData("slotid")
    
    updateAppList(true)
end


function updateAppList(loadDynamicIcon)
    mAppDataList = {}
    mAppViewNameList = {}

    local subscribe = Rapid:getData('subscribe','')
    local itemMargin = tonumber(Rapid:getData('horizontal_item_margin', ITEM_MARGIN_DEF))
    local iconSize = tonumber(Rapid:getData('icon_size',IMAGE_WIDTH_DEF))
    local itemNum = tonumber(Rapid:getData('item_num','0'))
    local configId = Rapid:getData('dynamic_icon_config_id','')

    -- icon大小实验相关参数计算
    local defLeft = 8
    local defRight = 16
    if useIconWidth(iconSize) == false then
        local margin = (tonumber(APP_TEXT_WIDTH_DEF) - tonumber(iconSize)) / 2
        defLeft = defLeft - margin
        defRight = defRight - margin
    end

    for i = 1, itemNum do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)

        putBaseReportText(itemData)


        itemData:put("subPosition",mJavaBridge:create("Var", i))
        itemData:put("app_slotId",mJavaBridge:create("Var", tostring(Rapid:getData("slotId")) .. "_-1_"..i))
        itemData:put("icon_size",mJavaBridge:create("Var", iconSize))
        itemData:put("horizontal_item_margin",mJavaBridge:create("Var", itemMargin))
        itemData:put("subscribe",mJavaBridge:create("Var", subscribe))
        itemData:put("dynamic_icon_config_id",mJavaBridge:create("Var", configId))
        itemData:put("marginleft",mJavaBridge:create("Var", '0'))

        -- icon大小
        if i == 1 then
            itemData:put("marginleft",mJavaBridge:create("Var", defLeft))
        elseif i == itemNum then
            itemData:put("horizontal_item_margin",mJavaBridge:create("Var", defRight))
        end

        if useIconWidth(iconSize) == false then
            itemData:put("app_text_size",mJavaBridge:create("Var", APP_TEXT_WIDTH_DEF))
        else
            itemData:put("app_text_size",mJavaBridge:create("Var", iconSize))
        end
 
        local subViewName = "dynamic_icon_classify_horizontal_scroll_app_card_app_item_normal.xml"
        if chechAndSetFirsetAppIconAnimation(i,itemData) then
            subViewName = 'dynamic_icon_classify_horizontal_scroll_app_card_app_item.xml'
        end

        if (itemData ~= nil) then
            mAppDataList[i] = itemData
            mAppViewNameList[i] = subViewName
        end
    end
    
    mRecyclerView:updateData(mAppViewNameList, mAppDataList, true)
    mRecyclerView:post(mMathRunnable)
end

-- 判断是否有首位动画
function chechAndSetFirsetAppIconAnimation(index,itemData)
    if index ~= 1 then
        return false
    end
    local coverIcon = itemData:get("cover_image_url","")
    local coverJumpUrl = itemData:get("cover_jump_url","")


    if coverIcon == "" then
        return false
    end

    Rapid:setData('icon_cover_url', tostring(coverIcon))
    Rapid:setData('cover_jump_url', tostring(coverJumpUrl))
    return true
end

MathRunnable = {}
function MathRunnable.run()
    checkCoverAnimation()
end

function checkCoverAnimation()
    Rapid:Log("realhe","checkCoverAnimation")

    local url = Rapid:getData('icon_cover_url','')
    if url == '' then
        -- 未配置封面动画，直接返回
        jumpCoverAnimation()
        return
    end

    local coverImageRapidView = Rapid:getChild('card_view')
    if mIsCoverAnimationEnd then
        Rapid:Log("realhe","mIsCoverAnimationEnd")
        -- 封面动画已经运行过，返回
        jumpCoverAnimation()
        return
    end

    setInitRecyclerViewAlpha()
    setCoverHeight()
    coverImageRapidView:setAttr("visibility","visible")
    runScaleAnim()

    mIsCoverAnimationEnd = true
end

-- 设置封面高度
function setCoverHeight()
    local rvHeight = mRecyclerView:getMeasuredHeight()
    local dpHeight = mJavaBridge:px2dip(rvHeight)
    -- 这里减8是因为在xml里面多了8的向上margin，所以需要减去
    Rapid:setData('coverHeight', dpHeight - 8)
end

-- 设置列表初始透明度
function setInitRecyclerViewAlpha()
    -- recyclerview初始化是invisible防止闪动,这里要恢复整体透明度
    Rapid:getChild('rv_app'):setAttr("visibility","visible")

    
    local count = mRecyclerView:getChildCount()
    for i = 0, count do
        -- 除了第1位外都先设置不可见
        setItemVisible(i,(i == 0))
    end
end

-- 下拉刷新或者从其他tab切过来需要跳过动画，直接设置item可见，并隐藏封面，触发第一个item的动画
function jumpCoverAnimation()
    clearAllAnimation()
    startFirstItemAnimation()
end

function clearAllAnimation()
    -- recyclerview初始化是invisible防止闪动,这里要恢复整体透明度
    local coverImageRapidView = Rapid:getChild('card_view')
    coverImageRapidView:setAttr("visibility","gone")
    Rapid:getChild('rv_app'):setAttr("visibility","visible")
    -- 所有位置都设置为可见
    local count = mRecyclerView:getChildCount()
    for i = 0, count do
        setItemVisible(i,true)
    end
end


function useIconWidth(iconSize)
    return tonumber(iconSize) < tonumber(IMAGE_WIDTH_DEF) or tonumber(iconSize) >= tonumber(APP_TEXT_WIDTH_DEF)
end

IRapidListDataController = {}
function IRapidListDataController.updateItemData(index, key, val)
    Rapid:setData(key, val)
    RapidList:updateItemData(index, key, val)
end

function IRapidListDataController.reload()
end

function IRapidListDataController.getItemData(index, key)
    return RapidList:getItemData(index, key)
end

function putBaseReportText(itemData)
    if itemData == nil then
        return
    end

    if _scene ~= nil then
        local var_scene = mJavaBridge:create("Var", _scene)
        itemData:put("scene",var_scene)
    end
    
    if _sourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create("Var", _sourcescene)
        itemData:put("sourcescene",var_sourcescene)
        itemData:put("sourceScene",var_sourcescene)
    end
    
    if _modeltype ~= nil then
        local var_modeltype = mJavaBridge:create("Var", _modeltype)
        itemData:put("modeltype",var_modeltype)
        itemData:put("modelType",var_modeltype)
    end
    
    if _sourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create("Var", _sourceslotid)
        itemData:put("sourcesceneslotid",var_sourceslotid)
        itemData:put("sourceSceneSlotId",var_sourceslotid)
    end
    
    if _slotid ~= nil then
        local var_slotid = mJavaBridge:create("Var", _slotid)
        itemData:put("slotid",var_slotid)
        itemData:put("slotId",var_slotid)
    end
end

-- 动画相关

function runScaleAnim()
    local animationSet = mJavaBridge:createAnimationSet("true")
    local listener = luajava.createProxy('android.view.animation.Animation$AnimationListener', CoverAnimationListener)
    animationSet:setAnimationListener(listener)

    local startAnimation = createCoverScaleExpandAnim()
    local endAnimation = createCoverScaleNarrowAnim()

    animationSet:addAnimation(startAnimation)
    animationSet:addAnimation(endAnimation)
    animationSet:setFillAfter(true)
    mBannerIconView:startAnimation(animationSet)
end

-- 封面放大
function createCoverScaleExpandAnim()
    local animation = luajava.newInstance('android.view.animation.ScaleAnimation', 1, 1.25, 1, 1.25, 1, 0.5, 1, 0.5)
    animation:setDuration(2500)
    animation:setFillAfter(true)
    animation:setStartOffset(0)
    return animation
end

-- 封面缩小
function createCoverScaleNarrowAnim()
    local animation = luajava.newInstance('android.view.animation.ScaleAnimation', 1, 0, 1, 0, 0, 
                            ANIM_NARROW_SCALE_CENTER_X, 0, ANIM_NARROW_SCALE_CENTER_Y)
    animation:setDuration(500)
    animation:setStartOffset(2500)
    animation:setFillAfter(true)
    return animation
end

OnAttachStateChangeListener = {}
function OnAttachStateChangeListener.onViewAttachedToWindow(view)

end

function OnAttachStateChangeListener.onViewDetachedFromWindow(view)
    jumpCoverAnimation()
end

-- 封面动画缩小监听
CoverAnimationListener = {}
function CoverAnimationListener.onAnimationStart(animation)

end

function CoverAnimationListener.onAnimationRepeat(animation)

end

function CoverAnimationListener.onAnimationEnd(animation)
    Rapid:getChild('card_view'):setAttr("visibility","gone")
    startItemExpandAnimation()
    startFirstItemAnimation()
end

ItemAnimatorUpdateListener = {}
function ItemAnimatorUpdateListener.onAnimationUpdate(animation)
    local index = animation:getAnimatedValue()
    setItemVisible(index,true)
end

ItemAnimationListener = {}
function ItemAnimationListener.onAnimationStart(animation)
end

function ItemAnimationListener.onAnimationRepeat(animation)
end

function ItemAnimationListener.onAnimationCancel(animation)
end

function ItemAnimationListener.onAnimationEnd(animation)
    clearAllAnimation()
end

function startItemExpandAnimation()
    -- 获得列表数目
    local recyclerview = Rapid:getChild('rv_app'):getView()
    local count = recyclerview:getChildCount()
 
    if count <= 0 then
        mJavaBridge:postRun(doItemExpandWithoutAnimation)
        return
    end

    local indexParams = {}
    for i = 0, count - 1 do
        indexParams[i + 1 ] = i
    end

    local indexValueAnimatorClz = luajava.bindClass("android.animation.ValueAnimator")
    local indexValueAnimator = indexValueAnimatorClz:ofInt(indexParams)

    local animatorUpdateListener = luajava.createProxy("android.animation.ValueAnimator$AnimatorUpdateListener", ItemAnimatorUpdateListener)
    local animatorListener = luajava.createProxy("android.animation.Animator$AnimatorListener", ItemAnimationListener)
    indexValueAnimator:addUpdateListener(animatorUpdateListener)
    indexValueAnimator:addListener(animatorListener)
    indexValueAnimator:setDuration(250)
    indexValueAnimator:start()
end

function doItemExpandWithoutAnimation()
    -- 获得列表数目
    local recyclerview = Rapid:getChild('rv_app'):getView()
    local count = recyclerview:getChildCount()

    for i = 0, count - 1 do
        setItemVisible(i, true)
    end
end

function setItemVisible(index,visible)
   if mRecyclerView == nil or index >=  mRecyclerView:getChildCount()  then
        return
   end

   local childView = mRecyclerView:getChildAt(index)
   if childView == nil then
       return
   end

   childView = childView:getTag()
   if childView == nil then
        return
   end
   
   if visible then
        childView:getParser():update("visibility","visible")
   else
        childView:getParser():update("visibility","invisible")
   end
end

function startFirstItemAnimation()
    local count = mRecyclerView:getChildCount()
    for i = 0, count do
        local childView = mRecyclerView:getChildAt(i)
        if childView ~= nil then
            childView = childView:getTag()
        end
        if childView ~= nil then
            childView:getParser():getTaskCenter():run("start_item_animation")
        end
    end
end


