local mPhotonView, mJavaBridge = ...

local mRecyclerView = nil

local itemCount = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil
local mRid = nil

function init()
    mRecyclerView = mPhotonView:getParser():getChildView('rv_list')
end

function fillValue()
    local stateListener =
        luajava.createProxy(
        'com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrollStateChangedListener',
        RecyclerScrollStateChangedListener
    )
    mRecyclerView:getView():setScrollStateChangedListener(stateListener)

    itemCount = tonumber(Rapid:getData('item_num', '0'))

    if itemCount < 1 then
        return
    end

    updateReportData()

    local dataList = {}
    local viewNameList = {}
    local subViewName = 'novel_tab_banner_card_item.xml'

    local index = 0
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get('item_data_' .. i)
        index = index + 1
        putReportElement(itemData)
        itemData:put('subPosition', mJavaBridge:create('Var', tostring(i)))
        itemData:put(
            'app_slotId',
            mJavaBridge:create('Var', tostring(Rapid:getData('slotId')) .. '_-1_' .. tostring(i))
        )

        itemData:put('is_first_visible', mJavaBridge:create('var', 'false'))

        dataList[i] = itemData
        viewNameList[i] = subViewName
    end
    mRecyclerView:getView():updateData(viewNameList, dataList, true)
    playFirstVisibileItemAnim()
end

function playFirstVisibileItemAnim()
    local run = luajava.createProxy('java.lang.Runnable', Runnable)
    mRecyclerView:getView():post(run)
end


Runnable = {}
function Runnable.run(...)
    changeItemAnim(false)
end

RecyclerScrollStateChangedListener = {}
function RecyclerScrollStateChangedListener.onScrollStateChanged(recyclerview, state)
    changeItemAnim(false)
end

function onResume()
    changeItemAnim(false)
end

function onPause()
    changeItemAnim(true)
end

function changeItemAnim(allStop)
    if mRecyclerView == nil or mRecyclerView:getView() == nil then
        return
    end
    local manager = mRecyclerView:getView():getLayoutManager()
    if manager == nil then
        return
    end
    local firstPos = manager:findFirstVisibleItemPosition()
    local firstComPos = manager:findFirstCompletelyVisibleItemPosition()
    local lastPos = manager:findLastVisibleItemPosition()
    for i = firstPos, lastPos do
        local currentView = manager:findViewByPosition(i)
        if currentView ~= nil then
            local tag = currentView:getTag()
            if tag ~= nil then
                local parser = tag:getParser()
                if parser ~= nil then
                    local binder = parser:getBinder()
                    if binder ~= nil then
                        if allStop then
                            binder:update('is_first_visible', 'false')
                        else
                            binder:update('is_first_visible', tostring(i == firstComPos))
                        end
                    end
                end
            end
        end
    end
end

function updateReportData() 
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    mRid = Rapid:getData("recommend_card")
end

function putReportElement(mapData)
    putMapData(mapData, "scene", mScene)
    
    putMapData(mapData, "sourcescene", mSourcescene)
    putMapData(mapData, "sourceScene", mSourcescene)
    
    putMapData(mapData, "modeltype", mModeltype)
    putMapData(mapData, "modelType", mModeltype)
    
    putMapData(mapData, "sourcesceneslotid", mSourceslotid)
    putMapData(mapData, "sourceSceneSlotId", mSourceslotid)
    
    putMapData(mapData, "slotid", mSlotid)
    putMapData(mapData, "slotId", mSlotid)

    putMapData(mapData, "recommend_card", mRid)
end

function putMapData(map, key, value)
    if ((map ~= nil) and (key ~= nil) and (value ~= nil)) then
        local var = mJavaBridge:create("var", value)
        map:put(key, var)
    end
end
