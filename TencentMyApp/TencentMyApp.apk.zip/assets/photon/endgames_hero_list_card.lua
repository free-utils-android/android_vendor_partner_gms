local mPhotonView, mJavaBridge = ...

local mRecyclerView = nil
local OnFixCenterListener = {}
local OnFocusChangeListener = {}

local mScrollView = nil
local curMaxX = 0
local DEFAULT_MAX_X = mJavaBridge:dip2px(60)

local TAG = "HRMMMMM"

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil
local isRegister = nil
local isAuthorized = nil

local focusIndex = 0

local FIX_SCROLL_X = -mJavaBridge:dip2px(8)

local UNSELECT_HOT_URL = "https://yybcms.gtimg.com/android_cms/gzskin/8b480af857d5b12a414b0b6ca607d582.png"
local SELECT_HOT_URL = "https://cms.myapp.com/yyb/2022/05/24/1653401490056_c60a19d554b02ae85f160bff66c9883e.png"

function init( ... )
    mRecyclerView = Rapid:getChild("recyclerview"):getView()
    initListener()
    clearSelectHeroInfo()
    local map = luajava.newInstance("java.util.HashMap")
    map:put("isfooter",mJavaBridge:create("Var", true))
    mRecyclerView:setFooter("endgames_hero_list_card_item_more.xml", map)

    mScrollView = Rapid:getChild("scrollview"):getView()
    local reboundListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IReboundListener", IReboundListener)
    mScrollView:setReboundListener(reboundListener)
end

IReboundListener = {}
function IReboundListener.rebound( isLeft, scrollX, deltaX )
    if isLeft then
        curMaxX = 0
        return
    end
    if scrollX > DEFAULT_MAX_X then
        curMaxX = scrollX
    end
    
    mJavaBridge:Log("HRM","scrollX:"..scrollX.." deltaX:"..scrollX..",  curMaxX:"..curMaxX..",  defaultX:"..DEFAULT_MAX_X)
    if (scrollX + deltaX) == 0 and curMaxX > DEFAULT_MAX_X then
        local mSystem = luajava.bindClass("java.lang.System")
        mJavaBridge:Log("showDialog","enter founction time:"..mSystem:currentTimeMillis())
        loadMore()
        curMaxX = 0
    end
end

function clearSelectHeroInfo( ... )
    mJavaBridge:removeMemoryCache("endgames_hero_group")
    mJavaBridge:removeMemoryCache("endgames_hero_id")
end

-- 可见时,要获取到全屏部分选中的英雄
function onResume( ... )
    curMaxX = 0
    local heroGroup = mJavaBridge:getMemoryCache("endgames_hero_group")
    local heroId = mJavaBridge:getMemoryCache("endgames_hero_id")
    if heroGroup == nil or heroId == nil then
        return
    end
    if tostring(heroGroup) == "" or tostring(heroId) == "" then
        return
    end
    updateAppList(tostring(heroGroup),tostring(heroId))
end

function initListener( ... )
    local onFixCenterListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IFocusRecyclerView$OnFixCenterListener", OnFixCenterListener)
    mRecyclerView:setOnFixCenterListener(onFixCenterListener)
    local onFocusChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IFocusRecyclerView$OnFocusChangeListener", OnFocusChangeListener)
    mRecyclerView:setOnFocusChangeListener(onFocusChangeListener)

    mRecyclerView:setActionListener(mPhotonView:getParser():getListener())
end

function afterUpdateData( ... )
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    isRegister = Rapid:getData("is_register")
    isAuthorized = Rapid:getData("is_authorized")

    updateAppList("1", "")
end

function updateAppList( heroGroup, heroId )
    local firstItemData = Rapid:getData("item_data_"..heroGroup, "")
    if firstItemData == "" then
        return
    end
    local blockNum = firstItemData:get("block_num"):getLuaValue()
    if blockNum == nil then
        return
    end
    local dataList = luajava.newInstance("java.util.ArrayList")
    local viewNameList = luajava.newInstance("java.util.ArrayList")
    local hotItem = getHotItem()
    if hotItem ~= nil then
        hotItem:put("hero_group", mJavaBridge:create("Var", heroGroup))
        fillItemData(hotItem, 1)
        dataList:add(hotItem)
        viewNameList:add("endgames_hero_list_card_item.xml")
    end
    blockNum = tonumber(tostring(blockNum))
    local hasHotItem = false
    for i = 1, blockNum do
        local itemData = firstItemData:get("block_"..i):getLuaValue()
        if tostring(itemData:get("hero_id")) == "-1" then
            hasHotItem = true
        else
            itemData:put("hero_group", mJavaBridge:create("Var", heroGroup))
            if tostring(itemData:get("hero_id")) == heroId then
                saveFirstHeroInfo(itemData)
                if hasHotItem then
                    focusIndex = i - 1
                else
                    focusIndex = i
                end
            end
            if hasHotItem then
                fillItemData(itemData, i)
            else
                fillItemData(itemData, i + 1)
            end
            dataList:add(itemData)
            viewNameList:add("endgames_hero_list_card_item.xml")
        end
    end
    mRecyclerView:removeAllViews()
    mRecyclerView:setInitFocusPosition(focusIndex)
    mRecyclerView:updateData(dataList, viewNameList, true)
    local runnable = luajava.createProxy("java.lang.Runnable", Runnable)
    mRecyclerView:post(runnable)
end

Runnable = {}
function Runnable.run(...)
    local targetView = mRecyclerView:getLayoutManager():findViewByPosition(focusIndex)
    if targetView ~= nil then
        mScrollView:smoothScrollTo(targetView:getLeft() + FIX_SCROLL_X, 0)
    end
end

function getHotItem( ... )
    local firstGroup = Rapid:getData("item_data_1", "")
    if firstGroup == nil or firstGroup == "" then
        return nil
    end
    local hotItem = firstGroup:get("block_1"):getLuaValue()
    if hotItem == nil then
        return nil
    end
    if tostring(hotItem:get("hero_id")) == "-1" then
        return hotItem
    else
        return nil
    end
end

function saveFirstHeroInfo( itemData )
    if itemData == nil then
        return
    end
    mJavaBridge:putToMemoryCache("endgames_hero_group", itemData:get("hero_group"))
    mJavaBridge:putToMemoryCache("endgames_hero_id", itemData:get("hero_id"))
end

function fillItemData(itemData, index)
    if itemData == nil then
        return
    end
    putBaseReportText(itemData)
    itemData:put("subposition", mJavaBridge:create("Var", index))
    if index == 1 then
        itemData:put("marginleft", mJavaBridge:create("Var", 16))
    else
        itemData:put("marginleft", mJavaBridge:create("Var", 8))
    end
end

function putBaseReportText(itemData)
    if mScene ~= nil then
        itemData:put("scene", mJavaBridge:create("Var", mScene))
    end
    
    if mSourcescene ~= nil then
        itemData:put("sourcescene", mJavaBridge:create("Var", mSourcescene))
    end
    
    if mModeltype ~= nil then
        itemData:put("modeltype", mJavaBridge:create("Var", mModeltype))
    end
    
    if mSourceslotid ~= nil then
        itemData:put("sourcesceneslotid", mJavaBridge:create("Var", mSourceslotid))
    end
    
    itemData:put("slotid", mJavaBridge:create("Var", "99_-1"))

    if isRegister ~= nil then
        itemData:put("is_register", mJavaBridge:create("Var", isRegister))
    end

    if isAuthorized ~= nil then
        itemData:put("is_authorized", mJavaBridge:create("Var", isAuthorized))
    end
end

function loadMore( ... )
    local param = {}
    param["key"] = "show_full_hero_card"
    param["value"] = ""
    Rapid:execAction("outeraction", param, param)
end

function OnFixCenterListener.onScrollToCenter( position )
    return false
end

function OnFocusChangeListener.onFocusGet( rapidView , isFromBindViewHolder)
    if rapidView:getParser():getBinder():get("isfooter") ~= nil then
        loadMore()
    end
    rapidView:getParser():getBinder():update("isFromBindViewHolder", isFromBindViewHolder)
    rapidView:getParser():run("select")
end

function OnFocusChangeListener.onFocusLose( rapidView )
    rapidView:getParser():run("unselect")
end