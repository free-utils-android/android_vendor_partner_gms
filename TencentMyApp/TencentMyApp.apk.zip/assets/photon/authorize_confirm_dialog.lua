local mPhotonView, mJavaBridge = ...
local TAG = "detail_welfare"
local DEBUG = true
local mIndex = 0

function close_dialog()
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:dismiss()
    end
end

function init()
    printf("init:")
end

function main()
    printf("main")
end

function tryAllAuthorize()
    printf("tryAllAuthorize")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "one_key")
    dialogSelf:notifyEvent("ON_ONE_KEY_SELECTED")
    close_dialog()
end

function clickCancel()
    printf("clickCancel")
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_button_name", "cancel")
    dialogSelf:notifyEvent("ON_CANCEL")
    close_dialog()
end

function printf(str)
    if DEBUG then
        print(TAG .. " " .. tostring(str))
    end
end