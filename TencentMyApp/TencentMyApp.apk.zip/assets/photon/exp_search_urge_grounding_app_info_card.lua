local mPhotonView,mJavaBridge = ...


local mMaxGroundingCount = 3 --用户每天可催促上架的最大次数
local mGroundingCount = 0 --当日用户已催促上架的总次数


function updateData()
    mMaxGroundingCount = tonumber(Rapid:getData('max_grounding_count', '3'))
    mGroundingCount = tonumber(Rapid:getData('grounding_click_count', '0'))
    if mGroundingCount > 0 then
        Rapid:setData('uni_button_title', tostring(Rapid:getData('button_text_nonzero_click','再催一下')))
    else
        Rapid:setData('uni_button_title', tostring(Rapid:getData('button_text_zero_click','催促上架')))
    end

    local appType = tostring(Rapid:getData('show_app_type', ''))
    if appType == 'true' then
        Rapid:setData('uni_is_appinfo', '1')
    else
        Rapid:setData('uni_is_appinfo', '0')
    end
end

-- 点击了催促上架按钮
function clickUrgeGrounding()
    local reportUniBtnTitle = Rapid:getData('uni_button_title', '')
    Rapid:setData('uni_button_title_report', tostring(reportUniBtnTitle))
    Rapid:setData('uni_button_title', tostring(Rapid:getData('button_text_nonzero_click','再催一下')))
    mGroundingCount = mGroundingCount + 1
    saveGroundingCountToAdapter()

    showToast()
    if mGroundingCount <= mMaxGroundingCount then
        notifyClickBtn()
    end
end

-- 存入催促次数
function saveGroundingCountToAdapter()
    Rapid:setData('grounding_click_count', mGroundingCount)
    local position = Rapid:getData('position', '0')
    RapidList:updateItemData(position, 'grounding_click_count', tostring(mGroundingCount))
end

-- 通知后台催促上架按钮被点击
function notifyClickBtn()
    local params = {}
	params["AppId"] = tostring(Rapid:getData('appid',''))
	params["ReportType"] = '2'
    mJavaBridge:request(305, params, reqListener)
end

function reqListener(succ, serverListView, serverListData)
	
end

-- 生成toast文案
function handleToastText()
    local defToast = '今天已经催促多次啦，请改天再试'
    if mGroundingCount < 0 or mGroundingCount > mMaxGroundingCount then
        return defToast
    end

    local toastTextSize = tonumber(Rapid:getData('toast_text_size', '0'))
    if toastTextSize <= 0 then
        return defToast
    end

    local random = tostring(math.random(toastTextSize))
    local toastText = Rapid:getData('toast_text_'..random, '')
    if toastText == '' then
        return defToast
    end

    return toastText
end

function showToast()
    local toastData = {}
    toastData["value"] = handleToastText()
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("toastaction", toastData, nil)
end