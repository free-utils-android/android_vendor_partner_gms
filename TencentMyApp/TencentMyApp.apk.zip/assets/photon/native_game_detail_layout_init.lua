local mPhotonView,mJavaBridge = ...
local mViewPager
local mScrollView
local mNavBar
local mBannerView

local yTouchLast = 0
local yTouchDistance = 0
local mTouchSlop = 6
local mLastTransCount = 0

function init()
	mViewPager = mPhotonView:getParser():getChildView("view_pager")
	initListener()
	initHeight()
	initTouchSlop()
end

function setTag()
	local viewPager = mPhotonView:getParser():getChildView("view_pager")
	local tabNum = mPhotonView:getParser():getBinder():get("tab_num")
	
	for i=1,tabNum do
		viewPager:getView():setTabTag(i-1, mPhotonView:getParser():getBinder():get("tab_id_" .. (i-1)))
	end
end

function initTouchSlop()
	local viewConfig = luajava.bindClass('android.view.ViewConfiguration')
	mTouchSlop = viewConfig:get(mPhotonView:getParser():getContext()):getScaledTouchSlop()
end

function initHeight()
	local bottomBarHeight = mPhotonView:getParser():getBinder():get("bottom_bar_height")
	local navBarHeight = mJavaBridge:dip2px(52)

	local screenHeight = mPhotonView:getParser():getScreenHeight()
	local height = screenHeight - navBarHeight - bottomBarHeight - mJavaBridge:dip2px(50) - mJavaBridge:dip2px(4)

	mViewPager:getParser():update("height", mJavaBridge:px2dip(height))
end

function initListener()
	mScrollView = mPhotonView:getParser():getChildView("scroll_container")
	mNavBar = mPhotonView:getParser():getChildView("nav_bar")
	mBannerView = mPhotonView:getParser():getChildView("header")

	local listener = luajava.createProxy('android.view.View$OnTouchListener', TouchListener)
	local gestureListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IScrollView$ISimpleOnGestureListener', GestureListener)
	local interrputListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IScrollView$IInterruptTouchListener', InterrputTouchListener)
	local scrollViewListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IScrollView$IScrollViewListener', ScrollViewListener)
	
	if( mScrollView ~= nil ) then
		mScrollView:getView():setOnTouchListener(listener)
		mScrollView:getView():setSimpleOnGestureListener(gestureListener)
		mScrollView:getView():setInterruptTouchEvent(interrputListener)
		mScrollView:getView():setScrollListener(scrollViewListener)
	end
end

TouchListener = {}
TouchListener.scrollView = nil
TouchListener.detector = nil

function TouchListener.onTouch(view, event)
	local action = event:getAction()

	if( TouchListener.scrollView == nil ) then
		TouchListener.scrollView = mPhotonView:getParser():getChildView("scroll_container")
	end

	TouchListener.scrollView:getView():getGestureDetector():onTouchEvent(event)

	if( action == 0 ) then
		yTouchLast = event:getY()
		yTouchDistance = 0
	end
	
	if( action == 2 ) then
		local view = TouchListener.scrollView:getView()
		local tabContainer = mViewPager:getView():getCurrentPhotonView()
		local currentInnerScroll = tabContainer:getParser():getChildView("inner_scrollview")

		if( currentInnerScroll == nil or mLastTransCount ~= 255 ) then
			return false
		end

		currentInnerScroll = currentInnerScroll:getView()

		local currentY = event:getY()

		yTouchDistance = yTouchDistance + (currentY - yTouchLast)
		
		local deltaY = currentY - yTouchLast
		yTouchLast = currentY

		if( view:getChildAt(0):getHeight() - view:getHeight() == view:getScrollY() and deltaY < 0 ) then
			currentInnerScroll:scrollDeltaY(deltaY)
			return true
		end

		if( currentInnerScroll:canScrollDown() and deltaY >= 0 ) then
			currentInnerScroll:scrollDeltaY(deltaY)
			return true
		end
	end
	
	TouchListener.yTouchLast = event:getY()

	return false
end

GestureListener = {}
function GestureListener.onScroll(e1, e2, distanceX, distanceY)
	return false
end

function GestureListener.onFling(e1, e2, velocityX, velocityY)
	local scrollView = mPhotonView:getParser():getChildView("scroll_container"):getView()
	local tabContainer = mViewPager:getView():getCurrentPhotonView()
	local currentInnerScroll = tabContainer:getParser():getChildView("inner_scrollview")

	if( currentInnerScroll == nil ) then
		return false
	end

	currentInnerScroll = currentInnerScroll:getView()

	if( velocityY < 0 ) then
		if( scrollView:getChildAt(0):getHeight() - scrollView:getHeight() == scrollView:getScrollY() ) then
			currentInnerScroll:fling( 0 - velocityY)
			return true
		end
	else
		if( scrollView:getScrollY() ~= 0 ) then
			currentInnerScroll:fling( 0 - velocityY)
			return true
		end
	end

	return false
end

InterrputTouchListener = {}
function InterrputTouchListener.onInterceptTouchEvent(ev)
	local action = ev:getAction()

	if( action == 0 ) then
		InterrputTouchListener.yDistance = 0
		InterrputTouchListener.yDistanceAbs = 0
		InterrputTouchListener.yLast = ev:getY()
		
		yTouchLast = ev:getY()
		yTouchDistance = 0
	end

	if( action == 2 ) then
		local curY = ev:getY()
		
		InterrputTouchListener.yDistanceAbs = InterrputTouchListener.yDistanceAbs + math.abs(curY - InterrputTouchListener.yLast)
		InterrputTouchListener.yLast = curY

		if( InterrputTouchListener.yDistanceAbs > mTouchSlop ) then
			return true
		end
	end

	return false
end

ScrollViewListener = {}
function ScrollViewListener.onScrollChanged(l, t, oldl, oldt)
	local scrollLength = 0
	local bannerHeight = 600
	
	if( mScrollView == nil or mNavBar == nil or mBannerView == nil )then
		return
	end
	
	scrollLength = mScrollView:getView():getScrollY()
	
	if( scrollLength <= 4 ) then
		mLastTransCount = 0
		mNavBar:getParser():update("titletransparency", 0)
		return
	end
	
	bannerHeight = mBannerView:getView():getHeight()
	if( scrollLength > bannerHeight ) then

		if( mLastTransCount ~= 255 ) then
			mLastTransCount = 255
			mNavBar:getParser():update("titletransparency", mLastTransCount)
		end
		return
	end

	if( scrollLength % 4 ~= 0 ) then
		return
	end
	
	local transCount = scrollLength / ( bannerHeight / 255 )
	if( transCount == mLastTransCount ) then
		return
	end

	mLastTransCount = transCount
	mNavBar:getParser():update("titletransparency", transCount)
end

function ScrollViewListener.onOverScrolled(scrollX, scrollY, clampedX, clampedY)
end