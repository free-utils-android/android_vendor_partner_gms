local mPhotonView, mJavaBridge = ...

function init()
    local commentIndex = mPhotonView:getParser():getBinder():get('comment_index')
    local commentCount = mPhotonView:getParser():getBinder():get('comment_count')

    if (commentIndex ~= nil and commentCount ~= nil) then
        local titleTextView = mPhotonView:getParser():getChildView('title_text' .. commentIndex)
        local titleText = mPhotonView:getParser():getBinder():get('title' .. commentIndex)

        -- 保底逻辑
        titleTextView:getView():setText(tostring(titleText) .. '(' .. tostring(commentCount) .. ')')

        local commentTitle = tostring(titleText) .. ' ' .. tostring(commentCount)
        local titleSpan =
            mJavaBridge:createNewInstance('android.text.SpannableString', {'java.lang.CharSequence', commentTitle})
        local absSpan =
            mJavaBridge:createNewInstance('android.text.style.AbsoluteSizeSpan', {'int', 10, 'boolean', true})
        titleSpan:setSpan(absSpan, characters(tostring(titleText), 1), characters(commentTitle, 1), 33)
        titleTextView:getView():setText(titleSpan)
    end
end

function characters(utf8Str, aChineseCharBytes)
    aChineseCharBytes = aChineseCharBytes or 2
    local i = 1
    local characterSum = 0
    while (i <= #utf8Str) do -- 编码的关系
        local bytes4Character = bytes4Character(string.byte(utf8Str, i))
        characterSum = characterSum + (bytes4Character > aChineseCharBytes and aChineseCharBytes or bytes4Character)
        i = i + bytes4Character
    end

    return characterSum
end

function bytes4Character(theByte)
    local seperate = {0, 0xc0, 0xe0, 0xf0}
    for i = #seperate, 1, -1 do
        if theByte >= seperate[i] then
            return i
        end
    end
    return 1
end
