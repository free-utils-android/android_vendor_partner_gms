local mPhotonView, mJavaBridge = ...

local currentCardPosition = nil
function addQueryText()
  initData()
  initTag()
end

function initData()
  currentCardPosition = tonumber(Rapid:getData("position"))
end

function initTag()
  local tabActionListener =
    luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonActionListener", TabActionListener)
  -- local screenWidth = mJavaBridge:px2dip(mPhotonView:getParser():getScreenWidth())
  local tagNum = tonumber(Rapid:getData("item_num"))
  -- local totalLength = 12
  -- local containerLength = screenWidth -16

  local containerNum = 1
  container = "tag_container_1"
  -- local textPaint = mPhotonView:getParser():getChildView("forMeasureTag"):getView():getPaint()
  mPhotonView:getParser():getChildView("tag_container_1"):getView():removeAllViews()
  mPhotonView:getParser():getChildView("tag_container_2"):getView():removeAllViews()
  mPhotonView:getParser():getChildView("tag_container_3"):getView():removeAllViews()
  mPhotonView:getParser():getChildView("tag_container_4"):getView():removeAllViews()
  for index = 1, tagNum do
    local itemData = Rapid:getData("item_data_" .. index)
    itemData:put("subposition", mJavaBridge:create("var", getReportPosition(index)))
    itemData:put("slotId", mJavaBridge:create("var", Rapid:getData("slotId")))
    itemData:put("scene", mJavaBridge:create("var", Rapid:getData("scene")))
    itemData:put("modeltype", mJavaBridge:create("var", Rapid:getData("modeltype")))
    itemData:put("sourceScene", mJavaBridge:create("var", Rapid:getData("sourceScene")))
    itemData:put("sourcescene", mJavaBridge:create("var", Rapid:getData("sourcescene")))
    itemData:put("sourcesceneslotid", mJavaBridge:create("var", Rapid:getData("sourcesceneslotid")))
    itemData:put("subscene", mJavaBridge:create("var", Rapid:getData("subscene")))
    local tagName = itemData:get("app_hot_topic_txt")
    local hotName = itemData:get("app_hot_topic_tag")
    local appName = itemData:get("app_name")
    -- local realName = appName
    -- if(tagName:getString() ~= nil and tagName:getString() ~="") then
    --      mJavaBridge:Log("testHotWord",tagName:getString())
    --      realName = tagName
    -- end
    -- local strHotName  = hotName:getString()
    -- if(strHotName ~= nil and strHotName ~="") then
    --   totalLength = totalLength + mJavaBridge:px2dip(textPaint:measureText(strHotName)) + 6
    -- end
    -- local strName = realName:getString()
    -- totalLength = totalLength + mJavaBridge:px2dip(textPaint:measureText(strName))+28

    if (index == 4 or index == 7 or index == 10) then
      containerNum = containerNum + 1
      container = "tag_container_" .. containerNum
    -- totalLength = 12+mJavaBridge:px2dip(textPaint:measureText(strName))+28
    -- if(containerNum >4) then
    --   return
    -- end
    end
    mJavaBridge:addView("native_search_app_hot_topic_card_item.xml",container,"",nil,itemData,tabActionListener)
  end
end

function getReportPosition(position)
  return string.format("%03d", position)
end

TabActionListener = {}
function TabActionListener.notify(key, value)
  if (key == "UpdateSourceQuery") then
    local params = {}
    params["key"] = "UpdateSourceQuery"
    Rapid:execAction("outeraction", params)
  end
end
