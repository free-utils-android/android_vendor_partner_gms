local mPhotonView,mJavaBridge = ...
local MB_UNIT = 1024 * 1024

-- 弹窗类别，垃圾清理弹窗
local POP_TYPE_RUBBISH_CLEAN = '1'
local POP_TYPE_GUID_TO_INSTALL = '8'
-- 场景条件类型
local CONDITION_ALL_RUBBISH = "\"type\":205"
local CONDITION_FAST_CLEAN_RUBBISH = "\"type\":207"

local external_install_app_id
local uni_pop_type
local SHOW = 1


function init()
    mJavaBridge:Log("desktop_common_bottom_double_button_window, from online")
    local main_title = Rapid:getData('main_title')
    local sub_title = Rapid:getData('sub_title')
    local check_point = Rapid:getData('check_point')

    uni_pop_type = Rapid:getData('uni_pop_type')
    if uni_pop_type == POP_TYPE_RUBBISH_CLEAN then
        -- 垃圾清理弹窗
        local rubbish_cache_size = getShowRubbishSize(check_point)
        local feature_title = string.format(main_title, "<font color='#f3b200'>"..rubbish_cache_size.."</font>")
        Rapid:setData('main_feature_title', resolveText(feature_title))
        Rapid:setData('sub_feature_title', resolveText(sub_title))
        Rapid:setData('uni_trash_size', getReportRubbishSize(check_point))
    else
        if uni_pop_type == POP_TYPE_GUID_TO_INSTALL then
            local external_install_app_name = Rapid:getData('external_install_app_name')
            local external_install_app_icon_url = Rapid:getData('external_install_app_icon_url')
            external_install_app_id = Rapid:getData('external_install_app_id')
            Rapid:setData('main_feature_title', external_install_app_name)
            Rapid:setData('sub_feature_title', resolveText(sub_title))
            Rapid:setData('small_icon_url', external_install_app_icon_url)
            dismiss_type = 0
        else
            Rapid:setData('main_feature_title', resolveText(main_title))
            Rapid:setData('sub_feature_title', resolveText(sub_title))
        end

    end



    local button_text = Rapid:getData('button_text')
    if button_text == nil or button_text == "" then
        Rapid:getChild('go_forward'):setAttr('visibility', 'gone')
    else
        Rapid:getChild('go_forward'):setAttr('visibility', 'visible')
    end
end

-- 根据场景条件判断显示哪种类型的垃圾：1. 全部垃圾； 2. 快速清理（已选中）的垃圾
function getShowRubbishSize(check_point)
    return formatSize(getRawRubbishSize(check_point))
end

-- 返回上报的垃圾数值格式，单位为MB
function getReportRubbishSize(check_point)
    return formatMBSize(getRawRubbishSize(check_point))
end

-- 根据场景条件返回特定的垃圾值，CONDITION_ALL_RUBBISH返回全部垃圾数量，CONDITION_FAST_CLEAN_RUBBISH返回快速清理垃圾数量
function getRawRubbishSize(check_point)
    local all_rubbish_condition = string.find(check_point, CONDITION_ALL_RUBBISH, 1)
    local fast_clean_rubbish_condition = string.find(check_point, CONDITION_FAST_CLEAN_RUBBISH, 1)
    if all_rubbish_condition ~= nil then
        return mJavaBridge:getRubbishCacheSize()
    elseif fast_clean_rubbish_condition ~= nil then
        return mJavaBridge:getRubbishSelectedCacheSize()
    else
        return mJavaBridge:getRubbishCacheSize()
    end
end

function formatSize(byteNum)
    local MemoryUtils = luajava.bindClass('com.tencent.assistant.utils.MemoryUtils')
    return MemoryUtils:formatSize(byteNum)
end

function formatMBSize(byteNum)
    return tostring(math.floor(byteNum/MB_UNIT + 0.5))
end

function resolveText(content)
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        return dialogSelf:resolveText(content)
    end
    return content
end

function doGoForward()
    local dialogSelf = Rapid:getData("self")
    if uni_pop_type == POP_TYPE_GUID_TO_INSTALL then
        jumpInstallPage()
        if dialogSelf ~= nil then
            dialogSelf:dismissDelayFinish(5,0, 2500)
        end
        mJavaBridge:reportClickForTouchSys()
        return
    end

    local button_click_action = Rapid:getData('button_click_action')

    if dialogSelf ~= nil then
        dialogSelf:executeClickAction(button_click_action)
        -- 跳转取消类型为5
        dialogSelf:dismiss(5, 0)
    end
end

function onPageOut(stayDuration)
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:2000,slotid:-1_-1,actionid:2005,subposition:-1,modeltype:-1"
    params1["extendparam"] = "report_element:page,stay_duration:"..stayDuration
    actionRunner:run("reportaction", params1, nil)
end

function onDismiss(dismissType)

    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:2000,slotid:99_001,actionid:201,subposition:001,modeltype:data@modeltype"
    params1["extendparam"] = "report_element:pop,uni_popid:data@uni_popid,uni_pop_type:data@uni_pop_type,uni_pop_configid:data@uni_pop_configid,uni_monitor_event_code:data@uni_monitor_event_code,uni_related_appid:data@external_install_app_id,uni_trash_size:data@uni_trash_size,uni_cancel_type:"..dismissType
    params1["recommendid"] = "data@R1"
    actionRunner:run("reportaction", params1, nil)
end

function jumpInstallPage()
    local params = {}
    mJavaBridge:setNormalSettingsData("key_accessibility_intro_dialog_show_time", SHOW)
    params['tmast'] = "tmast://go_install_by_appid?appid=" .. external_install_app_id
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end