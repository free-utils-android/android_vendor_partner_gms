require("game_welfare_ui_style")
local mPhotonView, mJavaBridge = ...

local recyclerView

function refreshData(...)
    recyclerView = Rapid:getChild("recyclerview")
    local itemCount = tonumber(Rapid:getData("item_count"))
    local viewName = "game_gift_rv_item.xml"
    local viewNameList = {}
    local dataList = {}
    local index = 1
    for i = 0, itemCount - 1 do
        local data = {}
        data["gift_tag"] = Rapid:getData("gift_tag_" .. index)
        data["icon_url"] = Rapid:getData("icon_url_" .. index)
        data = WelfareStyleCfg.mergeToTable(data, WelfareStyleCfg.gameGiftItemStyle())
        local visibility = "visible"
        if data["gift_tag"] == nil or data["gift_tag"] == "" then
            visibility = "gone"
        end
        data["visibility"] = visibility
        table.insert(viewNameList, viewName)
        table.insert(dataList, data)
        index = index + 1
    end
    local actionListner =
        luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonActionListener", IActionListener)
    recyclerView:getView():setActionListener(actionListner)
    recyclerView:getView():updateData(viewNameList, dataList, true)
end
IActionListener = {}
function IActionListener.notify(key, value)
    if (key == "go_detail") then
        goDetail()
    end
end
function goDetail(...)
    Rapid:runTask("jump_more_gift")
end
