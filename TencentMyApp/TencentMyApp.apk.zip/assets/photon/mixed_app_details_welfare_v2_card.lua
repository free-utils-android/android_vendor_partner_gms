require("game_welfare_ui_style")
local mRapidView, mJavaBridge = ...

-- const
local GET_SERVER = 0
local GAME_TYPE_CP = 1
-- 更多或推荐游戏
local TYPE_MORE_GAME = "5"
-- appstate list
local APP_UPDATE = 0
local APP_DOWNLOADING = 1
local APP_PAUSED = 3
local APP_DOWNLOADED = 4
local APP_INSTALLED = 5
local APP_DOWNLOAD = 9
-- gift status
local GIFT_CAN_GET = "0"
local GIFT_CAN_TOMORROW_GET = "1"
local GIFT_LIMIT = "2"
local GIFT_HAS_GET = "3"
local GIFT_COUPON_TYPE = "3"

-- member var
local mNeedRole = true
local mNeedServer = true
local mIsRequesting = false
local mAppStubComponent = nil
local mAppState = nil
local mGiftStatusMap = {}
local mGiftTypeMap = {}
local mGiftReportContextMap = {}
local signDataJson
local tomorrowSignJson
local tomorrowGameGiftJson
local isRefreshing = false
local totalWelfWare = 0
local mOnlyOneWelfWareType = false

-- 个安法授权
local AUTHORIZE_CMD = 306
local mAuthorize = false
local mAuthUrl = nil
local TAG = "detail_welfare"
local mRequesting = false
local mGiftRecyclerView = nil
local DEBUG = true
local mCurrentOffset = 0
local mAuthString = ""
local mAppId = 0
local mAppIdStrings = ""
local APP_TAG= "?appIds=%s"
local mAuthContent = ""
local mUnAuthorizeNum = 0

local function setOnlyOneWelfWareType(welfWareList)
    mOnlyOneWelfWareType = welfWareList:length() == 1
end

local function onlyOneTypeCountTxt(giftType)
    local lessThanTwoGameGiftHint = "更多礼包正在骑马赶来···"
    local onlyThreeGameGiftHint = "礼包正在骑马赶来···"
    local onlyOneGameCouponHint = "更多宝券正在骑马赶来···"
    local defaultHint = tostring("共" .. totalWelfWare .. "个")
    local weekSignGift = "4"
    local gameCoupon = "3"
    local gameGift = "1"
    if giftType == gameCoupon then
        if totalWelfWare == 1 then
            return onlyOneGameCouponHint
        else
            return defaultHint
        end

    elseif giftType == gameGift then
        if totalWelfWare <= 2 then
            return lessThanTwoGameGiftHint
        elseif totalWelfWare == 3 then
            return onlyThreeGameGiftHint
        else
            return defaultHint
        end
    else
        return defaultHint
    end
end

local function addStyle(welfwareData, welfwareType)
    local weekSignGift = "4"
    local gameCoupon = "3"
    local gameGift = "1"
    if welfwareType == weekSignGift then
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.weekSignGiftBgStyle())
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.weekSignGiftSumStyle())
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.weekSignGiftItemStyle())
    elseif welfwareType == gameCoupon then
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.gameCouponBgStyle())
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.gameCouponSumStyle())
        if ConfigUtils.useV3Style() and mOnlyOneWelfWareType and totalWelfWare <= 2 then
            welfwareData = WelfareStyleCfg.gameCouponBlockFullScreen(welfwareData, mJavaBridge)
        end
    else
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.gameGiftBgStyle())
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.gameGiftItemStyle())
        welfwareData = WelfareStyleCfg.mergeToTable(welfwareData, WelfareStyleCfg.gameGiftSumStyle())
        if ConfigUtils.useV3Style() and mOnlyOneWelfWareType and totalWelfWare <= 3 then
            welfwareData = WelfareStyleCfg.gameGiftBlockFullScreen(welfwareData, mJavaBridge)
        end
    end
    return welfwareData
end

local function setUpdateValue(data)
    data["is_update"] = Rapid:getData("is_update", 0)
    return data
end

IAppStateChangeListener = {}
function IAppStateChangeListener.onState(state)
    updateGiftBtnState(state)
end

function init()
    local itemDecoration = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.IItemDecorationListener",
            IItemDecorationListener
    )
    Rapid:getChild("recyclerview"):getView():addItemDecoration(itemDecoration)

    mAppStubComponent = mJavaBridge:createAppStubComponent()

    local appStateListener = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.control.IAppStubComponent$IAppStateChangeListener",
            IAppStateChangeListener
    )
    mAppStubComponent:registerAppStateChangeListener(appStateListener)
end

function main()
    getAuthString()
    initAuthorizeParam()
    parserAuthorize(mAuthString)
    WelfareStyleCfg.applyStyle(WelfareStyleCfg.welfareTitleStyle())
    WelfareStyleCfg.applyStyle(WelfareStyleCfg.welfareBtnStyle())
    fillData()
    local appModel = Rapid:getData("app_model")
    if appModel ~= nil then
        mAppStubComponent:setAppModel(Rapid:getData("app_model"))
    end

    updateGiftBtnState(mAppStubComponent:getAppState())
end

function onLoginStatusChanged(...)
    if isRefreshing then
        return
    end
    if mJavaBridge:getLoginType() == "NONE" then
        return
    end
    isRefreshing = true
    local params = {}
    params["pkgName"] = tostring(Rapid:getData("package_name", ""))
    params["appId"] = tostring(Rapid:getData("appid", ""))
    params["versionCode"] = tostring(Rapid:getData("version_code", ""))

    mJavaBridge:request(2200, params, onRefreshInfoListener)
end

function onRefreshInfoListener(succeed, viewNameList, dataList)
    isRefreshing = false
    if (succeed) then
        if dataList == nil or dataList:size() < 1 then
            return
        end


        local dataMap = dataList:get(0)
        local entries = dataMap:entrySet():iterator()
        while (entries:hasNext()) do
            local entry = entries:next()
            local key = entry:getKey()
            local val = entry:getValue():getLuaValue()
            mJavaBridge:Log(TAG, "key:" .. tostring(key) .. "  value:" .. tostring((val)))
        end

        local retCode = tonumber(tostring(dataMap:get("ret")))
        if retCode ~= 0 then
            return
        end

        Rapid:setData("display_gift_v2_list", tostring(dataMap:get("display_gift_v2_list")))
        Rapid:setData("app_list", tostring(dataMap:get("gift_app_list")))
        Rapid:setData("gift_total_worth", tostring(dataMap:get("gift_total_worth")))
        Rapid:setData("gift_total_count", tostring(dataMap:get("gift_total_count")))
        Rapid:setData("more_gift_url", tostring(dataMap:get("more_gift_url")))
        Rapid:setData("game_type", tostring(dataMap:get("game_type")))
        Rapid:setData("need_server", tostring(dataMap:get("need_server")))
        Rapid:setData("need_role", tostring(dataMap:get("need_role")))
        Rapid:setData("gift_list", tostring(dataMap:get("gift_list")))
        main()

    end
end

function updateGiftBtnState(state)
    if state == nil or state == mAppState then
        return
    end

    local gameType = Rapid:getData("game_type", "")
    if tonumber(gameType) == GAME_TYPE_CP then
        -- 联运游戏
        Rapid:getChild("btn_gift"):setAttr("text", "查看领取")
        return
    end

    mAppState = state

    local btnText = "下载领取"
    if mAppState == APP_DOWNLOADED then
        btnText = "安装领取"
    end

    if mAppState == APP_UPDATE then
        btnText = "更新领取"
    end

    if mAppState == APP_INSTALLED then
        btnText = "一键领取"
    end

    Rapid:getChild("btn_gift"):setAttr("text", btnText)
end

function fillData()
    mNeedRole = Rapid:getData("need_role", "0") == "1"
    mNeedServer = Rapid:getData("need_server", "0") == "1"

    initGiftData()
    if ConfigUtils.useV3Style() then
        local hintText = string.format("共<font color='#f79800'> %s </font>个礼包待领", totalWelfWare)
        local htmlClass = luajava.bindClass("android.text.Html")
        local title = htmlClass:fromHtml(hintText)
        Rapid:getChild("title"):getView():setText(title)
    else
        Rapid:setData("title", string.format("游戏福利（价值%s元）", Rapid:getData("gift_total_worth", "")))
    end
end

function initGiftData()
    local viewList = {}
    local dataList = {}

    -- 填充礼包数据
    local giftList = mJavaBridge:create("jsonarray", tostring(Rapid:getData("display_gift_v2_list", "")))
    local appList = mJavaBridge:create("jsonarray", tostring(Rapid:getData("gift_app_list", "")))

    if giftList == nil then
        return
    end
    -- 兼容后端数据，后端数据重构中。。。
    if appList ~= nil then
        for i = 0, appList:length() - 1 do
            local giftItem = appList:optJSONObject(i)
            if giftItem == nil then
                break
            end
            giftList:put(giftItem)
        end
    end

    setOnlyOneWelfWareType(giftList)
    for i = 0, giftList:length() - 1 do
        local giftItem = giftList:optJSONObject(i)
        if giftItem == nil then
            break
        end

        local giftData = {}
        local giftType = giftItem:optString("type")

        local giftArray = giftItem:optJSONArray("dataArray")
        if giftType ~= TYPE_MORE_GAME then
            totalWelfWare = totalWelfWare + giftArray:length()
        end
        local day = giftItem:optInt("day", 1)
        if day <= 0 then
            day = 1
        end
        local endPosition = getEndPosition(day, giftItem)
        local iconIndex = 1
        local dataIndex = 1
        local startDay = day

        if giftType ~= "4" and giftType ~= "3" then
            tomorrowGameGiftJson = giftArray
        end

        if giftArray ~= nil and endPosition > 0 then
            giftData["item_count"] = tostring(endPosition)
            if ConfigUtils.useV3Style() and mOnlyOneWelfWareType then
                giftData["total_count"] = onlyOneTypeCountTxt(giftType)
            else
                giftData["total_count"] = tostring("共" .. giftArray:length() .. "个")
            end
            if giftType == TYPE_MORE_GAME then
                giftData["more_title"] = giftItem:optString("moreTitle")
                giftData["more_url"] = giftItem:optString("more_url")
            elseif giftType == "3" then
                giftData["baoquan_title"] = "宝券（" .. "共" .. giftArray:length() .. "个）"
            else
                giftData["game_gift_title"] = "游戏礼包（" .. "共" .. giftArray:length() .. "个）"
            end

            for i = day - 1, endPosition - 1 do
                local giftDayData = giftArray:optJSONObject(i)
                -- 第2天和第五天的个数不一定的，当起始的天数为2或者5时，其下一天的的icon获取需要特殊处理下
                if startDay == 2 and i == 2 then
                    iconIndex = 4
                end
                if startDay == 5 and i == 5 then
                    iconIndex = 4
                end
                if giftDayData ~= nil then
                    local giftId = giftDayData:optString("id")
                    local giftStauts = giftDayData:optString("status", "-1")
                    local giftReportContext = giftDayData:optString("report_context", "-1")

                    if mGiftStatusMap[giftId] == nil then
                        mGiftStatusMap[giftId] = giftStauts
                    end
                    if mGiftTypeMap[giftId] == nil then
                        mGiftTypeMap[giftId] = giftType
                    end
                    mGiftReportContextMap[giftId] = giftReportContext

                    if giftType == "4" and i == day - 1 then
                        signDataJson = giftDayData
                    end
                    if giftType == "4" then
                        if day == 7 then
                            tomorrowSignJson = giftArray:optJSONObject(0)
                        else
                            if i == day then
                                tomorrowSignJson = giftDayData
                            end
                        end
                    end

                    local iconUrlString = giftDayData:optString("icon_url")
                    local iconUrls = mJavaBridge:create("jsonarray", iconUrlString)
                    if iconUrls ~= nil then
                        for i = 0, iconUrls:length() - 1 do
                            local iconData = iconUrls:optJSONObject(i)
                            giftData["icon_url_" .. iconIndex] = iconData:optString("url", "")
                            giftData["icon_name_" .. iconIndex] = iconData:optString("name", "")
                            iconIndex = iconIndex + 1
                        end
                    end
                    giftData["detail_url"] = giftDayData:optString("detail_url", "")
                    giftData["gift_url_" .. dataIndex] = giftDayData:optString("icon_url", "")
                    if giftType == "4" then
                        giftData["gift_tag_" .. dataIndex] = "第" .. (i + 1) .. "天"
                    elseif giftType == TYPE_MORE_GAME then
                        giftData["gift_tag_" .. dataIndex] = giftDayData:optString("count", "")
                        giftData["game_icon_" .. dataIndex] = giftDayData:optString("gameIcon", "")
                        giftData["detail_url_" .. dataIndex] = giftDayData:optString("detail_url", "")
                    else
                        giftData["gift_tag_" .. dataIndex] = giftDayData:optString("tag", "")
                    end
                    giftData = setUpdateValue(giftData)
                    giftData["gift_worth_" .. dataIndex] = giftDayData:optString("worth", "")
                    -- 由于价值在宝券上展示时为斜体，这里增加一个空格，防止最后一个字符被截断
                    giftData["gift_worth_text_" .. dataIndex] = "¥" .. giftDayData:optString("worth", "")

                    giftData["gift_title_" .. dataIndex] = giftDayData:optString("title", "")
                    giftData["gift_desc_" .. dataIndex] = giftDayData:optString("desc", "")
                    local status = giftDayData:optString("status", "")
                    if status == "0" then
                        giftData["gradientdrawable"] = "cornerradius:8,strokewidth:3,strokecolor:f79800"
                    else
                        giftData["gradientdrawable"] = ""
                    end
                    if i == day - 1 then
                        giftData["gift_report_context"] = tostring(giftReportContext)
                    end
                end
                dataIndex = dataIndex + 1
            end
        end

        -- 上报相关数据
        -- 礼包自带字段
        giftData["reportId"] = "coupon"
        giftData["card_report_context"] = Rapid:getData("card_report_context", "")

        -- 外卡塞进来的字段
        giftData["source_report_context"] = Rapid:getData("source_report_context", "")
        giftData["recommendid"] = Rapid:getData("card_recommendid", "")

        giftData["scene"] = Rapid:getData("scene", "")
        giftData["slotid"] = Rapid:getData("slotid", "")
        giftData["subposition"] = tostring(i + 1)
        giftData["sourcescene"] = Rapid:getData("sourcescene", "")
        giftData["sourcesceneslotid"] = Rapid:getData("sourcesceneslotid", "")
        giftData["sourcemodeltype"] = Rapid:getData("sourcemodeltype", "")
        giftData["modeltype"] = Rapid:getData("modeltype", "")
        giftData["giftType"] = giftType
        giftData = addStyle(giftData, giftType)
        table.insert(viewList, getItemViewName(giftItem))
        table.insert(dataList, giftData)

    end
    local outIndex = tonumber(Rapid:getData("index", "0"))
    local totalCount = giftList:length()
    Rapid:getChild("recyclerview"):getView():autoReport(outIndex, totalCount, RapidList:getController())
    Rapid:getChild("recyclerview"):getView():updateData(viewList, dataList, true)
end

--获取展示item的结束位置，从1开始
function getEndPosition(day, giftItem)
    local giftType = giftItem:optString("type")
    local giftArray = giftItem:optJSONArray("dataArray")
    if giftType == "4" then
        -- 签到
        if day == 3 then
            return getSignPkgLength(giftArray, 5)
        end
        if day == 7 then
            return getSignPkgLength(giftArray, day)
        end
        return getSignPkgLength(giftArray, day + 1)
    elseif giftType == "3" then
        --宝券
        if ConfigUtils.useV3Style() then
            return giftArray:length()
        else
            return getLength(giftArray, 2)
        end
    else
        -- 游戏礼包
        if ConfigUtils.useV3Style() then
            return giftArray:length()
        else
            return getLength(giftArray, 3)
        end
    end
end

function getSignPkgLength(giftArray, defaultLength)
    if giftArray == nil then
        return 0
    end
    local length = giftArray:length()
    if length < defaultLength then
        return length
    end
    return defaultLength
end

function getLength(giftArray, maxLength)
    if giftArray == nil then
        return 0
    end
    local length = giftArray:length()
    if length > maxLength then
        return maxLength
    end
    return length
end

function getItemViewName(jsonObj)
    local giftItem = jsonObj:optString("type")
    if giftItem == "3" then
        -- 宝券
        return "baoquan_item.xml"
    elseif giftItem == "4" then
        -- 签到

        return getSignViewName(jsonObj)
    elseif giftItem == TYPE_MORE_GAME then
        return "more_game_gift_item.xml"
    else
        --游戏礼包
        return "game_gift_item.xml"
    end
end

function getSignViewName(jsonObj)
    local signDay = jsonObj:optInt("day", 1)
    if signDay == 1 or signDay == 4 then
        return "sign_gift_day_container_1.xml"
    elseif signDay == 2 or signDay == 5 then
        return "sign_gift_day_container_2.xml"
    elseif signDay == 3 then
        return "sign_gift_day_container_3.xml"
    elseif signDay == 6 then
        return "sign_gift_day_container_6.xml"
    else
        return "sign_gift_day_container_7.xml"
    end
end

function getGiftCompeleteMap()
    local giftInfoMap = {}
    -- 解析全量礼包数据，领取成功后会从这里面选择出来展示
    local giftList = mJavaBridge:create("jsonarray", tostring(Rapid:getData("gift_list", "")))
    if giftList == nil then
        return
    end

    for i = 0, giftList:length() - 1 do
        local giftItem = giftList:optJSONObject(i)
        if giftItem == nil then
            break
        end

        local giftData = {}
        local giftId = tostring(giftItem:optString("id", ""))
        giftData["report_context"] = giftItem:optString("report_context", "")
        giftData["recommendid"] = giftItem:optString("card_recommendid", "")

        giftData["id"] = giftItem:optString("id", "")
        giftData["type"] = giftItem:optString("type", "")
        giftData["name"] = giftItem:optString("name", "")
        giftData["worth"] = giftItem:optString("worth", "")
        giftData["desc"] = giftItem:optString("desc", "")
        giftData["tag"] = giftItem:optString("tag", "")
        -- giftData["icon_url"] = giftItem:optString("icon_url", "")
        local iconJson = mJavaBridge:create("jsonarray", giftItem:optString("icon_url", ""))

        mJavaBridge:Log("popWin", " iconJson:" .. tostring(iconJson))

        giftData["icon_url"] = getUrl(iconJson)
        giftData["title"] = giftItem:optString("title", "")
        giftData["category"] = giftItem:optString("category", "")
        giftData["status"] = giftItem:optString("status", "")
        giftData["template_id"] = giftItem:optString("template_id", "")
        giftData["template_type"] = giftItem:optString("template_type", "")
        printf("handle gitfData template_id template_type")
        giftData["detail_url"] = giftItem:optString("detail_url", "")
        giftInfoMap[giftId] = giftData
    end
    return giftInfoMap
end

function getUrl(iconJson)
    if iconJson == nil then
        return ""
    end

    local object = iconJson:optJSONObject(0);
    if object == nil then
        return ""
    end
    local url = object:optString("url", "")
    if url == nil then
        return ""
    end
    return url
end

function showServers()
    local params = {}
    params["pkgName"] = Rapid:getData("package_name", "")
    params["appid"] = Rapid:getData("appid", "")

    mJavaBridge:request(2198, params, onServerRequestListener)
end

function onServerRequestListener(succeed, viewNameList, dataList)
    if (succeed) then
        showServerRoleSelectorDialog(dataList)
    else
        mJavaBridge:showToast("获取区服失败", 1000)
    end
    mIsRequesting = false
end

function showServerRoleSelectorDialog(dataList)
    local defaultServer = ""
    local serversList = ""

    if dataList == nil or dataList:size() < 1 then
        mJavaBridge:showToast("获取区服信息失败", 1000)
        return
    end

    local dataMap = dataList:get(0)
    local retCode = tonumber(tostring(dataMap:get("ret")))
    local errorMsg = dataMap:get("msg")
    if retCode ~= 0 then
        if errorMsg == nil then
            errorMsg = "获取区服信息失败,错误码：" .. tostring(retCode)
        end
        mJavaBridge:showToast(tostring(errorMsg), 1000)
        return
    end

    local serverList = dataMap:get("partitionList")
    local defaultServer = dataMap:get("defaultServer")
    local defaultRole = dataMap:get("defaultRole")

    local dialogParams = {}
    dialogParams["default_server"] = tostring(defaultServer)
    dialogParams["default_role"] = tostring(defaultRole)
    dialogParams["servers"] = tostring(serverList)
    dialogParams["need_role"] = mNeedRole
    dialogParams["need_server"] = mNeedServer
    dialogParams["pkg_name"] = Rapid:getData("package_name", "")
    dialogParams["theme_color"] = mThemeColor

    if mServerDialogShowing then
        return
    end
    mServerDialogShowing = true

    local selectDialog = mJavaBridge:showCustomDialogAsync("common_server_selector_dialog_v2.xml", dialogParams, nil, "资源拉取失败，请稍后重试")

    local dialogListner = luajava.createProxy(
            "com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",
            ServerRoleDialogEventListener
    )

    selectDialog:setPhotonDialogEventListener(dialogListner)
end

ServerRoleDialogEventListener = {}
function ServerRoleDialogEventListener.onDialogEvent(eventType, dialogData)
    if eventType == "ON_SERVER_ROLE_SELECTED" and dialogData ~= nil then
        mServerName = tostring(dialogData:get("selecetd_server_name"))
        mServerID = tostring(dialogData:get("selecetd_server_id"))
        mRoleName = tostring(dialogData:get("selecetd_role_name"))
        mRoleID = tostring(dialogData:get("selecetd_role_id"))
        sendGiftRequest(mServerID, mServerName, mRoleID, mRoleName)
    elseif eventType == "DISMISS" then
        mServerDialogShowing = false
    end
end

function tryRequestGift()
    mAppState = mAppStubComponent:getAppState()
    local gameType = Rapid:getData("game_type", "")

    if tonumber(gameType) == GAME_TYPE_CP then
        -- 联运游戏
        Rapid:runTask("jump_more_gift")
        return
    end

    if mAppState == APP_DOWNLOADING or mAppState == APP_PAUSED or mAppState == APP_DOWNLOAD then
        reportWelfareDownloadToClick()
    end

    if mAppState == APP_INSTALLED then
        local btnText = tostring(Rapid:getChild("btn_gift"):getView():getText())
        local context = "data@card_report_context,uni_button_title:" .. btnText
        reportButtonClick("102", context, 1)
        reportWelfareClickToGet()
    end

    if mAppState == APP_UPDATE then
        reportWalfareUpdateToClick()
        callPageButtonDoDownload()
        return
    end

    if mAppState == APP_DOWNLOAD then
        callPageButtonDoDownload()
        return
    end

    if mAppState == APP_DOWNLOADED then
        reportWalfareInstallToClick()
        callPageButtonDoInstall()
        return
    end

    -- 最后做一次检查，除了安装状态外，都转发给下载按钮
    if mAppState ~= APP_INSTALLED then
        callPageButtonDoDownload()
        return
    end

    -- 判断是否登录
    if mJavaBridge:getLoginType() == "NONE" then
        openLoginActivity()
        return
    end

    -- 个安法添加
    if mAuthorize == false then
        tryAuthorize()
        return
    end

    -- 不需要选区服，直接领取
    if not mNeedRole and not mNeedServer then
        sendGiftRequest("", "", "", "")
        return
    end
    showServers()
end

function callPageButtonDoDownload()
    local params = {}
    params["key"] = "download_app"
    -- 这里是数据同学定义的固定字段，需要区分点击场景传给外层按钮
    params["value"] = "uni_click_type:8910101"
    Rapid:execAction("outeraction", params, nil)
    mJavaBridge:showToast("正在下载安装游戏，完成后可领福利", 1000)
end

function callPageButtonDoInstall()
    local params = {}
    params["key"] = "install_app"
    -- 这里是数据同学定义的固定字段，需要区分点击场景传给外层按钮
    params["value"] = "uni_click_type:8910101"
    Rapid:execAction("outeraction", params, nil)
end

function openLoginActivity()
    local jsParams = {}
    jsParams["logintype"] = "DEFAULT"
    mJavaBridge:runJsBridge("openLoginActivity", jsParams, nil)
end

function getTestFunc()
    sendGiftRequest("", "", "", "")
end
function transString(string)
    if string == nil or string == "nil" then
        return ""
    end
    return string
end
function sendGiftRequest(svrId, svrName, roleId, roleName)
    local amsReq = mJavaBridge:create("jsonobject")
    amsReq:putOpt("svrId", transString(svrId))
    amsReq:putOpt("svrName", transString(svrName))
    amsReq:putOpt("roleId", transString(roleId))
    amsReq:putOpt("roleName", transString(roleName))

    local signInGift = mJavaBridge:create("jsonobject")
    local status = -1
    if signDataJson ~= nil then
        signInGift:putOpt("platform_gift_id", signDataJson:optString("platform_gift_id"))
        signInGift:putOpt("category", signDataJson:optInt("category"))

        local tempTypeStr = signDataJson:optString("template_type", "")
        signInGift:putOpt("template_type", tempTypeStr)

        local tempIdStr = signDataJson:optString("template_id", "")
        signInGift:putOpt("template_id", tempIdStr)

        printf("template_type sendGiftRequest tempTypeStr:" .. tostring(tempTypeStr)
            .. " template_id:" .. tostring(tempIdStr))
        status = signDataJson:optInt("status")
        --福利卡领取大同后台上报支持
        signInGift:putOpt("clientPrivateReport", tostring(Rapid:getData("card_report_context", "")))
        signInGift:putOpt("clientCommonReport", getClientCommonReportValue())
    end
    local params = {}
    params["pkgName"] = Rapid:getData("package_name", "")
    params["giftList"] = Rapid:getData("gift_list", "")
    params["amsReq"] = tostring(amsReq)
    if status == 0 then
        params["signInGift"] = tostring(signInGift)
    end
    print("reqjson-detail="..tostring(signInGift))
    mJavaBridge:request(2197, params, onGiftRequestListener)
end

function getClientCommonReportValue()
    local commonReportValue = mJavaBridge:create("jsonobject")
    commonReportValue:putOpt("dt_pgid","page_detail_soft")
    commonReportValue:putOpt("recommendid",getBase64RecommendId())
    commonReportValue:putOpt("scene",tostring(Rapid:getData("scene", "")))
    return tostring(commonReportValue)
end

function getBase64RecommendId()
    local rid = Rapid:getData("recommendid", "")
    local ridBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", rid), "default")
    local urlRid = mJavaBridge:urlEncode(ridBase64)
    return tostring(urlRid)
end

function onGiftRequestListener(succeed, viewNameList, dataList)
    local getGiftSucc = parserGiftData(dataList)
    if not getGiftSucc then
        onGetGiftFailed()
    end
end

function parserGiftData(dataList)
    if dataList == nil or dataList:size() < 1 then
        return false
    end
    local dataMap = dataList:get(0)
    local retCode = tonumber(tostring(dataMap:get("ret")))
    local errorMsg = dataMap:get("msg")
    if retCode ~= 0 then
        if errorMsg == nil then
            errorMsg = "获取区服信息失败,错误码：" .. tostring(retCode)
        end
        mJavaBridge:showToast(tostring(errorMsg), 1000)
        return false
    end

    local receiveGiftData = tostring(dataMap:get("receiveGiftData"))
    local receiveGiftJson = mJavaBridge:create("jsonarray", receiveGiftData)
    if receiveGiftJson == nil then
        return false
    end

    return showGiftResultDialog(receiveGiftData)
end

function showGiftResultDialog(data)
    local receiveGiftJson = mJavaBridge:create("jsonarray", data)
    if receiveGiftJson == nil then
        return false
    end

    local dialogDataMap = {}
    local giftInfoMap = getGiftCompeleteMap()
    -- 本次领取成功的礼物数量
    local validGiftCount = 0
    -- 本次未领取成功，但是还未领取，未来达成条件以后可领取的礼包梳理
    local futureValidGiftCount = 0

    local signGiftId = ""
    if signDataJson ~= nil then
        signGiftId = signDataJson:optString("id", "")
    end
    local isGiftSignSucc = false
    for i = 0, receiveGiftJson:length() - 1 do
        local receiveGiftItem = receiveGiftJson:optJSONObject(i)
        local onlyShowGift = false
        if receiveGiftItem ~= nil then
            local id = receiveGiftItem:optString("giftId", "")
            local ret = tonumber(receiveGiftItem:optString("receiveRet"))

            local reportContext = mGiftReportContextMap[id]
            local reportContextKey = "gift_item_rc_" .. tostring(id) .. ",uni_get_type:0"

            Rapid:setData(reportContextKey, reportContext)

            if signGiftId == id then
                onlyShowGift = ret == 0
                isGiftSignSucc = ret == 0
            end

            if ret == 0 then
                if not onlyShowGift then
                    -- 领取成功
                    local itemData = giftInfoMap[id]
                    validGiftCount = validGiftCount + 1
                    dialogDataMap["item_data_" .. validGiftCount] = itemData
                    -- 记录领取成功
                    mGiftStatusMap[id] = GIFT_HAS_GET
                end
                if mGiftTypeMap[id] ~= nil then
                    if (mGiftTypeMap[id] == GIFT_COUPON_TYPE) then
                        reportCouponGetSuccess("data@" .. reportContextKey, tostring(i + 1))
                    else
                        reportWelfareGetSuccess("data@" .. reportContextKey, tostring(i + 1))
                    end
                end
            else
                -- 领取失败
                local giftStatus = mGiftStatusMap[id]
                if giftStatus == GIFT_CAN_GET then
                    -- 可领取但是领取失败，说明条件不满足
                    futureValidGiftCount = futureValidGiftCount + 1
                end
                if mGiftTypeMap[id] ~= nil then
                    if (mGiftTypeMap[id] == GIFT_COUPON_TYPE) then
                        reportCouponGetFail("data@" .. reportContextKey, tostring(i + 1))
                    else
                        reportWalfareGetFail("data@" .. reportContextKey, tostring(i + 1))
                    end
                end
            end
        end
    end

    mJavaBridge:Log("popWin", "validGiftCount:" .. validGiftCount)
    if isGiftSignSucc then
        dialogDataMap["sign_data"] = tostring(signDataJson)
    end

    if validGiftCount == 0 and not isGiftSignSucc then
        showNoMoreGiftDialog(futureValidGiftCount)
        return true
    end

    dialogDataMap["item_count"] = validGiftCount
    dialogDataMap["future_item_count"] = futureValidGiftCount
    local itemCount = 0
    if tomorrowSignJson ~= nil then
        local iconUrlString = tomorrowSignJson:optString("icon_url")
        itemCount = inflateIconInfo(iconUrlString, dialogDataMap, 0)
    end
    if tomorrowGameGiftJson ~= nil then
        for i = 0, tomorrowGameGiftJson:length() - 1 do
            local itemData = tomorrowGameGiftJson:optJSONObject(i)
            if itemData:optString("tag") == "每日" then
                itemCount = itemCount + inflateIconInfo(itemData:optString("icon_url"), dialogDataMap, itemCount)
            end
        end
    end

    dialogDataMap["tomorrow_item_count"] = tostring(itemCount)
    mJavaBridge:Log("popWin", " show mixed_app_detail_welfare_gift_detail_dialog_v2")
    mJavaBridge:showCustomDialogAsync(
            "mixed_app_detail_welfare_gift_detail_dialog_v2.xml",
            dialogDataMap,
            nil,
            "礼包领取成功"
    )

    return true
end

function inflateIconInfo(iconUrlString, dialogDataMap, startIndex)
    local itemCount = 0
    local iconUrls = mJavaBridge:create("jsonarray", iconUrlString)
    if iconUrls ~= nil then
        for i = 0, iconUrls:length() - 1 do
            index = startIndex + 1 + i
            local iconData = iconUrls:optJSONObject(i)
            local giftData = {}
            giftData["icon_url"] = iconData:optString("url", "")
            giftData["icon_name"] = iconData:optString("name", "")
            dialogDataMap["tomorrow_item_data_" .. index] = giftData
            itemCount = itemCount + 1
        end
    end
    return itemCount
end

function showNoMoreGiftDialog(futureValidGiftCount)
    local dialogDataMap = {}
    local title = "暂无可领取礼包"
    local content = "明天再来领取更多礼包吧"

    if tonumber(futureValidGiftCount) > 0 then
        content = string.format("还有%s个礼包，解锁领取条件后再来领取吧！", futureValidGiftCount)
    end

    dialogDataMap["title"] = title
    dialogDataMap["content"] = content

    dialogDataMap["left_btn_text"] = "好的"
    dialogDataMap["left_btn_url"] = ""

    dialogDataMap["right_btn_text"] = ""
    if Rapid:getData("more_gift_url", "") ~= "" then
        dialogDataMap["right_btn_text"] = "查看详细"
    end

    dialogDataMap["right_btn_url"] = Rapid:getData("more_gift_url", "")

    local defaultText = title .. "," .. content
    mJavaBridge:showCustomDialogAsync("mixed_app_detail_welfare_tip_dialog_v2.xml", dialogDataMap, nil, defaultText)
end

function onGetGiftFailed()
    mJavaBridge:showToast("领取礼包失败，请稍后再试", 1000)
end

IItemDecorationListener = {}
function IItemDecorationListener.onDraw(c, parent, state)
end

function IItemDecorationListener.onDrawOver(c, parent, state)
end

function IItemDecorationListener.getItemOffsets(outRect, view, parent, state)
    local index = parent:getChildAdapterPosition(view)

    if (index == 0) then
        outRect.left = mJavaBridge:dip2px(16)
        outRect.right = mJavaBridge:dip2px(12)
    else
        outRect.right = mJavaBridge:dip2px(12)
    end
end

local ACTIONID_TEMPLATE = "actionid:%s"
local SUB_POSITION = "subposition:%s"
local REPORT_CONTEXT_TEMPLATE = report_context

function reportCommon(cmd, context)
    local actionStr = string.format(ACTIONID_TEMPLATE, cmd)
    local actionReportContext = "report_context:" .. context
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid,subposition:-1," ..
            actionStr ..
            ",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid"
    reportParams["recommendid"] = "data@card_recommendid"
    reportParams["extendparam"] = "report_element:welfare,sourcereportcontext:data@source_report_context," .. actionReportContext

    mRapidView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportCouponItemCommon(cmd, context, index)
    local actionStr = string.format(ACTIONID_TEMPLATE, cmd)
    local subPosStr = string.format(SUB_POSITION, index)
    local actionReportContext = "report_context:" .. context
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid," ..
            subPosStr ..
            "," ..
            actionStr ..
            ",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid"
    reportParams["recommendid"] = "data@card_recommendid"
    reportParams["extendparam"] = "report_element:coupon,sourcereportcontext:data@source_report_context," .. actionReportContext

    mRapidView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportWelfareItemCommon(cmd, context, index)
    local actionStr = string.format(ACTIONID_TEMPLATE, cmd)
    local subPosStr = string.format(SUB_POSITION, index)
    local actionReportContext = "report_context:" .. context
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid," ..
            subPosStr ..
            "," ..
            actionStr ..
            ",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid"
    reportParams["recommendid"] = "data@card_recommendid"
    reportParams["extendparam"] = "report_element:welfare,sourcereportcontext:data@source_report_context," .. actionReportContext

    mRapidView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportButtonClick(cmd, context, index)
    local actionStr = string.format(ACTIONID_TEMPLATE, cmd)
    local subPosStr = string.format(SUB_POSITION, index)
    local actionReportContext = "report_context:" .. context
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid," ..
            subPosStr ..
            "," ..
            actionStr ..
            ",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid"
    reportParams["recommendid"] = "data@card_recommendid"
    reportParams["extendparam"] = "report_element:button,sourcereportcontext:data@source_report_context," .. actionReportContext

    mRapidView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportWelfareClickToGet()
    local cmd = 102

    local giftList = mJavaBridge:create("jsonarray", tostring(Rapid:getData("display_gift_v2_list", "")))
    if giftList == nil then
        return
    end
    local index = 1
    for i = 0, giftList:length() - 1 do
        local giftItem = giftList:optJSONObject(i)
        if giftItem == nil then
            break
        end

        local giftType = giftItem:optString("type")

        local giftArray = giftItem:optJSONArray("dataArray")
        local day = giftItem:optInt("day", 1)
        if day <= 0 then
            day = 1
        end
        local endPosition = getEndPosition(day, giftItem)

        if giftArray ~= nil and endPosition > 0 then
            for i = day - 1, endPosition - 1 do
                local giftDayData = giftArray:optJSONObject(i)
                if giftDayData ~= nil then
                    local giftReportContext = tostring(giftDayData:optString("report_context", "-1"))
                    local id = giftDayData:optString("id", "")
                    local key = "gift_item_rc_" .. id
                    Rapid:setData(key, giftReportContext)
                    local context = "data@" .. key .. ",uni_get_type:0"
                    if giftType == "4" then
                        if i == day - 1 then
                            if giftDayData:optInt("status") == 0 then
                                reportWelfareItemCommon(cmd, context, index)
                            end
                        end
                    elseif giftType == "3" then
                        --宝券
                        reportCouponItemCommon(cmd, context, index)
                    else
                        -- 游戏礼包
                        reportWelfareItemCommon(cmd, context, index)
                    end
                end
            end
        end
        index = index + 1
    end
end

function reportCouponGetSuccess(context, index)
    local cmd = 103
    reportCouponItemCommon(cmd, context, index)
end

-- 礼包领取条件不满足导致的失败，使用giftitem report_context上报
function reportCouponGetFail(context, index)
    local cmd = 104
    reportCouponItemCommon(cmd, context, index)
end

function reportWelfareGetSuccess(context, index)
    local cmd = 103
    reportWelfareItemCommon(cmd, context, index)
end

-- 礼包领取条件不满足导致的失败，使用giftitem report_context上报
function reportWalfareGetFail(context, index)
    local cmd = 104
    reportWelfareItemCommon(cmd, context, index)
end

function reportWelfareDownloadToClick()
    local cmd = 108
    local context = "data@card_report_context"
    reportWelfareItemCommon(cmd, context, 1)
end

function reportWalfareUpdateToClick()
    local cmd = 109
    local context = "data@card_report_context"
    reportWelfareItemCommon(cmd, context, 1)
end

function reportWalfareInstallToClick()
    local cmd = 110
    local context = "data@card_report_context"
    reportWelfareItemCommon(cmd, context, 1)
end

-- 个安法授权添加
-- --------------------------------------------------------------
function initAuthorizeParam() 
    printf("initAuthorizeParam")
    mAuthUrl = Rapid:getData("personal_security_auth_data_url")
    mAuthorize = false 
    mAppIdStrings = ""
end


-- 卡片新增
function onResume()
    mJavaBridge:Log(TAG, "onResume requestQueryIfNeeded")
    requestQueryIfNeeded()
end

function printf(str)
    if DEBUG then
        print(TAG .. " " .. tostring(str))
    end
end


function jumpPage(url)
    if url == nil then
        return
    end

    local URLEncoder = luajava.bindClass('java.net.URLEncoder')
    local params = {}
    local jumpUrl = ""
    local appIdStr = string.format(APP_TAG, tostring(mAppIdStrings))
    jumpUrl = tostring(url) .. appIdStr

    params["tmast"] = jumpUrl

    mJavaBridge:Log(TAG, "jump mAuthUrl:" .. jumpUrl)
    mRapidView:getParser():getTaskCenter():getActionRunner():run("tmastaction", params, nil)
end

--------------------------个安法授权三期---------------------------------------------
function getAuthString()
    mAuthString = tostring(Rapid:getData("personal_security_json", ""))
    mAppId = tonumber(Rapid:getData("appid", ""))
end

function parserAuthorize(authInfo)
    printf(" playing_game_name_id authInfo:" .. tostring(authInfo))
    if authInfo == nil then
        return
    end

    local jsonAuthInfo = mJavaBridge:create('JSONObject', authInfo)
    if jsonAuthInfo == nil then
        return
    end

    local giftNum = tonumber(jsonAuthInfo:optString("total_num",""))
    printf(" playing_game_name_id total_num:" .. tostring(giftNum))
    local playingGames = jsonAuthInfo:optJSONArray("playing_games")
    if playingGames == nil then
        printf(" playingGames nil:")
        return
    end

    mAppIdStrings = ""
    mAuthContent = ""
    mUnAuthorizeNum = 0

    for i = 0, giftNum-1 do
        printf("enter for")
        local playingItem = playingGames:optJSONObject(i)
        if playingItem == nil then
            printf(" playingItem nil:")
            break
        end

        printf(" playing_game_name_id playingItem:" .. tostring(playingItem))
        local appId = tonumber(playingItem:optString("game_id",""))
        local appName = tostring(playingItem:optString("name",""))

        printf(" playing_game_name_id playingItem id:" .. tostring(appId) .. " name:" .. tostring(appName))

        local playingSences = playingItem:optJSONArray("scenes")
        parserScence(playingSences, appId, appName)
    end

end

local mAuthTable = {}
function parserScence(scene, appId, appName)
    if scene == nil then
        printf("playing_game_name_id sence null appid:" .. tostring(mAppId))
        return
    end
    local authTable = {}
    for i = 0,2 do
        local playingSenceItem = scene:optJSONObject(i)
        if playingSenceItem == nil then
            return
        end

        local content = playingSenceItem:optString("content")
        local visual = playingSenceItem:optString("visual")
        mAuthTable[i+1]= tonumber(visual)
    
        printf(" playing_game_name_id content:" .. tostring(content) 
            .. " visual:" .. tostring(visual))
    end

    local isAuthorize = isCurrentAppAuthorized()
    
    if appId == mAppId then
        mAuthorize = isAuthorize
        printf("mAuthorize:" .. tostring(mAuthorize))
    end

    if not isAuthorize then
        mUnAuthorizeNum = mUnAuthorizeNum + 1
        if mUnAuthorizeNum == 1 then
            mAuthContent = appName
            mAppIdStrings = tostring(appId)
            return
        end
        if mUnAuthorizeNum  <= 3 then
            mAuthContent = tostring(mAuthContent) .. tostring("、") .. appName
        end
        if mUnAuthorizeNum == 4 then --大于4个只需要加一个等，后续不需要处理了
            mAuthContent = mAuthContent .. tostring("...等")
        end
        mAppIdStrings = mAppIdStrings .. "_" .. tostring(appId)
    end

    printf(" mUnAuthorizeNum:" .. tostring(mUnAuthorizeNum) .. " mAuthContent:" .. tostring(mAuthContent)
        .. "  mAppIdStrings:" .. tostring(mAppIdStrings))
end

function isCurrentAppAuthorized()
    printf("enter isCurrentAppAuthorized: ")
    local length = #mAuthTable
    printf("current appid:" .. tostring(mAppId) .. " len:" .. tostring(length))
    for i = 1,3 do  
        if mAuthTable[i] == 2 then   -- 0 全部  1 自己 2 取消
            printf("isCurrentAppAuthorized false") 
            return false
        end
    end
    printf("isCurrentAppAuthorized true") 
    return true
end

function onPermissionRequestListener(succeed, viewNameList, dataList)
    mRequesting = false
    mJavaBridge:Log(TAG, " onPermissionRequestListener mRequesting:" .. tostring(mRequesting))
    if dataList == nil or dataList:size() == 0 then
         mJavaBridge:Log(TAG, "onPermissionRequestListener dataList error!")   -- 写这里返回了
         return
    end    

    if (succeed) then
        mJavaBridge:Log(TAG, " onPermissionRequestListener success!")
        onPermissionSucceed(viewNameList, dataList)
    else
        mJavaBridge:Log(TAG, " onPermissionRequestListener failure!")
    end
end

function onPermissionSucceed(viewNameList, dataList)
    if dataList == nil or dataList:size() < 1 then
        return
    end

    local dataMap = dataList:get(0)
    if dataMap == nil then
        mJavaBridge:Log(TAG, "is_authorize get Error!")
        return
    end

    local action = tostring(dataMap:get("action"))
    printf("action :" .. tostring(action)) 
    if action == "0" then -- action == 0 查询授权
        local result = tostring(dataMap:get("result"))
        printf("action query result :" .. result)
        if result == nil then
            return
        end
        mAuthString = result
        parserAuthorize(mAuthString)
    elseif action == "1" then -- action == 1 写授权
        printf("action write")
        mAuthorize = true
    else    -- action == 2 清除授权
        printf("action clear:" .. tostring(action)) 
    end
end

function tryAuthorize()
    -- 个安法添加
    showAuthorizeDialog()
end

function requestQueryIfNeeded() 
    local mAuthorize = isCurrentAppAuthorized()
    if mAuthorize then
        mJavaBridge:Log(TAG, "has been authorized before!")
        return
    end
    sendPermissionQueryRequest()
end

function requestAuthorizeIfNeeded() 
    local mAuthorize = isCurrentAppAuthorized()
    if mAuthorize then
        mJavaBridge:Log(TAG, "has been authorized before!")
        return
    end
    sendPermissionAuthorizeRequest()
end

function sendPermissionQueryRequest() 
    mRequesting = true
    mJavaBridge:Log(TAG, "send sendPermissionQueryRequest:")
    local params = {}
    params["action"] = "0" -- action == 0 查询授权
    params["data"] = mAuthString
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function sendPermissionAuthorizeRequest()
    mRequesting = true
    mJavaBridge:Log(TAG, "send sendPermissionAuthorizeRequest:")
    local params = {}
    params["action"] = "1" -- action == 1 写授权
    params["data"] = mAuthString
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

function sendPermissionClearRequest()
    mRequesting = true
    mJavaBridge:Log(TAG, "send sendPermissionClearRequest:")
    local params = {}
    params["action"] = "2"  -- action == 2 清除授权
    params["data"] = mAuthString
    printf("clear mAuthString:" .. tostring(mAuthString))
    mJavaBridge:request(AUTHORIZE_CMD, params, onPermissionRequestListener)
end

-----------------------界面显示,dialog部分--------------------------------
function showAuthorizeDialog()
    printf("showAuthorizeDialog")
    local itemData = {}
    local appIdStr = string.format(APP_TAG, tostring(mAppIdStrings))
    itemData["content"] = mAuthContent .. 
        "游戏未获得游戏数据使用权限，游戏内容如法精确推荐，也无法享受应用宝对应游戏福利。享受全部功能及福利，请开启授权。"

    local selectDialog = mJavaBridge:showCustomDialogAsync(
            "authorize_dialog.xml",
            itemData,
            nil,
            "授权弹窗"
    )

    local dialogListener = luajava.createProxy(
        "com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",
        AuthorizeDialogEventListener
    )
    selectDialog:setPhotonDialogEventListener(dialogListener)
end

AuthorizeDialogEventListener = {}
function AuthorizeDialogEventListener.onDialogEvent(eventType, dialogData)
    printf("AuthorizeDialogEventListener: eventType" .. tostring(eventType)
        .. " dialogData:" .. tostring(dialogData))
    
    if eventType == "ON_ONE_KEY_SELECTED" then
        sendPermissionAuthorizeRequest()
    elseif eventType == "ON_DETAIL_SELECTED" then
        jumpPage(mAuthUrl)
    elseif eventType == "ON_CLEAR_AUTHORIZE" then
        sendPermissionClearRequest()
    elseif eventType == "ON_CANCEL" then
        showConfirmDialog()
    else -- 销毁
        -- donothing
    end
end

-------------------comfirm dialog-----------------------------
function showConfirmDialog()
    printf("showConfirmDialog")
    local itemData = {}

    local confirmDialog = mJavaBridge:showCustomDialogAsync(
            "authorize_confirm_dialog.xml",
            itemData,
            nil,
            "授权确认弹窗"
    )

    local confirmListener = luajava.createProxy(
        "com.tencent.rapidview.deobfuscated.IPhotonDialogEventListener",
        ConfirmDialogEventListener
    )
    confirmDialog:setPhotonDialogEventListener(confirmListener)
end

ConfirmDialogEventListener = {}
function ConfirmDialogEventListener.onDialogEvent(eventType, dialogData)
    printf("ConfirmDialogEventListener: eventType" .. tostring(eventType)
        .. " dialogData:" .. tostring(dialogData))

    if eventType == "ON_ONE_KEY_SELECTED" then
        sendPermissionAuthorizeRequest()
    else -- dismiss
        -- donothing
    end
end