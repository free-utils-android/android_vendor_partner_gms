local mPhotonView,mJavaBridge = ...
local stepNum = 10000
RubbishScanCallBack = {}
function RubbishScanCallBack.updateScanData(selectedSize,selectedSizeFormat,selectedSizeUnit,totalSize,progress,selectedColor,unSelectedColor)
    --扫描进度提示
    local scanning_notice_text = mPhotonView:getParser():getBinder():get("scanning_notice_text")
    if scanning_notice_text~=nil then
        mPhotonView:getParser():getChildView("detailbutton"):getView():setText(tostring(scanning_notice_text).."..("..tostring(progress).."%)")
    else
        mPhotonView:getParser():getChildView("detailbutton"):getView():setText("正在扫描..("..tostring(progress).."%)")
    end
    
    --扫描中文案
    mJavaBridge:Log("chenjie_test","selectedSize="..tostring(selectedSize))
    --全屏背景色
    local Color = luajava.bindClass('android.graphics.Color')
    mPhotonView:getParser():getChildView("rootView"):getView():setBackgroundColor(Color:parseColor(selectedColor))
    mPhotonView:getParser():getChildView("rubbishsize"):getView():setText(selectedSize)
    mPhotonView:getParser():getChildView("rubbishsize_unit_half"):getView():setText(selectedSizeUnit)
    mJavaBridge:Log("onPartionResult","updateScanData  wqeqweqe="..tostring(selectedSize))
    mJavaBridge:Log("onPartionResult","updateScanData  wqeqweqe="..tostring(selectedColor))
    --mPhotonView:getParser():getChildView("rubbishsize"):getView():invalidate()
    

end

function RubbishScanCallBack.doScanFinish(selectedSize,selectedSizeFormat,selectedSizeUnit,totalSize,selectedColor,unSelectedColor)
    mJavaBridge:Log("onPartionResult","doScanFinish finish="..tostring(selectedSize))
    --全屏背景色
    local Color = luajava.bindClass('android.graphics.Color')
    mPhotonView:getParser():getChildView("rootView"):getView():setBackgroundColor(Color:parseColor(selectedColor))
    mPhotonView:getParser():getChildView("rubbishsize"):getView():setText(selectedSize)
    mPhotonView:getParser():getChildView("rubbishsize_unit_half"):getView():setText(selectedSizeUnit)

    mPhotonView:getParser():getChildView("rubbishsize_unit_half"):getView():setText(selectedSizeUnit)

    mPhotonView:getParser():getChildView("detailbutton"):getView():setText("查看垃圾详情")
    mPhotonView:getParser():getChildView("stopButton"):getView():setText("放心清理")
end

function updateValue()

    --注册垃圾扫描回调监听
    mJavaBridge:Log("onPartionResult","updateValue ")
    local rubbishCleanManager = luajava.bindClass("com.tencent.nucleus.manager.wxqqclean.WxCleanViewManager")
    rubbishScanCallBack = luajava.createProxy('com.tencent.nucleus.manager.spacecleannew.RubbishScanCallBack', RubbishScanCallBack)
    rubbishCleanManager:getInstance():registerScanListener(rubbishScanCallBack)

    --扫描按钮背景色
    local button_scanning_edge_color = mPhotonView:getParser():getBinder():get("button_scanning_edge_color")
    local button_scanning_bg_color = mPhotonView:getParser():getBinder():get("button_scanning_bg_color")


    --按钮背景色值
    local button_scanning_bg_color_format = "color:ffffff"
    if button_scanning_bg_color ~=nil then
        button_scanning_bg_color_format = "color:"..tostring(button_scanning_bg_color)
    end

    local button_scanning_edge_color_format = ",strokecolor:00ffffff"
    if button_scanning_edge_color ~=nil and button_scanning_edge_color ~= ''  then
        button_scanning_edge_color_format = ",strokecolor:"..tostring(button_scanning_edge_color)
    end
 
    local fullStopButtonBg ='strokewidth:4,'..tostring(button_scanning_bg_color_format)..tostring(button_scanning_edge_color_format)..",cornerradius:45,shape:0"
    Rapid:getChild("stopButton"):setAttr("backgroundgradientdrawable",fullStopButtonBg)


    local Color = luajava.bindClass('android.graphics.Color')
    local button_scanning_text_color = mPhotonView:getParser():getBinder():get("button_scanning_text_color")
    if button_scanning_text_color ~=nil and button_scanning_text_color ~= "" then
        mPhotonView:getParser():getChildView("stopButton"):getView():setTextColor(Color:parseColor("#"..tostring(button_scanning_text_color)))
    end

end
    

function finish()
    mJavaBridge:finish()
end

function stopScan()
    local cleanType  = mPhotonView:getParser():getBinder():get("clean_type")
    mJavaBridge:switchWxCleanModel(6,cleanType)
end

