local mPhotonView, mJavaBridge = ...



local mRecyclerView = nil


function main()
    mRecyclerView = mPhotonView:getParser():getChildView('recyclerview')
end

function onResume()
    loadData()
end

function loadData()
    local dataList = {}
    local viewNameList = {}
    local subViewName = 'other_used_card_item.xml'

    local _scene = mPhotonView:getParser():getBinder():get("scene")
    local _sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
    local _modeltype = mPhotonView:getParser():getBinder():get("modeltype")
    local _sourceslotid =  mPhotonView:getParser():getBinder():get("sourcesceneslotid")
    local _slotid =  mPhotonView:getParser():getBinder():get("slotid")
    local _uni_card_title =  mPhotonView:getParser():getBinder():get("card_title")
    
    local itemCount = tonumber(Rapid:getData('item_num','0'))
    for i = 1, itemCount do

        local itemData = {}
        local itemTitle = mPhotonView:getParser():getBinder():get("item_data_" .. i .. "_item_title")
        local itemSubTitle = mPhotonView:getParser():getBinder():get("item_data_" .. i .. "_item_sub_title")
        local itemIcon = mPhotonView:getParser():getBinder():get("item_data_" .. i .. "_item_icon")
        local itemJumpUrl = mPhotonView:getParser():getBinder():get("item_data_" .. i .. "_jump_url")
        local functionId = mPhotonView:getParser():getBinder():get("item_data_" .. i .. "_function_id")
        local entranceRecommendid = mPhotonView:getParser():getBinder():get("item_data_" .. i .. "_entrance_recommendid")
        local is_display_reddot = Rapid:getData("item_data_" .. i .. "_is_display_reddot", 0)
        local identify_id = mPhotonView:getParser():getBinder():get("item_data_" .. i .. "_identify_id")

        if _uni_card_title ~= nil then
            local var_uni_card_title = mJavaBridge:create("Var", _uni_card_title)
            itemData["uni_card_title"] = var_uni_card_title
        else
            itemData["uni_card_title"] = mJavaBridge:create("Var", "")
        end
        
        if functionId ~= nil then
            local var_functionId = mJavaBridge:create("Var", functionId)
            itemData["uni_entrance_id"] = var_functionId
        else 
            itemData["uni_entrance_id"] = mJavaBridge:create("Var", "")
        end
        
        if entranceRecommendid ~= nil then
            local var_entranceRecommendid = mJavaBridge:create("Var", entranceRecommendid)
            itemData["entrance_recommendid"] = var_entranceRecommendid
        else 
            itemData["entrance_recommendid"] = mJavaBridge:create("Var", "")
        end

        if itemTitle ~= nil then
            local var_itemTitle = mJavaBridge:create("Var", itemTitle)
            itemData["item_title"] = var_itemTitle
        else 
            itemData["item_title"] = mJavaBridge:create("Var", "")
        end

        if itemSubTitle ~= nil then
            local var_itemSubTitle = mJavaBridge:create("Var", itemSubTitle)
            itemData["item_sub_title"] = var_itemSubTitle
        else 
            itemData["item_sub_title"] = mJavaBridge:create("Var", "")
        end

        if itemIcon ~= nil then
            local var_itemIcon = mJavaBridge:create("Var", itemIcon)
            itemData["item_icon"] = var_itemIcon
        else 
            itemData["item_icon"] = mJavaBridge:create("Var", "")
        end

        if itemJumpUrl ~= nil then
            local var_itemJumpUrl = mJavaBridge:create("Var", itemJumpUrl)
            itemData["jump_url"] = var_itemJumpUrl
        else 
            itemData["jump_url"] = mJavaBridge:create("Var", "")
        end

        if _scene ~= nil then
            local var_scene = mJavaBridge:create("Var", _scene)
            itemData["scene"] = var_scene
        else 
            itemData["scene"] = mJavaBridge:create("Var", "")
        end
        
        if _sourcescene ~= nil then
            local var_sourcescene = mJavaBridge:create("Var", _sourcescene)
            itemData["sourcescene"] = var_sourcescene
            itemData["sourceScene"] = var_sourcescene
        else 
            itemData["sourcescene"] = mJavaBridge:create("Var", "")
            itemData["sourceScene"] = mJavaBridge:create("Var", "")
        end
        
        if _modeltype ~= nil then
            local var_modeltype = mJavaBridge:create("Var", _modeltype)
            itemData["modeltype"] = var_modeltype
            itemData["modelType"] = var_modeltype
        else 
            itemData["modeltype"] = mJavaBridge:create("Var", "")
            itemData["modelType"] = mJavaBridge:create("Var", "")
        end
        
        if _sourceslotid ~= nil then
            local var_sourceslotid = mJavaBridge:create("Var", _sourceslotid)
            itemData["sourcesceneslotid"] = var_sourceslotid
            itemData["sourceSceneSlotId"] = var_sourceslotid
        else 
            itemData["sourcesceneslotid"] = mJavaBridge:create("Var", "")
            itemData["sourceSceneSlotId"] = mJavaBridge:create("Var", "")
        end
        
        if _slotid ~= nil then
            local var_slotid = mJavaBridge:create("Var", _slotid)
            itemData["slotid"] = var_slotid
            itemData["slotId"] = var_slotid
        else 
            itemData["slotid"] = mJavaBridge:create("Var", "")
            itemData["slotId"] = mJavaBridge:create("Var", "")
        end
        itemData["subPosition"] = mJavaBridge:create("var",tostring(i))

        if i <= 4 then
            local var_marginTop = mJavaBridge:create("Var", "0")
            itemData["marginTop"] = var_marginTop
        else
            local var_marginTop = mJavaBridge:create("Var", "25.5")
            itemData["marginTop"] = var_marginTop
        end

        -- 获取当前icon的点击状态
        local reddotStatus = getLocalReddotStatus(identify_id)

        -- 只有本地从来没有点过，才会展示红点
        if reddotStatus == "" then
            itemData["is_display_reddot"] = is_display_reddot
        else 
            itemData["is_display_reddot"] = 0
        end

        itemData["identify_id"] = identify_id
        
        dataList[i] = itemData
        viewNameList[i] = subViewName
    end

    mRecyclerView:getView():clear()
    mRecyclerView:getView():updateData(viewNameList, dataList)
end

function getLocalReddotStatus(identify_id)
    return mJavaBridge:getSettingsData("other_used_card_"..tostring(identify_id), "")
end