local mPhotonView,mJavaBridge = ...
local tabContent = "detail"
local appExpose = false
local UI_EVENT_COMMENT_SUCCESS = 1360
local UI_EVENT_EVALUATION_RELEASE_PAGE_PUBLISH = 1374

local isAutoInstall = false
local isAutoDownload = false
local autoClickType = ""

-- 加入下载队列监听
local startDownloadListener = nil
-- 删除下载任务监听
local deleteDownloadListener = nil
local uiListener = nil

local needClickToScoll = true

local defaultTestPlayWidth = mJavaBridge:dip2px(160)
local changeTestPlayWidth = mJavaBridge:dip2px(224)

local isTestPlayApp = "0"
local isShowOne = "0"
local hasClickTips = false


-- 未展开试玩文案
local defaultTestPlayText = nil
-- 展开试玩文案
local changeTestPlayText = nil
-- 试玩按钮展开情况
local mTestPlayExpanded = false
-- 试玩按钮展开动画
local mTestPlayButtonExpandAnimator = nil

local TIPS_SHOW_FLAG_KEY = "mixed_app_detail_bottom_view_tips_97"

function init()
    appExpose = false

    initListener()
end

function initButtonSize( ... )
    mJavaBridge:Log("realhe", "initButtonSize start")

    if isTestPlayApp == "0" then
        return
    end

    if changeTestPlayText == nil or changeTestPlayText == "" then
        return
    end

    local appModel = Rapid:getData("app_model")
    local appState = mJavaBridge:getAppState(appModel)
    mJavaBridge:Log("HRM", "initButtonSize:"..appState)
    if (appState == "DOWNLOADING" or appState == "PAUSED" or appState == "QUEUING" or appState == "DOWNLOADED") and isXmlCompatible()  then
        setTestPlayWidth(changeTestPlayWidth)
        Rapid:getChild("test_play"):getParser():update("text", changeTestPlayText)
        mTestPlayExpanded = true
        return
    end
    setTestPlayWidth(defaultTestPlayWidth)
    Rapid:getChild("test_play"):getParser():update("text", defaultTestPlayText)

    mTestPlayExpanded = false
end

function initListener( ... )
    -- 监听app状态变化
    EventDispatcherEnum = luajava.bindClass("com.tencent.assistant.event.EventDispatcherEnum")
    deleteDownloadListener = luajava.createProxy('com.tencent.assistant.event.listener.UIEventListener', DeleteEventListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_DELETE, deleteDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_UPDATE_DELETE, deleteDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_SUCC, deleteDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_INSTALL, deleteDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_UNINSTALL, deleteDownloadListener)

    startDownloadListener = luajava.createProxy('com.tencent.assistant.event.listener.UIEventListener', StartEventListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_ADD, startDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_START, startDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_UPDATE_START, startDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_PAUSE, startDownloadListener)
    mJavaBridge:addUIEventListener(EventDispatcherEnum.UI_EVENT_APP_DOWNLOAD_QUEUING, startDownloadListener)

    -- 评论成功
    uiListener = luajava.createProxy('com.tencent.assistant.event.listener.UIEventListener', UIEventListener)
    mJavaBridge:addUIEventListener(UI_EVENT_COMMENT_SUCCESS,uiListener)
    mJavaBridge:addUIEventListener(UI_EVENT_EVALUATION_RELEASE_PAGE_PUBLISH,uiListener)
end

function showTestPlayTips( ... )
    if isShowOne == "1" then
        return
    end

    if isShowTips() then
        mJavaBridge:delayRun(100, tipsAnimation)
        isShowOne = "1"
    else
        Rapid:setData("tips_visible","gone")
    end

    if isTestPlayApp == "1" then
        Rapid:getChild("btn_test_play"):getParser():update("visibility", "visible")
        testPlayExpose()
    end
end

DeleteEventListener = {}
function DeleteEventListener.handleUIEvent(message)
    initButtonSize()
end

StartEventListener = {}
function StartEventListener.handleUIEvent ( message )
    if message == nil then
        return
    end
    local apkid = Rapid:getData('apkid','')
    local appid = Rapid:getData('appid','')
    local messageObj = tostring(message.obj)
    if apkid == messageObj or appid == messageObj then
        changeButtonSize()
    end
end

function setTestPlayWidth( width )
    testPlay = Rapid:getChild("btn_test_play"):getView()
    lp = testPlay:getLayoutParams()
    lp.width = width
    testPlay:setLayoutParams(lp)
    testPlay:requestLayout()
end

-- 是否需要展示tips
function isShowTips( ... )
    if isTestPlayApp == "0" then
        return false
    end
    tipsText = Rapid:getData("tips")
    if tipsText == nil or tipsText == "" then
        Rapid:Log("HRM", "test play tips null")
        return false
    end
    needShow = mJavaBridge:getSettingsData(TIPS_SHOW_FLAG_KEY, "")
    if needShow == nil or needShow == "" then
        return true
    end
    return false
end

function updateValue()
    isTestPlayApp = Rapid:getData("need_test_play", "0")
    Rapid:Log("HRM", "isTestPlayApp :  " .. isTestPlayApp)

    defaultTestPlayText = Rapid:getData("test_play_text", "秒玩")
    changeTestPlayText = Rapid:getData("change_test_play_text", "边下边玩")

    local pageBgColor = Rapid:getData("pageBgColor")
    local buttonSelectedBgColorStr = "ffffff"
    if pageBgColor ==nil or pageBgColor == "" then
        pageBgColor = "ffffff"
    end

    local shadowBgDrawable = "0,0,0,72,00000000,"..pageBgColor..",clamp"
    Rapid:getChild("shader_view"):setAttr("lineargradient", shadowBgDrawable)

    --评论按钮背景色
    local buttonSelectedBgColor = Rapid:getData("buttonSelectedBgColor")
    local buttonSelectedTextColor = Rapid:getData("buttonSelectedTextColor")
    local buttonSelectedStrokeColor = Rapid:getData("buttonSelectedStrokeColor")

    local buttonSelectedBgColorStr = "color:0080FF"
    if buttonSelectedBgColor ~=nil and buttonSelectedBgColor ~= "" then
        buttonSelectedBgColorStr = "color:"..tostring(buttonSelectedBgColor)
    end

    local buttonSelectedStrokeColorStr = ",strokecolor:00FFFFFF"
    if buttonSelectedStrokeColor ~=nil and buttonSelectedStrokeColor ~= ""  then
        buttonSelectedStrokeColorStr = ",strokecolor:"..tostring(buttonSelectedStrokeColor)
    end

    local fullStopButtonBg ="strokewidth:4,"..tostring(buttonSelectedBgColorStr)..tostring(buttonSelectedStrokeColorStr)..",cornerradius:16,shape:0"
    Rapid:getChild("btn_comment"):setAttr("backgroundgradientdrawable",fullStopButtonBg)

    local appFileSizeStr = Rapid:getData("appFileSizeStr","")
    local downloadText = "立即下载"
    if isTestPlayApp == "1" then
        downloadText = "下载"
    end
    if appFileSizeStr ~= "" then
        downloadText = downloadText .. " (" .. appFileSizeStr .. ")"
    end

    local updateText = "更新"
    if appFileSizeStr ~= "" then
        updateText = updateText .. " (" .. appFileSizeStr .. ")"
    end

    local buttonStr = 'download:'.. tostring(downloadText) ..",update:".. tostring(updateText)

    Rapid:getChild("btn_download"):setAttr("textmap", tostring(buttonStr))

    itemInfoChanged()

    appBtnExpose()

    if isAutoDownload == true then
        autoDownload(autoClickType)
    end

    if isAutoInstall == true then
        installApp(autoClickType)
    end

    handleButtonSize()
    initButtonSize()

    showTestPlayTips()

    updatePlayJumpUrl()
end

function updatePlayJumpUrl()
    Rapid:setData('test_play_jump_url', jumpUrlJoinRid(Rapid:getData('test_play_jump_url'), 
        Rapid:getData('sourcerecommendid')))
end

function jumpUrlJoinRid(jumpUrl, recommendid)
    if jumpUrl == nil or jumpUrl == "" then
        return jumpUrl
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendid), "default")
    if rcdBase64 ~= nil and rcdBase64 ~= "" then
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
        mJavaBridge:Log("jumpUrlJoinRid", 'jumpUrl: '..tostring(jumpUrl))
    end
    return jumpUrl
end

function appBtnExpose()
    if appExpose == true then
        return
    end

    local appModel = Rapid:getData("app_model")
    local appState = mJavaBridge:getAppState(appModel)

    local reportParams = {}
    reportParams["param"] = "slotid:99_000,subposition:1,status:-1,actionid:100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:data@searchid"
    reportParams["extendparam"] = "report_element:app,source_report_context:data@source_report_context,report_context:data@report_context,client_report_context:data@client_report_context"..",buttonstatus:"..appState
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)

    reportParams["param"] = "slotid:99_000,subposition:1,status:-1,actionid:-100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:data@searchid"
    reportParams["extendparam"] = "report_element:app,source_report_context:data@source_report_context,report_context:data@report_context,client_report_context:data@client_report_context"..",buttonstatus:"..appState
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)

    appExpose = true
end

-- 1. 检查是否有安装改应用
-- 2. 检查当前是否有登录态
function checkCommentStatus()
    mJavaBridge:Log("HRM","checkCommentStatus")
    tabContent = "comment"

    local hasComment = Rapid:getData("has_comment","")

    itemInfoChanged()

    if hasComment == true or hasComment == "true" then
        setAppDownloadBottomButtonVisible()
        return
    end

    local appModel = Rapid:getData("app_model")
    local appState = mJavaBridge:getAppState(appModel)

    if appState == "INSTALLED" or appState == "UPDATE" then
        setCommentBottomButtonVisible()

        local loginStatus = isLogined()
        if loginStatus then
            Rapid:getChild("btn_comment"):setAttr("text", "发表你的评价")
        else
            Rapid:getChild("btn_comment"):setAttr("text", "登录发表你的评价")
        end
    else
        setAppDownloadBottomButtonVisible()
    end
end

function showDownloadBtn()
    mJavaBridge:Log("HRM","showDownloadBtn")
    tabContent = "detail"

    mJavaBridge:delayRun(1000, itemInfoChanged)

    setAppDownloadBottomButtonVisible()
end


function setAppDownloadBottomButtonVisible()
    Rapid:getChild("app_layout"):setAttr("visibility", "visible")

    -- 重新展示时需要检查是否点击过了
    if not hasClickTips and isShowTips() then
        Rapid:getChild("tips"):setAttr("visibility", "visible")
    end
    
    Rapid:Log("realhe","setAppDownloadBottomButtonVisible")
    Rapid:getChild("btn_comment"):setAttr("visibility", "gone")
end

function setCommentBottomButtonVisible()
    Rapid:getChild("app_layout"):setAttr("visibility", "gone")
    Rapid:getChild("tips"):setAttr("visibility", "gone")
    Rapid:Log("realhe","setCommentBottomButtonVisible")
    Rapid:getChild("btn_comment"):setAttr("visibility", "visible")
end

function checkStatus()
    mJavaBridge:Log("HRM","checkStatus:"..tostring(tabContent))
    if (tabContent == nil or tabContent == "comment") then
        checkCommentStatus()
    end
end

function onResume()
    mJavaBridge:Log("HRM","onResume:"..tostring(tabContent))

    checkStatus()
end

function isLogined()
    local loginType = mJavaBridge:getLoginType()
    if (loginType ~= nil and loginType ~= "NONE") then
        return true
    end

    return false
end

function commentClick()
    local loginStatus = isLogined()
    if loginStatus then
        reportCommentReport()

        openCommentActivity()
    else
        reportLoginReport()

        local param = {}
        param["tmast"] = "none"
        Rapid:execAction("logintmastaction", param, param)
    end
end

function gotoSpecialityCommentPage(tmast)
    local params = {}
    params["extra"] = "pageId:data@scene,sourceModelType:data@modeltype,sourceSceneSlotId:99_000,subPosition:3"
    params["url"] = tmast
    Rapid:execAction("tmastaction", params, nil)
end

function openCommentActivity()
    local tmast = Rapid:getData('comment_jump_url', '')
    -- 不等于空则代表是白名单用户，跳转专业测评器页面
    if tmast ~= '' then
        gotoSpecialityCommentPage(tmast)
        return
    end

    local appId = Rapid:getData('appid','')
    local apkId = Rapid:getData('apkid','')
    local versionCode = Rapid:getData('versioncode','0')
    local appIcon = Rapid:getData('iconUrl','')
    local appName = Rapid:getData('appname','')
    local packageName = Rapid:getData('packagename','')
    local tmast = "tmast://commentpublish?appid="..appId.."&apkid="..apkId.."&versioncode="..versionCode.."&pkgname="..packageName.."&appicon="..appIcon.."&score=0&appname="..appName

    local params = {}
    params["extra"] = "pageId:data@scene,sourceModelType:data@modeltype,sourceSceneSlotId:99_000,subPosition:3"
    params["url"] = tmast
    Rapid:execAction("tmastaction", params, nil)
end

function reportLoginReport()
    local reportParams = {}
    reportParams["param"] = "slotid:99_000,subposition:3,actionid:215,scene:10199,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:data@searchid"
    reportParams["extendparam"] = "report_element:app,source_report_context:data@source_report_context,report_context:data@report_context"
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportCommentReport()
    local reportParams = {}
    reportParams["param"] = "slotid:99_000,subposition:3,actionid:210,scene:10199,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:data@searchid"
    reportParams["extendparam"] = "report_element:app,source_report_context:data@source_report_context,report_context:data@report_context"
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function scrollToRelatedRecommend()
    if Rapid:getData("need_test_play", "0") == "1" then
        return
    end

    local appModel = Rapid:getData("app_model")
    local appState = mJavaBridge:getAppState(appModel)
    mJavaBridge:Log("HRM", "scrollToRelatedRecommend:"..appState)
    if (appState == "DOWNLOAD" or appState == "UPDATE") then
        -- 外部卡片模拟下载点击时，不允许外部列表滑动到推荐区，生效一次后就重置
        mJavaBridge:Log("HRM", "scrollToRelatedRecommend, needClickToScoll:"..tostring(needClickToScoll))
        if needClickToScoll == false then
            needClickToScoll = true
            return
        end

        local param = {}
        param["key"] = "scroll_to_related_recommend"
        param["value"] = "true"
        Rapid:execAction("outeraction", param, param)
    end
end

function autoDownload(value)

    mJavaBridge:Log("HRM", "autoDownload")
    autoClickType = value

    local downloadBtn = Rapid:getChild("btn_download")
    if (downloadBtn == nil or downloadBtn:getView() == nil) then
        isAutoDownload = true
        return
    end

    local appModel = Rapid:getData("app_model", "")

    if (appModel == "") then
        isAutoDownload = true
        return
    end

    local appState = mJavaBridge:getAppState(appModel)
    mJavaBridge:Log("HRM", "downloadApp"..appState)
    if (appState == "DOWNLOAD" or appState == "UPDATE") then
        mJavaBridge:Log("HRM", "autoDownload, autoClickType:"..autoClickType)
        if autoClickType ~= nil and autoClickType ~= "" then
            -- 外部卡片模拟下载点击时，不允许外部列表滑动到推荐区，生效一次后就重置
            needClickToScoll = false
        end

        itemInfoChanged()
        downloadBtn:getView():performClick()
    end

    isAutoDownload = false
end

function installApp(value)
    autoClickType = value

    local downloadBtn = Rapid:getChild("btn_download")
    if (downloadBtn == nil or downloadBtn:getView() == nil) then
        isAutoInstall = true
        return
    end

    local appModel = Rapid:getData("app_model", "")

    if (appModel == "") then
        isAutoInstall = true
        return
    end

    local appState = mJavaBridge:getAppState(appModel)
    mJavaBridge:Log("HRM", "installApp"..appState)
    if appState == "DOWNLOADED" then
        itemInfoChanged()
        downloadBtn:getView():performClick()
    end

    -- 完成安装点击
    isAutoInstall = false
end

function itemInfoChanged()
    mJavaBridge:Log("HRM", "itemInfoChanged")

    local tab_sequence_id = mJavaBridge:getNormalSettingsData("key_app_detail_current_tab_sequence", "")

    local itemInfo = mJavaBridge:getNormalSettingsData("key_app_detail_last_item_info_"..tab_sequence_id, "")

    if (itemInfo == "") then
        return
    end

    local object = mJavaBridge:create('JSONObject', itemInfo)
    if (object == nil) then
        return
    end

    local scene = object:optString("scene")
    local position = object:optString("position","-1")
    local modeltype = object:optString("modeltype","-1")

    local extraparam = "report_element:app,client_report_context:data@client_report_context,source_report_context:data@source_report_context,report_context:data@report_context"

    local uni_click_type = "uni_click_type:-1"
    if autoClickType ~= "" then
        uni_click_type = autoClickType
    end

    extraparam = extraparam..",uni_click_scene:"..scene..",uni_click_modeltype:"..modeltype..",uni_click_position:"..position..","..uni_click_type

    Rapid:getChild('btn_download'):setAttr("extendparam",extraparam)

    mJavaBridge:Log("HRM", "extraparam:"..extraparam)
end

UIEventListener = {}
function UIEventListener.handleUIEvent(message)
    local commentDetailWrapper = message.obj
    if commentDetailWrapper == nil or commentDetailWrapper.commentDetail == nil then
        if message.what ~= UI_EVENT_EVALUATION_RELEASE_PAGE_PUBLISH then
            -- 如果不是新的测评发布器的评论结果监听，则return。
            return
        end
    end

    Rapid:setData("has_comment",true)

    checkCommentStatus()
end

function detailBottomCardInnerFunction(key, value)
    if "changeTab" == key then
        if "comment" == value then
            checkCommentStatus()
        else
            showDownloadBtn()
        end
    elseif "downloadApp" == key then
        autoDownload(value)
    elseif "installApp" == key then
        installApp(value)
    elseif "itemInfoChanged" == key then
        itemInfoChanged()
    end
end

function testPlayFun()
    local jumpType = Rapid:getData('test_play_jump_type','0')
    local jumpUrl = Rapid:getData('test_play_jump_url','')

    mJavaBridge:Log("HRM","jumpType:"..tostring(jumpType)..",jumpUrl:"..tostring(jumpUrl))
    
    if jumpType == '0' or jumpUrl == '' then
        return
    end

    lp = Rapid:getChild("btn_test_play"):getView():getLayoutParams()

    local buttonTitle = "game_demo"
    if lp.width == changeTestPlayWidth then
        buttonTitle = "cloudgame_demo"
    end

    -- jumpType : 1 跳转到H5页面
    if tostring(jumpType) == '1' then
        jumpAction(true, jumpUrl, buttonTitle)
        return
    end

    -- jumpType : 2 跳转到试玩插件
    if tostring(jumpType) == '2' then
        jumpToPlugin(jumpUrl, buttonTitle)
        return
    end
end

-- 这个老名字暂时不能删掉，由于目前有出现老xml加载新的lua的问题
function testPlay()
    testPlayFun()
end

function jumpAction(isH5, tmast, buttonTitle)
    mJavaBridge:Log("HRM","jumpAction:"..tmast)

    local targetType
    if isH5 == true then
        targetType = 'h5'
    else 
        targetType = 'plugin'
    end

    reportLoginClick(targetType , buttonTitle)

    local params = {}
    params["tmast"] = tmast
    Rapid:execAction("tmastaction", params, nil)
end

function jumpToQQLogin( buttonTitle )
    reportLoginClick('login' , buttonTitle)

    local jsParams = {}
    jsParams["logintype"] = "QMOBILEQ"
    mJavaBridge:runJsBridge("openLoginActivity", jsParams, nil)
end

function getQQLoginStatus()
    local loginInfo = mJavaBridge:getLoginInfoHash()

    if(loginInfo ~= "") then 
        local dataJSON = mJavaBridge:create('JSONObject', loginInfo)
        local loginType = dataJSON:getString("logintype")

        mJavaBridge:Log("HRM","getQQLoginStatus, loginInfo:"..tostring(loginInfo))
       
        if(loginType ~= nil and loginType == "MOBILEQ") then
            return true
        end
    end

    return false
end

function jumpToPlugin(tmast, buttonTitle)
    local needLogin = Rapid:getData('test_play_need_login','1')

    local isQQlogin = getQQLoginStatus()

    mJavaBridge:Log("HRM","jumpToPlugin, isQQlogin:"..tostring(needLogin)..",isLogin:"..tostring(isQQlogin))

    if tostring(needLogin) == '1' and isQQlogin == false then
        jumpToQQLogin(buttonTitle)
        return
    end

    jumpAction(false, tmast, buttonTitle)
end

function testPlayExpose()
    commonExpose(false, 4, "button")

    commonExpose(true, 4, "button")

    mJavaBridge:Log("yh-test","testPlayExpose")

    -- 试玩按钮曝光时，下载「云游戏插件」
    local params = {}
    params["packagename"] = "com.tencent.assistant.plugin.cloudgame"
    
    mJavaBridge:runJsBridge("downloadPlugin", params, nil)

    mJavaBridge:Log("yh-test","after downloadPlugin")
end

function commonExpose(isEffectiveExpose, subposition, reportElement)
    local actionId = 100

    if isEffectiveExpose == true then
        actionId = -100
    end

    local reportParams = {}
    reportParams["param"] = "slotid:99_000,subposition:"..tostring(subposition)..",status:-1,actionid:"..tostring(actionId)..",scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,searchid:data@searchid"
    reportParams["extendparam"] = "report_element:"..tostring(reportElement)..",source_report_context:data@source_report_context,report_context:data@report_context,client_report_context:data@client_report_context,,uni_button_title:game_demo,uni_demo_id:data@test_play_entrance_id"
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportLoginClick(target_type, button_title)
    local reportParams = {}
    reportParams["param"] = "slotid:99_000,subposition:4,status:-1,actionid:200,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,searchid:data@searchid,appid:0"
    reportParams["extendparam"] = "report_element:button,source_report_context:data@source_report_context,report_context:data@report_context,client_report_context:data@client_report_context,uni_button_title:" .. button_title .. ",uni_target_type:"..target_type .. ",uni_demo_id:data@test_play_entrance_id"
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function tipsExposure()
    local reportParams = {}
    reportParams["param"] = "slotid:99_-1,subposition:-1,status:-1,actionid:100,scene:data@scene,sourceScene:data@sourcescene,modeltype:-1,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:0,searchid:0"
    reportParams["extendparam"] = "report_element:bubble,uni_text_content:data@tips,source_report_context:data@source_report_context,report_context:data@report_context,client_report_context:data@client_report_context"
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function reportTipsCancel()
    local reportParams = {}
    reportParams["param"] = "slotid:99_-1,subposition:1,status:-1,actionid:201,scene:data@scene,sourceScene:data@sourcescene,modeltype:-1,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:0,searchid:0"
    reportParams["extendparam"] = "report_element:bubble,uni_text_content:data@tips,source_report_context:data@source_report_context,report_context:data@report_context,client_report_context:data@client_report_context,uni_cancel_type:1"
    reportParams['recommendid'] = "data@sourcerecommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function isXmlCompatible()
    return Rapid:getChild('default_bg') ~= nil
end

function changeButtonSize()
    if isTestPlayApp == "0" then
        return
    end

    if changeTestPlayText == nil or changeTestPlayText == "" or mTestPlayExpanded then
        return
    end

    if not isXmlCompatible() then
        return
    end


    if mTestPlayButtonExpandAnimator  == nil then
        mTestPlayButtonExpandAnimator = createButtonAnimator()
    end
   
    if mTestPlayButtonExpandAnimator:isRunning() then
        return
    end

    mTestPlayButtonExpandAnimator:start()
end

function createButtonAnimator( ... )
    mJavaBridge:Log("qiwei","createButtonAnimator defaultTestPlayWidth="..tostring(defaultTestPlayWidth))
    mJavaBridge:Log("qiwei","createButtonAnimator changeTestPlayWidth="..tostring(changeTestPlayWidth))
    local ValueAnimator = luajava.bindClass('android.animation.ValueAnimator')
    local params = {}
    params[1] = defaultTestPlayWidth
    params[2] = changeTestPlayWidth
    local valueAnimator =  ValueAnimator:ofInt(params):setDuration(300)
    animatorUpdateListener = luajava.createProxy("android.animation.ValueAnimator$AnimatorUpdateListener", AnimatorUpdateListener)
    animatorListener = luajava.createProxy('android.animation.Animator$AnimatorListener', AnimatorListener)
    valueAnimator:addListener(animatorListener)
    valueAnimator:addUpdateListener(animatorUpdateListener)
    return valueAnimator
end

AnimatorListener = {}
function AnimatorListener.onAnimationEnd(animation)
    Rapid:getChild("test_play"):getParser():update("text", changeTestPlayText)

    mTestPlayExpanded = true
end

AnimatorUpdateListener = {}
function AnimatorUpdateListener.onAnimationUpdate(animation)
    Rapid:Log("HRM"," onAnimationUpdate")
    btnTestPlay = Rapid:getChild("btn_test_play"):getView()
    lp = btnTestPlay:getLayoutParams()
    updateWidth = tonumber(animation:getAnimatedValue())
    lp.width = updateWidth
    btnTestPlay:setLayoutParams(lp)
    btnTestPlay:requestLayout()
end

function handleButtonSize()
    local screenWidth = mPhotonView:getParser():getScreenWidth()
    local screenHeight = mPhotonView:getParser():getScreenHeight()
    if screenWidth > screenHeight then
        -- 全屏后getScreenWidth接口可能会取反为屏幕高，所以对换一下
        screenWidth = screenHeight
    end
    local w = screenWidth - mJavaBridge:dip2px(16 + 8 + 16) --屏幕宽度减去视觉稿上的间距
    local bit = 1 / 2
    defaultTestPlayWidth = w * bit
    bit = 224 / 320
    changeTestPlayWidth = w * bit
    mJavaBridge:Log("qiwei","defaultTestPlayWidth="..tostring(defaultTestPlayWidth))
    mJavaBridge:Log("qiwei","changeTestPlayWidth="..tostring(changeTestPlayWidth))
end

-- 关闭tips
function closeTips( ... )
    hasClickTips = true
    Rapid:Log("HRM","close tips")
    Rapid:setData("tips_visible","gone")
    -- 主动关闭tips上报
    reportTipsCancel()
end

function tipsAnimation( ... )
    Rapid:Log("realhe","tipsAnimation")
    tipsExposure()
    Rapid:setData("tips_visible","visible")

    local tips = Rapid:getChild("tips"):getView()
    start = mJavaBridge:dip2px(0)
    target = mJavaBridge:dip2px(28)
    local animator = getObjectAnimator(tips, -start, -target)
    local interpolator = luajava.createProxy('android.view.animation.Interpolator',Interpolator)
    animator:setInterpolator(interpolator)
    animator:setDuration(7800):start()
    
    local alphaAnimation = luajava.newInstance("android.view.animation.AlphaAnimation", 0, 1)
    alphaAnimation:setDuration(600)
    tips:startAnimation(alphaAnimation)

    mJavaBridge:setSettingsDataAsync(TIPS_SHOW_FLAG_KEY,"alreadyShow")
end

function getObjectAnimator( view, start, endDis)
    local ObjectAnimator = luajava.bindClass('android.animation.ObjectAnimator')
    local params = {}
    params[1] = start
    params[2] = endDis
    return ObjectAnimator:ofFloat(view, "translationY", params)
end

-- 时间：3400 + 200 + 400 + 200 + 400 + 1000(2) + 200 + 400 + 200 + 400 + 1000(3)
-- 总共 7800ms,第一次3400ms, 第二次2200ms, 第三次2200ms
Interpolator = {}
function Interpolator.getInterpolation( t )
    if (t < 6/78.0) then
        return 78*78/36 * t * t
    elseif (t < 12/78.0) then
        return 1
    elseif (t < 14/78.0) then
        return -8.357142857143 * t + 2.2857142857143
    elseif (t < 18/78.0) then
        return 4.1785714285714 * t + 0.0357142857143
    elseif ( t < 20/78.0) then
        return -8.3571428571429 * t + 2.9285714285714
    elseif ( t < 24/78.0) then
        return 4.1785714285714 * t - 0.2857142857143
    elseif (t < 34/78.0) then
        return 1
    elseif (t < 36/78.0) then
        return -8.357142857142 * t + 4.6428571428567
    elseif (t < 40/78.0) then
        return 4.1785714285716 * t - 1.1428571428572
    elseif (t < 42/78.0) then
        return -8.3571428571402 * t + 5.2857142857129
    elseif (t < 46/78.0) then
        return 4.1785714285712 * t - 1.4642857142856
    elseif (t < 56/78.0) then
        return 1
    elseif (t < 58/78.0) then
        return -8.3571428571437 * t + 7.0000000000006
    elseif (t < 62/78.0) then
        return 4.1785714285706 * t - 2.3214285714279
    elseif (t < 64/78.0) then
        return -8.35714285715 * t + 7.6428571428629
    elseif (t < 68/78.0) then
        return 4.1785714285712 * t - 2.6428571428569
    else 
        return 1
    end
end