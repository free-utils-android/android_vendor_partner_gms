local mPhotonView, mJavaBridge = ...

local SearchHistory
local mHistoryWord
local binder
local mhistoryItem = {}
local mHistoryNum
local hasReport = {}
local mCardVisible
local historyNameList
local mVisibleNum = 0
local mShowFlag = true

function addHistoryWord()
    initData()
    --初始化标签
    refreshHistoryView()
end

function initData()
    binder = mPhotonView:getParser():getBinder()
end

function refreshHistoryData()
    --SearchHistory = luajava.bindClass('com.tencent.nucleus.search.SearchHistoryManager')
    --local historyWord = SearchHistory:getInstance():cloneSearchHistoryStack()

    local historyWord = mJavaBridge:getHistoryWord();
    if (historyWord == nil) then
        mHistoryNum = 0
    else
        mHistoryNum = historyWord:size()
    end

    mHistoryWord = {}
    for i = 0, mHistoryNum - 1 do
        local word = historyWord:pop()
        mHistoryWord[i] = word
    end
end

function refreshHistoryView()
    local historyActionListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IPhotonActionListener', historyActionListener)
    Rapid:getChild("historyContainer"):getView():removeAllViews()

    local screenWidth = mJavaBridge:px2dip(mPhotonView:getParser():getScreenWidth())
    local totalLength = 0
    local container = "historyContainer"
    local textPaint = mPhotonView:getParser():getChildView("forMeasurehistory"):getView():getPaint()

    local containerWidth = screenWidth - 48
    Rapid:getChild("historyContainer"):setAttr("width", containerWidth)
    refreshHistoryData()
    if (mHistoryNum == 0) then
        Rapid:getChild("historyCard"):setAttr("visibility", "gone")
        return
    else
        Rapid:getChild("historyCard"):setAttr("visibility", "visible")
    end

    mShowFlag = true
    for index = 0, mHistoryNum - 1 do
        local params = {}
        local historyName = mHistoryWord[index]

        if(mShowFlag==true) then
            mVisibleNum = mVisibleNum + 1
            params["historyWord"] = historyName
            params["history_index"] = index
            mhistoryItem[index] = mJavaBridge:addView("native_search_history_word_card_item.xml", container, "", nil, params, historyActionListener)
        end

        totalLength = totalLength + mJavaBridge:px2dip(textPaint:measureText(historyName)) + 16
        local remainLength = containerWidth - totalLength
        if (remainLength < 0) then
            mShowFlag = false;
        end

    end
end

function historyExplosureReport()
    for index = 0, mVisibleNum - 1 do
        historyReport(index, "explosure")
    end
end

historyActionListener = {}
function historyActionListener.notify(key, value)
    if (key == "clickhistory") then
        local params = {}
        params["key"] = "UpdateSourceScene"
        Rapid:execAction("outeraction", params)

        local historyName = mHistoryWord[tonumber(value)]
        local tmast = "tmast://search?key=" .. historyName .. "&sourceScene=2007&searchScene=2007020&sourceSlotId=" .. Rapid:getData("slotId").."&subPosition="..getPositionString(tonumber(value)+1)
        local params = {}
        params["tmast"] = tmast
        Rapid:execAction("tmastaction", params, nil)
        historyReport(tonumber(value), "click")
    end
end

function historyReport(index, type)
    local data = {}
    local slotId = binder:get("slotId")
    local subPosition = getPositionString(index + 1)
    data["reportelement"] = "history_word"
    if (type == "explosure") then
        data["param"] = "slotid:data@slotId,actionid:100,subposition:" .. subPosition .. ",extradata:" .. mHistoryWord[index]
    elseif (type == "click") then
        data["param"] = "slotid:data@slotId,actionid:200,subposition:" .. subPosition .. ",extradata:" .. mHistoryWord[index]
    end
    data["extendparam"] = "historykeyword:" .. mHistoryWord[index]
    Rapid:execAction("reportaction", data, nil)
end

function getPositionString(position)
    return string.format("%03d", position)
end

function clearHistoryWord()
    mJavaBridge:clearHistoryWord()
    refreshHistoryView()
end

function onResume()
    refreshHistoryView()
end