local mPhotonView,mJavaBridge = ...

local UI_EVENT_CLICK_CLOUD_PLAY = 1385
local LOG_TAG = 'qiwei'

local mAppRecyclerView = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil

local needUpdateData = false
local uiListener

UIEventListener = {}
function UIEventListener.handleUIEvent(message)
    if message.what == UI_EVENT_CLICK_CLOUD_PLAY then
        needUpdateData = true
        Rapid:Log(LOG_TAG, '接收到了云玩按钮被点击的消息')
    end
end

IActionListener = {}
function IActionListener.notify(key, value)
    if (key == 'jump_cloud_play') then
        Rapid:Log(LOG_TAG, '点击了云玩按钮，发送刷新消息')
        -- 点击进入云玩时outCall到这里处理
        sendNotifyEvent()
    end
end

function onResume()
    Rapid:Log(LOG_TAG, 'onResume')
    
    if needUpdateData then
        Rapid:Log(LOG_TAG, 'onResume 需要刷新消息')
        mJavaBridge:delayRun(500, notifyUpdate)
    end
    needUpdateData = false
end

function main()
    mAppRecyclerView = mPhotonView:getParser():getChildView('rv_app')
    mAppRecyclerView:getView():setClipToPadding(false)
    mAppRecyclerView:getView():setClipChildren(false)

    uiListener = luajava.createProxy("com.tencent.assistant.event.listener.UIEventListener", UIEventListener)
end

function notifyUpdate()
    local cmd = 3002
    local params = {}
    Rapid:Log(LOG_TAG, '调用刷新完成')
    mJavaBridge:callModuleWithParams("Update", "requestCardDataAndUpdate", {mPhotonView, RapidList:getController(), cmd, params, UpdateCallbackFunc})
    Rapid:Log(LOG_TAG, '调用刷新完成')
end

function UpdateCallbackFunc()
    
end

function sendNotifyEvent()
    mJavaBridge:sendEvent(UI_EVENT_CLICK_CLOUD_PLAY, nil, nil, nil)
end

function updateData()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")

    mJavaBridge:addUIEventListener(UI_EVENT_CLICK_CLOUD_PLAY, uiListener)
    local actionListner = luajava.createProxy("com.tencent.rapidview.deobfuscated.IPhotonActionListener", IActionListener)
    mAppRecyclerView:getView():setActionListener(actionListner)
    updateAppList()
end

function updateAppList()
    local dataList = {}
    local viewNameList = {}

    local itemCount = tonumber(tostring(Rapid:getData('item_num', '0')))
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        fillItemData(itemData, i)
        dataList[i] = itemData
        viewNameList[i] = 'game_tab_v2_launcher_app_card_item_.xml'
    end

    mAppRecyclerView:getView():removeAllViews()
    mAppRecyclerView:getView():updateData(viewNameList, dataList, true)
end

function fillItemData(itemData, index)
    if itemData == nil then
        return
    end
    putBaseReportText(itemData)
    itemData:put("subPosition", mJavaBridge:create("Var", index))
    itemData:put("app_slotId", mJavaBridge:create("Var", tostring(Rapid:getData("slotId")) .. "_-1_"..index))
end

function putBaseReportText(itemData)
    if mScene ~= nil then
        local var_scene = mJavaBridge:create("Var", mScene)
        itemData:put("scene", var_scene)
    end
    
    if mSourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create("Var", mSourcescene)
        itemData:put("sourcescene", var_sourcescene)
        itemData:put("sourceScene", var_sourcescene)
    end
    
    if mModeltype ~= nil then
        local var_modeltype = mJavaBridge:create("Var", mModeltype)
        itemData:put("modeltype", var_modeltype)
        itemData:put("modelType", var_modeltype)
    end
    
    if mSourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create("Var", mSourceslotid)
        itemData:put("sourcesceneslotid", var_sourceslotid)
        itemData:put("sourceSceneSlotId", var_sourceslotid)
    end
    
    if mSlotid ~= nil then
        local var_slotid = mJavaBridge:create("Var", mSlotid)
        itemData:put("slotid", var_slotid)
        itemData:put("slotId", var_slotid)
    end
end