local mPhotonView, mJavaBridge = ...
local playStateChangeListener = nil
local videoView =nil
local videoMsgView = nil
local muteView = nil
local muteRl = nil

function init()
    videoMsgView = mPhotonView:getParser():getChildView("video_msg")
    videoView = mPhotonView:getParser():getChildView("video")
    muteView = mPhotonView:getParser():getChildView("mute")
    muteRl = mPhotonView:getParser():getChildView("mute_rl")
    initListener()
end

-- 初始化静音UI
function showMute()
    muteRl:getParser():update("visibility", "VISIBLE")
    local isMute = videoView:getView():isMute()
    if isMute then
        Rapid:setData("image", "https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("image", "https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end

-- 设置静音
function setMute()
    local isMute = videoView:getView():isMute()
    if  isMute then
        videoView:getView():setMuteToGlobal(false, true, true)
        Rapid:setData("image", "https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    else
        videoView:getView():setMuteToGlobal(true, true, true)
        Rapid:setData("image", "https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    end
end

function initListener()
    playStateChangeListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener', IPlayerStateChangeListener)
    videoView:getView():registerIPlayerStateChangeListener(playStateChangeListener)
end

IPlayerStateChangeListener = {}
-- 播放按钮被点击
function IPlayerStateChangeListener.onPlayButtonClick( videoView, isPlaying )

end
-- 播放开始
function IPlayerStateChangeListener.onPlayStart( videoView )
    videoMsgView:getParser():update("visibility", "GONE")
    showMute()
end
-- 播放停止
function IPlayerStateChangeListener.onPlayStop( videoView, currentPosition )
    videoMsgView:getParser():update("visibility", "VISIBLE")
    muteRl:getParser():update("visibility", "GONE");
end
-- 播放暂停
function IPlayerStateChangeListener.onPlayPause( videoView, currentPosition, reason )
    videoMsgView:getParser():update("visibility", "VISIBLE")
    muteRl:getParser():update("visibility", "GONE");
end
-- 播放继续
function IPlayerStateChangeListener.onPlayContinue( videoView, currentPosition )
    videoMsgView:getParser():update("visibility", "GONE")
    showMute()
end
-- 播放完成
function IPlayerStateChangeListener.onPlayComplete( videoView )
    videoMsgView:getParser():update("visibility", "VISIBLE")
    muteRl:getParser():update("visibility", "GONE");
end
-- 播放出错
function IPlayerStateChangeListener.onError( videoView, errorCode )
    videoMsgView:getParser():update("visibility", "VISIBLE")
    muteRl:getParser():update("visibility", "GONE");
end
-- 播放器静音状态改变
function IPlayerStateChangeListener.onMute( videoView, mute )
    if  mute then
        Rapid:setData("image", "https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("image", "https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end

function jumpVideoDetail()
    videoView:getView():performVideoComponentClick()
end