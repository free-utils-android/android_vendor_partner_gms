local mPhotonView,mJavaBridge = ...


local mBookRecyclerView = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil
local mRid = nil


function main()
    mBookRecyclerView = mPhotonView:getParser():getChildView('rv_book')
end

function updateData()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    mRid = Rapid:getData("recommend_card")

    updateAppList()
end

function updateAppList()
    local dataList = {}
    local viewList = {}

    local itemCount = tonumber(Rapid:getData('item_num', '0'))
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        fillItemData(itemData, i, itemCount)
        dataList[i] = itemData
        viewList[i] = 'novel_tab_book_shelf_card_item.xml'
    end

    mBookRecyclerView:getView():removeAllViews()
    mBookRecyclerView:getView():updateData(viewList, dataList, true)
end

function fillItemData(itemData, index, itemCount)
    putReportElement(itemData)
    putMapData(itemData, "subPosition", index)
    if index == itemCount then
        putMapData(itemData, "marginRight", 16)
    else
        putMapData(itemData, "marginRight", 0)
    end
end

function putReportElement(mapData)
    putMapData(mapData, "scene", mScene)
    
    putMapData(mapData, "sourcescene", mSourcescene)
    putMapData(mapData, "sourceScene", mSourcescene)
    
    putMapData(mapData, "modeltype", mModeltype)
    putMapData(mapData, "modelType", mModeltype)
    
    putMapData(mapData, "sourcesceneslotid", mSourceslotid)
    putMapData(mapData, "sourceSceneSlotId", mSourceslotid)
    
    putMapData(mapData, "slotid", mSlotid)
    putMapData(mapData, "slotId", mSlotid)

    putMapData(mapData, "recommend_card", mRid)
end

function putMapData(map, key, value)
    if ((map ~= nil) and (key ~= nil) and (value ~= nil)) then
        local var = mJavaBridge:create("var", value)
        map:put(key, var)
    end
end