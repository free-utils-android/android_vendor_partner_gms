local mPhotonView,mJavaBridge = ...

-- 下方appIcon列表
local mAppIconRecyclerView = nil
-- 数据数量
local itemCount = nil
local OnFixCenterListener = {}
local OnFocusChangeListener = {}

-- 动画相关常量
local DEFAULT_ICON_ALPHA = 0.65
local CHANGE_ICON_ALPHA = 1
local DEFAULT_ICON_SCALE = 1
local CHANGE_ICON_SCALE = 1.4
local DURATION = 300

local MAX_TAG_COUNT = 4

local mVideoView = nil
local mIsStart = false
local mStartTimeMs = 0
local mIsCompleted = false
local mProgress = 0
local mStateChangeListener = nil
local IPlayerStateChangeListener = {}

local CLOSE = "https://yybcms.gtimg.com/android_cms/gzskin/9965898f4c1e213299c09e01ab38d933.png"
local OPEN = "https://yybcms.gtimg.com/android_cms/gzskin/9460dba248c953442f7ecb494058b282.png"

local isFirst = true

function initView( ... )
    mAppIconRecyclerView = Rapid:getChild("rl_app_icon")

    initListener()
end

function updateData( ... )
    itemCount = tonumber(Rapid:getData("game_count","0"))

    initVideoView()

    local appViewNameList = {}
    local appViewName = "cloud_game_recently_launched_landscape_app_item_card.xml"
    local dataList = {}
    local viewNameList = {}
    local gameInfoViewName = "cloud_game_recently_launched_landscape_game_info_item_card.xml"
    for i = 1, itemCount do
        local itemData = Rapid:getData("item_data_" .. i)
        if itemData == nil then
            break
        end
        itemData:put("subposition" , mJavaBridge:create("Var", i))
        itemData:put("sourcescene" , mJavaBridge:create("Var", Rapid:getData("sourcescene","")))
        itemData:put("sourceslotid" , mJavaBridge:create("Var", Rapid:getData("sourceslotid","")))
        itemData:put("sourcesceneslotid" , mJavaBridge:create("Var", Rapid:getData("sourcesceneslotid","")))
        itemData:put("sourcemodeltype" , mJavaBridge:create("Var", Rapid:getData("sourcemodeltype","")))
        itemData:put("slotid" , mJavaBridge:create("Var", Rapid:getData("slotid","")))
        itemData:put("modeltype" , mJavaBridge:create("Var", Rapid:getData("modeltype","")))
        itemData:put("scene" , mJavaBridge:create("Var", Rapid:getData("scene","")))
        appViewNameList[i] = appViewName
        dataList[i] = itemData
        viewNameList[i] = gameInfoViewName
    end

    mAppIconRecyclerView:getView():updateData(appViewNameList, dataList, true)
    if isFirst then
        -- 加载第一个item
        anchorCurrentItem(1)
        isFirst = false
    end
end

function initListener( ... )
    local onFixCenterListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IFocusRecyclerView$OnFixCenterListener", OnFixCenterListener)
    mAppIconRecyclerView:getView():setOnFixCenterListener(onFixCenterListener)
    local onFocusChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IFocusRecyclerView$OnFocusChangeListener", OnFocusChangeListener)
    mAppIconRecyclerView:getView():setOnFocusChangeListener(onFocusChangeListener)
end

function OnFixCenterListener.onScrollToCenter( position )
    return true
end

local focusView = nil
function OnFocusChangeListener.onFocusGet( rapidView , isFromBindViewHolder)
    local txImageView = rapidView:getParser():getChildView("app_icon"):getView()
    focusView = txImageView
    if isFromBindViewHolder then
        focusView:setScaleX(CHANGE_ICON_SCALE)
        focusView:setScaleY(CHANGE_ICON_SCALE)
        focusView:setAlpha(CHANGE_ICON_ALPHA)
        if mVideoView:getView() ~= nil then
            if mVideoView:getView():getVisibility() == 0 then
                mVideoView:getView():setAutoPlay(true)
            end
        end
    else
        mJavaBridge:postRun(onFocusGet)
    end
end

function onFocusGet( )
    if focusView == nil then
        return
    end
    xParam = createParams(DEFAULT_ICON_SCALE, CHANGE_ICON_SCALE)
    yParam = createParams(DEFAULT_ICON_SCALE, CHANGE_ICON_SCALE)
    startAnimation( focusView, xParam, yParam, CHANGE_ICON_ALPHA)
end

local loseFocusView = nil
function OnFocusChangeListener.onFocusLose( rapidView )
    local txImageView = rapidView:getParser():getChildView("app_icon"):getView()
    loseFocusView = txImageView
    mJavaBridge:postRun(onFocusLose)
end

function onFocusLose( ... )
    if loseFocusView == nil then
        return
    end
    params = prepareScaleSmallParam(loseFocusView, CHANGE_ICON_SCALE)
    startAnimation( loseFocusView, params, params, DEFAULT_ICON_ALPHA)
end

function OnFocusChangeListener.onClick(hasFocus, rapidView, position)
    -- 传入的是 recyclerview的position，下标从 0 开始
    if position < 0 or position >= itemCount then
        return
    end
    -- 第二次点击时，跳转到应用详情页
    if hasFocus then
        local params = {}
        -- lua下标从1开始
        local realPosition = position + 1
        data = Rapid:getData("item_data_" .. realPosition)
        if data == nil then
            return
        end
        if isNotEmpty(data, "vid") then
            params["tmast"] = tostring(data:get("jump_url")) .. "&extra_video_uri=" .. tostring(data:get("vid")) .. "&extra_progress=" .. tostring(mProgress)
        else
            params["tmast"] = tostring(data:get("jump_url"))
        end
        Rapid:execAction("tmastaction", params, nil)
        rapidView:getParser():getTaskCenter():run("second_click")
    else
        anchorCurrentItem(position + 1)
        rapidView:getParser():getTaskCenter():run("first_click")
    end
end

function startAnimation( view, xParam, yParam, alpha)
    view:clearAnimation()
    local mIconAnimSet = luajava.newInstance('android.animation.AnimatorSet')
    local listener = luajava.createProxy('android.animation.Animator$AnimatorListener', LayoutScaleAnimationListener)
    local ObjectAnimator = luajava.bindClass("android.animation.ObjectAnimator")

    local layoutScaleXAnim = ObjectAnimator:ofFloat(view, 'scaleX', xParam)
    local layoutScaleYAnim = ObjectAnimator:ofFloat(view, 'scaleY', yParam)

    local objParams = {}
    objParams[1] = layoutScaleXAnim
    objParams[2] = layoutScaleYAnim

    mIconAnimSet:playTogether(objParams)
    mIconAnimSet:setDuration(DURATION)
    mIconAnimSet:addListener(listener)
    mIconAnimSet:start()
    view:setAlpha(alpha)
end

function anchorCurrentItem(dataIndex)
    local itemData = Rapid:getData("item_data_"..dataIndex)
    if itemData == nil then
        return
    end
    Rapid:setData("subposition", dataIndex)
    updateExposeData(itemData, "appid")

    -- 设置最近上新
    if isNotEmpty(itemData, "game_newest_desc") then
        Rapid:getChild("game_newest"):setAttr("visibility", "visible")
        Rapid:setData("game_newest_desc", itemData:get("game_newest_desc"))
    else
        Rapid:getChild("game_newest"):setAttr("visibility", "gone")
    end

    Rapid:setData("app_name", itemData:get("app_name"))
    Rapid:setData("jump_url", itemData:get("jump_url"))
    -- 设置云玩按钮跳转
    if isNotEmpty(itemData, "test_play_jump_url") then
        Rapid:getChild("cloud_play_button"):setAttr("visibility", "visible")
        Rapid:getChild("cloud_play_button"):setAttr("playurl", itemData:get("test_play_jump_url"))
        exposeCloudGameBtn(itemData)
    else
        Rapid:getChild("cloud_play_button"):setAttr("visibility", "gone")
    end

    -- 设置 tag
    for i = 1, MAX_TAG_COUNT do
        if isNotEmpty(itemData, "tag_" .. i) then
            Rapid:setData("tag_" .. i, itemData:get("tag_" .. i))
            Rapid:setData("visible_" .. i, "visible")
        else
            Rapid:setData("visible_" .. i, "gone")
        end
    end

    -- 优先展示视频
    if isNotEmpty(itemData, "vid") then
        Rapid:getChild("video_view"):setAttr("visibility", "visible")
        Rapid:getChild("game_image"):setAttr("visibility", "gone")
        mProgress = 0
        initVideo(false)
        startPlay(itemData, true, false)
        exposeVideo( "vid", itemData)
        return
    end

    -- 设置大图
    if isNotEmpty(itemData, "game_image_url") then
        Rapid:setData("game_image_url", itemData:get("game_image_url"))
        Rapid:getChild("game_image"):setAttr("visibility", "visible")
        Rapid:getChild("game_image"):getView():updateImageView(itemData:get("game_image_url"))
        Rapid:getChild("video_view"):setAttr("visibility", "gone")
        exposeImage(itemData)
        setMuteVisible(false)
        if mVideoView == nil then
            return
        end
        if mVideoView:getView() == nil then
            return
        end
        if mVideoView:getView():isPlaying() == true or mVideoView:getView():isPaused() == true then
            mVideoView:getView():stop(false)
            mVideoView:getView():setAutoPlay(false)
        end
    end
end

function initVideo()
    if mVideoView:getView():isPlaying() == true or mVideoView:getView():isPaused() == true then
        mVideoView:getView():stop(false)
    end
end

function initVideoView()
    mVideoView = Rapid:getChild("video_view")
    mStateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener",IPlayerStateChangeListener)
    if (mVideoView ~= nil and mStateChangeListener ~= nil) then
        mVideoView:getView():registerIPlayerStateChangeListener(mStateChangeListener)
    end
end

-- index: play视频的item index
-- force: 是否检查播放
-- 不检查播放场景：
-- 1) 重新播放，切换时，不然会切换不成功
-- 2) 用户手动切换
-- 检查播放场景
-- 1) 设置了视频的wifi播放、关闭等场景
function startPlay(itemData, force, hidePlay)
    local video_vid = tostring(itemData:get("vid"))
    local jump_url = tostring(itemData:get("jump_url"))
    updateExposeData(itemData, "jump_url")
    updateExposeData(itemData, "vid")
    local cover_image_url = tostring(itemData:get("cover_image_url"))
    local video_recommendid = tostring(itemData:get("video_recommendid"))
    local video_report_context = tostring(itemData:get("video_report_context"))
    local video_jump_url = jump_url .. "&extra_video_uri=" .. video_vid .. "&extra_progress=0"

    mVideoView:getView():setScaleType(0)
    mVideoView:getView():setVid(video_vid)
    mVideoView:getView():setCoverImageUrl(cover_image_url)
    mVideoView:getView():hidePlayButton(hidePlay, true)
    mVideoView:getView():setJumpUrl(video_jump_url)
    mVideoView:getView():tryContinueOrRestartPlay(false, force)
end

function isPlayingCompleted()
    return mIsStart == false and mIsCompleted == true
end

function setMuteVisible( isVisible )
    if isVisible then
        Rapid:getChild("mute"):setAttr("visibility", "visible")
    else
        Rapid:getChild("mute"):setAttr("visibility", "gone")
    end
end

function initMute()
    if mVideoView == nil then
        return
    end

    local isMute = mVideoView:getView():isMute()
    updateMuteImage(isMute)
end

function setMute()
    if mVideoView == nil then
        return
    end

    local isMute = mVideoView:getView():isMute()
    if isMute then
        mVideoView:getView():setMuteToGlobal(false, true, true)
    else
        mVideoView:getView():setMuteToGlobal(true, true, true)
    end
    updateMuteImage(not isMute)
end

function updateMuteImage(isMute)
    if isMute then
        Rapid:setData("mute_image", CLOSE)
    else
        Rapid:setData("mute_image", OPEN)
    end
end

-- 视频曝光
function exposeVideo( vid, itemData)
    updateExposeData(itemData, "video_report_context")
    updateExposeData(itemData, "video_recommendid")
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:video,source_report_context:data@source_report_context,report_context:data@video_report_context,videoid:"..vid
    reportParams["recommendid"] = "data@video_recommendid"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)

    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:-100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:video,source_report_context:data@source_report_context,report_context:data@video_report_context,videoid:"..vid
    reportParams["recommendid"] = "data@video_recommendid"
    reportParams["dteventkey"] = "imp"
    reportParams["viewid"] = "video_view"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

-- 图片曝光
function exposeImage( itemData )
    updateExposeData(itemData, "app_report_context")
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid,status:-1,subposition:data@subposition,actionid:100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:image,source_report_context:data@source_report_context,report_context:data@app_report_context"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)

    reportParams["param"] = "slotid:data@slotid,status:-1,subposition:data@subposition,actionid:-100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:image,source_report_context:data@source_report_context,report_context:data@app_report_context"
    reportParams["dteventkey"] = "imp"
    reportParams["viewid"] = "game_image"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

-- 云玩按钮曝光
function exposeCloudGameBtn( itemData )
    updateExposeData(itemData, "btn_report_context")
    updateExposeData(itemData, "btn_recommendid")
    Rapid:getChild("cloud_play_button"):setAttr("extendparam", "recommendid:data@btn_recommendid,report_context:data@btn_report_context")
    local reportParams = {}
    reportParams["param"] = "slotid:data@slotid,status:-1,actionid:100,scene:data@scene,sourceScene:data@sourcescene,modeltype:data@modeltype,sourcemodeltype:data@sourcemodeltype,sourcesceneslotid:data@sourcesceneslotid,appid:data@appid,searchid:0"
    reportParams["extendparam"] = "report_element:button,elementid:cloudgame_btn,source_report_context:data@source_report_context,report_context:data@btn_report_context,uni_button_title:云玩"
    reportParams["recommendid"] = "data@btn_recommendid"
    reportParams["dteventkey"] = "imp"
    reportParams["viewid"] = "cloud_play_button"
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end

function updateExposeData( itemData, key )
    if isNotEmpty(itemData, key) then
        Rapid:setData(key, itemData:get(key):getLuaValue())
    end
end

function IPlayerStateChangeListener.onPlayStart()
    mIsStart = true
    mIsCompleted = false

    setMuteVisible(true)
    initMute()
end

-- 视频进度改变，显示的内容变化
function IPlayerStateChangeListener.onProgressUpdate(mVideoView, progress)
    if (mVideoView == nil) then
        return
    end
    mProgress = progress
    local jump_url = Rapid:getData("jump_url")
    local vid = Rapid:getData("vid")
    local video_jump_url = jump_url .. "&extra_video_uri=" .. vid .. "&extra_progress=" .. tostring(progress)
    mVideoView:setJumpUrl(video_jump_url)
end

function IPlayerStateChangeListener.onPlayContinue()
    setMuteVisible(true)
    initMute()
end

function IPlayerStateChangeListener.onPlayStop()
    setMuteVisible(false)

    mIsStart = false

    mVideoView:getView():hidePlayButton(false, true)
end

function IPlayerStateChangeListener.onPlayPause()
    setMuteVisible(false)
end

function IPlayerStateChangeListener.onPlayComplete(videoView)
    setMuteVisible(false)
    mIsStart = false
    mIsCompleted = true
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    updateMuteImage(mute)
end

function isNotEmpty(itemData, key)
    if itemData:containsKey(key) then
        local str = tostring(itemData:get(key))
        if (str ~= nil and string.len(str) > 0) then
            return true
        else
            return false
        end
    else
        return false
    end
end

function createParams(params1, params2)
    local params = {}
    params[1] = params1
    params[2] = params2
    return params
end

function prepareScaleSmallParam(view, max)
    if view == nil then
        return
    end
    view:clearAnimation()
    local scaleX = view:getScaleX()
    local rate = math.min(scaleX, max)
    local param = createScaleAnimParamEnd(1) -- 用这种方式可以规避lua framework的问题
    return param
end

function createScaleAnimParamEnd(after)
    local params = {}
    params[1] = after
    return params
end

LayoutScaleAnimationListener = {}
function LayoutScaleAnimationListener.onAnimationStart(animator)

end

function LayoutScaleAnimationListener.onAnimationEnd(animator)

end

function LayoutScaleAnimationListener.onAnimationCancel(animator)
    
end

function LayoutScaleAnimationListener.onAnimationRepeat(animator)
    
end