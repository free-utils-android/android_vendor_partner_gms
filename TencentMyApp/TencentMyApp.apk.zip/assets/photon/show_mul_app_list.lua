local mPhotonView,javaBridge = ...
function initView()
	mRootView = mPhotonView
	appSize = mPhotonView:getParser():getBinder():get("bottom_app_size")
	mBinder = mPhotonView:getParser():getBinder()
	if ( appSize == nil or mBinder == nil )
	then
		return
	end
	--增加appItem
	for i=0,tonumber(appSize)-1 do
		local data ={}
		data["item_name"] = mBinder:get("item_name_"..i)
		data["item_icon"] = mBinder:get("item_icon_"..i)
		data["item_file_size"] = mBinder:get("item_file_size_"..i)
		data["item_desc"] = mBinder:get("item_desc_"..i)
		data["app_item"] = mBinder:get("app_item_"..i)
		data["sourcescene"] = mBinder:get("sourcescene")
		data["sourcesceneslotid"]="20_03"
		data["subposition"]=i+1
		data["download_pos"]=3
		data["desc_visiable"]="visible"
		data["download_margin_right"]=12
		data["item_tag"] = mBinder:get("app_tag_"..i)
		data["tag_visiable"]="gone"
		if (data["item_tag"] ~= nil and string.len(data["item_tag"]) > 0 )
		then
			data["tag_visiable"]="visible"
		end
		data["sourcesceneslotid"]="20_"..(i+1)
		data["scene"]="200898"
		data["bg_color"]="ffffffff"
		data["view_margin"]="11"
		data["img_margin"]="11"
		data["app_margin"]="20"
		sourcescene = data["sourcescene"]
		--data["item_desc"]=""
		--控制标签是否展示
		if ( data["item_tag"] == nil or string.len(data["item_tag"]) < 1 )
		then
			data["item_visiable"]="gone"
		end
		--控制描述是否展示
		if (data["item_desc"] == nil or string.len(tostring(data["item_desc"])) < 1)
		then
			data["desc_visiable"]="gone"
		end
		local view = javaBridge:addView('native_content_detail_app_item.xml','root_view',nil,nil,nil)
		view:getParser():getBinder():update(data)
		if ( i >= 1 )
		then
			view:getView():setVisibility(8)
		else
			local data ={}
			data["param"]="scene:200898,actionid:100,slotid:20_"..tostring(i+1)..",sourcescene:"..tostring(sourcescene)
			mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
		end
	end
	--决定是否需要展示“查看更多”
	if ( tonumber(appSize) > 1)
	then
		local moreData={}
		moreData["app_size"] = mPhotonView:getParser():getBinder():get("bottom_app_size")
		moreData["more_btn_text"]= "更多应用".."("..appSize..")"
		moreData["sourcescene"] = sourcescene
		local view = javaBridge:addView('content_show_more_btn_view.xml','root_view',nil,nil,nil)
		view:getParser():getBinder():update(moreData)
		--修改view的高度
	end
end

--点击展开更多事件
function doClick()
	appSize = mPhotonView:getParser():getBinder():get("app_size")
	mParentView = mPhotonView:getParser():getParentView()
	sourcescene=mPhotonView:getParser():getBinder():get("sourcescene")
	if ( appSize == nil)
	then
		return
	end
	local flag = 0
	for i=0,tonumber(appSize)-1 do
		--这里由于增加了一个标题view，因此需要+1
		local appItem = mParentView:getView():getChildAt(i+1)
		if ( appItem ~=nil)
		then
			if ( i > 0)
			then
				if ( appItem:getVisibility() == 0)
				then
					appItem:setVisibility(8)
					flag = 1
				else
					appItem:setVisibility(0)
					flag = 0
					local data ={}
					data["param"]="scene:200898,actionid:100,slotid:20_"..tostring(i+1)..",sourcescene:"..tostring(sourcescene)
					mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
				end
			end
		end
	end
	local textView = mPhotonView:getParser():getChildView("more_text")
	local imgView = mPhotonView:getParser():getChildView("more_img")
	if ( textView ~= nil and imgView ~= nil )
	then
		if ( flag == 1 )
		then
			textView:getParser():update("text","更多应用".."("..appSize..")")
			imgView:getParser():update("backgroundresource","res@icon_open")
			local data ={}
			data["param"]="scene:200898,actionid:200,slotid:31,status:2"..",sourcescene:"..tostring(sourcescene)
			mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
		else
			textView:getParser():update("text","点击收起")
			imgView:getParser():update("backgroundresource","res@icon_close")
			local data ={}
			data["param"]="scene:200898,actionid:200,slotid:31,status:1"..",sourcescene:"..tostring(sourcescene)
			mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction",data,data)
		end
	end
end