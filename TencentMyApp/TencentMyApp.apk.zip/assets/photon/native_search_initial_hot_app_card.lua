local mPhotonView,mJavaBridge = ...

local KEY_VIEW_SHOW_FLAG = "view_show_flag_"
local mRecyclerView
local mCardPosition
local mListController

IRapidListDataController = {}
function IRapidListDataController.updateItemData(index,key,val)
    Rapid:setData(key,val)
    RapidList:updateItemData(index,key,val)
end

function IRapidListDataController.reload()
end

function IRapidListDataController.getItemData(index,key)
    return RapidList:getItemData(index,key)
end

function init()
    mListController = luajava.createProxy('com.tencent.rapidview.deobfuscated.IRapidListDataController',IRapidListDataController)
    mRecyclerView = Rapid:getChild("recyclerView")
end

function refreshData()

    local num = tonumber(Rapid:getData("app_num"))
    if (num == nil or num == 0) then
        return
    end

    local realDataList = {}
    local realViewList = {}

    local slotId = Rapid:getData("slotId")
    local sourcescene = Rapid:getData("sourcescene")
    local sourcesceneslotid = Rapid:getData("sourcesceneslotid")
    local modeltype = Rapid:getData("modeltype")
    local scene = Rapid:getData("scene")

    for i=0,num-1 do
        local index = i + 1
        local data = {}
        data["app_icon"]    = Rapid:getData("app_icon_"..index)
        data["app_name"]    = Rapid:getData("app_name_"..index)
        data["app_desc"]    = Rapid:getData("app_desc_"..index)
        data["app_model"]   = Rapid:getData("app_model_"..index)
        data["appid"]      = Rapid:getData("app_id_"..index)
        data["recommendid"] = Rapid:getData("recommendid_"..index)
        data["app_rank"] = Rapid:getData("app_rank_"..index)
        data["subposition"] = getReportPosition(index)
        data["slotId"] = slotId
        data["sourcescene"] = sourcescene
        data["sourcesceneslotid"] = sourcesceneslotid
        data["modeltype"]   = modeltype
        data["scene"]       = scene
        realDataList[index] = data
        realViewList[index] = "native_search_initial_hot_app_card_item.xml"
        -- 设置曝光flag
        mRecyclerView:getView():setViewShowFlag(i, KEY_VIEW_SHOW_FLAG..index)
    end

    attachListController()
    mRecyclerView:getView():clear()
    mRecyclerView:getView():updateData(realViewList, realDataList)
end

function attachListController( ... )
    mCardPosition =  tonumber(Rapid:getData("position"))
    if mCardPosition == nil then
        mCardPosition = tonumber(Rapid:getData("index"))
    end
    mRecyclerView:getView():attachToListController(mCardPosition, mListController)
end

function getReportPosition(position)
    return string.format( "%03d", position )
end

function jumpMorePageHotNew()
    mJavaBridge:Log("jumpMorePage","init")
    local title = Rapid:getData("title")
    local params = {}
    --  params['tmast'] = "tmast://appdemo?photonid=301536669916606&params=scene:20060,sourcescene:30029,sourcesceneslotid:31_003_00_-1"
    params['tmast'] = "tmast://appdemo?photonid=301566904338919&params=scene:200715,cmdId:301,item_title:"..title;
    mPhotonView:getParser():getTaskCenter():getActionRunner():run("tmastaction",params,nil)
end

