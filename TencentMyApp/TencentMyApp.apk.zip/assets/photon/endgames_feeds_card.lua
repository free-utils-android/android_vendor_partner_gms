local mPhotonView, mJavaBridge = ...

local TAG = 'qiwei'
local CLOUD_GAME_GAME_FINISH_EVENT = 36017
local BEFORE_TAG = 'endgames_feed_card_'

local stateChangeListener
local videoView

local uiListener

-- 刷新卡片数据
function updateData()
    local endgamesId = tostring(Rapid:getData('endgames_id', ''))
    local params = {}
    params['type'] = 'endgame_update'
    params['endgame_id_for_update'] = endgamesId
    mJavaBridge:request(3003, params, onRequestListener)
end

function onRequestListener(succeed, viewNameList, dataList)
	if succeed then
		onRequestSucceed(viewNameList, dataList)
	else
		onRequestFailed()
	end
end

function onRequestSucceed(viewNameList, dataList)
    if(viewNameList == nil or dataList == nil) then
        onRequestFailed()
		return
    end

    if dataList:size() <= 0 then
        mJavaBridge:Log(TAG,"请求数据为空===")
        return
    end
    mJavaBridge:Log(TAG,"请求数据成功===")
    
    local dataMap = dataList:get(0)
    if dataMap == nil or dataMap:size() <= 0 then
        return
    end

    local endgamesId = tostring(Rapid:getData('endgames_id', ''))
    local id = dataMap:get('endgames_id')
    if endgamesId == '' or id == nil or id == '' then
        return
    end

    Rapid:setData('on_list_text', dataMap:get('on_list_text'))
    mJavaBridge:Log(TAG,"更新数据成功===")
end

function onRequestFailed()
    mJavaBridge:Log(TAG,"onRequestFailed===")
end

CommonEventListener = {}
function CommonEventListener.handleCommonEvent(message)
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent")
    if checkRefreshPage(message) then
        mJavaBridge:Log(TAG, "CommonEventListener.updateData")
        updateData()
    end
end

function checkRefreshPage(message)
    mJavaBridge:Log(TAG, "checkRefreshPage")
    local what = message.what
    local entranceid = "entranceid="..tostring(message.obj)
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent what: "..tostring(what))
    mJavaBridge:Log(TAG, "CommonEventListener.handleCommonEvent entranceid: "..tostring(entranceid))
    if what ~= CLOUD_GAME_GAME_FINISH_EVENT then
        return false
    end

    local challengeJumpUrl = tostring(Rapid:getData('challenge_jump_url', ''))
    if challengeJumpUrl == nil or string.find(challengeJumpUrl, entranceid) == nil then
        return false
    end
    return true
end

function initListener()
    uiListener = luajava.createProxy("com.tencent.assistant.event.listener.CommonEventListener", CommonEventListener)
    mJavaBridge:callModuleWithParams("EventListener", "addCommonEventListener",{CLOUD_GAME_GAME_FINISH_EVENT, uiListener})
end

function loadFinish()
    initListener()
end

function afterUpdateData()
    setVideoViewHeight()
    setTitleTag()
    initLabel()
    initVideo()
end

function setVideoViewHeight()
    local screenWidth = getScreenHeight()
    local bit = 202 / 360
    local videoHeight = screenWidth * bit
    mJavaBridge:Log(TAG,"videoHeight=="..tostring(videoHeight))
    Rapid:setData('videoHeight', tostring(videoHeight))
end

function setTitleTag()
    local title_tag = tostring(Rapid:getData('title_tag', ''))
    if tostring(title_tag) ~= '' then
        Rapid:getChild('iv_title_tag'):setAttr('visibility', 'visible')
    else
        Rapid:getChild('iv_title_tag'):setAttr('visibility', 'gone')
    end
end

function initLabel()
    Rapid:getChild('rl_label'):setAttr('visibility', 'gone')
    Rapid:getChild('tv_label_1'):setAttr('visibility', 'gone')
    Rapid:getChild('tv_label_2'):setAttr('visibility', 'gone')
    Rapid:getChild('tv_label_3'):setAttr('visibility', 'gone')
    local showLabel = false

    local labels = Rapid:getData('labels', '')
    if labels == '' then
        return
    end
    local splitStrTable = splitStr(labels)
    if splitStrTable ~= nil then
        for i, v in ipairs(splitStrTable) do
            -- 目前最多显示3个
            if i > 3 then
                return
            end
            showLabel = true
            Rapid:getChild("tv_label_"..i):setAttr("visibility", "visible")
            Rapid:getChild("tv_label_"..i):setAttr("text", tostring(v))
        end
    end

    if showLabel then
        Rapid:getChild('rl_label'):setAttr('visibility', 'visible')
    end
end

function initVideo()
    stateChangeListener = luajava.createProxy(
        "com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener",
        IPlayerStateChangeListener)
    videoView = Rapid:getChild("video_view")
    videoView:getView():registerIPlayerStateChangeListener(stateChangeListener)
    dismissControlView()
end

function onResume()
    mJavaBridge:Log(TAG,"onResume==")
    local endGameId = tostring(Rapid:getData('endgames_id', ''))
    if endGameId == '' then
        mJavaBridge:Log(TAG,"endGameId == nil")
        return
    end
    local commentCount = mJavaBridge:getMemoryCache(BEFORE_TAG..endGameId)
    if commentCount == nil or commentCount == '' then
        mJavaBridge:Log(TAG,"commentCount == nil")
        return
    end
    if tostring(commentCount) == '0' then
        commentCount = '评论'
    end
    Rapid:setData('comment_text', tostring(commentCount))
    mJavaBridge:removeMemoryCache(BEFORE_TAG..endGameId)
    mJavaBridge:Log(TAG,"comment_text=="..tostring(commentCount))
end

function onPause()
    videoView:getView():stop(false)
end

function dismissControlView()
    videoView:getView():setShowSmallPlayButton(false, true)
    videoView:getView():setIsShowMuteView(false, true)
    videoView:getView():setIsShowProgressBar(false, true)
    videoView:getView():setIsShowTextProgressLayout(false, true)
    videoView:getView():setIsShowFullScreenView(false, true)
end

function showControlView()
    videoView:getView():setShowSmallPlayButton(true, true)
    videoView:getView():setIsShowMuteView(true, true)
    videoView:getView():setIsShowProgressBar(true, true)
    videoView:getView():setIsShowTextProgressLayout(true, true)
    videoView:getView():setIsShowFullScreenView(true, true)
end

IPlayerStateChangeListener = {}
function IPlayerStateChangeListener.onPureClick(videoView)

end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart()
    showControlView()
end

function IPlayerStateChangeListener.onPlayContinue()

end

function IPlayerStateChangeListener.onPlayStop()

end

function IPlayerStateChangeListener.onPlayComplete(videoView)

end

function IPlayerStateChangeListener.onPlayPause()

end

function splitStr(str)
    if (str == nil or str == "") then
        return {}
    end

    local last_start = 1
    local single_str = nil
    local index = 1
    local res = {}
    for k = 1, string.len(str) do
        if string.sub(str, k, k) == ',' then
            if (last_start < k) then
                single_str = string.sub(str, last_start, k - 1)
                res[index] = single_str
                index = index + 1
            end
            last_start = k + 1
        end
    end

    if (last_start <= string.len(str)) then
        single_str = string.sub(str, last_start, string.len(str))
        res[index] = single_str
        index = index + 1
    end
    return res
end

function getScreenHeight()
    local screenWidth = mJavaBridge:px2dip(mPhotonView:getParser():getScreenWidth())
    local screenHeight = mJavaBridge:px2dip(mPhotonView:getParser():getScreenHeight())
    if screenWidth > screenHeight then
        -- 全屏后getScreenWidth接口可能会取反为屏幕高，所以对换一下
        screenWidth = screenHeight
    end
    return screenWidth
end