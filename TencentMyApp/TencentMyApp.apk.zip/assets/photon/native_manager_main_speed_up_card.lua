local mPhotonView,mJavaBridge = ...

local scoreChangeListener = nil
local scoreViewChangeListener = nil

local MAX_SCORE = 100
local mScore = MAX_SCORE

local DEFAULT_CONFIG = "default"
local DEFAULT_BG_COLOR = "1c90ee"
local DEFAULT_TEXT_COLOR = "0080ff"
local DEFAULT_SHOW_INFO = "手机状态满分，请继续保持"

local textAndColorConfig = nil

local currentConfig = nil

function init()
    scoreChangeListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IManagerScoreChangedListener', IManagerScoreChangedListener)

    scoreViewChangeListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IManagerScoreViewChangedListener', IManagerScoreViewChangedListener)

    initHeight()
end

function initHeight()
    local statusBarHeight = mJavaBridge:getStatusBarHeight()

    local rootView = mPhotonView:getParser():getChildView("root_view"):getView()
    rootView:setPadding(0, statusBarHeight, 0, 0)
end

function updateValue()
    mJavaBridge:showLightStatusBar(mPhotonView:getView():getContext())
    initConfig()
end

IManagerScoreChangedListener = {}
function IManagerScoreChangedListener.onScoreChanged(score)
    Rapid:setData("manager_main_score", tostring(score))
    reportScoreRefresh(score)

    -- score = 100

    -- if (score == 100) then
    --     showSmallView()
    --     return
    -- end

    showLargeView()

    mJavaBridge:animationWithScore(mScore, score, scoreViewChangeListener)
end

function reportScoreRefresh(score)
	local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] ="scene:data@scene,actionid:2007,slotid:99_-1,subposition:-1,modeltype:data@modeltype,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid"
    params1["extendparam"] = "report_element:score,uni_manage_score:"..tostring(score)
    params1["recommendid"] = "data@card_recommendid"
	actionRunner:run("reportaction", params1, nil)
end

IManagerScoreViewChangedListener = {}
function IManagerScoreViewChangedListener.onScoreChanged(score, scoreText)
    if (score == mScore) then
        return
    end

    mScore = score

    updateView(score, scoreText)
end

function initConfig()
    local tempConfig = Rapid:getData("config")

    mJavaBridge:setSettingsDataAsync("photon_manager_speed_up_config", tostring(tempConfig))

    textAndColorConfig = mJavaBridge:create('JSONArray', tempConfig)
end

function getConfig(score)
    local maxScore = MAX_SCORE

    if (textAndColorConfig == nil) then
        return DEFAULT_CONFIG
    end

    local size = textAndColorConfig:length()
    for i = 0, textAndColorConfig:length() - 1 do
        local itemConfigLarge = textAndColorConfig:get(i)
        local itemConfigSmall = nil

        if (i < size - 1) then
            itemConfigSmall = textAndColorConfig:get(i + 1)
        end

        local itemMaxScore = itemConfigLarge:getString("maxScore")
        local itemMinScore = -1

        if (itemConfigSmall ~= nil) then
            itemMinScore = itemConfigSmall:getString("maxScore")
        end

        if (tonumber(score) > tonumber(itemMaxScore)) then
            return DEFAULT_CONFIG
        end

        if (tonumber(score) > tonumber(itemMinScore) and tonumber(score) <= tonumber(itemMaxScore)) then
            return itemConfigLarge
        end

        i = i + 1
    end

    return DEFAULT_CONFIG
end

function updateView(score, scoreText)
    local config = getConfig(score)

    local showInfo = ""
    local maxScore = ""
    local bgColor = ""
    local textColor = ""

    if (config == DEFAULT_CONFIG or config == nil) then
        showInfo = DEFAULT_SHOW_INFO
        bgColor = DEFAULT_BG_COLOR
        textColor = DEFAULT_BG_COLOR
    else
        showInfo = config:getString("showInfo")
        bgColor = config:getString("bgColor")
        textColor = config:getString("bgColor")
    end

    if (config ~= currentConfig) then
        Rapid:getChild('root_view'):setAttr("backgroundcolor", bgColor)
        Rapid:getChild('tv_score_large_desc'):setAttr("text", showInfo)
        Rapid:getChild('one_key_btn'):setAttr("textcolor", textColor)
    end

    currentConfig = config

    updateLargeView(scoreText)
end

function showSmallView()
    Rapid:getChild('one_key_layout'):setAttr("visibility", "gone")

    Rapid:getChild('small_layout'):setAttr("visibility", "visible")
end

function showLargeView()
    Rapid:getChild('small_layout'):setAttr("visibility", "gone")

    Rapid:getChild('one_key_layout'):setAttr("visibility", "visible")
end

function updateLargeView(scoreText)
    mPhotonView:getParser():getChildView("tv_score_large"):getView():setText(scoreText)
end

function resumeView()
    mJavaBridge:calcFinalScoreAsync(scoreChangeListener)
end

function onResume()
    mJavaBridge:calcFinalScoreAsync(scoreChangeListener)

    mJavaBridge:showLightStatusBar(mPhotonView:getView():getContext())
end

function onPause()
    mJavaBridge:showDarkStatusBar(mPhotonView:getView():getContext())
end