local mPhotonView, mJavaBridge = ...

local mAppRecyclerView = nil

local delegateProperties = {
    "modeltype",
    "slotid",
    "sourcemodeltype",
    "sourcescene",
    "sourceQuery",
    "sourcesceneslotid",
    "scene",
    "searchId",
    "searchid",
    "searchScene",
    "searchSession",
    "slotId",
    "searchsession",
    "queryWord"
}

function main()
    mAppRecyclerView = Rapid:getChild("rv_app")

    mAppRecyclerView:getView():setClipToPadding(false)
    mAppRecyclerView:getView():setClipChildren(false)

    updateData()
end

function updateData()
    local itemCount = tonumber(Rapid:getData("game_count","0"))

    local dataList = {}
    local viewNameList = {}
    local subViewName = "search_guide_cloud_game_card_item.xml"

    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        if itemData == nil then
            break
        end
        putJumpUrlJoinRid(itemData, 'test_play_jump_url', 'app_recommendid')

        for _, property in ipairs(delegateProperties) do
            itemData:put(property, mJavaBridge:create("Var", Rapid:getData(property)))
        end
        itemData:put("app_context", mJavaBridge:create("Var", '{"is_cloudgame":"1","cloudgame":{"cloudgame_style":"only_cloud_game"}}'))
        itemData:put("subPosition", mJavaBridge:create("Var", index))
        dataList[i] = itemData
        viewNameList[i] = subViewName
    end
    mAppRecyclerView:getView():updateData(viewNameList, dataList, true)
end

function putJumpUrlJoinRid(itemData, jumpUrlKey, appRecommendidKey)
    if itemData ~= nil and itemData:get(jumpUrlKey) ~= nil and itemData:get(appRecommendidKey) ~= nil then
        itemData:put(jumpUrlKey, jumpUrlJoinRid(itemData:get(jumpUrlKey):getString(), 
            itemData:get(appRecommendidKey):getLuaValue()))
    end
end

function jumpUrlJoinRid(jumpUrl, recommendid)
    if jumpUrl == nil or jumpUrl == "" then
        return jumpUrl
    end
    local rcdBase64 = mJavaBridge:encode(mJavaBridge:create("bytes", recommendid), "default")
    if rcdBase64 ~= nil and rcdBase64 ~= "" then
        jumpUrl = jumpUrl.."&app_rid="..mJavaBridge:urlEncode(rcdBase64)
        mJavaBridge:Log("jumpUrlJoinRid", 'jumpUrl: '..tostring(jumpUrl))
    end
    return mJavaBridge:create("Var", jumpUrl)
end