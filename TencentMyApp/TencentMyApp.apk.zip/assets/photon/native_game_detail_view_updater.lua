local mPhotonView,mJavaBridge = ...

function load()
	loadTab()
end

function loadTab()
	local tableView = {}
	local viewPager = mPhotonView:getParser():getChildView("view_pager")
	local tabNum = tonumber(mPhotonView:getParser():getBinder():get("tab_num"))
	
	for i=1,tabNum do
		local id = tonumber(mPhotonView:getParser():getBinder():get("tab_id_" .. (i - 1)))
		
		if( id == 0 ) then
			tableView[i] = mJavaBridge:loadView('game_detail_choice_tab_container', 'viewpagerparams', nil);
		end
		
		if( id == 1 ) then
			tableView[i] = mJavaBridge:loadView('game_detail_community_tab_container', 'viewpagerparams', nil);
		end
		if( id == 2 ) then
			tableView[i] = mJavaBridge:loadView('game_detail_video_tab_container', 'viewpagerparams', nil);
		end
		if( id == 3 ) then
			tableView[i] = mJavaBridge:loadView('game_detail_strategy_container', 'viewpagerparams', nil);
		end
		
		if( id == 4 ) then
			tableView[i] = mJavaBridge:loadView('game_detail_comment_container', 'viewpagerparams', nil);
		end
	end

	viewPager:getView():getAdapter():refresh(tableView);
end