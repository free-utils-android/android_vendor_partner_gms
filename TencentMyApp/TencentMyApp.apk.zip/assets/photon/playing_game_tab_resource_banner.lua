local mRapidView, mJavaBridge = ...

local TAG = 'playing_game_tab_resource_banner'

local mRecyclerView
local mIndicateView
local mDataList, mViewList

local PageChangeListener = {}
local pageChangeListener
local OnTouchListener = {}
local onTouchListener = nil

local mDownX
local mMovex
local mUpx

local mIsGesture = false


function PageChangeListener.onPageChange(beforePageIndex, afterPageIndex)
    Rapid:Log(TAG, " afterPageIndex=" .. afterPageIndex)
    mIndicateView:setCurrentSelectedDotIndex(afterPageIndex)

end

function OnTouchListener.onTouch(v, event)

    Rapid:Log(TAG, " event=" .. tostring(event))

    if (event ~= nil) then
        local code = tonumber(event:getAction())
        if (code == 2) then
            if (mDownX == nil) then
                mDownX = (event:getRawX())
                mIsGesture = false
            end
            mMovex = tonumber(event:getRawX())
        end
        if (code == 1) then
            mUpx = tonumber(event:getRawX())

            if (mDownX ~= nil and mMovex ~= nil) then
                Rapid:Log(TAG, " abs " .. math.abs(mDownX - mMovex))
                if (math.abs(mDownX - mMovex) > 10) then
                    mIsGesture = true
                end
                mDownX = nil
                mMovex = nil
            end
        end
        Rapid:Log(TAG, " code="
        .. tostring(code) .. ' mDownX='
        .. tostring(mDownX) .. ' mDowny='
        .. tostring(mDowny) .. ' mMovex='
        .. tostring(mMovex) .. ' mMovey='
        .. tostring(mMovey) .. ' mUpx='
        .. tostring(mUpx) .. ' mUpy='
        .. tostring(mUpy))
    end

    return false

end


local isInit = true

function init()
    Rapid:Log(TAG, "init")
    if (isInit) then
        mRecyclerView = Rapid:getChild('banner'):getView()
        pageChangeListener =        luajava.createProxy(
        'com.tencent.rapidview.deobfuscated.control.IBannerPageChangeListener',
        PageChangeListener
        )
        mRecyclerView:addPageChangeListener(pageChangeListener)
        mIndicateView = Rapid:getChild('indicate_view'):getView()
        -- 添加view的手势监听事件
        onTouchListener = luajava.createProxy(
        'android.view.View$OnTouchListener',
        OnTouchListener
        )
        mRecyclerView:setOnTouchListener(onTouchListener)

        isInit = false
    end
end

function fillValue()
    Rapid:Log(TAG, " start fillValue ")
    init()
    mDataList = {}
    mViewList = {}


    local itemCount = Rapid:getData('item_num', '0')
    Rapid:Log(TAG, " itemCount : " .. tostring(itemCount))


    local itemWidthDp = mJavaBridge:px2dip(mJavaBridge:getScreenWidth()) - 32

    for i = 1, itemCount do
        local itemData = Rapid:getData('item_data_' .. i)

        Rapid:Log(TAG, " itemData : " .. tostring(itemData))
        itemData:put("item_width", mJavaBridge:create("var", itemWidthDp))
        itemData:put("num",mJavaBridge:create("var", tostring(i)))

        itemData:put("scene",mJavaBridge:create("var", Rapid:getData('scene')))
        itemData:put("sourcescene",mJavaBridge:create("var", Rapid:getData('sourcescene')))
        itemData:put("client_report_context",mJavaBridge:create("var", Rapid:getData('client_report_context')))
        itemData:put("source_report_context",mJavaBridge:create("var", Rapid:getData('source_report_context')))
        itemData:put("slotid",mJavaBridge:create("var", Rapid:getData('slotid')))
        itemData:put("sourcesceneslotid",mJavaBridge:create("var", Rapid:getData('sourceSceneSlotId')))
        itemData:put("modeltype",mJavaBridge:create("var", Rapid:getData('modeltype')))
        itemData:put("recommendid",mJavaBridge:create("var", Rapid:getData('recommendid')))
        itemData:put("uni_channel_appid",mJavaBridge:create("var", Rapid:getData('uni_channel_appid')))
        itemData:put("item_id",mJavaBridge:create("var", "item_id_" .. tostring(i)))

        mDataList[i] = itemData
        mViewList[i] = "playing_game_tab_resource_banner_item.xml"
    end

    updateAllViewList()
    Rapid:Log(TAG, " end fillValue ")
end

function updateAllViewList()
    Rapid:Log(TAG, " updateAllViewList viewList : " .. #mViewList .. ' dataList : ' .. #mDataList)
    mRecyclerView:clear()
    if (tonumber(#mViewList) > 0 and tonumber(#mDataList) > 0) then
        mRecyclerView:updateData(mViewList, mDataList)
        -- 一张图片时不自动播放不可滑动
        if (tonumber(#mViewList) == 1) then
            Rapid:getChild('banner'):setAttr('autoplay', '-1')
            Rapid:getChild('banner'):setAttr('cantouchscroll', false)
            Rapid:getChild('indicate_view'):setAttr('visibility', 'gone')

        end
    else
        Rapid:getChild('card_view_root'):setAttr('visibility', 'gone')
    end

end

function isEmpty(str)
    if (str == nil or str == '') then
        return true
    else
        return false
    end
end