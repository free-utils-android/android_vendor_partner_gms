local mPhotonView,mJavaBridge = ...

function check_tag_visible()
	local screenWidth = mPhotonView:getParser():getScreenWidth()
	local btnWidth = {}
	local containerPadding = mJavaBridge:dip2px(12.3)
	local tagLeftMargin = mJavaBridge:dip2px(9)
	local tagWidthPadding =  mJavaBridge:dip2px(19)
	local leftCount = containerPadding
	local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
	for i = 0,6 do
		local btn = mPhotonView:getParser():getChildView("tag" .. i )
		local text = mPhotonView:getParser():getBinder():get("tagname_" .. i )
		if( text ~= nil and btn ~= nil ) then
			local paint = btn:getView():getPaint(); 
			btnWidth[i] = paint:measureText(text) + tagWidthPadding
			if( leftCount + btnWidth[i] >= screenWidth - containerPadding)then
				btn:getParser():update("visibility","gone")
			else
				btn:getParser():update("visibility","visible")
				local params = {}
				params["param"]= "scene:2008,slotid:25_00".. i+1 ..",actionid:100"
				actionRunner:run("reportaction", params, nil)
				leftCount = leftCount + btnWidth[i] + tagLeftMargin
			end
		end
	end
end
