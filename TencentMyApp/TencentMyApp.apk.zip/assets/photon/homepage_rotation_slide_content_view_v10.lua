local mPhotonView, mJavaBridge = ...

local mRecyclerView = nil

local _scene = nil
local _sourcescene = nil
local _modeltype = nil
local _sourceslotid = nil
local _slotid = nil
local itemCount = nil

function init()
    mRecyclerView = mPhotonView:getParser():getChildView('rv_list')
end

function fillValue()
    local stateListener =
        luajava.createProxy(
        'com.tencent.rapidview.deobfuscated.control.IRapidRecyclerView$IScrollStateChangedListener',
        RecyclerScrollStateChangedListener
    )
    mRecyclerView:getView():setScrollStateChangedListener(stateListener)

    _scene = mPhotonView:getParser():getBinder():get('scene')
    _sourcescene = mPhotonView:getParser():getBinder():get('sourcescene')
    _modeltype = mPhotonView:getParser():getBinder():get('modeltype')
    _sourceslotid = mPhotonView:getParser():getBinder():get('sourcesceneslotid')
    _slotid = mPhotonView:getParser():getBinder():get('slotid')
    itemCount = tonumber(Rapid:getData('item_num', '0'))

    local dataList = {}
    local viewNameList = {}
    local subViewName = 'homepage_rotation_slide_content_view_item_v10.xml'

    local index = 0
    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get('item_data_' .. i)
        index = index + 1
        putBaseReportText(itemData)
        itemData:put('subPosition', mJavaBridge:create('Var', tostring(i)))
        itemData:put(
            'app_slotId',
            mJavaBridge:create('Var', tostring(Rapid:getData('slotId')) .. '_-1_' .. tostring(i))
        )

        itemData:put('is_first_visible', mJavaBridge:create('var', 'false'))

        dataList[i] = itemData
        viewNameList[i] = subViewName
    end
    mRecyclerView:getView():updateData(viewNameList, dataList, true)

    mJavaBridge:delayRun(150, changeFirstItemAnim)
end

function changeFirstItemAnim()
    changeItemAnim(false)
end

function putBaseReportText(itemData)
    if itemData == nil then
        return
    end

    if _scene ~= nil then
        local var_scene = mJavaBridge:create('Var', _scene)
        itemData:put('scene', var_scene)
    end

    if _sourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create('Var', _sourcescene)
        itemData:put('sourcescene', var_sourcescene)
        itemData:put('sourceScene', var_sourcescene)
    end

    if _modeltype ~= nil then
        local var_modeltype = mJavaBridge:create('Var', _modeltype)
        itemData:put('modeltype', var_modeltype)
        itemData:put('modelType', var_modeltype)
    end

    if _sourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create('Var', _sourceslotid)
        itemData:put('sourcesceneslotid', var_sourceslotid)
        itemData:put('sourceSceneSlotId', var_sourceslotid)
    end

    if _slotid ~= nil then
        local var_slotid = mJavaBridge:create('Var', _slotid)
        itemData:put('slotid', var_slotid)
        itemData:put('slotId', var_slotid)
    end
end

RecyclerScrollStateChangedListener = {}
function RecyclerScrollStateChangedListener.onScrollStateChanged(recyclerview, state)
    changeItemAnim(false)
end

function onResume()
    changeItemAnim(false)
end

function onPause()
    changeItemAnim(true)
end

function changeItemAnim(allStop)
    if mRecyclerView == nil or mRecyclerView:getView() == nil then
        return
    end
    local manager = mRecyclerView:getView():getLayoutManager()
    if manager == nil then
        return
    end
    local firstPos = manager:findFirstVisibleItemPosition()
    local firstComPos = manager:findFirstCompletelyVisibleItemPosition()
    local lastPos = manager:findLastVisibleItemPosition()
    for i = firstPos, lastPos do
        local currentView = manager:findViewByPosition(i)
        if currentView ~= nil then
            local tag = currentView:getTag()
            if tag ~= nil then
                local parser = tag:getParser()
                if parser ~= nil then
                    local binder = parser:getBinder()
                    if binder ~= nil then
                        if allStop then
                            binder:update('is_first_visible', 'false')
                        else
                            binder:update('is_first_visible', tostring(i == firstComPos))
                        end
                    end
                end
            end
        end
    end
end
