local mPhotonView,mJavaBridge = ...


local _scene = nil
local _sourcescene = nil
local _modeltype = nil
local _sourceslotid = nil
local _slotid = nil


local mAppDataList
local mAppViewNameList
local mRecyclerView


function main()
    mRecyclerView = Rapid:getChild('rv_app'):getView()
end

function updateData()
    _scene = mPhotonView:getParser():getBinder():get("scene")
    _sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
    _modeltype = mPhotonView:getParser():getBinder():get("modeltype")
    _sourceslotid = mPhotonView:getParser():getBinder():get("sourcesceneslotid")
    local position = tonumber(Rapid:getData('position', '0')) + 1
    _slotid = '11_00' .. tostring(position)
    Rapid:setData('slotid', _slotid)
    Rapid:setData('slotId', _slotid)
    
    updateAppList()
end

-- 更新列表
function updateAppList()
    mAppDataList = {}
    mAppViewNameList = {}

    local itemCount = tonumber(Rapid:getData('item_num','0'))

    for i = 1, itemCount do
        local itemData = mPhotonView:getParser():getBinder():get("item_data_" .. i)
        fillData(itemData, i)
    end
    
    mRecyclerView:updateData(mAppViewNameList, mAppDataList, true)
end

-- 填充数据
function fillData(itemData, index)
    if itemData == nil then
        return
    end

    putBaseReportText(itemData)
    itemData:put("subPosition",mJavaBridge:create("Var", index))

    if index == 1 then
        itemData:put("marginLeft",mJavaBridge:create("Var", '8'))
    else
        itemData:put("marginLeft",mJavaBridge:create("Var", '0'))
    end

    mAppDataList[index] = itemData
    mAppViewNameList[index] = 'search_common_horizontal_slide_card_item.xml'
    
end

-- 存入基础上报字段
function putBaseReportText(itemData)
    if _scene ~= nil then
        local var_scene = mJavaBridge:create("Var", _scene)
        itemData:put("scene",var_scene)
    end
    
    if _sourcescene ~= nil then
        local var_sourcescene = mJavaBridge:create("Var", _sourcescene)
        itemData:put("sourcescene",var_sourcescene)
        itemData:put("sourceScene",var_sourcescene)
    end
    
    if _modeltype ~= nil then
        local var_modeltype = mJavaBridge:create("Var", _modeltype)
        itemData:put("modeltype",var_modeltype)
        itemData:put("modelType",var_modeltype)
    end
    
    if _sourceslotid ~= nil then
        local var_sourceslotid = mJavaBridge:create("Var", _sourceslotid)
        itemData:put("sourcesceneslotid",var_sourceslotid)
        itemData:put("sourceSceneSlotId",var_sourceslotid)
    end
    
    if _slotid ~= nil then
        local var_slotid = mJavaBridge:create("Var", _slotid)
        itemData:put("slotid",var_slotid)
        itemData:put("slotId",var_slotid)
    end
end