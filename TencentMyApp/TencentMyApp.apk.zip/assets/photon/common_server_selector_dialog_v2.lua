local mPhotonView,mJavaBridge = ...

local mNeedRole = true
local mNeedServer = true

local mSelectorItems = nil
local mSelectorIds = nil
local mSelectedIndex = nil
local mSelectedServerId = nil
local mSelectedServerName = nil


local mSelectorRoleItems = nil
local mSelectorRoleIds = nil
local mSelectorRoleNames = nil
local mSelectedRoleIndex = nil
local mSelectedRoleId = nil
local mSelectedRoleName = nil

local mServersRecyclerView = nil
local mRolesRecyclerView = nil

local mIsRequesting = false

local mGiftType = nil
local mThemeColor = nil
local mPkgName = nil
local GET_ROLE_TYPE = 7


function init()
    
    mNeedRole = Rapid:getData("need_role")
    mNeedServer = Rapid:getData("need_server")
    mThemeColor = Rapid:getData("theme_color")
    mGiftType = Rapid:getData("gift_type")
    mPkgName = Rapid:getData("pkg_name")
    mServersRecyclerView = Rapid:getChild("server_selector_list"):getView()
    mRolesRecyclerView = Rapid:getChild("role_selector_list"):getView()

    -- 如果需要选角色再展示角色选择
    if mNeedRole then
        Rapid:getChild("rl_role_selector"):setAttr("visibility","visible")
    end

    if mNeedServer then
        Rapid:getChild("rl_server_selector"):setAttr("visibility","visible")
    end

    if (not mNeedServer) and (not mNeedRole)then
        return
    end
    init_server_list()

end

function init_server_list()
     -- 初始化服务器列表
     local serverList = Rapid:getData("servers","")
     local defaultServer = Rapid:getData("default_server","")
     local defaultRole = Rapid:getData("default_role","")
     local appName = Rapid:getData("app_name","")

     -- 清空旧数据
     mServersRecyclerView:clear()

     local defaultServerJson = mJavaBridge:create("jsonobject",tostring(defaultServer))
     local defaultRoleJson = mJavaBridge:create("jsonobject",tostring(defaultRole))

     local hasDefaultServer = false
     if defaultServerJson ~= nil then
        mSelectedServerId = defaultServerJson:optString("id","")
        mSelectedServerName = defaultServerJson:optString("name","")

        if mSelectedServerId ~= "" and mSelectedServerName ~= "" then
            Rapid:getChild("tv_server_selector"):setAttr("text",mSelectedServerName)
            refreshConfirmBtn()
            hasDefaultServer = true
        end
    end
  
    -- 区服有的前提下，再解析默认角色
    if defaultRoleJson ~= nil and hasDefaultServer then
        mSelectedRoleId = defaultRoleJson:optString("id","")
        mSelectedRoleName = defaultRoleJson:optString("name","")
        if mSelectedRoleId ~= "" and mSelectedRoleName ~= "" then
            Rapid:getChild("tv_role_selector"):setAttr("text",mSelectedRoleName)
            refreshConfirmBtn()
        end
     end
 
     if serverList == "" then
         -- the user have no account in any server, show tips dialog
         local tipsText = "您可能还没有注册" .. appName .. "账户，请先注册账户"
         Rapid:getChild("tv_tips"):setAttr("text",tipsText)
         Rapid:getChild("tips_dialog_container"):setAttr("visibility","visible")
         return
     end
 
     -- show the guide dialog for user to select a server
     Rapid:getChild("guide_dialog"):setAttr("visibility","visible")
 
     -- get server items

     refresh_server_list()
     refreshConfirmBtn()
end


function refresh_server_list()
    local serverList = Rapid:getData("servers","")
    mSelectorIds = {}
    local serverJsonArray = mJavaBridge:create("jsonarray",serverList)

    local viewList = {}
    local dataList = {}
    mServersRecyclerView:clear()
    for i=0,serverJsonArray:length() - 1 do
        local serverItem = serverJsonArray:optJSONObject(i)
        if serverItem == nil then
            break
        end
        
        local serverId = serverItem:optString("id")
        local serverName =  serverItem:optString("name")

        local params = {}
        params["item_id"] = serverId
        params["item_name"] = serverName
        --  params["item_name"] = tostring(serverName) .. tostring(serverId)

        params["is_selected"] = "false"
        params["index"] = i
        params["updater"] = ListSelectorUpdater:new(mServersRecyclerView,i,server_selected_callback)
        if mSelectedServerId == serverId then
             -- set default server selected
            params["is_selected"] = "true"
            mSelectedIndex = i
        end
        
        mSelectorIds[i] = serverId 

        table.insert(viewList, "common_server_selector_dialog_item_v2.xml")
        table.insert(dataList, params)
    end
    mServersRecyclerView:updateData(viewList, dataList,true)
end

ListSelectorUpdater = {
    _arg = argValue,
    _recyclerView = nil,
    _callback = nil
}
ListSelectorUpdater.__index = ListSelectorUpdater
function ListSelectorUpdater:new(recyclerView,index,selectedCallback)
    local o = {}
    setmetatable(o,self)
    self.__index = self
    o._recyclerView = recyclerView
    o._index = index
    o._callback = selectedCallback
    return o
end

function ListSelectorUpdater:selectItem(itemIndex,itemName)
    local count = self._recyclerView:getChildCount()
    for i=0,count do
        local childView = self._recyclerView:getChildAt(i)
        if childView ~= nil then
            childView = childView:getTag()
        end
        if childView ~= nil then
            childView:getParser():getBinder():update("is_selected","false")
        end
    end
    self._callback(itemIndex,itemName)
end

function splitString(strInput, sep)
    if sep == nil then
            sep = "%s"
    end
    local t = {} 
    local i = 1
    if strInput == nil or sep == nil then
        return ""
    end
    for str in string.gmatch(strInput, "([^"..sep.."]+)") do
            t[i] = str
            i = i + 1
    end
    return t
end


function server_selected_callback(index,serverName)
    clear_role_list()
    mSelectedServerId = mSelectorIds[index]
    mSelectedServerName = serverName
    Rapid:getChild("tv_server_selector"):setAttr("text",serverName)
    mJavaBridge:delayRun(200,hide_server_selector)
end


function role_selected_callback(index,roleName)
    mSelectedRoleId = mSelectorRoleIds[index]
    mSelectedRoleName = roleName
    Rapid:getChild("tv_role_selector"):setAttr("text",roleName)
    mJavaBridge:delayRun(200,hide_role_selector)
end

function hide_server_selector()
    Rapid:getChild("select_dialog_container"):setAttr("visibility","gone")
    refreshConfirmBtn()
end

function hide_role_selector()
    Rapid:getChild("select_role_dialog_container"):setAttr("visibility","gone")
    refreshConfirmBtn()
end


function refreshConfirmBtn()
    local enable = true
    if mNeedRole and (mSelectedRoleId == nil or mSelectedRoleId== "" )then
        enable = false
    end

    if mNeedServer and (mSelectedServerId == nil or mSelectedServerId== "" ) then
        enable = false
    end

    local comfirmBtn = Rapid:getChild("right_btn")
    -- set the button clickable

    if enable then
        comfirmBtn:setAttr("clickable","true")
        comfirmBtn:setAttr("textcolor","ff1c81ff")
    else
        comfirmBtn:setAttr("clickable","false")
        comfirmBtn:setAttr("textcolor","591c81ff")
    end
end

function confirm_select()
    local dialogSelf = Rapid:getData("self")
    dialogSelf:putEventData("selecetd_server_name",mSelectedServerName)
    dialogSelf:putEventData("selecetd_server_id",mSelectedServerId)
    dialogSelf:putEventData("selecetd_role_name",mSelectedRoleName)
    dialogSelf:putEventData("selecetd_role_id",mSelectedRoleId)
    dialogSelf:notifyEvent("ON_SERVER_ROLE_SELECTED")
    if dialogSelf == nil then
        return
    end
    close_dialog()
    
end

function close_dialog()
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:dismiss()
    end
end

function show_server_list()
    refresh_server_list()
    Rapid:getChild('select_dialog_container'):setAttr("visibility","visible")
end

function show_role_list()
    -- 需要选区服但是没有选的情况
    if mSelectedServerId == nil and mNeedServer then
        Rapid:runTask("select_server_tips")
        return
    end
    mRolesRecyclerView:clear()
    get_role_list(mSelectedServerId)
end


function get_role_list(serverId)
    if mIsRequesting then
        return
    end
    mIsRequesting = true
    local params = {}
    params["pkgName"] = mPkgName
    params["partitionId"] = serverId
	mJavaBridge:request(2199, params, onRequestRoleListListener)
end

function clear_role_list()
    Rapid:getChild("tv_role_selector"):setAttr("text","选择角色")
    mSelectedRoleId = nil
    mSelectedRoleIndex = nil
    mRolesRecyclerView:clear()
    refreshConfirmBtn()
end


function onRequestRoleListListener(succeed, viewNameList, dataList)
    mIsRequesting = false
    if not succeed then
        apid:runTask("get_role_failed")
        return
    end
    local parserSucc = parserRoleData(dataList)
    if not parserSucc then
        Rapid:runTask("get_role_failed")
    end
end

function parserRoleData(dataList)
    if dataList == nil or dataList:size() < 1 then
        return false
    end
    local roleList = dataList:get(0):get("roleList")
    local roleJsonArray = mJavaBridge:create("jsonarray",tostring(roleList))

    if roleJsonArray == nil then
        return false
    end

    local roleItems = {}
    for i=0,roleJsonArray:length() - 1 do
        local roleItem = roleJsonArray:optJSONObject(i)
        if roleItem == nil then
            break
        end
        
        local roleId = roleItem:optString("id")
        local roleName =  roleItem:optString("name")
        roleItems[roleId] = roleName
    end
    
    local selectIndex = 0
    mSelectorRoleItems = {}
    mSelectorRoleIds = {}
    mSelectorRoleNames = {}
    for k,v in pairs(roleItems) do
        mSelectorRoleIds[selectIndex] = k
        mSelectorRoleNames[selectIndex] = v
        local params = {}
        params["item_id"] = k
        params["item_name"] = v
        params["is_selected"] = "false"
        params["index"] = selectIndex
        params["updater"] = ListSelectorUpdater:new(mRolesRecyclerView,i,role_selected_callback)
        if mSelectedRoleId == k then
            params["is_selected"] = "true"
            mSelectedRoleIndex = selectIndex
        end
        mRolesRecyclerView:updateData("common_server_selector_dialog_item.xml", params,false)
        selectIndex = selectIndex + 1
    end
    Rapid:getChild("select_role_dialog_container"):setAttr("visibility","visible")
    
    return true
end

