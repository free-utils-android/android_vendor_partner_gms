local mPhotonView,mJavaBridge = ...

local mAppRecyclerView = nil

local tag = "lua_cloud_game_recent_play_card"

function main()
    mAppRecyclerView = mPhotonView:getParser():getChildView('rv_app')
    mAppRecyclerView:getView():setClipToPadding(false)
    mAppRecyclerView:getView():setClipChildren(false)
    mJavaBridge:Log(tag, "updateAppList")
end

function updateAppList()
    local dataList = {}
    local viewNameList = {}
    local subViewName = 'cloud_game_recent_play_card_app_item.xml'
    
    local itemCount = tonumber(Rapid:getData('game_count', '0'))
    local moreJumpUrl = tostring(Rapid:getData('more_jump_url', ''))
    if moreJumpUrl ~= '' then
        -- 增加一个尾部的查看更多item
        itemCount = itemCount + 1
    end
    mJavaBridge:Log(tag, "itemCount : "..itemCount)
    mJavaBridge:Log(tag, "title : "..Rapid:getData('title', ''))
    for i = 1, itemCount do
        local itemData = nil
        if i == itemCount and moreJumpUrl ~= '' then
            -- 最后一个item数据需要主动创建
            itemData = luajava.newInstance("java.util.HashMap")
            subViewName = 'cloud_game_recent_play_card_more_item.xml'
            itemData:put('more_jump_url', mJavaBridge:create("Var", Rapid:getData('more_jump_url', '')))
            itemData:put('card_report_context', mJavaBridge:create("Var", Rapid:getData('card_report_context', '')))
            itemData:put('card_commendid', mJavaBridge:create("Var", Rapid:getData('card_recommendid')))
            local slotid = tostring(Rapid:getData('slotid', '')) .. '_00_-1'
            itemData:put('more_slotid', mJavaBridge:create("Var", slotid))
        else
            itemData = Rapid:getData("item_data_" .. i)
            subViewName = 'cloud_game_recent_play_card_app_item.xml'
        end
        if (itemData ~= nil) then
            itemData:put('scene', mJavaBridge:create("Var", Rapid:getData('scene', '')))
            itemData:put('modeltype', mJavaBridge:create("Var", Rapid:getData('modeltype', '')))
            itemData:put('slotid', mJavaBridge:create("Var", Rapid:getData('slotid', '')))
            itemData:put('sourcescene', mJavaBridge:create("Var", Rapid:getData('sourcescene', '')))
            itemData:put('sourcesceneslotid', mJavaBridge:create("Var", Rapid:getData('sourcesceneslotid', '')))
            itemData:put('sourcemodeltype', mJavaBridge:create("Var", Rapid:getData('sourcemodeltype', '')))
            itemData:put('subposition', mJavaBridge:create("Var", i))
            dataList[i] = itemData
            viewNameList[i] = subViewName
        end
    end
    mJavaBridge:Log(tag, "updateAppList end")
    mAppRecyclerView:getView():removeAllViews()
    mAppRecyclerView:getView():updateData(viewNameList, dataList, true)
    mAppRecyclerView:getView():scrollToPosition(0)
end