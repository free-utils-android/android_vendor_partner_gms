require("playing_welfare_config_utils")
WelfareStyleCfg = {}

COLOR_D9000000 = "d9000000"
COLOR_FFFFFF = "ffffff"
COLOR_73452200 = "73452200"
COLOR_452200 = "452200"
COLOR_73000000 = "73000000"
COLOR_26FFC82E = "26ffc82e"
COLOR_F5F6F9 = "f5f6f9"
COLOR_E6E8F0 = "E6E8F0"
COLOR_A6000000 = "a6000000"

SIZE_328 = "328"
SIZE_112 = "112"
SIZE_31 = "31"
SIZE_16 = "16"
SIZE_14 = "14"
SIZE_12 = "12"
SIZE_MATCH_PARENT = "match_parent"
SIZE_WRAP_CONTENT = "wrap_content"

FONT_STYLE_BOLD = "bold"

GRAVITY_CENTER = "center"
GRAVITY_LEFT = "left"

function WelfareStyleCfg.applyStyle(styleTable)
    for k, v in pairs(styleTable) do
        Rapid:setData(k, v)
    end
end

function WelfareStyleCfg.mergeToTable(welfareData, styleData)
    for k, v in pairs(styleData) do
        welfareData[k] = v
    end
    return welfareData
end


function WelfareStyleCfg.gameGiftBlockFullScreen(welfareData, javaBridge)
    local screenWidth = javaBridge:getScreenWidth()
    local totalMargin = 2 * 16
    welfareData["gameGiftBgGradientWidth"] = tostring(javaBridge:px2dip(screenWidth) - totalMargin)
    welfareData["gameGiftDetailBgWidth"] = tostring(SIZE_MATCH_PARENT)
    welfareData["gameGiftSumTxtWidth"] = tostring(SIZE_MATCH_PARENT)
    welfareData["gameGiftSumGravity"] = tostring(GRAVITY_CENTER)
    return welfareData
end

function WelfareStyleCfg.gameCouponBlockFullScreen(welfareData, javaBridge)
    local screenWidth = javaBridge:getScreenWidth()
    local totalMargin = 2 * 16
    welfareData["gameCouponBgGradientWidth"] = tostring(javaBridge:px2dip(screenWidth) - totalMargin)
    welfareData["gameCouponDetailWidth"] = tostring(SIZE_MATCH_PARENT)
    welfareData["gameCouponSumTxtWidth"] = tostring(SIZE_MATCH_PARENT)
    welfareData["gameCouponSumGravity"] = tostring(GRAVITY_CENTER)
    return welfareData
end

function WelfareStyleCfg.welfareTitleStyle()
    local titleStyle = {}
    if ConfigUtils.useV3Style() then
        titleStyle["welfareTitleColor"] = tostring(COLOR_D9000000)
        titleStyle["welfareTitleStyle"] = tostring(FONT_STYLE_BOLD)
        titleStyle["welfareTitleFontSize"] = tostring(SIZE_16)
        titleStyle["useV3Style"] = "true"
    else
        titleStyle["welfareTitleColor"]= tostring(COLOR_D9000000)
        titleStyle["welfareTitleStyle"]= tostring(FONT_STYLE_BOLD)
        titleStyle["welfareTitleFontSize"]= tostring(SIZE_14)
        titleStyle["useV3Style"] = "false"
    end
    return titleStyle
end

function WelfareStyleCfg.welfareBtnStyle()
    local btnStyle = {}
    if ConfigUtils.useV3Style() then
        btnStyle["getWelfareBtnTxtColor"] = tostring(COLOR_FFFFFF)
        btnStyle["getWelfareBtnTxtStyle"] = tostring(FONT_STYLE_BOLD)
        btnStyle["getWelfareBtnTxtFontSize"] = tostring(SIZE_12)
        btnStyle["getWelfareBgGradient"] = "startcolor:F79800,endcolor:FFC82E,cornerradius:18,angle:0"
    else
        btnStyle["getWelfareBtnTxtColor"] = tostring(COLOR_FFFFFF)
        btnStyle["getWelfareBtnTxtStyle"] = tostring(FONT_STYLE_BOLD)
        btnStyle["getWelfareBtnTxtFontSize"] = tostring(SIZE_12)
        btnStyle["getWelfareBgGradient"] = "startcolor:0080FF,endcolor:0080FF,cornerradius:12,angle:0"
    end
    return btnStyle
end

function WelfareStyleCfg.gameCouponBgStyle()
    local couponStyle = {}
    if ConfigUtils.useV3Style() then
        couponStyle["gameCouponTitleColor"] = tostring(COLOR_452200)
        couponStyle["gameCouponTitleStyle"] = tostring(FONT_STYLE_BOLD)
        couponStyle["gameCouponTitleFontSize"]= tostring(SIZE_14)
        couponStyle["gameCouponBgGradient"]= "cornerradius:8,color:26ffc82e,shape:0"
        couponStyle["gameCouponBgGradientWidth"]= tostring(SIZE_WRAP_CONTENT)
        couponStyle["gameCouponDetailWidth"] = tostring(SIZE_WRAP_CONTENT)
        couponStyle["gameCouponBgGradientHeight"]= tostring(SIZE_112)
    else
        couponStyle["gameCouponTitleColor"]= tostring(COLOR_D9000000)
        couponStyle["gameCouponTitleStyle"]= tostring(FONT_STYLE_BOLD)
        couponStyle["gameCouponTitleFontSize"]= tostring(SIZE_14)
        couponStyle["gameCouponBgGradient"]= "cornerradius:8,color:f5f6f9,shape:0"
        couponStyle["gameCouponBgGradientWidth"]= tostring(SIZE_WRAP_CONTENT)
        couponStyle["gameCouponDetailWidth"] = tostring(SIZE_WRAP_CONTENT)
        couponStyle["gameCouponBgGradientHeight"]= tostring(SIZE_112)
    end
    return couponStyle
end

function WelfareStyleCfg.gameCouponSumStyle()
    local couponSumStyle = {}
    if ConfigUtils.useV3Style() then
        couponSumStyle["gameCouponSumTxtColor"]= tostring(COLOR_73452200)
        couponSumStyle["gameCouponSumTxtFontSize"]= tostring(SIZE_12)
        couponSumStyle["gameCouponSumTxtWidth"]= tostring(SIZE_31)
        couponSumStyle["gameCouponSumTxtHeight"]= tostring(SIZE_WRAP_CONTENT)
        couponSumStyle["gameCouponSumGravity"] = tostring(GRAVITY_LEFT)
    else
        couponSumStyle["gameCouponSumTxtColor"]= tostring(COLOR_73000000)
        couponSumStyle["gameCouponSumTxtFontSize"]= tostring(SIZE_12)
        couponSumStyle["gameCouponSumTxtWidth"]= tostring(SIZE_31)
        couponSumStyle["gameCouponSumTxtHeight"]= tostring(SIZE_WRAP_CONTENT)
        couponSumStyle["gameCouponSumGravity"] = tostring(GRAVITY_LEFT)
    end
    return couponSumStyle
end


function WelfareStyleCfg.gameGiftBgStyle()
    local gameGiftStyle = {}
    if ConfigUtils.useV3Style() then
        gameGiftStyle["gameGiftTitleColor"]= tostring(COLOR_452200)
        gameGiftStyle["gameGiftTitleStyle"]= tostring(FONT_STYLE_BOLD)
        gameGiftStyle["gameGiftTitleFontSize"]= tostring(SIZE_14)
        gameGiftStyle["gameGiftBgGradient"]= "cornerradius:8,color:26ffc82e,shape:0"
        gameGiftStyle["gameGiftBgGradientWidth"]= tostring(SIZE_WRAP_CONTENT)
        gameGiftStyle["gameGiftDetailBgWidth"] = tostring(SIZE_WRAP_CONTENT)
        gameGiftStyle["gameGiftBgGradientHeight"]= tostring(SIZE_112)
    else
        gameGiftStyle["gameGiftTitleColor"]= tostring(COLOR_D9000000)
        gameGiftStyle["gameGiftTitleStyle"]= tostring(FONT_STYLE_BOLD)
        gameGiftStyle["gameGiftTitleFontSize"]= tostring(SIZE_14)
        gameGiftStyle["gameGiftBgGradient"]= "cornerradius:8,color:f5f6f9,shape:0"
        gameGiftStyle["gameGiftBgGradientWidth"]= tostring(SIZE_WRAP_CONTENT)
        gameGiftStyle["gameGiftDetailBgWidth"] = tostring(SIZE_WRAP_CONTENT)
        gameGiftStyle["gameGiftBgGradientHeight"]= tostring(SIZE_112)
    end
    return gameGiftStyle
end


function WelfareStyleCfg.gameGiftItemStyle()
    local gameGiftItemStyle = {}
    if ConfigUtils.useV3Style() then
        gameGiftItemStyle["gameGiftCardBg"]= tostring(COLOR_26FFC82E)
    else
        gameGiftItemStyle["gameGiftCardBg"]= tostring(COLOR_E6E8F0)
    end
    return gameGiftItemStyle
end


function WelfareStyleCfg.gameGiftSumStyle()
    local gameGiftSumStyle = {}
    if ConfigUtils.useV3Style() then
        gameGiftSumStyle["gameGiftSumTxtColor"]= tostring(COLOR_73452200)
        gameGiftSumStyle["gameGiftSumTxtFontSize"]= tostring(SIZE_12)
        gameGiftSumStyle["gameGiftSumTxtWidth"]= tostring(SIZE_31)
        gameGiftSumStyle["gameGiftSumTxtHeight"]= tostring(SIZE_WRAP_CONTENT)
        gameGiftSumStyle["gameGiftSumGravity"] = tostring(GRAVITY_LEFT)
    else
        gameGiftSumStyle["gameGiftSumTxtColor"]= tostring(COLOR_73000000)
        gameGiftSumStyle["gameGiftSumTxtFontSize"]= tostring(SIZE_12)
        gameGiftSumStyle["gameGiftSumTxtWidth"]= tostring(SIZE_31)
        gameGiftSumStyle["gameGiftSumTxtHeight"]= tostring(SIZE_WRAP_CONTENT)
        gameGiftSumStyle["gameGiftSumGravity"] = tostring(GRAVITY_LEFT)
    end
    return gameGiftSumStyle
end


function WelfareStyleCfg.weekSignGiftBgStyle()
    local weekSignGiftBgStyle = {}
    if ConfigUtils.useV3Style() then
        weekSignGiftBgStyle["weekSignGiftTitleColor"]= tostring(COLOR_452200)
        weekSignGiftBgStyle["weekSignGiftTitleStyle"]= tostring(FONT_STYLE_BOLD)
        weekSignGiftBgStyle["weekSignGiftTitleFontSize"]= tostring(SIZE_14)
        weekSignGiftBgStyle["weekSignGiftSubTitleColor"]= tostring(COLOR_73452200)
        weekSignGiftBgStyle["weekSignGiftSubTitleFontSize"]= tostring(SIZE_12)
        weekSignGiftBgStyle["weekSignGiftBgGradient"]= "cornerradius:8,color:26ffc82e,shape:0"
    else
        weekSignGiftBgStyle["weekSignGiftTitleColor"]= tostring(COLOR_D9000000)
        weekSignGiftBgStyle["weekSignGiftTitleStyle"]= tostring(FONT_STYLE_BOLD)
        weekSignGiftBgStyle["weekSignGiftTitleFontSize"]= tostring(SIZE_14)
        weekSignGiftBgStyle["weekSignGiftSubTitleColor"]= tostring(COLOR_A6000000)
        weekSignGiftBgStyle["weekSignGiftSubTitleFontSize"]= tostring(SIZE_12)
        weekSignGiftBgStyle["weekSignGiftBgGradient"]= "cornerradius:8,color:f5f6f9,shape:0"
    end
    return weekSignGiftBgStyle
end


function WelfareStyleCfg.weekSignGiftSumStyle()
    local weekSignGiftSumStyle = {}
    if ConfigUtils.useV3Style() then
        weekSignGiftSumStyle["weekSignGiftSumTxtColor"]= tostring(COLOR_73452200)
        weekSignGiftSumStyle["weekSignGiftSumTxtFontSize"]= tostring(SIZE_12)
    else
        weekSignGiftSumStyle["weekSignGiftSumTxtColor"]= tostring(COLOR_73000000)
        weekSignGiftSumStyle["weekSignGiftSumTxtFontSize"]= tostring(SIZE_12)
    end
    return weekSignGiftSumStyle
end


function WelfareStyleCfg.weekSignGiftItemStyle()
    local weekSignGiftItemStyle = {}
    if ConfigUtils.useV3Style() then
        weekSignGiftItemStyle["weekSignGiftCardBg"]= tostring(COLOR_26FFC82E)
    else
        weekSignGiftItemStyle["weekSignGiftCardBg"]= tostring(COLOR_E6E8F0)
    end
    return weekSignGiftItemStyle
end


function WelfareStyleCfg.moreWelfareViewStyle()
    local moreWelfareViewStyle = {}
    if ConfigUtils.useV3Style() then
        moreWelfareViewStyle["moreWelfareBg"] = tostring(COLOR_26FFC82E)
        moreWelfareViewStyle["moreWelfareTextStyle"] = tostring(FONT_STYLE_BOLD)
        moreWelfareViewStyle["moreWelfareTextColor"] = tostring(COLOR_452200)
        moreWelfareViewStyle["moreWelfareTextFontSize"] = tostring(SIZE_14)
    else
        moreWelfareViewStyle["moreWelfareBg"] = tostring(COLOR_F5F6F9)
        moreWelfareViewStyle["moreWelfareTextStyle"] = tostring(FONT_STYLE_BOLD)
        moreWelfareViewStyle["moreWelfareTextColor"] = tostring(COLOR_D9000000)
        moreWelfareViewStyle["moreWelfareTextFontSize"] = tostring(SIZE_14)
    end
    return moreWelfareViewStyle
end

return WelfareStyleCfg
