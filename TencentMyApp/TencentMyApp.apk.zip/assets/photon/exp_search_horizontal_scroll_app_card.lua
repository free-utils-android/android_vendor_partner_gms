local mPhotonView, mJavaBridge = ...

local TAG = "lua_exp_search_horizontal_scroll_app_card"

local mRecyclerView

-- 检查是否有nil
local function checkNil(...)
    local args = {...}
    for i = 1, select("#", ...) do
        if args[i] == nil then
            return true
        end
    end
    return false
end

local function getPositionString(position)
    return string.format("%03d", position)
end

local function queryData(start, params, fine)
    local data = {}
    if type(params) ~= 'table' then
        return data
    end
    if start == nil then
        start = ''
    end
    if fine == nil then
        fine = ''
    end
    for k, v in pairs(params) do
        data[k] = Rapid:getData(start..k..fine, v)
    end
    return data
end

local function queryItemData(start, params)
    local data = {}
    if type(params) ~= 'table' then
        return data
    end
    if start == nil then
        start = ''
    end
    local itemData = Rapid:getData(start)
    if type(itemData) ~= 'userdata' then
        return data
    end
    for k, v in pairs(params) do
        data[k] = itemData:get(k)
        if data[k] == nil then
            data[k] = v
        end
    end
    return data
end

-- 填充数据
local function fillData(data, params, keys)
    if type(data) ~= 'table' or type(params) ~= 'table' then
        return
    end
    if keys == nil then
        for k, v in pairs(params) do
            data[k] = v
        end
    elseif type(keys) == 'table' then
        for i, key in pairs(keys) do
            if type(key) == 'string' then
                data[key] = params[key]
            end
        end
    end
end

local function onData(data)
    local position = Rapid:getData('position', 0)
    local subscene = Rapid:getData('subscene', 0)
    data['slotid'] = tostring(subscene)..'_'..getPositionString(position + 1)
    Rapid:setData('slotid', data['slotid'])
end

local function onItemData(data, itemCount, index, itemData)
    itemData['subposition'] = getPositionString(index)
    if index == 1 then
        itemData['marginleft'] = 16
    else
        itemData['marginleft'] = 8
    end
    if index == itemCount then
        itemData['marginright'] = 16
    else
        itemData['marginright'] = 0
    end
    fillData(itemData, data, {
        'modeltype',
        'scene',
        'slotid',
        'sourcescene',
        'sourcesceneslotid',
        'sourcemodeltype',
        'searchId',
        'searchScene',
        'queryWord',
        'sourceQuery',
        'searchsession',
    })
end

-- 填充视图和数据
local function fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    if checkNil(viewNameList, dataList, params, queries, itemQueries) then
        return
    end
    if checkNil(params['view_name'], params['item_count_name']) then
        return
    end

    fillData(queries, {
        ['modeltype'] = '',
        ['scene'] = '',
        ['slotid'] = '',
        ['sourcescene'] = '',
        ['sourcesceneslotid'] = '',
        ['sourcemodeltype'] = '',
        [params['item_count_name']] = 0,
    })

    local data = queryData('', queries, '')
    onData(data)
    local itemCount = tonumber(data[params['item_count_name']])
    if itemCount == nil or itemCount <= 0 then
        return
    end

    local itemMax = tonumber(params['item_max'])
    if itemMax ~= nil and itemCount > itemMax then
        itemCount = itemMax
    end

    for i = 1, itemCount do
        table.insert(viewNameList, params['view_name'])
        local itemData = queryItemData('item_data_'..i, itemQueries)
        onItemData(data, itemCount, i, itemData)
        table.insert(dataList, itemData)
    end
end

local function insuranceData(key)
    if Rapid:getData(key) == nil then
        Rapid:setData(key, -1)
    end
end

-- 防止source相关的上报字段为空时,大同上报在oma下的问题
local function insuranceOmaSource()
    insuranceData('sourcemodeltype')
    insuranceData('sourcesceneslotid')
end

function loadFinish()
    mJavaBridge:Log(TAG, "loadFinish")
    mRecyclerView = Rapid:getChild('recycler_view')
end

function afterUpdateData()
    mJavaBridge:Log(TAG, "afterUpdateData")

    insuranceOmaSource()

    local viewNameList = {}
    local dataList = {}
    local params = {
        ['view_name'] = 'exp_search_horizontal_scroll_app_card_item.xml',
        ['item_count_name'] = 'item_num',
    }
    local queries = {
        [params['item_count_name']] = 0,
        ['searchId'] = '',
        ['searchScene'] = '',
        ['queryWord'] = '',
        ['sourceQuery'] = '',
        ['searchsession'] = '',
    }
    local itemQueries = {
        ['app_icon'] = '',
        ['jump_url'] = '',
        ['app_name'] = '',
        ['appid'] = '',
        ['app_model'] = '',
        ['app_context'] = '',
        ['app_recommendid'] = '',
        ['app_report_context'] = '',
    }
    fillViewOrDataList(viewNameList, dataList, params, queries, itemQueries)
    mRecyclerView:getView():updateData(viewNameList, dataList, true)
end