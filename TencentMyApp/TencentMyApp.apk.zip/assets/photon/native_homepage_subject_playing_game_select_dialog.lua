local mPhotonView,mJavaBridge = ...
local mMaxScrollY = -1
local mMaxVisibleItemIndex = 0
local LIST_HEIGHT =  0
local TITLE_HEIGHT = mJavaBridge:dip2px(40)
local ITEM_HEIGHT = mJavaBridge:dip2px(64)
local UNUSE_HEIGHT = 0
local mPlayGameCount = 0
local mRmdGameCount = 0

local mSelectedPkgName = ""

function init()
    local data = {}

	local scene = mPhotonView:getParser():getBinder():get("scene")
    local sourcescene = mPhotonView:getParser():getBinder():get("sourcescene")
    local sourceslotid = mPhotonView:getParser():getBinder():get("sourceslotid")
    local sourcemodeltype = mPhotonView:getParser():getBinder():get("sourcemodeltype")
    
    mSelectedPkgName = mPhotonView:getParser():getBinder():get("selectedPkgName")
	
	-- 获取在玩
	mPlayGameCount =  mPhotonView:getParser():getBinder():get("playingCount")
	if mPlayGameCount == nil then
        mPlayGameCount = 0
    else
        mPlayGameCount = tonumber(mPlayGameCount)
    end
    if mPlayGameCount == 0 then
        mPhotonView:getParser():getChildView("playing_game_title"):getParser():update("visibility","gone")
    else
        UNUSE_HEIGHT = UNUSE_HEIGHT + TITLE_HEIGHT
    end

	mRmdGameCount =  mPhotonView:getParser():getBinder():get("rmdGameCount")
	if mRmdGameCount == nil then
		mRmdGameCount = 0
    else
        mRmdGameCount = tonumber(mRmdGameCount)
    end

    if mRmdGameCount == 0 then
        mPhotonView:getParser():getChildView("rmd_game_title"):getParser():update("visibility","gone")
    else
        UNUSE_HEIGHT = UNUSE_HEIGHT + TITLE_HEIGHT
    end
    
    local actionListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IPhotonActionListener', PhotonActionListener)
    local scrollListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.IScrollView$IScrollViewListener',ScrollListener)

    mPhotonView:getParser():getChildView("scroll_container"):getView():setScrollListener(scrollListener)

	for i=0, mPlayGameCount - 1 do
        local itemData = {}
        local packageName = mPhotonView:getParser():getBinder():get("playingPkgName_" .. tostring(i))
        itemData["icon_url"] =      mPhotonView:getParser():getBinder():get("playingIconUrl_" .. tostring(i))
        itemData["package_name"] =  mPhotonView:getParser():getBinder():get("playingPkgName_" .. tostring(i))
        itemData["display_name"] =  mPhotonView:getParser():getBinder():get("playingDisplayName_" .. tostring(i))
        itemData["app_des"] =  mPhotonView:getParser():getBinder():get("playingGameDesc_" .. tostring(i))
        itemData["remark"] =  mPhotonView:getParser():getBinder():get("playingGameRemark_" .. tostring(i))
        itemData["report_index"] = 102 + i
        itemData["scene"] = scene
        itemData["sourcescene"] = sourcescene
        itemData["sourceslotid"] = sourceslotid
        itemData["sourcemodeltype"] = sourcemodeltype
        itemData["refresh_params"] = "pkgName:" .. itemData["package_name"] .. ",fromScene:0"
        

        local normalUrl = mPhotonView:getParser():getBinder():get("playingNormalUrl_" .. tostring(i))
		local selectUrl = mPhotonView:getParser():getBinder():get("playingSelectedUrl_" .. tostring(i))
		if( normalUrl ~= nil and selectUrl ~= nil ) then
			itemData["tab_icon_url"] = normalUrl .. "," .. selectUrl
        end
        
        if( packageName == mSelectedPkgName ) then
			itemData["select"] = "true"
        end

        if( i == 0 ) then
			itemData["has_divide_line"] = "invisible"
        end
        mJavaBridge:addView("native_homepage_subject_playing_game_select_item.xml", "playing_game_list", "", nil, itemData, actionListener)
    end

    for i=0, mRmdGameCount - 1 do
        local itemData = {}
        local packageName = mPhotonView:getParser():getBinder():get("rmdPkgName_" .. tostring(i))
        itemData["icon_url"] =      mPhotonView:getParser():getBinder():get("rmdIconUrl_" .. tostring(i))
        itemData["package_name"] =  mPhotonView:getParser():getBinder():get("rmdPkgName_" .. tostring(i))
        itemData["display_name"] =  mPhotonView:getParser():getBinder():get("rmdDisplayName_" .. tostring(i))
        itemData["app_des"] =  mPhotonView:getParser():getBinder():get("rmdGameDesc_" .. tostring(i))
        itemData["remark"] =  mPhotonView:getParser():getBinder():get("rmdGameRemark_" .. tostring(i))
        itemData["report_index"] = 200 + i
        itemData["scene"] = scene
        itemData["sourcescene"] = sourcescene
        itemData["sourceslotid"] = sourceslotid
        itemData["sourcemodeltype"] = sourcemodeltype
        itemData["refresh_params"] = "pkgName:" .. itemData["package_name"] .. ",fromScene:0"

        local normalUrl = mPhotonView:getParser():getBinder():get("rmdNormalUrl_" .. tostring(i))
		local selectUrl = mPhotonView:getParser():getBinder():get("rmdSelectedUrl_" .. tostring(i))
		if( normalUrl ~= nil and selectUrl ~= nil ) then
			itemData["tab_icon_url"] = normalUrl .. "," .. selectUrl
        end

        if( packageName == mSelectedPkgName ) then
			itemData["select"] = "true"
        end

        if( i == 0 ) then
			itemData["has_divide_line"] = "invisible"
        end
        mJavaBridge:addView("native_homepage_subject_playing_game_select_item.xml", "rmd_game_list", "", nil, itemData, actionListener)
    end

    mJavaBridge:postRun(measureHeightAndReport)
end

PhotonActionListener = {}
function PhotonActionListener.notify(key, value)
    if key == "close_dialog" then
        close_dialog()
    else
        mPhotonView:getParser():getListener():notify(key,value)
    end
end

function close_dialog()
    local dialogSelf = mPhotonView:getParser():getBinder():get("self")
    dialogSelf:dismiss()
end



ScrollListener = {}
function ScrollListener.onScrollChanged(l,t,oldl,oldt)

end
function ScrollListener.onOverScrolled(scrollX,scrollY,clampedX,clampedY)
    -- 向下滑时才进行曝光检测
    if scrollY > mMaxScrollY then
        mMaxScrollY = scrollY
        reportViewShow(mMaxScrollY)
    end
end

function measureHeightAndReport()
    LIST_HEIGHT = mPhotonView:getParser():getChildView("scroll_container"):getView():getHeight()
    reportViewShow(0)
end

function reportViewShow(maxScroll)
    -- 减去标题所占据的宽度，除以item单项高度向上取整，得出视野内出现过的item数目
    local index = math.ceil( ((maxScroll + LIST_HEIGHT) - UNUSE_HEIGHT) / ITEM_HEIGHT ) 
    if index <= mMaxVisibleItemIndex then
       return
    end
    -- 逐个曝光
    local lastShowIndex = mMaxVisibleItemIndex + 1
    for i = lastShowIndex, index do
        if i <= mPlayGameCount then
            -- 说明是在玩游戏曝光
            report(101 + i)
            mMaxVisibleItemIndex = i
        else 
            -- 说明是在
            if i <= mPlayGameCount + mRmdGameCount then
                report(199 + (i - mPlayGameCount ))
                mMaxVisibleItemIndex = i
            end
            -- 其他情况说明已超出最大游戏展示数目，不进行曝光
        end
    end
end


function report(subpos)
    reportParams = {}
    reportParams["param"] = "slotid:30_002,actionid:100,subposition:" .. subpos 
	mPhotonView:getParser():getTaskCenter():getActionRunner():run("reportaction", reportParams, nil)
end
