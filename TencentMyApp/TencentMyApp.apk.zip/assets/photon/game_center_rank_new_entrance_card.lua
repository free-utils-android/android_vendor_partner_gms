local mPhotonView, mJavaBridge = ...

local CARD_TYPE_RANK = '1'
local CARD_TYPE_NEW_GAME = '0'


local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil


local bannerRecyclerView
local mIndicateView
local pageChangeListener

local PageChangeListener = {}
function PageChangeListener.onPageChange(beforePageIndex, afterPageIndex)
    mIndicateView:setCurrentSelectedDotIndex(afterPageIndex)
end

function main()
    bannerRecyclerView = Rapid:getChild('banner'):getView()
    pageChangeListener = luajava.createProxy('com.tencent.rapidview.deobfuscated.control.IBannerPageChangeListener', 
            PageChangeListener)
    bannerRecyclerView:addPageChangeListener(pageChangeListener)
    mIndicateView = Rapid:getChild('indicate_view'):getView()
    local interval = mJavaBridge:dip2px(4)
    Rapid:getChild('indicate_view'):setAttr('indicateinterval', interval)
end

function handleCardSize()
    local screenWidth = mJavaBridge:px2dip(mPhotonView:getParser():getScreenWidth())
    local screenHeight = mJavaBridge:px2dip(mPhotonView:getParser():getScreenHeight())
    mJavaBridge:Log("qiwei","screenWidth===="..tostring(screenWidth))
    mJavaBridge:Log("qiwei","screenHeight===="..tostring(screenHeight))
    if screenWidth > screenHeight then
        -- 全屏后getScreenWidth接口可能会取反为屏幕高，所以对换一下
        screenWidth = screenHeight
    end

    -- 计算大屏幕下的榜单宽度
    local width = (screenWidth - 16 - 17 - 16) / 2
    mJavaBridge:Log("qiwei","大屏幕下的榜单宽度===="..tostring(width))
    -- 然后减去大屏幕下的左右间距20*2得到剩余的宽度
    local surplusWidth = width - 20 * 2
    mJavaBridge:Log("qiwei","剩余的宽度===="..tostring(surplusWidth))
    -- 判断剩下的位置是否放得下3个大icon+每个icon最小间距5dp
    if surplusWidth < (64 * 3 + 5 * 2) then
        -- 小屏幕
        width = (screenWidth - 16 - 12 - 16) / 2
        mJavaBridge:Log("qiwei","小屏幕，榜单卡宽度===="..tostring(width))
        Rapid:setData('banner_w', tostring(width))
        Rapid:setData('icon_w', tostring(40))
        Rapid:setData('marginRankDistance', tostring(12))
        Rapid:setData('titleMarginLeft', tostring(8))
        Rapid:setData('titleMarginTop', tostring(6))
        Rapid:setData('iconMarginTop', tostring(9))
        Rapid:setData('iconMarginBottom', tostring(10))

        Rapid:setData('appNameMarginLeft', tostring(12))
        Rapid:setData('appNameMarginTop', tostring(6))
        Rapid:setData('appNameMarginRight', tostring(8))
    else
        -- 大屏幕
        mJavaBridge:Log("qiwei","大屏幕，榜单卡宽度===="..tostring(width))
        Rapid:setData('banner_w', tostring(width))
        Rapid:setData('icon_w', tostring(64))
        Rapid:setData('marginRankDistance', tostring(17))
        Rapid:setData('titleMarginLeft', tostring(20))
        Rapid:setData('titleMarginTop', tostring(8))
        Rapid:setData('iconMarginTop', tostring(6))
        Rapid:setData('iconMarginBottom', tostring(14))

        Rapid:setData('appNameMarginLeft', tostring(16))
        Rapid:setData('appNameMarginTop', tostring(16))
        Rapid:setData('appNameMarginRight', tostring(20))
    end
end

function updateData()
    handleCardSize()
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    
    local dataList = {}
    local viewList = {}
    local bannerItemNum = 0
    local itemNum = tonumber(Rapid:getData('item_num', '0'))
    for i = 1, itemNum do
        local itemDataMap = Rapid:getData('item_data_' .. i)
        local type = tostring(itemDataMap:get('section_type'))
        if type == '1' then
            bannerItemNum = bannerItemNum + 1
            putValue(itemDataMap, "item_w", Rapid:getData('banner_w', ''))
            putValue(itemDataMap, "icon_w", Rapid:getData('icon_w', ''))
            putValue(itemDataMap, "titleMarginLeft", Rapid:getData('titleMarginLeft', ''))
            putValue(itemDataMap, "titleMarginTop", Rapid:getData('titleMarginTop', ''))
            putValue(itemDataMap, "iconMarginTop", Rapid:getData('iconMarginTop', ''))
            putValue(itemDataMap, "iconMarginBottom", Rapid:getData('iconMarginBottom', ''))

            putBaseReportValue(itemDataMap)
            handleAppData(itemDataMap)
            dataList[i] = itemDataMap
            viewList[i] = 'game_center_rank_new_entrance_card_item.xml'
        else
            handleNewGameData(itemDataMap)
        end
    end
    bannerRecyclerView:updateData(viewList, dataList, true)
    Rapid:setData('banner_item_num', bannerItemNum)
end

function handleAppData(itemDataMap)
    local appNum = 3 -- 这里固定轮询3个icon，不能使用后台返回的icon数量，否则有item复用的问题。
    for i = 1, appNum do
        local itemData = itemDataMap:get('block_' .. i)
        if itemData ~= nil then
            local map = itemData:getObject()
            local icon = map:get('app_icon_url')
            itemDataMap:put('app_icon_'..i, mJavaBridge:create("Var", icon))
        else
            itemDataMap:put('app_icon_'..i, mJavaBridge:create("Var", ''))
        end
    end
end

function handleNewGameData(itemDataMap)
    Rapid:setData('newgame_report_context', tostring(itemDataMap:get('report_context')))
    Rapid:setData('newgame_section_title', tostring(itemDataMap:get('section_title')))
    Rapid:setData('newgame_jump_url', tostring(itemDataMap:get('jump_url')))
    Rapid:setData('newgame_bg_color', tostring(itemDataMap:get('bg_color')))

    -- 这里和后台确认只取第1个数据，且只会下发1个数据
    local itemData = itemDataMap:get('block_1')
    if itemData ~= nil then
        local map = itemData:getObject()
        local icon = map:get('app_icon_url')
        local name = map:get('app_name')
        local text = map:get('time_text')
        Rapid:setData('newgame_app_icon', icon)
        Rapid:setData('newgame_app_name', name)
        if text ~= nil and tostring(text) ~= '' then
            Rapid:getChild('rl_newgame_text'):setAttr('gradientdrawable', 'color:1FFFFFFF,strokecolor:1FFFFFFF,cornerradius:2')
            Rapid:setData('newgame_app_text', text)
        else
            Rapid:getChild('rl_newgame_text'):setAttr('gradientdrawable', 'color:00000000,strokecolor:00000000,cornerradius:2')
            Rapid:setData('newgame_app_text', '')
        end
    end
end

function putBaseReportValue(itemData)
    putValue(itemData, "scene", mScene)
    
    putValue(itemData, "sourcescene", mSourcescene)
    putValue(itemData, "sourceScene", mSourcescene)
    
    putValue(itemData, "modeltype", mModeltype)
    putValue(itemData, "modelType", mModeltype)
    
    putValue(itemData, "sourcesceneslotid", mSourceslotid)
    putValue(itemData, "sourceSceneSlotId", mSourceslotid)
    
    putValue(itemData, "slotid", mSlotid)
    putValue(itemData, "slotId", mSlotid)
end

function putValue(map, key, value)
    if map == nil or key == nil then
        return
    end
    map:put(key, mJavaBridge:create("Var", value))
end