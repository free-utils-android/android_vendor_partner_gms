local mPhotonView, mJavaBridge = ...


local beforeVideoView
local afterVideoView

local beforeVideoStateChangeListener
IBeforePlayerStateChangeListener = {}
function IBeforePlayerStateChangeListener.onMute(videoview, mute)

end

-- 视频开始播放回调
function IBeforePlayerStateChangeListener.onPlayStart(videoView)

end

function IBeforePlayerStateChangeListener.onPlayContinue(videoView, currentPosition)
    
end

-- 视频播放进度回调
function IBeforePlayerStateChangeListener.onProgressUpdate(videoView, progress)

end

-- 视频暂停播放回调
function IBeforePlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    
end

-- 视频停止播放回调
function IBeforePlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    
end

-- 视频完成播放回调
function IBeforePlayerStateChangeListener.onPlayComplete(videoView)
    if videoView ~= nil then
        Rapid:getChild("video_view_before"):setAttr("visibility","gone")
        Rapid:getChild("video_view_after"):setAttr("visibility","visible")
        afterVideoView:startPlay(false)
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
end

-- 播放出错
function IBeforePlayerStateChangeListener.onError(videoView, errorCode)

end

function main()
    beforeVideoView = Rapid:getChild("video_view_before"):getView()
    beforeVideoStateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IBeforePlayerStateChangeListener)
    beforeVideoView:registerIPlayerStateChangeListener(beforeVideoStateChangeListener)

    afterVideoView = Rapid:getChild("video_view_after"):getView()
    afterVideoStateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IAfterPlayerStateChangeListener)
    afterVideoView:registerIPlayerStateChangeListener(afterVideoStateChangeListener)
end

function afterUpdateData()
    Rapid:getChild("video_view_before"):setAttr("visibility","visible")
    Rapid:getChild("video_view_after"):setAttr("visibility","gone")
    afterVideoView:stop(false)
    beforeVideoView:startPlay(false)
end


local afterVideoStateChangeListener
IAfterPlayerStateChangeListener = {}
function IAfterPlayerStateChangeListener.onMute(videoview, mute)

end

-- 视频开始播放回调
function IAfterPlayerStateChangeListener.onPlayStart(videoView)
    
end

function IAfterPlayerStateChangeListener.onPlayContinue(videoView, currentPosition)

end

-- 视频播放进度回调
function IAfterPlayerStateChangeListener.onProgressUpdate(videoView, progress)

end

-- 视频暂停播放回调
function IAfterPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)

end

-- 视频停止播放回调
function IAfterPlayerStateChangeListener.onPlayStop(videoView, currentPosition)

end

-- 视频完成播放回调
function IAfterPlayerStateChangeListener.onPlayComplete(videoView)

end

-- 播放出错
function IAfterPlayerStateChangeListener.onError(videoView, errorCode)

end