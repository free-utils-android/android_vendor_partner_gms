local mPhotonView,mJavaBridge = ...

local ViewUtils = nil
local textPaint = nil
local videoView = nil
local IPlayerStateChangeListener = {}
local stateChangeListener

function main()
    textPaint = mPhotonView:getParser():getChildView("textHelper"):getView():getPaint()

    ViewUtils = luajava.bindClass('com.tencent.assistant.utils.ViewUtils')
    local strokeWidth = ViewUtils:dip2px(1)
    Rapid:getChild('tv_app_tag'):setAttr('gradientdrawable', 'cornerradius:4,strokewidth:'.. strokeWidth ..',strokecolor:26ffffff')

    videoView = mPhotonView:getParser():getChildView("video_view")
    stateChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener", IPlayerStateChangeListener)
    videoView:getView():registerIPlayerStateChangeListener(stateChangeListener)
    initMute()
end

function updateData()
    -- 更新4种样式
    Rapid:getChild('tv_summary'):setAttr('visibility', 'gone')
    Rapid:getChild('rl_tag'):setAttr('visibility', 'gone')
    Rapid:getChild('iv_label_icon'):setAttr('visibility', 'gone')
    Rapid:getChild('tv_label'):setAttr('marginleft', '')
    Rapid:getChild('rl_app_info'):setAttr('margintop', '')

    local radius = ViewUtils:dip2px(16)
    local cornerradiusarray = radius .. '_0_' .. radius .. '_' .. radius
    local style = Rapid:getData('app_info_style', '')
    if style == '1' then
        Rapid:getChild('rl_tag'):setAttr('gradientdrawable', 'cornerradiusarray:' .. cornerradiusarray .. ',color:263680F7')
        Rapid:getChild('rl_tag'):setAttr('visibility', 'visible')
        Rapid:getChild('iv_label_icon'):setAttr('visibility', 'visible')
    elseif style == '2' then
        Rapid:getChild('tv_label'):setAttr('marginleft', '8')
        Rapid:getChild('rl_tag'):setAttr('visibility', 'visible')
        Rapid:getChild('rl_tag'):setAttr('gradientdrawable', 'cornerradius:' .. radius .. ',color:263680F7')
    elseif style == '3' then
        Rapid:getChild('tv_summary'):setAttr('visibility', 'visible')
    else
        Rapid:getChild('rl_app_info'):setAttr('margintop', '11')
    end

    local parentWidth = 162
    local tagText = tostring(Rapid:getData('app_tag', ''))
    if tagText ~= '' then
        -- 文字的宽度
        local textWidth = mJavaBridge:px2dip(textPaint:measureText(tagText))
        -- 标签视图的宽度，加上内间距和边框宽度
        local tagViewWidth = textWidth + 4 + 4 + 1 + 1
        -- 文案视图的最大宽度，额外减去视图间距8
        local maxTextViewWidth = parentWidth - tagViewWidth - 8
        Rapid:getChild('tv_app_name'):setAttr('maxwidth', maxTextViewWidth)
    else
        Rapid:getChild('tv_app_name'):setAttr('maxwidth', parentWidth)
    end

    -- 设置视频标签边框线
    local w = ViewUtils:dip2px(1)
    Rapid:getChild('tv_video_tag_1'):setAttr('gradientdrawable', 'cornerradius:6,color:161C2A,strokewidth:' .. w .. ',strokecolor:2BD6A9')
    Rapid:getChild('tv_video_tag_2'):setAttr('gradientdrawable', 'cornerradius:6,color:161C2A,strokewidth:' .. w .. ',strokecolor:2BD6A9')
    Rapid:getChild('tv_video_tag_3'):setAttr('gradientdrawable', 'cornerradius:6,color:161C2A,strokewidth:' .. w .. ',strokecolor:2BD6A9')
    Rapid:getChild('tv_video_tag_4'):setAttr('gradientdrawable', 'cornerradius:6,color:161C2A,strokewidth:' .. w .. ',strokecolor:2BD6A9')
end

function IPlayerStateChangeListener.onMute(videoview, mute)
    updateMuteImage(mute)
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart(videoView)
    Rapid:getChild("iv_mute"):setAttr("visibility","visible")
    initMute()
end

function IPlayerStateChangeListener.onPlayContinue(videoView, currentPosition)
    Rapid:getChild("iv_mute"):setAttr("visibility","visible")
    initMute()
end

-- 视频播放进度回调
function IPlayerStateChangeListener.onProgressUpdate(videoView, progress)
    Rapid:setData("videoCurProgress", tostring(progress))
end

-- 视频暂停播放回调
function IPlayerStateChangeListener.onPlayPause(videoView, currentPosition, reason)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
end

-- 视频停止播放回调
function IPlayerStateChangeListener.onPlayStop(videoView, currentPosition)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
end

-- 视频完成播放回调
function IPlayerStateChangeListener.onPlayComplete(videoView)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
    if videoView ~= nil then
        Rapid:setData("videoCurProgress", tostring(videoView:getTotalDuring()))
    end
end

-- 播放出错
function IPlayerStateChangeListener.onError(videoView, errorCode)
    Rapid:getChild("iv_mute"):setAttr("visibility","gone")
end

-- 设置静音
function setMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    if isMute then
        videoView:getView():setMuteToGlobal(false, true, true)
    else
        videoView:getView():setMuteToGlobal(true, true, true)
    end
    updateMuteImage(isMute)
end

-- 初始化静音按钮
function initMute()
    if videoView == nil then
        return
    end

    local isMute = videoView:getView():isMute()
    updateMuteImage(isMute)
end

-- 更新静音图标显示
function updateMuteImage(isMute)
    if isMute then
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762481_9f924c0d787d6bf8421d662693181e6a.png")
    else
        Rapid:setData("mute_image","https://cms.myapp.com/yyb/2020/07/22/1595422762485_7d06058de6be1eb7dd7d3ba3bc47ab61.png")
    end
end