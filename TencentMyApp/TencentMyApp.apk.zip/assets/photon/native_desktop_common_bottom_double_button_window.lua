local mPhotonView,mJavaBridge = ...
local isNegativeFeedbackSelected = 0

local MB_UNIT = 1024 * 1024

-- 弹窗类别，垃圾清理弹窗
local POP_TYPE_RUBBISH_CLEAN = '1'
-- 弹窗类别，权限引导弹窗
local POP_TYPE_PERMISSION_GUIDE = '7'

-- 场景条件类型
local CONDITION_ALL_RUBBISH = "\"type\":205"
local CONDITION_FAST_CLEAN_RUBBISH = "\"type\":207"

-- 对齐方式
local GRAVITY_TOP = '1'
local GRAVITY_BOTTOM = '4'

function init()
    mJavaBridge:Log("desktop_common_bottom_double_button_window, from online")
    local main_title = Rapid:getData('main_title', '')
    local sub_title = Rapid:getData('sub_title', '')
    local check_point = Rapid:getData('check_point')

    local uni_pop_type = Rapid:getData('uni_pop_type')
    if uni_pop_type == POP_TYPE_RUBBISH_CLEAN then
        -- 垃圾清理弹窗
        local rubbish_cache_size = getShowRubbishSize(check_point)
        Rapid:setData('rubbish_cache_size', rubbish_cache_size)
        Rapid:setData('uni_trash_size', getReportRubbishSize(check_point))
    end

    Rapid:getChild('tv_main_title'):setAttr('htmltext', resolveText(main_title))
    Rapid:getChild('tv_sub_title'):setAttr('htmltext', resolveText(sub_title))

    local main_title_icon_url = Rapid:getData('main_title_icon_url', '')
    if (main_title_icon_url == '') then
        Rapid:getChild('iv_main_title_icon'):setAttr('visibility', 'gone')
    else
        Rapid:getChild('iv_main_title_icon'):setAttr('visibility', 'visible')
    end

    local enable_negative_feedback = Rapid:getData('enable_negative_feedback', '1')
    local negative_text = Rapid:getData('negative_text', '')
    if enable_negative_feedback == '0' or negative_text == '' then
        Rapid:getChild('ll_negative_feedback'):setAttr('visibility', 'gone')
    else
        Rapid:getChild('ll_negative_feedback'):setAttr('visibility', 'visible')
    end

    local gravity_type = Rapid:getData('gravity_type','1')
    if gravity_type == GRAVITY_TOP then
        Rapid:getChild('container'):setAttr('alignparenttop', 'true')
        Rapid:getChild('container'):setAttr('alignparentbottom', 'false')
        Rapid:getChild('container'):setAttr('centerinparent', 'false')
    elseif gravity_type == GRAVITY_BOTTOM then
        Rapid:getChild('container'):setAttr('alignparenttop', 'false')
        Rapid:getChild('container'):setAttr('alignparentbottom', 'true')
        Rapid:getChild('container'):setAttr('centerinparent', 'false')
    else
        Rapid:getChild('container'):setAttr('alignparenttop', 'false')
        Rapid:getChild('container'):setAttr('alignparentbottom', 'false')
        Rapid:getChild('container'):setAttr('centerinparent', 'true')
    end

    -- 展示全屏
    local activity = Rapid:getChild('container'):getView():getContext()
    local lp = activity:getWindow():getAttributes()
    lp.width = -1
    lp.height = -2
    activity:getWindow():setAttributes(lp)
end

-- 根据场景条件判断显示哪种类型的垃圾：1. 全部垃圾； 2. 快速清理（已选中）的垃圾
function getShowRubbishSize(check_point)
    return formatSize(getRawRubbishSize(check_point))
end

-- 返回上报的垃圾数值格式，单位为MB
function getReportRubbishSize(check_point)
    return formatMBSize(getRawRubbishSize(check_point))
end

-- 根据场景条件返回特定的垃圾值，CONDITION_ALL_RUBBISH返回全部垃圾数量，CONDITION_FAST_CLEAN_RUBBISH返回快速清理垃圾数量
function getRawRubbishSize(check_point)
    local all_rubbish_condition = string.find(check_point, CONDITION_ALL_RUBBISH, 1)
    local fast_clean_rubbish_condition = string.find(check_point, CONDITION_FAST_CLEAN_RUBBISH, 1)
    if all_rubbish_condition ~= nil then
        return mJavaBridge:getRubbishCacheSize()
    elseif fast_clean_rubbish_condition ~= nil then
        return mJavaBridge:getRubbishSelectedCacheSize()
    else
        return mJavaBridge:getRubbishCacheSize()
    end
end


function formatSize(byteNum)
    local MemoryUtils = luajava.bindClass('com.tencent.assistant.utils.MemoryUtils')
    return MemoryUtils:formatSize(byteNum)
end

function formatMBSize(byteNum)
    return tostring(math.floor(byteNum/MB_UNIT + 0.5))
end

function resolveText(content)
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        return dialogSelf:resolveText(content)
    end
    return content
end

function clickNegativeFeedback()
    -- 点击负反馈
    if isNegativeFeedbackSelected == 1 then
        isNegativeFeedbackSelected = 0
        Rapid:getChild('iv_negative_feedback'):setAttr('gifurl', 'https://cms.myapp.com/yyb-img-75056/2020/05/13/1589373567833_c087074c1f95cbb0cc7d74f510d8feda47723077.png')
    else
        isNegativeFeedbackSelected = 1
        Rapid:getChild('iv_negative_feedback'):setAttr('gifurl', 'https://cms.myapp.com/yyb-img-75056/2020/05/13/1589373499607_299db5d050c8e64fd81a05cfbdfba0bfe7eb2fb2.png')
    end
end

function clickOutside()
    local enable_click_outside = Rapid:getData('enable_click_outside', '0')
    if enable_click_outside == '0' then
        return
    end
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        -- 点击弹窗外取消类型为6
        dialogSelf:dismiss(6, 0)
    end
end

function clickLeftButton()
    local left_button_action = Rapid:getData('left_button_action')
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:executeClickAction(left_button_action)
    end
end

function clickRightButton()
    -- 点击上报
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:data@page_source_scene,sourceSceneSlotId:data@page_source_slot,slotid:99_001,actionid:200,subposition:001,modeltype:data@modeltype"
    params1["extendparam"] = "report_element:pop,uni_popid:data@uni_popid,uni_pop_type:data@uni_pop_type,uni_pop_configid:data@uni_pop_configid,uni_monitor_event_code:data@uni_monitor_event_code,uni_trash_size:data@uni_trash_size,"..getReportContext()
    params1["recommendid"] = "data@R1"
    actionRunner:run("reportaction", params1, nil)
    -- 点击跳转
    local right_button_action = Rapid:getData('right_button_action')
    local dialogSelf = Rapid:getData("self")
    if dialogSelf ~= nil then
        dialogSelf:executeClickAction(right_button_action)
        -- 跳转取消类型为5
        dialogSelf:dismiss(5, 0)
    end
end

function onPageIn()
    local uni_pop_type = Rapid:getData('uni_pop_type')
    if uni_pop_type == POP_TYPE_PERMISSION_GUIDE then
        return
    end
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:data@page_source_scene,sourceSceneSlotId:data@page_source_slot,slotid:-1_-1,actionid:100,subposition:-1,modeltype:-1"
    params1["extendparam"] = "report_element:page,time_delayed:data@time_delayed"
    actionRunner:run("reportaction", params1, nil)
end

function onPageOut(stayDuration)
    local uni_pop_type = Rapid:getData('uni_pop_type')
    if uni_pop_type == POP_TYPE_PERMISSION_GUIDE then
        return
    end
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:data@page_source_scene,sourceSceneSlotId:data@page_source_slot,slotid:-1_-1,actionid:2005,subposition:-1,modeltype:-1"
    params1["extendparam"] = "report_element:page,stay_duration:"..stayDuration
    actionRunner:run("reportaction", params1, nil)
end

function onVisibileExposure()
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:data@page_source_scene,sourceSceneSlotId:data@page_source_slot,slotid:99_001,actionid:100,subposition:001,modeltype:data@modeltype"
    params1["extendparam"] = "report_element:pop,uni_popid:data@uni_popid,uni_pop_type:data@uni_pop_type,uni_pop_configid:data@uni_pop_configid,uni_monitor_event_code:data@uni_monitor_event_code,uni_trash_size:data@uni_trash_size,"..getReportContext()
    params1["recommendid"] = "data@R1"
    actionRunner:run("reportaction", params1, nil)
end

function onDismiss(dismissType)
    local actionRunner = mPhotonView:getParser():getTaskCenter():getActionRunner()
    local params1 = {}
    params1["param"] = "scene:data@uni_pop_scene,sourcescene:data@page_source_scene,sourceSceneSlotId:data@page_source_slot,slotid:99_001,actionid:201,subposition:001,modeltype:data@modeltype"
    params1["extendparam"] = "report_element:pop,uni_popid:data@uni_popid,uni_pop_type:data@uni_pop_type,uni_pop_configid:data@uni_pop_configid,uni_monitor_event_code:data@uni_monitor_event_code,uni_show_type:data@uni_show_type,uni_trash_size:data@uni_trash_size,uni_cancel_type:"..dismissType..",uni_check_status:"..tostring(isNegativeFeedbackSelected)..","..getReportContext()
    params1["recommendid"] = "data@R1"
    actionRunner:run("reportaction", params1, nil)
end

-- 返回弹窗上报需要携带的特殊上下文组合
function getReportContext()
    return Rapid:getData('report_context', '')
end