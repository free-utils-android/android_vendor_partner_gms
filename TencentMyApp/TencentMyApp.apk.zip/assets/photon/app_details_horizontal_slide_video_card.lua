local mPhotonView, mJavaBridge = ...

local mRecycleView = nil
local mSlotId
local mDataCount
local mScene
local mSourceScene
local mSourceSceneSlotId
local mModeltype
local mSourceModelType

function init()
    mRecycleView = mPhotonView:getParser():getChildView('video_recycler_view')
    mPhotonView:getParser():getBinder():update('shouldResetScrollCheck', '0')
    mRecycleView:getView():setClipToPadding(false)
end
PhotonActionListener = {}
function PhotonActionListener.notify(key, value)
    if key == 'item_video_play_error' then
        onItemVideoPlayError(value)
    end
end
function onItemVideoPlayError(errorCode)
    if errorCode == nil then
        return
    end
    local code = tonumber(errorCode)
    if code >= 1300061 and code <= 1300068 then
        mPhotonView:getParser():getBinder():update('shouldResetScrollCheck', '0')
        Rapid:getChild('title_layout'):setAttr('scrollexposure', 'false')
    else
        mPhotonView:getParser():getBinder():update('shouldResetScrollCheck', '1')
        Rapid:getChild('title_layout'):setAttr('scrollexposure', 'true')
    end
end

function fillValue()
    local subViewName = 'app_details_horizontal_video_item.xml'
    local dataCountStr = Rapid:getData('item_count')
    mDataCount = tonumber(dataCountStr)
    if mDataCount <= 0 then
        return
    end

    mScene = mPhotonView:getParser():getBinder():get('scene')
    mSourceScene = mPhotonView:getParser():getBinder():get('sourcescene')
    mSourceSceneSlotId = mPhotonView:getParser():getBinder():get('sourcesceneslotid')
    mModeltype = mPhotonView:getParser():getBinder():get('modeltype')
    mSourceModelType = mPhotonView:getParser():getBinder():get('sourcemodeltype')
    local slotIdData = mPhotonView:getParser():getBinder():get('slotid')
    if slotIdData ~= nil and slotIdData ~= '' then
        mSlotId = slotIdData
    else
        mSlotId = '99'
    end

    local dataList = {}
    local viewNameList = {}

    for i = 1, mDataCount do
        local itemData = mPhotonView:getParser():getBinder():get('item_data_' .. i)
        if (itemData ~= nil) then
            itemData:put('scene', mJavaBridge:create('var', mScene))
            itemData:put('sourceScene', mJavaBridge:create('var', mSourceScene))
            itemData:put('modelType', mJavaBridge:create('var', mModeltype))
            itemData:put('slotId', mJavaBridge:create('var', mSlotId))
            itemData:put('subPosition', mJavaBridge:create('var', '' .. i))
            itemData:put('sourceSceneSlotId', mJavaBridge:create('var', mSourceSceneSlotId))
            itemData:put('sourceModelType', mJavaBridge:create('var', mSourceModelType))

            itemData:put('sourcescene', mJavaBridge:create('var', mSourceScene))
            itemData:put('modeltype', mJavaBridge:create('var', mModeltype))
            itemData:put('slotid', mJavaBridge:create('var', mSlotId))
            itemData:put('subposition', mJavaBridge:create('var', '' .. i))
            itemData:put('sourcesceneslotid', mJavaBridge:create('var', mSourceSceneSlotId))
            itemData:put('sourcemodeltype', mJavaBridge:create('var', mSourceModelType))

            dataList[i] = itemData
            viewNameList[i] = subViewName
        end
    end
    mRecycleView:getView():clear()
    local recyclerActionListener =
        luajava.createProxy('com.tencent.rapidview.deobfuscated.IPhotonActionListener', PhotonActionListener)
    mRecycleView:getView():setActionListener(recyclerActionListener)
    mRecycleView:getView():updateData(viewNameList, dataList)
end

function reportTwoVideo()
    if mDataCount <= 0 then
        return
    end
    if mDataCount >= 1 then
        local itemData = mPhotonView:getParser():getBinder():get('item_data_' .. 1)
        reportItemExposure(itemData, '1')
    end
    if mDataCount >= 2 then
        local itemData = mPhotonView:getParser():getBinder():get('item_data_' .. 2)
        reportItemExposure(itemData, '2')
    end
end

function reportItemExposure(itemData, subPosition)
    local videoId = itemData:get('vid')
    local videoRecommendId = itemData:get('video_recommendid')
    local videoReportContext = itemData:get('video_report_context')

    mPhotonView:getParser():getBinder():update('my_report_item_data_' .. subPosition .. 'vid', videoId:getLuaValue())
    mPhotonView:getParser():getBinder():update(
        'my_report_item_data_' .. subPosition .. 'video_recommendid',
        videoRecommendId:getLuaValue()
    )
    mPhotonView:getParser():getBinder():update(
        'my_report_item_data_' .. subPosition .. 'video_report_context',
        videoReportContext:getLuaValue()
    )
    local slotNewId = mSlotId .. '_-1'
    local data = {}
    data['param'] =
        'slotid:' ..
        slotNewId ..
            ',actionid:100,subposition:' ..
                subPosition ..
                    ',scene:data@scene,sourcescene:data@sourcescene,sourcesceneslotid:data@sourcesceneslotid,searchid:0,status:-1'
    data['recommendid'] = 'data@my_report_item_data_' .. subPosition .. 'video_recommendid'
    data['extendparam'] =
        'report_context:data@my_report_item_data_' ..
        subPosition ..
            'video_report_context' ..
                ',videoid:data@my_report_item_data_' .. subPosition .. 'vid' .. ',report_element:video'
    mPhotonView:getParser():getTaskCenter():getActionRunner():run('reportaction', data, data)
end

function onCardShow()
    mPhotonView:getParser():getBinder():update('shouldResetScrollCheck', '1')
    mPhotonView:getParser():getChildView('title_layout'):getParser():update('scrollexposure', 'true')
end
