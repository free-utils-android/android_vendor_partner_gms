local mPhotonView, mJavaBridge = ...

local mRecyclerView = nil
local OnFixCenterListener = {}
local OnFocusChangeListener = {}

local mScrollView = nil

local mScene = nil
local mSourcescene = nil
local mModeltype = nil
local mSourceslotid = nil
local mSlotid = nil
local isRegister = nil
local isAuthorized = nil

local TAG = "endgames_label_tag"

function init( ... )
    mRecyclerView = Rapid:getChild("recyclerview"):getView()
    initListener()
end

function initListener( ... )
    mScrollView = Rapid:getChild("scrollview"):getView()

    local onFixCenterListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IFocusRecyclerView$OnFixCenterListener", OnFixCenterListener)
    mRecyclerView:setOnFixCenterListener(onFixCenterListener)
    local onFocusChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.IFocusRecyclerView$OnFocusChangeListener", OnFocusChangeListener)
    mRecyclerView:setOnFocusChangeListener(onFocusChangeListener)

    mRecyclerView:setActionListener(mPhotonView:getParser():getListener())
end

function refreshLabel( ... )
    mJavaBridge:Log(TAG, "refreshLabel")
    local heroId = mJavaBridge:getMemoryCache("endgames_hero_id")
    if heroId == nil then
        mJavaBridge:Log(TAG, "refreshLabel heroId is nil, reset -1")
        heroId = "-1"
    end
    local params = {}
    params["type"] = "labels_with_endgames"
    params["hero_id"] = heroId
    local cmdId = 3003
    mJavaBridge:requestWithSeq(cmdId, params, onRequestListener)
    mJavaBridge:Log(TAG, "refreshLabel send request heroId:"..heroId)
end

function onRequestListener(succeed, viewNameList, dataList)
    mJavaBridge:Log(
        TAG,
        "succeed" ..
            tostring(succeed) .. "viewNameList " .. tostring(viewNameList) .. " dataList " .. tostring(dataList)
    )

    if succeed then
        local itemNum = dataList:size()
        if itemNum == 0 then
            mJavaBridge:Log(TAG, "refreshLabel onSuccess, but error itemNum == 0")
            return
        end
        local finalDataList = {}
        local finalViewNameList = {}
        local data = dataList:get(0)
        local labelNum = tonumber(tostring(data:get("item_num")))
        for i = 1, labelNum do
            local itemData = data:get("item_data_"..i):getLuaValue()
            fillItemData(itemData, i, labelNum)
            finalDataList[i] = itemData
            finalViewNameList[i] = "endgames_label_sliding_card_item.xml"
        end
    
        mRecyclerView:removeAllViews()
        mRecyclerView:setInitFocusPosition(0)
        mRecyclerView:updateData(finalViewNameList, finalDataList, true)

        mJavaBridge:Log(TAG, "refreshLabel updateList success")
    end
    local runnable = luajava.createProxy("java.lang.Runnable", Runnable)
    mRecyclerView:post(runnable)
end

Runnable = {}
function Runnable.run(...)
    local targetView = mRecyclerView:getLayoutManager():findViewByPosition(0)
    if targetView ~= nil then
        mScrollView:smoothScrollTo(targetView:getLeft(), 0)
    end
end

function showNoChallengePage( ... )
    reportNoChallenge(100, "imp")
    noChallenge:setAttr("visibility","visible")
    Rapid:getChild("recyclerview"):setAttr("visibility","gone")
end

function afterUpdateData( ... )
    mScene = Rapid:getData("scene")
    mSourcescene = Rapid:getData("sourcescene")
    mModeltype = Rapid:getData("modeltype")
    mSourceslotid = Rapid:getData("sourcesceneslotid")
    mSlotid = Rapid:getData("slotid")
    isRegister = Rapid:getData("is_register")
    isAuthorized = Rapid:getData("is_authorized")

    updateAppList()
end

function updateAppList()
    local dataList = {}
    local viewNameList = {}

    local itemCount = tonumber(tostring(Rapid:getData("item_num", "0")))
    for i = 1, itemCount do
        local itemData = Rapid:getData("item_data_" .. i)
        fillItemData(itemData, i, itemCount)
        dataList[i] = itemData
        viewNameList[i] = "endgames_label_sliding_card_item.xml"
    end

    mRecyclerView:removeAllViews()
    mRecyclerView:setInitFocusPosition(0)
    mRecyclerView:updateData(viewNameList, dataList, true)
end

function fillItemData(itemData, index, itemCount)
    if itemData == nil then
        return
    end
    putBaseReportText(itemData)
    if tostring(itemData:get("label_id")) == "-1" then
        itemData:put("padding", mJavaBridge:create("Var", "8,0,8,0"))
    else
        itemData:put("padding", mJavaBridge:create("Var", "12,0,12,0"))
    end
    itemData:put("subposition", mJavaBridge:create("Var", index))
    if index == 1 then
        itemData:put("marginleft", mJavaBridge:create("Var", 16))
    else
        itemData:put("marginleft", mJavaBridge:create("Var", 8))
    end
    if index == itemCount then
        itemData:put("marginright", mJavaBridge:create("Var", 16))
    else
        itemData:put("marginright", mJavaBridge:create("Var", 0))
    end
end

function putBaseReportText(itemData)
    if itemData == nil then
        return
    end

    if mScene ~= nil then
        itemData:put("scene", mJavaBridge:create("Var", mScene))
    end
    
    if mSourcescene ~= nil then
        itemData:put("sourcescene", mJavaBridge:create("Var", mSourcescene))
    end
    
    if mModeltype ~= nil then
        itemData:put("modeltype", mJavaBridge:create("Var", mModeltype))
    end
    
    if mSourceslotid ~= nil then
        itemData:put("sourcesceneslotid", mJavaBridge:create("Var", mSourceslotid))
    end
    
    itemData:put("slotid", mJavaBridge:create("Var", "99_-1"))

    if isRegister ~= nil then
        itemData:put("is_register", mJavaBridge:create("Var", isRegister))
    end

    if isAuthorized ~= nil then
        itemData:put("is_authorized", mJavaBridge:create("Var", isAuthorized))
    end
end

function OnFixCenterListener.onScrollToCenter( position )
    return false
end

function OnFocusChangeListener.onFocusGet( rapidView , isFromBindViewHolder)
    rapidView:getParser():getBinder():update("isFromBindViewHolder", isFromBindViewHolder)
    rapidView:getParser():run("select")
end

function OnFocusChangeListener.onFocusLose( rapidView )
    rapidView:getParser():run("unselect")
end