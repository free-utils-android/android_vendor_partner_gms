local mRapidView, mJavaBridge = ...

local TAG = "playing_video_card_more"
local DEBUG = true
-- 必须定义成全局变量，否则会监听不到视频的状态
local stateChangeListener
local videoView
local position = 0
local playing = false
local isPausePlaying = false

--load的时候运行
function loadFinish()
    printf(TAG .. " loadFinish")
end

function init()
    printf("init")
end

--数据更新后，卡片入口主方法
function main()
    printf("update main")
    local index = Rapid:getData("index", "0")
    position = index + 1
    initVideo()
end

IPlayerStateChangeListener = {}
function IPlayerStateChangeListener.onPureClick(videoView)
    -- 视频处于全屏模式及初始态时不管理光子卡按钮的显示状态
    printf("onPureClick")
end

-- 视频开始播放回调
function IPlayerStateChangeListener.onPlayStart()
    printf("onPlayStart")
    playing = true
    showControlView()
end

function IPlayerStateChangeListener.onPlayContinue()
    playing = true
    printf("onPlayContinue")
end

function IPlayerStateChangeListener.onPlayStop()
    playing = false
    printf("onPlayStop")
end

function IPlayerStateChangeListener.onPlayComplete(videoView)
    playing = false
    printf("onPlayComplete")
end

function IPlayerStateChangeListener.onPlayPause()
    playing = false
    printf("onPlayPause")
end
function initVideo()
    stateChangeListener = luajava.createProxy(
        "com.tencent.rapidview.deobfuscated.control.video_component.IPlayerStateChangeListener",
        IPlayerStateChangeListener)
    local visibleAreaRatioChangeListener = luajava.createProxy("com.tencent.rapidview.deobfuscated.control.video_component.IPlayerVisibleAreaRatioChangeListener", 
            IPlayerVisibleAreaRatioChangeListener)
    videoView = Rapid:getChild("video_view")
    videoView:getView():registerIPlayerStateChangeListener(stateChangeListener)
    videoView:getView():setPlayerVisibleAreaChangeListener(visibleAreaRatioChangeListener)
    dismissControlView()
end

function dismissControlView()
    videoView:getView():setShowSmallPlayButton(false, true)
    videoView:getView():setIsShowMuteView(false, true)
    videoView:getView():setIsShowProgressBar(false, true)
    videoView:getView():setIsShowTextProgressLayout(false, true)
    videoView:getView():setIsShowFullScreenView(false, true)
end

function showControlView()
    videoView:getView():setShowSmallPlayButton(true, true)
    videoView:getView():setIsShowMuteView(true, true)
    videoView:getView():setIsShowProgressBar(true, true)
    videoView:getView():setIsShowTextProgressLayout(true, true)
    videoView:getView():setIsShowFullScreenView(true, true)
end

-- 视频可见区域回调
IPlayerVisibleAreaRatioChangeListener = {}
function IPlayerVisibleAreaRatioChangeListener.onVisibleAreaRatioChange(visibleAreaRatio)
    printf("onVisibleAreaRatioChange")
    -- 上滑至移出屏幕时暂停
    if visibleAreaRatio <= 0 then 
        videoView:getView():pause(true, 3)

    -- 播放未完成，滑回来时要续播                                        
    elseif videoView:getView():isStopped() == false and visibleAreaRatio > 0 and videoView:getView():canPlayCurrentNetworkEnvironment() then
        videoView:getView():tryContinueOrRestartPlay(true)
    end

    return true
end

function onPause()
    videoView:getView():stop(false)
end

function printf(str)
    if DEBUG then
        print(TAG .. " " .. tostring(str))
    end
end