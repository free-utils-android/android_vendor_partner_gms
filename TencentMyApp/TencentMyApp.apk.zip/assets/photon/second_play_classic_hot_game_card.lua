local mPhotonView,mJavaBridge = ...

local mAppRecyclerView = nil

function main()
    mAppRecyclerView = Rapid:getChild("rv_app")

    mAppRecyclerView:getView():setClipToPadding(false)
    mAppRecyclerView:getView():setClipChildren(false)
end

function updateData( )
    local itemCount = tonumber(Rapid:getData("game_count","0"))

    local dataList = {}
    local viewNameList = {}
    local subViewName = "second_play_classic_hot_game_card_item.xml"

    for i = 1, itemCount do
        local itemData = Rapid:getData("item_data_" .. i)
        if itemData == nil then
            break
        end
        itemData:put("modeltype", mJavaBridge:create("Var", Rapid:getData("modeltype")))
        itemData:put("slotid", mJavaBridge:create("Var", Rapid:getData("slotid")))
        itemData:put("subposition", mJavaBridge:create("Var", i))
        itemData:put("sourcemodeltype", mJavaBridge:create("Var", Rapid:getData("sourcemodeltype")))
        itemData:put("sourcescene", mJavaBridge:create("Var", Rapid:getData("sourcescene")))
        itemData:put("sourcesceneslotid", mJavaBridge:create("Var", Rapid:getData("sourcesceneslotid")))
        itemData:put("scene", mJavaBridge:create("Var", Rapid:getData("scene")))
        dataList[i] = itemData
        viewNameList[i] = subViewName
    end
    mAppRecyclerView:getView():clear()
    mAppRecyclerView:getView():updateData(viewNameList, dataList, false)
    mAppRecyclerView:getView():scrollToPosition(0)
end