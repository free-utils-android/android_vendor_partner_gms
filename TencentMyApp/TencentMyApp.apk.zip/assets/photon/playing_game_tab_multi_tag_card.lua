local mRapidView, mJavaBridge = ...

local TAG = "playing_game_tab_multi_tag"
local DEBUG = true
local MAX_ITEM = 9
local mScreenWidth = nil
local mTotalItem = 0
local DEBUG = true
-- local ACTIONID_TEMPLATE = "actionid:%s"
-- local SUB_POSITION = "subposition:%s"
-- local REPORT_ELEMENT = "report_element:%s"
-- local CONTEXT_FORMAT = "report_context:data@report_context"
-- local NAME_TAG_FORMAT = "tab_name:%s"

--load的时候运行
function loadFinish()
    local width = tonumber(mRapidView:getParser():getScreenWidth())
    mScreenWidth = mJavaBridge:px2dip(tonumber(width))
    printf("loadFinish mScreenWidth:" .. tostring(mScreenWidth))
end

function init()

end

--数据更新后，卡片入口主方法
function main()
   
    mTotalItem = tonumber(Rapid:getData("item_num"))
    printf("update main mTotalItem: ".. tostring(mTotalItem))

    if mTotalItem > tonumber(MAX_ITEM) then
        mTotalItem = tonumber(MAX_ITEM) -- 最多支持9个
    end
    printf("item_num:" .. tostring(mTotalItem))
    refreshData()
    dismissItem()
    updateVisibility()

end

function refreshData()
    for i=1, mTotalItem do
        local itemData = mRapidView:getParser():getBinder():get("item_data_" .. i)
        if itemData == nil then
            return
        end

        local name = itemData:get('name')
        local jump_url = itemData:get('jump_url')
        printf("name:" .. tostring(name) .. " jump_url:" .. tostring(jump_url))

        local itemView = mRapidView:getParser():getChildView("item_"..i)
        local itemText = mRapidView:getParser():getChildView("iv_"..i)

        local marginTop = mJavaBridge:dip2px(4)
        local marginRight = mJavaBridge:dip2px(mScreenWidth*0.0222)
        printf("marginTop=" ..  tostring(marginRight) .." marginRight:" .. tostring(marginRight))
        itemView:getView():getLayoutParams():setMargins(0,0,marginRight,0)

        if name == nil then
            Rapid:setData('name_'..i, tostring(name))
            -- 如果对应item为空，把响应的item gone掉
            dismissView(itemView)
        end

        if name ~= nil then
            printf("set" .. " name_"..i .. " jump_url:" .. tostring(jump_url))
            Rapid:setData("name_"..i, tostring(name))
            itemText:getView():setText(tostring(name))
            -- reportAction(100, i, tostring(name))
        end 

        if jump_url ~= nil then
            Rapid:setData('jump_url_'..i, tostring(jump_url))
        end
    end
end

function dismissItem()
    local begin = mTotalItem + 1
    if begin > tonumber(MAX_ITEM) then
        return
    end
    for i = begin, tonumber(MAX_ITEM) do
        dismissItemView(i)
    end
end

-- 把这一行中没有消失的item给gone掉
function dismissItemView(index)
    local itemView = mRapidView:getParser():getChildView("item_"..index)
    if itemView == nil then
        return
    end
    dismissView(itemView)
end

function updateVisibility()
    updateline1Visibility()
    updateline2Visibility()
    updateline3Visibility()
end

function updateline1Visibility()
    local line1View = mRapidView:getParser():getChildView("line_1")

    local name1 = Rapid:getData("name_1")
    local name2 = Rapid:getData("name_2")
    local name3 = Rapid:getData("name_3")

    printf("name1:" .. tostring(name1))
    if isNameInValid(name1) and isNameInValid(name2) and isNameInValid(name3) then
        dismissView(line1View)
    end
end

function updateline2Visibility()
    local line2View = mRapidView:getParser():getChildView("line_2")

    local name4 = Rapid:getData("name_4")
    local name5 = Rapid:getData("name_5")
    local name6 = Rapid:getData("name_6")

    printf("name4:" .. tostring(name4))
    if isNameInValid(name4) and isNameInValid(name5) and isNameInValid(name6) then
        dismissView(line2View)
    end
end

function updateline3Visibility()
    local line3View = mRapidView:getParser():getChildView("line_3")

    local name7 = Rapid:getData("name_7")
    local name8 = Rapid:getData("name_8")
    local name9 = Rapid:getData("name_9")

    printf("name7:" .. tostring(name7))
    if isNameInValid(name7) and isNameInValid(name8) and isNameInValid(name8) then
        dismissView(line3View)
    end
end

function isNameInValid(name)
    return name == nil or name == ""
end

function dismissView(view)
    printf("dismissView1:")
    if view == nil then
        return    
    end
    printf("dismissView2:")
    view:getParser():update("visibility", "gone")
end

function showView()
    if view == nil then
        return    
    end
    view:getParser():update("visibility", "visible")
end

function printf(str)
    if DEBUG then
        print(TAG .. " " .. tostring(str))
    end
end